@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d 'Financeiro 404.lnk')); $s.TargetPath=(Join-Path (Get-Location) 'iniciar_windows.bat'); $s.WorkingDirectory=(Get-Location).Path; $s.WindowStyle=7; $s.Save()"
if errorlevel 1 (echo Nao foi possivel criar o atalho.) else (echo Atalho "Financeiro 404" criado na area de trabalho.)
pause
