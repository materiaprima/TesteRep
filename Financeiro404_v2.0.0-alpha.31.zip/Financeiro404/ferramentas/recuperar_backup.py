"""Recupera um backup do Financeiro 404 SEM o programa: só Python 3.10+ e o pacote `cryptography`.

Uso (no Prompt de Comando, na pasta onde está este arquivo):
    py -m pip install cryptography
    py recuperar_backup.py financeiro404_auto_2026-11-06.fin404
    py recuperar_backup.py financeiro404_auto_2026-11-06.fin404 meu_banco.sqlite3

Pede a senha do backup, decifra, confere se o banco está íntegro e grava o arquivo .sqlite3.
O arquivo gravado pode ser aberto por qualquer leitor de SQLite (ex.: DB Browser for SQLite) ou colocado em
`data/financeiro_v2.sqlite3` de uma instalação nova do Financeiro 404.

Formatos: FIN404ENC3 (backup automático: X25519 + HKDF-SHA256 + AES-256-GCM, chave privada cifrada pela senha),
FIN404ENC2 (backup manual: scrypt + AES-256-GCM) e FIN404ENC1 (versões antigas).
Este arquivo é independente do resto do programa de propósito: ele também é copiado para a pasta dos backups automáticos.
"""
import getpass
import sqlite3
import struct
import sys
import tempfile
from pathlib import Path


def _decifrar(blob, senha):
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    if blob.startswith(b'FIN404ENC3') and len(blob) > 15:
        from cryptography.hazmat.primitives import hashes
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
        versao, tam = struct.unpack('>BI', blob[10:15])
        if versao != 3 or tam > 4096 or len(blob) < 15 + tam + 44:
            raise ValueError('Cabeçalho do backup inválido.')
        privada_cifrada = blob[15:15 + tam]
        efemera = blob[15 + tam:15 + tam + 32]
        nonce = blob[15 + tam + 32:15 + tam + 44]
        cab = blob[:15 + tam + 44]
        privada = X25519PrivateKey.from_private_bytes(_decifrar(privada_cifrada, senha))
        compartilhado = privada.exchange(X25519PublicKey.from_public_bytes(efemera))
        chave = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'fin404-enc3').derive(compartilhado)
        try:
            return AESGCM(chave).decrypt(nonce, blob[len(cab):], cab)
        except Exception:
            raise ValueError('Arquivo de backup alterado ou corrompido.')
    if blob.startswith(b'FIN404ENC2') and len(blob) > 42:
        versao, log_n, r, p = struct.unpack('BBBB', blob[10:14])
        if versao != 2 or not 14 <= log_n <= 22 or r > 32 or p > 4:
            raise ValueError('Cabeçalho do backup inválido.')
        sal, nonce, cab = blob[14:30], blob[30:42], blob[:42]
        chave = Scrypt(salt=sal, length=32, n=2 ** log_n, r=r, p=p).derive(senha.encode('utf-8'))
        corpo, aad = blob[42:], cab
    elif blob.startswith(b'FIN404ENC1') and len(blob) > 38:
        sal, nonce = blob[10:26], blob[26:38]
        chave = Scrypt(salt=sal, length=32, n=2 ** 15, r=8, p=1).derive(senha.encode('utf-8'))
        corpo, aad = blob[38:], b'FIN404ENC1'
    else:
        raise ValueError('Este arquivo não é um backup do Financeiro 404.')
    try:
        return AESGCM(chave).decrypt(nonce, corpo, aad)
    except Exception:
        raise ValueError('Senha incorreta ou arquivo de backup alterado/corrompido.')


def recuperar(origem, destino, senha):
    dados = _decifrar(Path(origem).read_bytes(), senha)
    if not dados.startswith(b'SQLite format 3\x00'):
        raise ValueError('O conteúdo decifrado não é um banco SQLite.')
    with tempfile.TemporaryDirectory() as tmp:
        teste = Path(tmp) / 'teste.sqlite3'
        teste.write_bytes(dados)
        c = sqlite3.connect(teste)
        try:
            integridade = c.execute('PRAGMA integrity_check').fetchone()[0]
            n = c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0]
            ultima = c.execute('SELECT MAX(data) FROM transacoes').fetchone()[0]
        finally:
            c.close()
    if integridade != 'ok':
        raise ValueError(f'O banco decifrado está danificado: {integridade}')
    destino = Path(destino)
    if destino.exists():
        raise ValueError(f'{destino} já existe; escolha outro nome para não sobrescrever nada.')
    destino.write_bytes(dados)
    return n, ultima


def main(argv):
    if len(argv) < 2:
        print(__doc__)
        return 2
    origem = argv[1]
    destino = argv[2] if len(argv) > 2 else Path(origem).with_suffix('.sqlite3').name
    try:
        import cryptography  # noqa: F401
    except ImportError:
        print('Falta o pacote cryptography. Rode: py -m pip install cryptography')
        return 1
    senha = getpass.getpass('Senha do backup (não aparece ao digitar): ')
    try:
        n, ultima = recuperar(origem, destino, senha)
    except (ValueError, OSError) as exc:
        print(f'Não foi possível recuperar: {exc}')
        return 1
    print(f'Pronto: {destino} gravado. Banco íntegro, {n} lançamento(s), o mais recente em {ultima}.')
    print('Para usar no programa: feche o Financeiro 404 e coloque este arquivo em data\\financeiro_v2.sqlite3.')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv))
