"""Importa um catálogo de produtos (Open Food Facts / Beauty / Products Facts) para o Financeiro 404, lendo em fluxo.

Uso, na pasta do programa (com o Financeiro 404 fechado ou aberto):
    .venv\\Scripts\\python ferramentas\\importar_catalogo.py en.openfoodfacts.org.products.csv.gz --fonte off --pais brazil

O arquivo é baixado por você no site da base (seção "Data" / "Dados"); este programa não acessa a internet.
Licença dos dados: Open Database License (ODbL) — a atribuição fica registrada e aparece nas telas de preços.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fin404.dados import banco  # noqa: E402
from fin404.dominio import catalogo  # noqa: E402


def main(argv=None):
    ap = argparse.ArgumentParser(description='Importa catálogo de produtos por código de barras.')
    ap.add_argument('arquivo')
    ap.add_argument('--fonte', choices=sorted(catalogo.FONTES), default='off')
    ap.add_argument('--pais', default='brazil', help='filtro de país (vazio = todos)')
    ap.add_argument('--limite', type=int, default=None)
    a = ap.parse_args(argv)
    banco.migrar()
    with catalogo._linhas_de_arquivo(a.arquivo) as linhas, banco.transacao() as c:
        r = catalogo.importar(c, linhas, a.fonte, a.pais, a.limite)
    print(f'Pronto: {r["gravados"]} produto(s) gravados de {r["lidos"]} lidos ({r["ignorados"]} ignorados: outro país ou sem código).')
    return 0


if __name__ == '__main__':
    sys.exit(main())
