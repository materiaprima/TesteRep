"""Remove o PIN de acesso (para quem esqueceu). Feche o programa antes.

Uso: python ferramentas/remover_pin.py
Quem tem acesso aos arquivos do computador já poderia ler o banco; por isso esta ferramenta não pede senha.
O backup cifrado continua protegido pela senha dele, que é outra.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fin404.dados import banco, config  # noqa: E402

banco.migrar()
config.definir('pin', None)
print('PIN removido. Abra o Financeiro 404 e, se quiser, defina um novo em "Backup e segurança".')
