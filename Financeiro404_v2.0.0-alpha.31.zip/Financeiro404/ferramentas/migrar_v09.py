"""Migração pela linha de comando (alternativa à página "Trazer dados da versão anterior").

Uso:
  python ferramentas/migrar_v09.py CAMINHO/financeiro.sqlite3            -> só simula e mostra o relatório
  python ferramentas/migrar_v09.py CAMINHO/financeiro.sqlite3 --executar -> grava no banco novo (precisa estar vazio)
O arquivo antigo é aberto somente para leitura e nunca é alterado.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from fin404 import migracao_v09  # noqa: E402
from fin404.dinheiro import ErroValidacao, formatar  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('legado', type=Path)
    p.add_argument('--executar', action='store_true')
    a = p.parse_args()
    try:
        rel = migracao_v09.executar(a.legado) if a.executar else migracao_v09.simular(a.legado)
    except ErroValidacao as exc:
        sys.exit(f'Erro: {exc}')
    print('EXECUTADO' if a.executar else 'SIMULAÇÃO (nada gravado)')
    for k in ('contas', 'lancamentos', 'agendados', 'transferencias', 'pagamentos', 'estornos', 'saldos_iniciais', 'previsoes', 'orcamentos'):
        print(f'  {k:16s} {rel[k]}')
    print('\nMês        receitas antes / depois           despesas antes / depois')
    for x in rel['comparacao']:
        marca = 'ok' if x['receitas_antes'] == x['receitas_depois'] and x['despesas_antes'] == x['despesas_depois'] else 'DIFERENTE'
        print(f"  {x['mes']}  {formatar(x['receitas_antes']):>14} / {formatar(x['receitas_depois']):<14}  "
              f"{formatar(x['despesas_antes']):>14} / {formatar(x['despesas_depois']):<14} {marca}")
    for item in rel['revisar'] + rel['nao_migrado']:
        print('  revisar:', item)
    print('\nTotais conferem:', 'sim' if rel['totais_conferem'] else 'NÃO')


if __name__ == '__main__':
    main()
