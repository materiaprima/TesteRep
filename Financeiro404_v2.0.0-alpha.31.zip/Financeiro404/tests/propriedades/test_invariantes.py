"""Invariantes do livro-razão sob sequências aleatórias de operações (Hypothesis).

Um modelo independente, em Python puro, acompanha o que cada conta deveria ter.
Rodar mais exemplos: FIN404_EXEMPLOS=10000 pytest tests/propriedades
"""
import os
import re
import tempfile
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path

from hypothesis import HealthCheck, given, settings, strategies as st

from fin404.dinheiro import ErroValidacao, dividir
from fin404.dominio import cartoes, operacoes, razao, relatorios

EXEMPLOS = int(os.environ.get('FIN404_EXEMPLOS') or '300')   # variável vazia (comum no PowerShell) = padrão
BASE = date(2026, 1, 1)

valor = st.integers(min_value=1, max_value=5_000_000)
dia = st.integers(min_value=0, max_value=500)
op = st.one_of(
    st.tuples(st.just('despesa'), st.sampled_from(['corrente', 'dinheiro', 'cartao']), valor, st.integers(1, 12), dia),
    st.tuples(st.just('receita'), valor, dia),
    st.tuples(st.just('transf'), st.sampled_from(['corrente', 'poupanca', 'dinheiro']), st.sampled_from(['corrente', 'poupanca', 'dinheiro']), valor, dia),
    st.tuples(st.just('pagar'), valor, dia),
    st.tuples(st.just('estorno'), st.integers(0, 50), st.integers(1, 120), dia),
    st.tuples(st.just('excluir'), st.integers(0, 50)),
)


def _novo_banco(regra='proxima', deslocamentos=()):
    pasta = tempfile.mkdtemp(prefix='fin404-prop-')
    os.environ['FIN404_DATA'] = pasta
    from fin404.dados import banco
    banco.migrar()
    with banco.transacao() as c:
        ids = {n: razao.criar_conta(c, n, n if n != 'cartao' else 'cartao', dia_fechamento=7, dia_vencimento=15,
                                    regra_fechamento=regra)
               for n in ('corrente', 'poupanca', 'dinheiro', 'cartao')}
        # Datas reais de fechamento (como as que vêm da fatura do BB), deslocadas alguns dias do dia 7.
        for i, desloc in enumerate(deslocamentos):
            m = date(2026 + (i // 12), i % 12 + 1, 7) + timedelta(days=desloc)
            cartoes.registrar_fechamento(c, ids['cartao'], m, m + timedelta(days=8))
        ids['cat'] = c.execute("SELECT id FROM contas WHERE nome='Mercado'").fetchone()[0]
        ids['rec'] = c.execute("SELECT id FROM contas WHERE nome='Salário'").fetchone()[0]
    return banco, ids


@settings(max_examples=EXEMPLOS, deadline=None, suppress_health_check=[HealthCheck.too_slow])
@given(st.lists(op, min_size=1, max_size=25), st.sampled_from(['proxima', 'atual']),
       st.lists(st.integers(-6, 6), max_size=24))
def test_invariantes_do_razao(ops, regra, deslocamentos):
    banco, ids = _novo_banco(regra, deslocamentos)
    esperado = defaultdict(int)          # saldo contábil esperado por conta
    vivas = {}                           # transação -> lista de (conta, valor) do modelo
    despesas = []                        # transações de despesa (para estornar/excluir)
    estornado = defaultdict(int)
    estornos_de = defaultdict(list)
    valor_estorno = {}
    with banco.transacao() as c:
        for o in ops:
            if o[0] == 'despesa':
                _, conta, v, n, d = o
                n = n if conta == 'cartao' else 1
                if v < n:
                    continue
                tids = operacoes.despesa(c, BASE + timedelta(days=d), 'Compra', v, ids['cat'], ids[conta], parcelas=n)
                for tid, parte in zip(tids, dividir(v, n)):
                    vivas[tid] = [(ids['cat'], parte), (ids[conta], -parte)]
                    despesas.append(tid)
            elif o[0] == 'receita':
                _, v, d = o
                tid = operacoes.receita(c, BASE + timedelta(days=d), 'Salário', v, ids['rec'], ids['corrente'])
                vivas[tid] = [(ids['corrente'], v), (ids['rec'], -v)]
            elif o[0] == 'transf':
                _, a, b, v, d = o
                if a == b:
                    try:
                        operacoes.transferencia(c, BASE + timedelta(days=d), 'T', v, ids[a], ids[b])
                        raise AssertionError('transferência para a mesma conta foi aceita')
                    except ErroValidacao:
                        continue
                tid = operacoes.transferencia(c, BASE + timedelta(days=d), 'T', v, ids[a], ids[b])
                vivas[tid] = [(ids[b], v), (ids[a], -v)]
            elif o[0] == 'pagar':
                _, v, d = o
                tid = cartoes.pagar(c, ids['corrente'], ids['cartao'], v, BASE + timedelta(days=d))
                vivas[tid] = [(ids['cartao'], v), (ids['corrente'], -v)]
            elif o[0] == 'estorno':
                _, i, pct, d = o
                vivas_desp = [t for t in despesas if t in vivas]
                if not vivas_desp:
                    continue
                tid = vivas_desp[i % len(vivas_desp)]
                original = vivas[tid][0][1]
                v = max(1, original * pct // 100)
                if estornado[tid] + v > original:
                    try:
                        razao.estornar(c, tid, v, BASE + timedelta(days=d))
                        raise AssertionError('estorno acima da compra foi aceito')
                    except ErroValidacao:
                        continue
                eid = razao.estornar(c, tid, v, BASE + timedelta(days=d))
                valor_estorno[eid] = (tid, v)
                conta_pag = vivas[tid][1][0]
                vivas[eid] = [(conta_pag, v), (ids['cat'], -v)]
                estornado[tid] += v
                estornos_de[tid].append(eid)
            elif o[0] == 'excluir':
                if not vivas:
                    continue
                tid = sorted(vivas)[o[1] % len(vivas)]
                if estornos_de.get(tid) and any(e in vivas for e in estornos_de[tid]):
                    try:
                        razao.excluir(c, tid)
                        raise AssertionError('exclusão de compra com estorno foi aceita')
                    except ErroValidacao:
                        continue
                razao.excluir(c, tid)
                del vivas[tid]
                if tid in despesas:
                    despesas.remove(tid)
                if tid in valor_estorno:
                    orig, v = valor_estorno.pop(tid)
                    estornado[orig] -= v
        # Recalcula o esperado a partir do modelo.
        esperado.clear()
        for linhas in vivas.values():
            for conta, v in linhas:
                esperado[conta] += v
        # 0. IDs nunca reaproveitados após exclusão
        assert len(set(vivas)) == len(vivas)
        # 1. toda transação soma zero; nada órfão
        assert razao.verificar_tudo(c) == []
        assert c.execute('SELECT COALESCE(SUM(valor_centavos),0) FROM lancamentos').fetchone()[0] == 0
        # 2. saldos batem com o modelo independente
        for nome in ('corrente', 'poupanca', 'dinheiro', 'cartao', 'cat', 'rec'):
            assert razao.saldo(c, ids[nome]) == esperado[ids[nome]], nome
        # 3. relatórios: despesa e receita totais = só categorias (transferências e pagamentos nunca entram)
        anos = {r[0] for r in c.execute('SELECT DISTINCT substr(data,1,4) FROM transacoes')}
        total_desp = sum(relatorios.resumo_ano(c, int(a))['total_despesas'] for a in anos)
        total_rec = sum(relatorios.resumo_ano(c, int(a))['total_receitas'] for a in anos)
        assert total_desp == esperado[ids['cat']]
        assert total_rec == -esperado[ids['rec']]
        # 4. estorno nunca excede a compra
        for tid in despesas:
            if tid in vivas:
                assert razao.total_estornado(c, tid) <= vivas[tid][0][1]
        # 5. fatura = dívida do cartão na véspera do fechamento, para todo ciclo tocado
        k = cartoes.completo(c, ids['cartao'])
        for (d,) in c.execute('SELECT DISTINCT t.data FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id WHERE l.conta_id=?', (ids['cartao'],)).fetchall():
            f = cartoes.fechamento_da_compra(k, d)
            fat = cartoes.fatura(c, ids['cartao'], f)
            assert fat['inicio'] <= date.fromisoformat(d) < fat['fim']          # a compra está no ciclo da sua fatura
            assert fat['valor'] == -razao.saldo(c, ids['cartao'], fat['fim'] - timedelta(days=1))
            assert fat['valor'] == fat['saldo_anterior'] + fat['compras'] - fat['creditos']
            assert cartoes.fechamento_seguinte(k, cartoes.fechamento_anterior(k, f)) == f   # ciclos encadeados sem buraco


def test_nenhum_float_no_codigo_de_dinheiro():
    raiz = Path(__file__).resolve().parents[2] / 'fin404'
    for arquivo in raiz.rglob('*.py'):
        texto = arquivo.read_text(encoding='utf-8')
        assert not re.search(r'\bfloat\s*\(', texto), f'float() usado em {arquivo.name}'
        assert not re.search(r'/\s*100\b', texto), f'divisão por 100 (gera float) em {arquivo.name}'
