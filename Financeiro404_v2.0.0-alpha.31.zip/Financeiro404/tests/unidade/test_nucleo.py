"""Núcleo: dinheiro, razão, cartões e o mês típico da revisão (cenário S1 corrigido)."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao, centavos, data, dividir, percentual
from fin404.dominio import cartoes, operacoes, razao, relatorios


@pytest.mark.parametrize('texto,esperado', [
    ('1,00', 100), ('1.234,56', 123456), ('1234,56', 123456), ('1234.56', 123456), ('1234', 123400),
    ('R$ 12,30', 1230), ('0,01', 1), ('999.999.999,99', 99_999_999_999), ('1.234', 123400),
])
def test_centavos_validos(texto, esperado):
    assert centavos(texto) == esperado


@pytest.mark.parametrize('texto,esperado', [('-12,30', -1230), ('12,30-', -1230), ('12,30 D', -1230), ('12,30 C', 1230), ('(5,00)', -500)])
def test_centavos_com_sinal(texto, esperado):
    assert centavos(texto, permitir_negativo=True) == esperado


@pytest.mark.parametrize('texto', ['', 'abc', '1,999', '1.2.3', 'NaN', '1e5', '0', '-1', '12.345,6.7', 'Infinity'])
def test_centavos_invalidos(texto):
    with pytest.raises(ErroValidacao):
        centavos(texto)


def test_percentual_aceita_virgula_e_rejeita_nan():
    assert str(percentual('24,5')) == '24.5'
    for ruim in ('NaN', 'inf', '-1', 'abc'):
        with pytest.raises(ErroValidacao):
            percentual(ruim)


def test_datas():
    assert data('05/11/2026') == date(2026, 11, 5)
    assert data('2026-11-05') == date(2026, 11, 5)
    assert data('5/1/26') == date(2026, 1, 5)
    with pytest.raises(ErroValidacao):
        data('31/02/2026')


def test_dividir():
    assert dividir(10000, 3) == [3334, 3333, 3333]
    assert sum(dividir(1, 1)) == 1


def test_transacao_desequilibrada_recusada(banco, contas):
    with banco.transacao() as c:
        with pytest.raises(ErroValidacao):
            razao.registrar(c, '2026-11-01', 'x', 'despesa', [(contas['Mercado'], 100), (contas['corrente'], -99)])
        with pytest.raises(TypeError):
            razao.registrar(c, '2026-11-01', 'x', 'despesa', [(contas['Mercado'], 1.0), (contas['corrente'], -1.0)])
        with pytest.raises(ErroValidacao):  # receita não pode usar categoria de despesa
            razao.registrar(c, '2026-11-01', 'x', 'receita', [(contas['corrente'], 100), (contas['Mercado'], -100)])


def test_ciclo_do_cartao(banco, contas):
    with banco.conexao() as c:
        k = razao.conta(c, contas['cartao'])
    assert cartoes.fechamento_da_compra(k, date(2026, 11, 4)) == date(2026, 11, 5)
    assert cartoes.fechamento_da_compra(k, date(2026, 11, 5)) == date(2026, 12, 5)   # dia do fechamento -> próxima
    assert cartoes.vencimento(k, date(2026, 11, 5)) == date(2026, 11, 12)
    k2 = dict(k, dia_fechamento=28, dia_vencimento=5)
    assert cartoes.vencimento(k2, date(2026, 11, 28)) == date(2026, 12, 5)
    k3 = dict(k, dia_fechamento=31, dia_vencimento=10)
    assert cartoes.fechamento_da_compra(k3, date(2026, 2, 27)) == date(2026, 2, 28)


def test_parcelas_caem_em_faturas_consecutivas(banco, contas):
    with banco.transacao() as c:
        ids = operacoes.despesa(c, '2026-10-31', 'TV', 300000, contas['Casa nova'], contas['cartao'], parcelas=10)
        k = razao.conta(c, contas['cartao'])
        fechamentos = [cartoes.fechamento_da_compra(k, razao.transacao(c, i)['data']) for i in ids]
        valores = [razao.lancamentos_de(c, i)[0]['valor_centavos'] for i in ids]
    assert len(set(fechamentos)) == 10
    assert fechamentos[0] == date(2026, 11, 5) and fechamentos[-1] == date(2027, 8, 5)
    assert sum(valores) == 300000


def test_mes_tipico_sem_dupla_contagem(banco, contas):
    """Cenário S1 da revisão: na v0.9, receitas 16.000, despesas 3.200 e saldo 19.300. Real: 8.000, 1.500 e 11.300."""
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], '2026-10-31', 500000)
        operacoes.receita(c, '2026-11-05', 'Salário', 800000, contas['Salário'], contas['corrente'])
        operacoes.despesa(c, '2026-10-12', 'Mercado', 120000, contas['Mercado'], contas['cartao'])
        operacoes.despesa(c, '2026-10-20', 'Restaurante', 30000, contas['Restaurantes e delivery'], contas['cartao'])
        fat = cartoes.fatura(c, contas['cartao'], '2026-11-05', hoje='2026-11-06')
        assert fat['valor'] == 150000 and fat['situacao'] == 'fechada'
        cartoes.pagar(c, contas['corrente'], contas['cartao'], 150000, '2026-11-10')
        operacoes.transferencia(c, '2026-11-12', 'Pix poupança', 20000, contas['corrente'], contas['poupanca'])
        nov = relatorios.resumo_mes(c, '2026-11'); out = relatorios.resumo_mes(c, '2026-10')
        assert nov['total_receitas'] == 800000 and nov['total_despesas'] == 0
        assert out['total_despesas'] == 150000            # despesa no mês da compra, uma vez só
        assert razao.saldo(c, contas['corrente'], '2026-11-30') == 1130000
        fat = cartoes.fatura(c, contas['cartao'], '2026-11-05', hoje='2026-11-30')
        assert fat['situacao'] == 'paga' and fat['restante'] == 0
        assert razao.verificar_tudo(c) == []


def test_estorno_reduz_despesa_e_orcamento(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, '2026-11-02', 'Tênis', 40000, contas['Vestuário'], contas['cartao'])
        relatorios.definir_orcamento(c, '2026-11', contas['Vestuário'], 30000)
        razao.estornar(c, tid, 40000, '2026-11-08')
        assert relatorios.resumo_mes(c, '2026-11')['total_despesas'] == 0
        linha = next(r for r in relatorios.orcamento(c, '2026-11') if r['id'] == contas['Vestuário'])
        assert linha['gasto'] == 0
        with pytest.raises(ErroValidacao):
            razao.estornar(c, tid, 1, '2026-11-09')
        with pytest.raises(ErroValidacao):
            razao.excluir(c, tid)  # tem estorno


def test_mes_fechado_bloqueia_escrita(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, '2026-09-10', 'Feira', 5000, contas['Mercado'], contas['dinheiro'])
        c.execute("INSERT INTO meses_fechados(mes) VALUES('2026-09')")
    with banco.transacao() as c:
        with pytest.raises(ErroValidacao):
            operacoes.despesa(c, '2026-09-11', 'Feira', 5000, contas['Mercado'], contas['dinheiro'])
    with banco.transacao() as c:
        with pytest.raises(ErroValidacao):
            razao.excluir(c, tid)
    with banco.transacao() as c:
        with pytest.raises(ErroValidacao):
            razao.editar(c, tid, 'Feira', '2026-10-01')


def test_previsoes_idempotentes_e_sem_passado(banco, contas):
    with banco.transacao() as c:
        operacoes.criar_previsao(c, 'Aluguel', 200000, contas['corrente'], contas['Moradia'], 'saida', 5, '2026-01')
        n1 = operacoes.gerar_previsoes(c, '2027-12', hoje='2026-11-04')
        n2 = operacoes.gerar_previsoes(c, '2027-12', hoje='2026-11-04')
        vencidas = c.execute("SELECT COUNT(*) FROM transacoes WHERE status='agendada' AND data<'2026-11-04'").fetchone()[0]
    assert n1 == 14 and n2 == 0 and vencidas == 0


def test_fluxo_de_caixa_inclui_faturas(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], '2026-11-01', 100000)
        operacoes.despesa(c, '2026-11-10', 'Mercado', 80000, contas['Mercado'], contas['cartao'])
        operacoes.criar_previsao(c, 'Salário', 500000, contas['corrente'], contas['Salário'], 'entrada', 5, '2026-12')
        operacoes.gerar_previsoes(c, '2027-01', hoje='2026-11-15')
        f = relatorios.fluxo_caixa(c, 60, hoje='2026-11-15')
    descricoes = [l['descricao'] for l in f['linhas']]
    assert any('Fatura Cartão Inter' in d for d in descricoes)
    assert f['inicial'] == 100000
    assert f['final'] == 100000 - 80000 + 2 * 500000  # salários de 05/12 e 05/01


def test_ids_nao_sao_reaproveitados(banco, contas):
    """Encontrado pelo Hypothesis: sem AUTOINCREMENT, o SQLite reaproveitava o ID de uma transação excluída."""
    with banco.transacao() as c:
        [t1] = operacoes.despesa(c, '2026-11-01', 'A', 100, contas['Mercado'], contas['corrente'])
        razao.excluir(c, t1)
        t2 = operacoes.receita(c, '2026-11-01', 'B', 100, contas['Salário'], contas['corrente'])
    assert t2 != t1
