"""PIN, sessões, backup automático cifrado com chave pública e lixeira."""
import datetime
import os
import sqlite3
import time

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import operacoes, razao, relatorios
from fin404.seguranca import acesso, backup


@pytest.fixture(autouse=True)
def limpa_estado_acesso():
    acesso._sessoes.clear(); acesso._falhas.update(n=0, ate=0.0)
    yield
    acesso._sessoes.clear(); acesso._falhas.update(n=0, ate=0.0)


def test_pin_hash_sessao_e_bloqueio(banco):
    assert not acesso.pin_ativo()
    with pytest.raises(ErroValidacao):
        acesso.definir_pin('1111')
    acesso.definir_pin('482913', inatividade=10)
    assert acesso.pin_ativo()
    with banco.conexao() as c:
        guardado = c.execute("SELECT valor FROM configuracoes WHERE chave='pin'").fetchone()[0]
    assert '482913' not in guardado                                   # só o hash é guardado
    token = acesso.verificar_pin('482913')
    assert acesso.sessao_valida(token) and not acesso.sessao_valida('inventado')
    for _ in range(5):
        with pytest.raises(ErroValidacao, match='incorreto'):
            acesso.verificar_pin('000000')
    with pytest.raises(ErroValidacao, match='Aguarde'):
        acesso.verificar_pin('482913')                                # bloqueado mesmo com o PIN certo
    acesso._falhas['ate'] = 0.0
    assert acesso.verificar_pin('482913')


def test_sessao_expira_por_inatividade(banco, monkeypatch):
    acesso.definir_pin('482913', inatividade=5)
    token = acesso.verificar_pin('482913')
    agora = time.monotonic()
    monkeypatch.setattr(acesso.time, 'monotonic', lambda: agora + 5 * 60 + 1)
    assert not acesso.sessao_valida(token)


def test_backup_automatico_sem_senha_guardada(banco, contas, tmp_path):
    with banco.transacao() as c:
        operacoes.receita(c, '2026-11-05', 'Salário', 800000, contas['Salário'], contas['corrente'])
    destino = tmp_path / 'nuvem'
    destino.mkdir()
    st = backup.configurar_automatico('senha-do-backup-123', str(destino))
    assert not st['erro']
    arquivos = list(destino.glob('financeiro404_auto_*.fin404'))
    assert len(arquivos) == 1 and arquivos[0].read_bytes()[:10] == b'FIN404ENC3'
    with banco.conexao() as c:
        cfg = c.execute("SELECT valor FROM configuracoes WHERE chave='backup_auto'").fetchone()[0]
    assert 'senha-do-backup-123' not in cfg
    # Só abre com a senha.
    with pytest.raises(ErroValidacao):
        backup.decifrar(arquivos[0].read_bytes(), 'outra-senha-qualquer')
    dados = backup.decifrar(arquivos[0].read_bytes(), 'senha-do-backup-123')
    copia = tmp_path / 'r.sqlite3'; copia.write_bytes(dados)
    c2 = sqlite3.connect(copia)
    assert c2.execute("SELECT COUNT(*) FROM transacoes").fetchone()[0] == 1
    c2.close()
    # Restauração pela via normal aceita o formato automático.
    _, info = backup.preparar_restauracao(arquivos[0].read_bytes(), 'senha-do-backup-123')
    assert info['transacoes'] == 1
    # Retenção
    for i in range(40):
        (destino / f'financeiro404_auto_2025-01-{i % 28 + 1:02d}x{i}.fin404').write_bytes(b'x')
    backup.executar_automatico(forcar=True)
    assert len(list(destino.glob('financeiro404_auto_*.fin404'))) == 30


def test_backup_automatico_avisa_quando_a_pasta_some(banco, contas, tmp_path):
    destino = tmp_path / 'pendrive'; destino.mkdir()
    backup.configurar_automatico('senha-do-backup-123', str(destino))
    for f in destino.iterdir():
        f.unlink()
    destino.rmdir()
    st = backup.executar_automatico(forcar=True)
    assert st['erro']
    with banco.conexao() as c:
        operacoes  # noqa
        assert any('backup automático falhou' in t for _, t, _ in relatorios.alertas(c))
    with pytest.raises(ErroValidacao, match='não existe'):
        backup.configurar_automatico('senha-do-backup-123', str(tmp_path / 'inexistente'))
    with pytest.raises(ErroValidacao, match='caminho completo'):
        backup.configurar_automatico('senha-do-backup-123', 'pasta-relativa')


def test_lixeira_restaura_lancamento_excluido(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, '2026-11-02', 'Tênis', 40000, contas['Vestuário'], contas['cartao'])
        razao.excluir(c, tid)
        itens = razao.lixeira(c)
        assert [i['transacao']['descricao'] for i in itens] == ['Tênis']
        novo = razao.restaurar(c, itens[0]['auditoria_id'])
        assert novo != tid and razao.transacao(c, novo)['descricao'] == 'Tênis'
        assert razao.lixeira(c) == []
        with pytest.raises(ErroValidacao, match='já foi restaurado'):
            razao.restaurar(c, itens[0]['auditoria_id'])
        assert relatorios.resumo_mes(c, '2026-11')['total_despesas'] == 40000


def test_testar_backup_automatico(banco, contas, tmp_path):
    from fin404.dados import config
    from fin404.dominio import relatorios
    destino = tmp_path / 'nuvem'; destino.mkdir()
    with banco.transacao() as c:
        operacoes.despesa(c, datetime.date(2026, 9, 5), 'MERCADO', 1000, contas['Mercado'], contas['corrente'])
    backup.configurar_automatico('senha-do-backup-123', str(destino))
    with banco.conexao() as c:
        assert any('ainda não foi testado' in t for _, t, _ in relatorios.alertas(c))
    with pytest.raises(ErroValidacao, match='Senha incorreta'):
        backup.testar_automatico('senha-errada-123456')
    assert config.obter('backup_verificado') is None
    r = backup.testar_automatico('senha-do-backup-123')
    assert r['transacoes'] == 1 and r['arquivo'].startswith('financeiro404_auto_')
    with banco.conexao() as c:
        assert not any('testado' in t or 'teste do backup' in t for _, t, _ in relatorios.alertas(c))
        assert any('mais de 3 meses' in t for _, t, _ in relatorios.alertas(c, datetime.date.today() + datetime.timedelta(days=95)))
    # Arquivo adulterado: o teste falha e não grava sucesso
    arq = sorted(destino.glob('*.fin404'))[-1]
    dados = bytearray(arq.read_bytes()); dados[-5] ^= 1; arq.write_bytes(bytes(dados))
    with pytest.raises(ErroValidacao):
        backup.testar_automatico('senha-do-backup-123')


def test_recuperar_backup_sem_o_programa(banco, contas, tmp_path):
    """O script da pasta dos backups decifra ENC3 (automático) e ENC2 (manual) sem importar nada do fin404."""
    import importlib.util
    import subprocess
    import sys
    destino = tmp_path / 'nuvem'; destino.mkdir()
    with banco.transacao() as c:
        operacoes.despesa(c, datetime.date(2026, 9, 5), 'MERCADO', 1000, contas['Mercado'], contas['corrente'])
    backup.configurar_automatico('senha-do-backup-123', str(destino))
    assert (destino / 'LEIA-ME_RECUPERACAO.txt').is_file() and (destino / 'recuperar_backup.py').is_file()
    # Roda isolado (-I): sem o pacote fin404 no caminho
    codigo = ("import sys; sys.path.insert(0, sys.argv[1]); import recuperar_backup as r; "
              "print(r.recuperar(sys.argv[2], sys.argv[3], 'senha-do-backup-123'))")
    arq = sorted(destino.glob('*.fin404'))[-1]
    saida = subprocess.run([sys.executable, '-I', '-c', codigo, str(destino), str(arq), str(tmp_path / 'auto.sqlite3')],
                           capture_output=True, text=True, cwd=tmp_path)
    assert saida.returncode == 0, saida.stderr
    assert saida.stdout.strip().startswith('(1,')
    spec = importlib.util.spec_from_file_location('rb', destino / 'recuperar_backup.py')
    rb = importlib.util.module_from_spec(spec); spec.loader.exec_module(rb)
    nome, blob = backup.gerar('outra-senha-forte-1')
    (tmp_path / nome).write_bytes(blob)
    assert rb.recuperar(tmp_path / nome, tmp_path / 'manual.sqlite3', 'outra-senha-forte-1')[0] == 1
    with pytest.raises(ValueError, match='Senha incorreta'):
        rb.recuperar(tmp_path / nome, tmp_path / 'x.sqlite3', 'errada-errada-1')
    with pytest.raises(ValueError, match='já existe'):
        rb.recuperar(tmp_path / nome, tmp_path / 'manual.sqlite3', 'outra-senha-forte-1')


# ------------------------------------------------------------------ restauração (achado 1 do Kiro)

def _contar(banco):
    with banco.conexao() as c:
        return c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0]


def _backup_de_um_lancamento(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, datetime.date(2026, 9, 5), 'MERCADO', 1000, contas['Mercado'], contas['corrente'])
    _, blob = backup.gerar('senha-forte-123')
    caminho, _ = backup.preparar_restauracao(blob, 'senha-forte-123')
    with banco.transacao() as c:                                   # depois do backup, mais dois lançamentos
        operacoes.despesa(c, datetime.date(2026, 9, 6), 'PADARIA', 500, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, datetime.date(2026, 9, 7), 'FARMACIA', 700, contas['Mercado'], contas['corrente'])
    assert _contar(banco) == 3
    return caminho


def test_restauracao_troca_o_banco_e_guarda_o_anterior(banco, contas):
    caminho = _backup_de_um_lancamento(banco, contas)
    r = backup.ativar_restauracao(caminho)
    assert _contar(banco) == 1 and not banco._pausado.is_set()
    import sqlite3
    guarda = sqlite3.connect(r['copia_anterior'])
    assert guarda.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0] == 3
    guarda.close()
    assert not banco.caminho_banco().with_suffix('.restaurando').exists()


def test_restauracao_falha_na_troca_mantem_o_banco_e_os_extras(banco, contas, monkeypatch):
    """Windows: os.replace falha com o arquivo preso. O banco atual fica intacto e -wal/-shm voltam ao lugar."""
    caminho = _backup_de_um_lancamento(banco, contas)
    original = backup._substituir

    def troca(origem, destino, **kw):
        if str(origem).endswith('.restaurando'):
            raise PermissionError('arquivo em uso por outro processo')
        return original(origem, destino, **kw)
    monkeypatch.setattr(backup, '_substituir', troca)
    with pytest.raises(ErroValidacao, match='não liberou o arquivo'):
        backup.ativar_restauracao(caminho)
    assert not banco._pausado.is_set()
    assert not banco.caminho_banco().with_suffix('.restaurando').exists()
    assert _contar(banco) == 3
    with banco.conexao() as c:
        assert c.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'


def test_restauracao_reprovada_volta_ao_anterior(banco, contas, monkeypatch):
    caminho = _backup_de_um_lancamento(banco, contas)
    with monkeypatch.context() as m:
        m.setattr(banco, 'integridade', lambda: {'integridade': 'corrompido', 'transacoes_desequilibradas': []})
        with pytest.raises(ErroValidacao, match='não passou na verificação'):
            backup.ativar_restauracao(caminho)
    assert _contar(banco) == 3 and not banco._pausado.is_set()
    with banco.conexao() as c:
        assert c.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'


def test_restauracao_para_se_outro_programa_segura_o_wal(banco, contas):
    """Leitor externo (ex.: DB Browser) impede esvaziar o WAL: tirar o -wal do lugar perderia dados, então não troca."""
    import sqlite3
    caminho = _backup_de_um_lancamento(banco, contas)
    externo = sqlite3.connect(banco.caminho_banco())
    externo.execute('BEGIN')
    externo.execute('SELECT COUNT(*) FROM transacoes').fetchone()       # segura um instantâneo de leitura
    with banco.transacao() as c:                                         # e há páginas novas no WAL depois dele
        operacoes.despesa(c, datetime.date(2026, 9, 8), 'POSTO', 900, contas['Mercado'], contas['corrente'])
    try:
        with pytest.raises(ErroValidacao, match='Outro programa'):
            backup.ativar_restauracao(caminho)
    finally:
        externo.rollback()
        externo.close()
    assert _contar(banco) == 4 and not banco._pausado.is_set()


def test_substituir_tenta_de_novo_quando_o_windows_segura(monkeypatch, tmp_path):
    a, b = tmp_path / 'a', tmp_path / 'b'
    a.write_text('x')
    falhas = []
    real = os.replace

    def replace(o, d):
        if len(falhas) < 2:
            falhas.append(1)
            raise PermissionError('em uso')
        return real(o, d)
    monkeypatch.setattr(backup.os, 'replace', replace)
    monkeypatch.setattr(backup.time, 'sleep', lambda s: None)
    backup._substituir(a, b)
    assert b.read_text() == 'x' and len(falhas) == 2


def test_csv_neutraliza_formulas():
    from fin404.web.pg_lancamentos import texto_planilha
    assert texto_planilha('=HYPERLINK("http://x")') == '\'=HYPERLINK("http://x")'
    assert [texto_planilha(x) for x in ('+1', '-2', '@SOMA', '\tA', 'Mercado', None, '')] == ["'+1", "'-2", "'@SOMA", "'\tA", 'Mercado', '', '']


def test_ciclo_completo_em_pasta_com_acento_e_espaco(tmp_path, monkeypatch):
    """Windows real: "C:\\Users\\José\\Área de Trabalho". Criar, lançar, gerar backup e restaurar numa pasta assim."""
    pasta = tmp_path / 'Área de Trabalho' / 'Finanças da Família'
    pasta.mkdir(parents=True)
    monkeypatch.setenv('FIN404_DATA', str(pasta))
    from fin404.dados import banco as b
    b.migrar()
    with b.transacao() as c:
        cc = razao.criar_conta(c, 'Conta São João', 'corrente')
        cat = c.execute("SELECT id FROM contas WHERE nome='Mercado'").fetchone()[0]
        operacoes.despesa(c, datetime.date(2026, 9, 5), 'AÇOUGUE ÇÃO', 1000, cat, cc)
    _, blob = backup.gerar('senha-forte-123')
    caminho, info = backup.preparar_restauracao(blob, 'senha-forte-123')
    assert info['transacoes'] == 1 and 'Área de Trabalho' in str(caminho)
    with b.transacao() as c:
        operacoes.despesa(c, datetime.date(2026, 9, 6), 'PADARIA', 500, cat, cc)
    backup.ativar_restauracao(caminho)
    with b.conexao() as c:
        assert c.execute('SELECT descricao FROM transacoes').fetchall()[0][0] == 'AÇOUGUE ÇÃO'
        assert c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0] == 1
