"""Recursos de uso diário: alertas de vencimento e de backup, cópia automática, exportação."""
import datetime

import pytest

from fin404.dominio import operacoes, relatorios


def test_alerta_de_fatura_vencendo_e_de_backup(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, '2026-10-20', 'Mercado', 50000, contas['Mercado'], contas['cartao'])   # fatura fecha 05/11, vence 12/11
        textos = [t for _, t, _ in relatorios.alertas(c, hoje='2026-11-11')]
        assert any('vence amanhã' in t and 'R$ 500,00' in t for t in textos)
        assert any('Nenhum backup cifrado' in t for t in textos)
        tipos = {t: k for k, t, _ in relatorios.alertas(c, hoje='2026-11-08')}
        assert any('vence em 4 dias' in t and k == 'conferir' for t, k in tipos.items())
        banco.auditar(c, 'backup', 'banco', None, 'x')
        assert not any('backup' in t for _, t, _ in relatorios.alertas(c, hoje=datetime.date.today()))


def test_copia_diaria_guarda_as_ultimas(banco, contas):
    pasta = banco.pasta_dados() / 'copias'
    pasta.mkdir(parents=True, exist_ok=True)
    for i in range(20):
        (pasta / f'automatica_2026-01-{i + 1:02d}.sqlite3').write_bytes(b'x')
    feita = banco.copia_diaria(manter=14)
    restantes = sorted(pasta.glob('automatica_*.sqlite3'))
    assert feita in restantes and len(restantes) == 14
    assert banco.copia_diaria(manter=14) == feita          # uma por dia


def test_sem_extrato_diferenca_vira_gasto_nao_identificado(banco, contas):
    from fin404.dominio import razao
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], '2026-10-31', 500000)
        operacoes.receita(c, '2026-11-05', 'Salário', 800000, contas['Salário'], contas['corrente'])
        # No app do banco o saldo é 11.700: saíram 1.300 em Pix e débitos não lançados.
        tid = operacoes.lancar_diferenca(c, contas['corrente'], '2026-11-30', 1170000)
        assert razao.saldo(c, contas['corrente'], '2026-11-30') == 1170000
        nov = relatorios.resumo_mes(c, '2026-11')
        assert ('Gastos não identificados', 130000) in [(n, v) for _, n, v in nov['despesas']]
        assert razao.transacao(c, tid)['tipo'] == 'despesa'
        assert operacoes.lancar_diferenca(c, contas['corrente'], '2026-11-30', 1170000) is None   # já confere
        tid2 = operacoes.lancar_diferenca(c, contas['corrente'], '2026-12-01', 1180000)             # entrou 100 não lançado
        assert razao.transacao(c, tid2)['tipo'] == 'receita'


def test_confirmar_previsto_com_valor_e_data_reais(banco, contas):
    from fin404.dominio import razao
    with banco.transacao() as c:
        operacoes.criar_previsao(c, 'Conta de luz', 25000, contas['corrente'], contas['Moradia'], 'saida', 10, '2026-11')
        operacoes.gerar_previsoes(c, '2026-12', hoje='2026-11-01')
        tid = c.execute("SELECT id FROM transacoes WHERE descricao='Conta de luz' ORDER BY data LIMIT 1").fetchone()[0]
        operacoes.confirmar_previsto(c, tid, 27390, '2026-11-12')
        t = razao.transacao(c, tid)
        assert t['status'] == 'confirmada' and t['data'] == '2026-11-12'
        assert relatorios.resumo_mes(c, '2026-11')['total_despesas'] == 27390
        import pytest
        from fin404.dinheiro import ErroValidacao
        with pytest.raises(ErroValidacao):
            operacoes.confirmar_previsto(c, tid)


@pytest.mark.parametrize('pasta, esperado', [
    ('C:\\Users\\Jose\\OneDrive\\Área de Trabalho\\Financeiro404\\data', True),
    ('C:\\Users\\Jose\\OneDrive - Empresa\\Documentos\\Financeiro404\\data', True),
    ('G:\\Meu Drive\\Financeiro404\\data', True),
    ('C:\\Users\\Jose\\Dropbox\\fin\\data', True),
    ('C:\\Financeiro404\\data', False),
    ('C:\\Users\\Jose\\Documents\\Financeiro404\\data', False),
    ('/home/jose/financeiro/data', False),
])
def test_pasta_sincronizada(pasta, esperado):
    from fin404.dominio.relatorios import pasta_sincronizada
    assert pasta_sincronizada(pasta) is esperado


def test_pasta_sincronizada_onedrive_renomeado(monkeypatch):
    from fin404.dominio.relatorios import pasta_sincronizada
    monkeypatch.setenv('OneDriveCommercial', 'C:\\Users\\Jose\\Empresa SA')
    assert pasta_sincronizada('C:\\Users\\Jose\\Empresa SA\\Financeiro404\\data') is True
    assert pasta_sincronizada('C:\\Users\\Jose\\Empresa SA2\\data') is False
    assert pasta_sincronizada('C:\\Financeiro404\\data') is False


def test_nenhum_modulo_acessa_a_internet():
    """Premissa fundadora: 100% local. Só o servidor (que escuta em 127.0.0.1) pode usar rede; ninguém faz requisição."""
    import re
    from pathlib import Path
    raiz = Path(__file__).resolve().parents[2] / 'fin404'
    proibido = re.compile(r'^\s*(import|from)\s+(urllib\.request|http\.client|requests|httpx|aiohttp|ftplib|smtplib|socket)\b', re.M)
    culpados = [str(p.relative_to(raiz)) for p in raiz.rglob('*.py')
                if p.name != 'servidor.py' and proibido.search(p.read_text(encoding='utf-8'))]
    assert culpados == [], f'Acesso à rede fora do servidor: {culpados}'
