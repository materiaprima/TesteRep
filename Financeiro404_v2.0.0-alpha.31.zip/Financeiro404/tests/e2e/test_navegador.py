"""Ponta a ponta num navegador real (Chromium/Chrome/Edge via Playwright), com formulários de verdade.

Rodar:  pip install playwright pytest  (e, se preciso, `python -m playwright install chromium`)
        pytest tests/e2e
No Windows, para usar o Edge instalado: set FIN404_NAVEGADOR=msedge
"""
import os
import shutil
import socket
import subprocess
import sys
import time
from pathlib import Path

import pytest

playwright = pytest.importorskip('playwright.sync_api')

RAIZ = Path(__file__).resolve().parents[2]
FIX = RAIZ / 'tests' / 'fixtures'
SAIDA = Path(os.environ.get('FIN404_CAPTURAS', RAIZ / 'tests' / 'e2e' / 'capturas'))


def _porta_livre():
    s = socket.socket(); s.bind(('127.0.0.1', 0)); p = s.getsockname()[1]; s.close(); return p


@pytest.fixture(scope='module')
def app(tmp_path_factory):
    dados = tmp_path_factory.mktemp('dados')
    porta = _porta_livre()
    env = dict(os.environ, FIN404_DATA=str(dados), FIN404_PORTA=str(porta), FIN404_NAO_ABRIR='1')
    proc = subprocess.Popen([sys.executable, str(RAIZ / 'app.py')], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for _ in range(100):
        try:
            socket.create_connection(('127.0.0.1', porta), 0.2).close(); break
        except OSError:
            time.sleep(0.1)
    yield f'http://127.0.0.1:{porta}', dados
    proc.terminate(); proc.wait(10); proc.stdout.close()


@pytest.fixture(scope='module')
def pagina(app):
    with playwright.sync_playwright() as p:
        nav = os.environ.get('FIN404_NAVEGADOR', '')
        kw = {'args': ['--no-sandbox']}
        if nav in ('msedge', 'chrome'):
            kw['channel'] = nav
        elif nav:
            kw['executable_path'] = nav
        elif shutil.which('google-chrome'):
            kw['executable_path'] = shutil.which('google-chrome')
        navegador = p.chromium.launch(**kw)
        ctx = navegador.new_context(viewport={'width': 1366, 'height': 900}, accept_downloads=True)
        pg = ctx.new_page()
        pg.violacoes = []
        pg.on('console', lambda m: pg.violacoes.append(m.text) if 'Content Security Policy' in m.text else None)
        pg.on('response', lambda r: pg.violacoes.append(f'{r.status} {r.url}') if r.status >= 500 or r.status == 404 else None)
        pg.on('dialog', lambda d: (pg.violacoes.append('diálogo JS: ' + d.message), d.dismiss()))
        yield pg
        navegador.close()


def ok(pg, texto):
    """Confere a mensagem verde de sucesso e que não há página de erro."""
    assert pg.locator('.aviso.erro').count() == 0, pg.locator('main').inner_text()[:500]
    assert texto in pg.locator('.aviso.ok').inner_text(), pg.locator('main').inner_text()[:500]


def capturar(pg, nome):
    SAIDA.mkdir(parents=True, exist_ok=True)
    pg.screenshot(path=str(SAIDA / f'{nome}.png'), full_page=True)


def escolher(pg, seletor, rotulo):
    pg.select_option(seletor, label=rotulo)


def test_jornada_completa(app, pagina):
    base, dados = app
    pg = pagina
    pg.goto(base + '/')
    assert 'Primeiros passos' in pg.content()
    capturar(pg, '01_boas_vindas')

    # Pessoas
    for nome in ('Pessoa A', 'Pessoa B'):
        pg.goto(base + '/pessoas'); pg.fill('form[action="/pessoas"] input[name=nome]', nome); pg.click('form[action="/pessoas"] button')
        ok(pg, 'Pessoa adicionada')

    # Contas: corrente com saldo inicial, poupança e cartão
    def nova_conta(nome, tipo, saldo='', fecha='', vence='', limite=''):
        pg.goto(base + '/contas')
        f = 'form[action="/contas"]'
        pg.fill(f'{f} input[name=nome]', nome); escolher(pg, f'{f} select[name=subtipo]', tipo)
        if saldo:
            pg.fill(f'{f} input[name=saldo]', saldo); pg.fill(f'{f} input[name=data_saldo]', '2026-10-31')
        if fecha:
            pg.fill(f'{f} input[name=dia_fechamento]', fecha); pg.fill(f'{f} input[name=dia_vencimento]', vence)
        if limite:
            pg.fill(f'{f} input[name=limite]', limite)
        pg.click(f'{f} button'); ok(pg, 'Conta cadastrada')
    nova_conta('Conta BB', 'Conta corrente', '5.000,00')
    nova_conta('Poupança BB', 'Poupança')
    nova_conta('Cartão Inter', 'Cartão de crédito', fecha='5', vence='12', limite='10.000,00')
    capturar(pg, '02_contas')

    # Compras no cartão (uma à vista em outubro, uma parcelada) e uma despesa paga com a conta
    def despesa(desc, valor, data, cat, conta, parcelas='1', pessoa=None):
        pg.goto(base + '/novo?tipo=despesa')
        pg.fill('input[name=descricao]', desc); pg.fill('input[name=valor]', valor); pg.fill('input[name=data]', data)
        escolher(pg, 'select[name=categoria]', cat); escolher(pg, 'select[name=conta]', conta)
        pg.fill('input[name=parcelas]', parcelas)
        if pessoa:
            escolher(pg, 'select[name=pessoa]', pessoa)
        pg.select_option('select[name=status]', 'confirmada')
        pg.click('form[action="/novo"] button')
    despesa('Supermercado', '1.200,00', '2026-10-12', 'Mercado', 'Cartão Inter', pessoa='Pessoa A'); ok(pg, 'Despesa registrada')
    despesa('Restaurante', '300,00', '2026-10-20', 'Restaurantes e delivery', 'Cartão Inter', pessoa='Pessoa B'); ok(pg, 'Despesa registrada')
    despesa('TV sala', '3.000,00', '2026-10-31', 'Casa nova', 'Cartão Inter', parcelas='10'); ok(pg, '10 parcela')
    despesa('Tênis', '400,00', '2026-11-02', 'Vestuário', 'Cartão Inter'); ok(pg, 'Despesa registrada')
    # Salário lançado à mão (depois virá no extrato e deve ser casado, não duplicado)
    pg.goto(base + '/novo?tipo=receita')
    pg.fill('input[name=descricao]', 'Salário'); pg.fill('input[name=valor]', '8.000,00'); pg.fill('input[name=data]', '2026-11-05')
    escolher(pg, 'select[name=categoria]', 'Salário'); escolher(pg, 'select[name=conta]', 'Conta BB')
    pg.select_option('select[name=status]', 'confirmada')
    pg.click('form[action="/novo"] button'); ok(pg, 'Receita registrada')

    # Fatura que fecha em 05/11 (compras de 05/10 a 04/11):
    # mercado 1.200 + restaurante 300 + 1ª parcela da TV (31/10) 300 + tênis (02/11) 400 = 2.200
    pg.goto(base + '/cartoes')
    assert 'R$ 2.200,00' in pg.locator('main').inner_text()
    capturar(pg, '03_cartoes')

    # Importar o extrato OFX da conta e revisar
    pg.goto(base + '/importar')
    escolher(pg, 'select[name=conta]', 'Conta BB')
    pg.set_input_files('input[name=arquivo]', str(FIX / 'extrato_nov.ofx'))
    pg.click('form[action="/importar"] button')
    assert pg.locator('.aviso.erro').count() == 0, pg.locator('main').inner_text()[:500]
    assert 'Revisar importação' in pg.locator('h1').inner_text()
    linhas = pg.locator('tbody tr')
    assert linhas.count() == 6
    # salário: casado com o lançamento manual; fatura: reconhecida como pagamento
    assert 'Já lançado: Salário' in linhas.nth(0).locator('select option:checked').inner_text()
    assert 'Pagamento de Cartão Inter' in linhas.nth(1).locator('select option:checked').inner_text()
    linhas.nth(2).locator('select').select_option(label='Para Poupança BB')
    linhas.nth(3).locator('select').select_option(label='Moradia')
    linhas.nth(3).locator('input[type=checkbox]').check()
    linhas.nth(4).locator('select').select_option(label='Transporte')
    linhas.nth(5).locator('select').select_option(label='Transporte')
    capturar(pg, '04_revisao_importacao')
    pg.click('form[action^="/importacoes/"] button')
    ok(pg, 'Importação concluída')

    # Estorno do tênis
    pg.goto(base + '/lancamentos?mes=2026-11&busca=T%C3%AAnis')
    pg.click('table a:has-text("Tênis")')
    pg.fill('form[action$="/estornar"] input[name=valor]', '400,00'); pg.fill('form[action$="/estornar"] input[name=data]', '2026-11-08')
    pg.click('form[action$="/estornar"] button'); ok(pg, 'Estorno registrado')

    # Relatório de novembro: só despesas reais (água, Uber x2), sem pagamento de fatura, sem Pix, tênis estornado
    pg.goto(base + '/relatorios?mes=2026-11')
    texto = pg.locator('main').inner_text()
    assert 'R$ 8.000,00' in texto                       # receitas = 1 salário
    # água 89,90 + duas corridas 51,80 + 2ª parcela da TV (30/11) 300 = 441,70; tênis 400 − estorno 400 = 0
    assert 'R$ 441,70' in texto
    capturar(pg, '05_relatorio_mes')
    pg.goto(base + '/relatorios?mes=2026-10')
    assert 'R$ 1.800,00' in pg.locator('main').inner_text()   # mercado + restaurante + 1ª parcela TV

    # Conferência com o banco em 30/11: 5.000 + 8.000 − 1.500 − 200 − 89,90 − 51,80 = 11.158,30
    pg.goto(base + '/contas'); pg.click('table a:has-text("Conta BB")')
    f = 'form[action$="/conciliar"]'
    pg.fill(f'{f} input[name=data]', '2026-11-30'); pg.fill(f'{f} input[name=valor]', '11.158,30'); pg.click(f'{f} button')
    ok(pg, 'Confere')
    # O extrato pagou 1.500 da fatura de 2.200: falta 700, paga parcialmente.
    # O estorno do tênis (08/11, depois do fechamento) abate a fatura seguinte, como no banco.
    pg.goto(base + '/cartoes')
    texto = pg.locator('main').inner_text()
    assert 'paga parcialmente' in texto and 'R$ 700,00' in texto

    # Exportar para planilha
    with pg.expect_download() as dl:
        pg.goto(base + '/lancamentos?mes=2026-11')
        pg.click('text=Baixar estes lançamentos em planilha (CSV)')
    csv_txt = Path(dl.value.path()).read_text(encoding='utf-8-sig')
    assert csv_txt.splitlines()[0].startswith('data;descricao;tipo') and 'SALARIO' not in csv_txt and 'Salário' in csv_txt

    # Início
    pg.goto(base + '/')
    capturar(pg, '06_inicio')
    assert 'Disponível agora' in pg.content()

    # Exclusão exige confirmação no servidor (sem JavaScript)
    pg.goto(base + '/lancamentos?mes=2026-10&busca=Restaurante')
    pg.click('table a[href^="/lancamentos/"]:has-text("Restaurante")')
    pg.click('text=Excluir…')
    assert 'Confirmar exclusão' in pg.locator('h1').inner_text()
    pg.click('text=Cancelar')
    assert 'Restaurante' in pg.locator('h1').inner_text()

    # Excluir uma linha importada a devolve para revisão (defeito D3 da v0.9)
    pg.goto(base + '/lancamentos?mes=2026-11&busca=UBER')
    pg.locator('table a', has_text='UBER').first.click()
    pg.click('text=Excluir…'); pg.check('input[name=confirmo]'); pg.click('button.perigo')
    ok(pg, 'excluído')

    # Fechamento e bloqueio do mês
    pg.goto(base + '/fechamento?mes=2026-10')
    # R11: sem conferir ou dispensar cada conta com movimento, o botão de fechar fica travado
    assert pg.locator('button:has-text("Fechar out/2026")').is_disabled()
    assert 'não conferida' in pg.locator('main').inner_text()
    while pg.locator('summary:has-text("Dispensar neste mês")').count():
        pg.locator('summary:has-text("Dispensar neste mês")').first.click()
        pg.locator('form:has(input[value="dispensar"]) input[name=motivo]').first.fill('teste sem app do banco')
        pg.locator('form:has(input[value="dispensar"]) button').first.click(); ok(pg, 'dispensada')
    assert 'teste sem app do banco' in pg.locator('main').inner_text()
    pg.click('text=Fechar out/2026'); ok(pg, 'fechado')
    despesa('Esquecida', '10,00', '2026-10-15', 'Mercado', 'Conta BB')
    assert 'mês está fechado' in pg.locator('.aviso.erro').inner_text()
    pg.goto(base + '/fechamento?mes=2026-10'); pg.click('text=Reabrir out/2026'); ok(pg, 'reaberto')

    # Fluxo de caixa e previsões
    pg.goto(base + '/previsoes')
    f = 'form[action="/previsoes"]'
    pg.fill(f'{f} input[name=descricao]', 'Aluguel'); pg.fill(f'{f} input[name=valor]', '2.000,00')
    escolher(pg, f'{f} select[name=conta]', 'Conta BB'); escolher(pg, f'{f} select[name=contraparte]', 'Moradia')
    # Vence amanhã (o teste não pode depender do dia em que roda; dia 1 de um mês de 28 dias ainda fica dentro da janela de 3 dias)
    import datetime as _dt
    pg.fill(f'{f} input[name=dia]', str(min((_dt.date.today() + _dt.timedelta(days=1)).day, 28)))
    pg.click(f'{f} button'); ok(pg, 'Previsão cadastrada')
    pg.goto(base + '/fluxo?dias=90')
    assert 'Aluguel' in pg.content() and 'Fatura Cartão Inter' in pg.content()
    capturar(pg, '07_fluxo')

    # Backup cifrado: baixar, verificar e restaurar
    pg.goto(base + '/backup')
    pg.fill('form[action="/backup"] input[name=senha]', 'senha-de-teste-123'); pg.fill('form[action="/backup"] input[name=senha2]', 'senha-de-teste-123')
    with pg.expect_download() as dl:
        pg.click('form[action="/backup"] button')
    arquivo = dl.value.path()
    assert Path(arquivo).read_bytes()[:10] == b'FIN404ENC2'
    pg.goto(base + '/restaurar')
    pg.set_input_files('input[name=arquivo]', arquivo); pg.fill('input[name=senha]', 'senha-errada-123')
    pg.click('form[action="/restaurar"] button')
    assert 'Senha incorreta' in pg.locator('.aviso.erro').inner_text()
    pg.goto(base + '/restaurar')
    pg.set_input_files('input[name=arquivo]', arquivo); pg.fill('input[name=senha]', 'senha-de-teste-123')
    pg.click('form[action="/restaurar"] button')
    ok(pg, 'Backup íntegro')
    pg.check('input[name=confirmo]'); pg.click('button.perigo')
    ok(pg, 'Backup restaurado')

    pg.goto(base + '/integridade')
    ok(pg, 'Tudo certo')

    # Nenhuma violação de CSP, diálogo JavaScript, erro 5xx ou recurso inexistente em toda a jornada
    assert pg.violacoes == [], pg.violacoes


def test_post_de_outro_site_e_recusado(app):
    import urllib.request, urllib.error
    base, _ = app
    req = urllib.request.Request(base + '/pessoas', data=b'nome=x&csrf=x', method='POST',
                                 headers={'Origin': 'https://site-malicioso.example', 'Content-Type': 'application/x-www-form-urlencoded'})
    with pytest.raises(urllib.error.HTTPError) as exc:
        urllib.request.urlopen(req)
    assert exc.value.code == 403
    exc.value.close()
    req = urllib.request.Request(base + '/', headers={'Host': 'rebinding.example:4040'})
    with pytest.raises(urllib.error.HTTPError) as exc:
        urllib.request.urlopen(req)
    assert exc.value.code == 403
    exc.value.close()


def test_fatura_pdf_bb_no_navegador(app, pagina, tmp_path):
    pymupdf = pytest.importorskip('pymupdf')
    sys.path.insert(0, str(RAIZ / 'tests' / 'integracao'))
    from test_fatura_pdf_bb import fatura_texto
    doc = pymupdf.open(); pg_pdf = doc.new_page(width=595, height=842 * 3); y = 20
    for linha in fatura_texto().split('\n'):
        pg_pdf.insert_text((30, y), linha, fontsize=7); y += 9
    arquivo = tmp_path / 'fatura_ourocard.pdf'; arquivo.write_bytes(doc.tobytes()); doc.close()
    base, _ = app
    pg = pagina
    pg.goto(base + '/contas')
    f = 'form[action="/contas"]'
    pg.fill(f'{f} input[name=nome]', 'Ourocard'); pg.select_option(f'{f} select[name=subtipo]', label='Cartão de crédito')
    pg.fill(f'{f} input[name=dia_fechamento]', '27'); pg.fill(f'{f} input[name=dia_vencimento]', '6')
    pg.select_option(f'{f} select[name=regra_fechamento]', value='atual')
    pg.click(f'{f} button'); ok(pg, 'Conta cadastrada')
    pg.goto(base + '/importar')
    pg.select_option('select[name=conta]', label='Ourocard')
    pg.set_input_files('input[name=arquivo]', str(arquivo))
    pg.click('form[action="/importar"] button')
    assert pg.locator('.aviso.erro').count() == 0, pg.locator('main').inner_text()[:500]
    assert 'conferido com a soma dos lançamentos lidos' in pg.locator('main').inner_text()
    pg.click('button:has-text("como saldo inicial do cartão")'); ok(pg, 'Saldo inicial definido')
    for sel in pg.locator('select[name^="acao_"]').all():
        if not sel.input_value():
            sel.select_option(label='Outras despesas')
    capturar(pg, '08_revisao_fatura_pdf')
    pg.click('form[action^="/importacoes/"] button:has-text("Gravar decisões")'); ok(pg, 'Importação concluída')
    pg.goto(base + '/cartoes')
    pg.click('h2 a:has-text("Ourocard")')
    pg.click('table a:has-text("27/12/2026")')
    assert 'Confere com o documento do banco' in pg.locator('main').inner_text()
    assert 'data do banco' in pg.locator('main').inner_text()
    capturar(pg, '09_fatura_conferida')
    # R4: atalho "Mínimo" (do PDF desta fatura) passa por confirmação com aviso de rotativo
    url_fatura = pg.url
    f = 'form[action$="/pagar/confirmar"]'
    escolher(pg, f'{f} select[name=origem]', 'Conta BB')
    pg.click(f'{f} button:has-text("Mínimo (R$ 123,45)")')
    texto = pg.locator('main').inner_text()
    assert 'Pagar R$ 123,45' in texto and 'rotativo' in texto
    pg.click('button:has-text("Confirmar pagamento")'); ok(pg, 'Pagamento registrado')
    pg.goto(url_fatura)
    escolher(pg, f'{f} select[name=origem]', 'Conta BB')
    pg.fill(f'{f} input[name=valor]', '999.999,00'); pg.click(f'{f} button:has-text("Outro valor")')
    assert 'maior que o que falta pagar' in pg.locator('main').inner_text()
    pg.click('text=Voltar sem pagar')
    assert pg.url == url_fatura
    assert pg.violacoes == [], pg.violacoes


def test_rotina_sem_extrato_no_navegador(app, pagina):
    """Sem extrato: lançamento rápido, confirmar previstos e fechar a conta pela diferença com o saldo do app do banco."""
    base, _ = app
    pg = pagina
    pg.goto(base + '/')
    f = 'form[action="/novo"]'
    pg.fill(f'{f} input[name=descricao]', 'Pix padaria'); pg.fill(f'{f} input[name=valor]', '18,50')
    pg.select_option(f'{f} select[name=categoria]', label='Mercado'); pg.select_option(f'{f} select[name=conta]', label='Conta BB')
    pg.click(f'{f} button'); ok(pg, 'Despesa registrada')
    assert pg.url.rstrip('/').endswith(base.split('//')[1]) or pg.url.startswith(base + '/?')
    pg.goto(base + '/confirmar')
    assert 'Aluguel' in pg.locator('main').inner_text()
    capturar(pg, '10_confirmar_previstos')
    pg.locator('tr:has-text("Aluguel") input[type=checkbox]').first.check()
    pg.click('form[action="/confirmar"] button'); ok(pg, 'marcado(s) como pago ou recebido')
    pg.goto(base + '/contas'); pg.click('table a:has-text("Poupança BB")')
    c = 'form[action$="/conciliar"]'
    pg.fill(f'{c} input[name=valor]', '150,00'); pg.click(f'{c} button')
    assert 'Sem extrato? Lance a diferença' in pg.locator('main').inner_text()
    pg.click('form[action$="/diferenca"] button'); ok(pg, 'confere com o do banco')
    pg.fill(f'{c} input[name=valor]', '150,00'); pg.click(f'{c} button'); ok(pg, 'Confere')
    assert pg.violacoes == [], pg.violacoes


def test_seguranca_pin_backup_auto_e_lixeira(app, pagina, tmp_path):
    base, _ = app
    pg = pagina
    # Lixeira: excluir e restaurar
    pg.goto(base + '/lancamentos?mes=2026-11&busca=padaria')
    pg.click('table a[href^="/lancamentos/"]:has-text("Pix padaria")'); pg.click('text=Excluir…')
    pg.check('input[name=confirmo]'); pg.click('button.perigo'); ok(pg, 'excluído')
    pg.goto(base + '/lixeira'); assert 'Pix padaria' in pg.locator('main').inner_text()
    pg.click('form[action^="/lixeira/"] button'); ok(pg, 'restaurado')
    # Backup automático numa pasta "de nuvem"
    nuvem = tmp_path / 'OneDrive'; nuvem.mkdir()
    pg.goto(base + '/backup')
    f = 'form[action="/seguranca/backup-auto"]'
    pg.fill(f'{f} input[name=pasta]', str(nuvem)); pg.fill(f'{f} input[name=senha]', 'senha-backup-auto-1')
    pg.fill(f'{f} input[name=senha2]', 'senha-backup-auto-1'); pg.click(f'{f} button'); ok(pg, 'Backup automático ativado')
    assert len(list(nuvem.glob('financeiro404_auto_*.fin404'))) == 1
    # PIN
    f = 'form[action="/seguranca/pin"]'
    pg.fill(f'{f} input[name=pin]', '482913'); pg.fill(f'{f} input[name=pin2]', '482913'); pg.click(f'{f} button')
    ok(pg, 'PIN ativado')
    capturar(pg, '11_seguranca')
    pg.click('text=Bloquear')
    assert '/entrar' in pg.url
    pg.goto(base + '/relatorios')
    assert '/entrar' in pg.url                                 # sem sessão, nada é mostrado
    capturar(pg, '12_entrar')
    pg.fill('input[name=pin]', '000000'); pg.click('form[action="/entrar"] button')
    assert 'PIN incorreto' in pg.locator('.aviso.erro').inner_text()
    pg.fill('input[name=pin]', '482913'); pg.click('form[action="/entrar"] button')
    assert '/relatorios' in pg.url                              # volta para onde ia
    # Outro navegador (sem o cookie) não entra, nem por POST
    import urllib.request
    resp = urllib.request.urlopen(urllib.request.Request(base + '/lancamentos'))
    assert '/entrar' in resp.url; resp.close()
    # Remove o PIN para não afetar outros testes
    pg.goto(base + '/backup')
    f = 'form[action="/seguranca/pin"]'
    pg.fill(f'{f} input[name=atual]', '482913'); pg.click(f'{f} button'); ok(pg, 'PIN removido')
    assert pg.violacoes == [], pg.violacoes


def test_analises_metas_tema_e_celular(app, pagina):
    base, _ = app
    pg = pagina
    # Simulador de dívidas
    pg.goto(base + '/simulador')
    f = 'form[action="/simulador"]'
    pg.fill(f'{f} input[name=divida]', '8.123,45'); pg.fill(f'{f} input[name=pagamento]', '1.500,00')
    pg.fill(f'{f} input[name=rotativo]', '16,53'); pg.fill(f'{f} input[name=parcelado]', '6,09')
    pg.fill(f'{f} input[name=emprestimo]', '3,5'); pg.click(f'{f} button')
    texto = pg.locator('main').inner_text()
    assert 'a mais barata é Empréstimo em 12x' in texto and 'teto legal' in texto
    capturar(pg, '13_simulador')
    # Metas
    pg.goto(base + '/metas')
    f = 'form[action="/metas"]'
    pg.fill(f'{f} input[name=nome]', 'Reserva de emergência'); pg.fill(f'{f} input[name=alvo]', '15.000,00')
    pg.select_option(f'{f} select[name=conta]', label='Poupança BB'); pg.fill(f'{f} input[name=prazo]', '2027-12')
    pg.click(f'{f} button'); ok(pg, 'Meta criada')
    assert 'por mês até' in pg.locator('main').inner_text()
    capturar(pg, '14_metas')
    for caminho in ('/recorrentes', '/relatorios/irpf?ano=2026', '/relatorios/ano'):
        pg.goto(base + caminho)
        assert pg.locator('.aviso.erro').count() == 0
    # Acessibilidade básica: link de pular e item atual do menu marcado
    assert pg.locator('a.pular[href="#conteudo"]').count() == 1
    assert pg.locator('.nav-areas a[aria-current="page"]').inner_text() == 'Para onde foi'
    assert pg.locator('.abas-area a[aria-current="page"]').inner_text() in ('Mês', 'Ano')
    # Tema claro: volta para a mesma página e fica gravado
    pg.click('form.tema button[value=claro]')
    assert pg.url.endswith('/relatorios/ano')
    assert 'claro' in pg.locator('html').get_attribute('class')
    capturar(pg, '15_tema_claro')
    pg.click('form.tema button[value=auto]')
    assert 'auto' in pg.locator('html').get_attribute('class')
    # Celular: sem rolagem horizontal da página e colunas secundárias escondidas
    pg.set_viewport_size({'width': 390, 'height': 844})
    for caminho in ('/', '/lancamentos', '/simulador', '/metas', '/compras'):
        pg.goto(base + caminho)
        largura = pg.evaluate('document.documentElement.scrollWidth')
        assert largura <= 392, (caminho, largura)
        cortados = pg.evaluate("[...document.querySelectorAll('main form')].filter(f => f.scrollWidth > f.clientWidth + 1).length")
        assert cortados == 0, (caminho, 'formulário mais largo que a tela')
    pg.goto(base + '/lancamentos')
    assert not pg.locator('th.m-oculta').first.is_visible()
    capturar(pg, '16_celular_lancamentos')
    pg.set_viewport_size({'width': 1366, 'height': 900})
    assert pg.violacoes == [], pg.violacoes


def test_parcelamento_raio_x_alertas_e_teste_de_backup(app, pagina):
    base, _ = app
    pg = pagina
    # Encerrar um parcelamento (antecipação)
    pg.goto(base + '/parcelamentos')
    assert 'TV sala' in pg.locator('main').inner_text()
    pg.locator('a:has-text("Antecipei ou cancelei")').first.click()
    assert 'saem do planejamento' in pg.locator('main').inner_text()
    pg.select_option('select[name=motivo]', value='antecipado')
    pg.click('form[action$="/encerrar"] button'); ok(pg, 'Parcelamento encerrado')
    capturar(pg, '17_parcelamentos')
    # Provisão anual
    pg.goto(base + '/previsoes')
    f = 'form[action="/previsoes"]'
    pg.fill(f'{f} input[name=descricao]', 'IPVA'); pg.fill(f'{f} input[name=valor]', '2.400,00')
    pg.select_option(f'{f} select[name=conta]', label='Conta BB'); pg.select_option(f'{f} select[name=contraparte]', label='Transporte')
    pg.select_option(f'{f} select[name=periodicidade]', value='anual'); pg.select_option(f'{f} select[name=mes_do_ano]', value='3')
    pg.fill(f'{f} input[name=dia]', '15'); pg.click(f'{f} button'); ok(pg, 'Previsão cadastrada')
    assert 'Separar por mês' in pg.locator('main').inner_text() and 'R$ 200,00' in pg.locator('main').inner_text()
    # Natureza da categoria
    pg.goto(base + '/categorias')
    form = pg.locator('form[action^="/categorias/"]').filter(has=pg.locator('input[value="Vestuário"]'))
    form.locator('select[name=natureza]').select_option(value='discricionario'); form.locator('button').click()
    ok(pg, 'Categoria atualizada')
    # Raio-X e cenário
    pg.goto(base + '/raio-x')
    pg.select_option('select[name=queda]', value='50'); pg.click('form[action="/raio-x"] button')
    texto = pg.locator('main').inner_text()
    assert 'Custo de vida mínimo' in texto and 'A reserva dura' in texto and 'Despesas anuais (1/12 por mês)' in texto
    capturar(pg, '18_raio_x')
    # Dispensar um alerta e trazer de volta
    pg.goto(base + '/')
    antes = pg.locator('form.dispensar').count()
    assert antes > 0
    pg.locator('form.dispensar button').first.click(); ok(pg, 'Alerta escondido')
    assert pg.locator('form.dispensar').count() == antes - 1
    pg.click('form[action="/alertas/reexibir"] button'); ok(pg, 'voltaram')
    # Pistas da diferença na conferência de saldo
    pg.goto(base + '/contas'); pg.click('table a:has-text("Conta BB")')
    c = 'form[action$="/conciliar"]'
    pg.fill(f'{c} input[name=valor]', '1,00'); pg.click(f'{c} button')
    texto = pg.locator('main').inner_text()
    assert 'Pistas no que já foi lançado' in texto or 'Nada do que já foi lançado' in texto
    # Testar o backup automático com a senha
    pg.goto(base + '/backup')
    assert 'não protege' in pg.locator('main').inner_text()
    f = 'form[action="/seguranca/backup-auto/testar"]'
    pg.fill(f'{f} input[name=senha]', 'senha-errada-000'); pg.click(f'{f} button')
    assert 'Senha incorreta' in pg.locator('main').inner_text()
    pg.goto(base + '/backup')
    pg.fill(f'{f} input[name=senha]', 'senha-backup-auto-1'); pg.click(f'{f} button'); ok(pg, 'Backup testado')
    assert pg.violacoes == [], pg.violacoes


def test_cartao_novo_pela_fatura_e_exclusoes(app, pagina, tmp_path):
    pymupdf = pytest.importorskip('pymupdf')
    sys.path.insert(0, str(RAIZ / 'tests' / 'integracao'))
    from test_fatura_pdf_bb import fatura_texto
    doc = pymupdf.open(); pg_pdf = doc.new_page(width=595, height=842 * 3); y = 20
    for linha in fatura_texto(fechamento='27/04/2027', vencimento='06/05/2027', proximo='26/05/2027').split('\n'):
        pg_pdf.insert_text((30, y), linha, fontsize=7); y += 9
    arquivo = tmp_path / 'outra_fatura.pdf'; arquivo.write_bytes(doc.tobytes()); doc.close()
    base, _ = app
    pg = pagina
    # Cartão novo criado a partir da fatura
    pg.goto(base + '/importar')
    pg.select_option('select[name=conta]', value='novo_cartao')
    pg.set_input_files('input[name=arquivo]', str(arquivo)); pg.click('form[action="/importar"] button')
    ok(pg, 'criado com as datas e o limite da fatura')
    pg.click('text=Desfazer importação') if pg.locator('text=Desfazer importação').count() else None
    # Conta criada por engano: excluir em dois passos
    pg.goto(base + '/contas')
    f = 'form[action="/contas"]'
    pg.fill(f'{f} input[name=nome]', 'Conta errada'); pg.select_option(f'{f} select[name=subtipo]', label='Conta corrente')
    pg.click(f'{f} button'); ok(pg, 'Conta cadastrada')
    pg.click('table a:has-text("Conta errada")')
    pg.click('details.excluir summary'); pg.click('details.excluir button.perigo'); ok(pg, 'excluída')
    assert pg.locator('table a:has-text("Conta errada")').count() == 0
    # Conta com histórico: explica e não oferece excluir
    pg.click('table a:has-text("Conta BB")')
    assert pg.locator('details.excluir').count() == 0 and 'desmarque "Conta ativa"' in pg.locator('main').inner_text()
    # Categoria e pessoa
    pg.goto(base + '/categorias')
    f = 'form[action="/categorias"]'
    pg.click('summary:has-text("Nova categoria")')
    pg.fill(f'{f} input[name=nome]', 'Aquário'); pg.click(f'{f} button'); ok(pg, 'Categoria criada')
    linha = pg.locator('tr').filter(has=pg.locator('input[value="Aquário"]'))
    linha.locator('details.excluir summary').click(); linha.locator('button.perigo').click(); ok(pg, 'excluída')
    pg.goto(base + '/pessoas')
    f = 'form[action="/pessoas"]'
    pg.fill(f'{f} input[name=nome]', 'Visita'); pg.click(f'{f} button'); ok(pg, 'Pessoa adicionada')
    linha = pg.locator('tr').filter(has=pg.locator('input[value="Visita"]'))
    linha.locator('details.excluir summary').click(); linha.locator('button.perigo').click(); ok(pg, 'excluída')
    # Previsão e meta
    pg.goto(base + '/previsoes')
    linha = pg.locator('tr').filter(has_text='IPVA')
    linha.locator('details.excluir summary').click(); linha.locator('button.perigo').click(); ok(pg, 'excluída')
    pg.goto(base + '/metas')
    pg.locator('summary:has-text("Editar")').first.click()
    pg.locator('details.excluir summary').first.click(); pg.locator('details.excluir button.perigo').first.click(); ok(pg, 'excluída')
    assert pg.violacoes == [], pg.violacoes


def test_lancamento_recorrente_e_forma_de_pagamento(app, pagina):
    base, _ = app
    pg = pagina
    pg.goto(base + '/novo?tipo=despesa')
    f = 'form[action="/novo"]'
    pg.fill(f'{f} input[name=descricao]', 'Internet fibra'); pg.fill(f'{f} input[name=valor]', '99,90')
    pg.select_option(f'{f} select[name=categoria]', label='Moradia'); pg.select_option(f'{f} select[name=conta]', label='Conta BB')
    pg.select_option(f'{f} select[name=forma]', value='debito_automatico'); pg.select_option(f'{f} select[name=repetir]', value='mensal')
    pg.select_option(f'{f} select[name=status]', 'confirmada')
    pg.click(f'{f} button'); ok(pg, 'Repete: todo mês')
    pg.goto(base + '/previsoes')
    assert 'Internet fibra' in pg.locator('main').inner_text()
    pg.goto(base + '/lancamentos?busca=Internet+fibra')
    pg.locator('table a[href^="/lancamentos/"]:has-text("Internet fibra")').first.click()
    texto = pg.locator('main').inner_text()
    assert 'Débito automático' in texto and 'se repete' in texto
    # Receita mensal pelo detalhe: tornar recorrente depois
    pg.goto(base + '/novo?tipo=receita')
    pg.fill(f'{f} input[name=descricao]', 'Freela fixo'); pg.fill(f'{f} input[name=valor]', '500,00')
    pg.select_option(f'{f} select[name=categoria]', index=1); pg.select_option(f'{f} select[name=conta]', label='Conta BB')
    pg.select_option(f'{f} select[name=forma]', value='pix'); pg.select_option(f'{f} select[name=status]', 'confirmada')
    pg.click(f'{f} button'); ok(pg, 'Receita registrada')
    pg.goto(base + '/lancamentos?busca=Freela+fixo'); pg.locator('table a[href^="/lancamentos/"]:has-text("Freela fixo")').first.click()
    pg.click('form[action$="/repetir"] button'); ok(pg, 'Agora repete: todo mês')
    pg.goto(base + '/relatorios')
    assert 'Despesas por forma de pagamento' in pg.locator('main').inner_text()
    assert pg.violacoes == [], pg.violacoes


def test_lote_dividir_tags_anexos_filtros_e_graficos(app, pagina, tmp_path):
    base, _ = app
    pg = pagina
    # Lançar vários de uma vez
    pg.goto(base + '/lote')
    pg.fill('textarea[name=texto]', '18,50 padaria pix\nontem uber 23,90 crédito\n+300 freela pix\nlinha sem valor')
    pg.select_option('select[name=conta]', label='Conta BB'); pg.fill('input[name=tags]', 'teste-lote')
    pg.click('form[action="/lote/previa"] button')
    texto = pg.locator('main').inner_text()
    assert '3 de 4 linha(s) entendida(s)' in texto and 'sem valor' in texto
    for i in range(3):   # garante categoria nas linhas que o sistema não adivinhou
        sel = pg.locator(f'select[name=categoria_{i}]')
        if not sel.input_value():
            sel.select_option(index=1)
    pg.click('form[action="/lote/gravar"] button'); ok(pg, '3 lançamento(s) gravado(s)')
    capturar(pg, '19_lote')
    # Tags: página e filtro
    pg.goto(base + '/tags')
    assert 'teste-lote' in pg.locator('main').inner_text()
    pg.click('table a:has-text("teste-lote")')
    assert pg.locator('table a[href^="/lancamentos/"]:has-text("padaria")').count() == 1 and 'Por categoria, neste filtro' in pg.locator('main').inner_text()
    pg.fill('form[action="/lancamentos/filtros"] input[name=nome]', 'Lote de teste'); pg.click('form[action="/lancamentos/filtros"] button')
    assert pg.locator('.abas a:has-text("Lote de teste")').count() == 1
    # Dividir em categorias
    pg.click('table a[href^="/lancamentos/"]:has-text("padaria")')
    pg.click('summary:has-text("Dividir em categorias")')
    f = 'form[action$="/dividir"]'
    pg.select_option(f'{f} select[name=categoria_0]', label='Mercado'); pg.fill(f'{f} input[name=valor_0]', '10,00')
    pg.select_option(f'{f} select[name=categoria_1]', label='Farmácia e remédios'); pg.fill(f'{f} input[name=valor_1]', '8,50')
    pg.click(f'{f} button'); ok(pg, 'Dividido em 2 categorias')
    # Anexo: envia, baixa como download
    recibo = tmp_path / 'recibo.pdf'; recibo.write_bytes(b'%PDF-1.4\n%teste\n')
    pg.set_input_files('form[action$="/anexos"] input[name=arquivo]', str(recibo))
    pg.click('form[action$="/anexos"] button'); ok(pg, 'Comprovante anexado')
    with pg.expect_download() as d:
        pg.click('a:has-text("recibo.pdf")')
    assert d.value.suggested_filename == 'recibo.pdf'
    capturar(pg, '20_lancamento_dividido_com_anexo')
    # Gráficos e resumo
    pg.goto(base + '/evolucao')
    assert pg.locator('figure.grafico svg').count() == 4
    capturar(pg, '21_evolucao')
    pg.goto(base + '/resumo')
    assert 'Para onde foi' in pg.locator('main').inner_text() and '<span' not in pg.locator('main').inner_text()
    capturar(pg, '22_resumo')
    pg.goto(base + '/raio-x')
    assert 'Folga' in pg.locator('main').inner_text()
    # Nenhuma página mostra HTML escapado como texto (sinal de valor formatado passado por e() duas vezes)
    for caminho in ('/', '/lancamentos', '/lancamentos?mes=&tag=teste-lote', '/novo', '/lote', '/confirmar', '/importar', '/cartoes',
                    '/parcelamentos', '/fluxo', '/raio-x', '/evolucao', '/relatorios', '/relatorios/ano', '/relatorios/irpf',
                    '/recorrentes', '/orcamento', '/metas', '/previsoes', '/simulador', '/fechamento', '/contas', '/categorias',
                    '/tags', '/pessoas', '/regras', '/backup', '/lixeira', '/resumo', '/importacoes', '/lancamentos/filtros',
                    '/compras', '/compras/projetos', '/compras/lista', '/compras/historico', '/receber', '/reuniao', '/prazos', '/notas', '/precos', '/precos/agrupar'):
        pg.goto(base + caminho)
        texto = pg.locator('main').inner_text()
        assert '<span' not in texto and '&lt;' not in texto and '&amp;' not in texto, caminho
    assert pg.violacoes == [], pg.violacoes


def test_compras_e_projetos(app, pagina):
    base, _ = app
    pg = pagina
    # Projeto a partir da lista pronta
    pg.goto(base + '/compras/projetos')
    f = 'form[action="/compras/projetos"]'
    pg.fill(f'{f} input[name=nome]', 'Casa 404'); pg.select_option(f'{f} select[name=tipo]', 'casa')
    pg.fill(f'{f} input[name=orcamento]', '30.000,00'); pg.fill(f'{f} input[name=mes_alvo]', '2027-06')
    pg.check(f'{f} input[name=modelo]')
    pg.click(f'{f} button'); ok(pg, 'itens para cotar')
    texto = pg.locator('main').inner_text()
    assert 'Cozinha' in texto and 'Lavanderia' in texto and 'a cotar' in texto
    assert pg.locator('.nav-areas a[aria-current="page"]').inner_text() == 'Compras'
    assert pg.locator('.abas-area a[aria-current="page"]').inner_text() == 'Projetos'
    assert 'Compras › Projetos › Casa 404' in ' '.join(pg.locator('.caminho').inner_text().split())
    projeto_url = pg.url
    # Item manual no projeto
    a = 'form[action="/compras"]'
    pg.click('summary:has-text("Adicionar item")')
    pg.fill(f'{a} input[name=descricao]', 'Rack da sala'); pg.fill(f'{a} input[name=grupo]', 'Sala')
    pg.fill(f'{a} input[name=valor]', '900,00'); pg.select_option(f'{a} select[name=prioridade]', 'desejo')
    pg.click(f'{a} button'); ok(pg, 'Compra adicionada ao plano')
    assert pg.url.startswith(projeto_url.split('?')[0])
    # Cotações da geladeira: o link perigoso não vira link; "usar esta" passa o preço
    pg.click('table a:has-text("Geladeira")')
    q = 'form[action$="/cotacoes"]'
    for loja, preco, frete, link in [('Loja A', '3.500,00', '', 'https://loja-a.example/geladeira'),
                                     ('Loja B', '3.200,00', '150,00', 'javascript:alert(1)')]:
        pg.fill(f'{q} input[name=loja]', loja); pg.fill(f'{q} input[name=valor]', preco)
        pg.fill(f'{q} input[name=frete]', frete); pg.fill(f'{q} input[name=link]', link)
        pg.click(f'{q} button'); ok(pg, 'Cotação guardada')
    assert 'Menor preço: R$ 3.350,00 em Loja B' in pg.locator('main').inner_text()
    assert pg.locator('a[href^="javascript"]').count() == 0 and pg.locator('a[href="https://loja-a.example/geladeira"]').count() == 1
    pg.locator('form[action$="/usar"] button').first.click(); ok(pg, 'Valor e parcelas da cotação')
    assert 'Valor: R$ 3.350,00' in pg.locator('main').inner_text()
    capturar(pg, '24_compra_com_cotacoes')
    # Carro: comprar a troca de óleo planeja a próxima
    pg.goto(base + '/compras/projetos')
    pg.fill(f'{f} input[name=nome]', 'Carro'); pg.select_option(f'{f} select[name=tipo]', 'carro')
    pg.fill(f'{f} input[name=mes_alvo]', ''); pg.fill(f'{f} input[name=orcamento]', '')
    pg.check(f'{f} input[name=modelo]')
    pg.click(f'{f} button'); ok(pg, 'itens para cotar')
    pg.click('table a:has-text("Troca de óleo e filtros")')
    c = 'form[action$="/comprar"]'
    escolher(pg, f'{c} select[name=conta]', 'Conta BB'); pg.fill(f'{c} input[name=valor]', '320,00')
    pg.click(f'{c} button'); ok(pg, 'Próxima troca planejada para')
    # Lista com filtros
    pg.goto(base + '/compras/lista?estado=a+cotar')
    assert 'Pneus' in pg.locator('main').inner_text() and 'Rack da sala' not in pg.locator('main').inner_text()
    pg.select_option('form.filtros select[name=estado]', ''); pg.select_option('form.filtros select[name=prioridade]', 'desejo')
    pg.click('form.filtros button')
    assert 'Rack da sala' in pg.locator('main').inner_text()
    capturar(pg, '26_lista_de_compras')
    # Visão geral: projetos, gráfico e atenção
    pg.goto(base + '/compras')
    texto = pg.locator('main').inner_text()
    assert 'Projetos em andamento' in texto and 'Casa 404' in texto and 'sem preço' in texto
    assert pg.locator('figure.grafico svg').count() == 1
    capturar(pg, '23_compras_visao_geral')
    pg.goto(projeto_url.split('?')[0])
    capturar(pg, '25_projeto_casa')
    pg.goto(base + '/compras/historico')
    assert 'Troca de óleo e filtros' in pg.locator('main').inner_text()
    # Remover sugestões da lista pronta sem uso: o item com preço e o manual ficam
    pg.goto(projeto_url.split('?')[0])
    pg.click('form[action$="/sem-sugestoes"] button'); ok(pg, 'sugestão(ões) sem uso removida(s)')
    texto = pg.locator('main').inner_text()
    assert 'Geladeira' in texto and 'Rack da sala' in texto and 'Cama' not in texto
    # Arquivar tira do calendário; excluir apaga o planejado
    pg.goto(projeto_url.split('?')[0])
    pg.click('form[action$="/situacao"] button:has-text("Arquivar")'); ok(pg, 'Situação do projeto atualizada')
    assert 'fora de andamento' in pg.locator('main').inner_text()
    pg.click('summary:has-text("Excluir projeto")'); pg.click('form[action$="/excluir"] button')
    ok(pg, 'Projeto "Casa 404" excluído')
    assert pg.violacoes == [], pg.violacoes


def test_a_receber_e_conferencia_de_saldo(app, pagina):
    base, _ = app
    pg = pagina
    # Uma despesa que foi para outra pessoa sai dos gastos e vira a receber
    pg.goto(base + '/lancamentos?mes=2026-10')
    pg.locator('table a[href^="/lancamentos/"]').first.click()
    titulo = pg.locator('h1').inner_text()
    if pg.locator('summary:has-text("Foi para outra pessoa?")').count():
        pg.click('summary:has-text("Foi para outra pessoa?")')
        pg.fill('form[action$="/a-receber"] input[name=nome]', 'Cunhado')
        pg.click('form[action$="/a-receber"] button'); ok(pg, 'Passou para valores a receber')
        pg.goto(base + '/receber')
        texto = pg.locator('main').inner_text()
        assert 'Cunhado' in texto and titulo in texto
        f = 'form[action="/receber/devolver"]'
        pg.select_option(f'{f} select[name=pessoa]', label=pg.locator(f'{f} select[name=pessoa] option').nth(1).inner_text())
        pg.fill(f'{f} input[name=valor]', '1,00'); escolher(pg, f'{f} select[name=conta]', 'Conta BB')
        pg.click(f'{f} button'); ok(pg, 'Devolução registrada')
    # Emprestar direto pela página
    f = 'form[action="/receber/emprestar"]'
    pg.goto(base + '/receber')
    pg.fill(f'{f} input[name=nome]', 'Vizinho'); pg.fill(f'{f} input[name=valor]', '50,00')
    escolher(pg, f'{f} select[name=conta]', 'Conta BB'); pg.fill(f'{f} input[name=descricao]', 'Gás emprestado')
    pg.click(f'{f} button'); ok(pg, 'Registrado como valor a receber')
    assert 'Vizinho' in pg.locator('main').inner_text()
    capturar(pg, '27_a_receber')
    # Conferência de saldo com data sugerida pelo fechamento
    pg.goto(base + '/fechamento?mes=2026-11')
    link = pg.locator('a:has-text("conferir saldo de 30/11")').first
    if link.count():
        link.click()
        assert pg.locator('#conferir input[name=data]').input_value() == '2026-11-30'
        pg.fill('#conferir input[name=valor]', '0,00'); pg.click('#conferir button')
        assert 'Diferença' in pg.locator('main').inner_text()
        pg.goto(base + '/fechamento?mes=2026-11')
        assert 'diferença de' in pg.locator('main').inner_text()          # a última conferência não bateu
        assert pg.locator('button:has-text("Fechar nov/2026")').is_disabled()
    capturar(pg, '28_fechamento_conferencia')
    assert pg.violacoes == [], pg.violacoes


def test_reuniao_do_mes(app, pagina):
    base, _ = app
    pg = pagina
    pg.goto(base + '/reuniao?mes=2026-10')
    texto = pg.locator('main').inner_text()
    assert 'sobrou ou faltou' in texto and 'Compras dos próximos 3 meses' in texto
    pg.fill('textarea[name=decisoes]', '- revisar delivery\n- <script>alert(1)</script>')
    pg.click('form[action="/reuniao"] button'); ok(pg, 'Reunião registrada')
    assert 'reunião feita' in pg.locator('main').inner_text()
    assert pg.locator('.decisoes script').count() == 0 and '<script>' in pg.locator('.decisoes').inner_text()
    capturar(pg, '29_reuniao_do_mes')
    assert pg.violacoes == [], pg.violacoes


def test_varios_lancamentos_seguidos_sem_sair_do_formulario(app, pagina):
    """Depois de salvar, volta ao Novo lançamento com data, conta e forma mantidas; os últimos aparecem embaixo."""
    base, _ = app
    pg = pagina
    pg.goto(base + '/novo?tipo=despesa')
    f = 'form[action="/novo"]'
    pg.fill(f'{f} input[name=descricao]', 'Padaria seguida'); pg.fill(f'{f} input[name=valor]', '12,00')
    pg.fill(f'{f} input[name=data]', '2026-11-03')
    escolher(pg, f'{f} select[name=categoria]', 'Mercado'); escolher(pg, f'{f} select[name=conta]', 'Conta BB')
    pg.select_option(f'{f} select[name=forma]', value='pix')
    pg.select_option(f'{f} select[name=status]', 'confirmada')
    pg.click(f'{f} button'); ok(pg, 'Despesa registrada')
    assert '/novo?' in pg.url
    assert pg.locator(f'{f} select[name=status]').input_value() == 'confirmada'      # a escolha fica para o próximo
    assert pg.locator(f'{f} input[name=data]').input_value() == '2026-11-03'
    assert pg.locator(f'{f} select[name=forma]').input_value() == 'pix'
    assert 'Conta BB' in pg.locator(f'{f} select[name=conta] option:checked').inner_text()
    assert pg.locator(f'{f} input[name=descricao]').input_value() == ''
    pg.fill(f'{f} input[name=descricao]', 'Feira seguida'); pg.fill(f'{f} input[name=valor]', '30,00')
    escolher(pg, f'{f} select[name=categoria]', 'Mercado')
    pg.click(f'{f} button'); ok(pg, 'Despesa registrada')
    ultimos = pg.locator('section:has(h2:has-text("Últimos lançados")) tbody').inner_text()
    assert ultimos.index('Feira seguida') < ultimos.index('Padaria seguida')
    pg.click('text=Ver todos os lançamentos de nov/2026')
    assert 'Feira seguida' in pg.locator('main').inner_text()
    assert pg.violacoes == [], pg.violacoes


def test_prazos_e_garantias(app, pagina):
    base, _ = app
    pg = pagina
    pg.goto(base + '/prazos')
    f = 'form[action="/prazos"][method=post]'
    pg.select_option(f'{f} select[name=tipo]', 'licenciamento'); pg.fill(f'{f} input[name=titulo]', 'Licenciamento do carro')
    pg.fill(f'{f} input[name=data_fim]', '2026-11-20'); pg.click(f'{f} button'); ok(pg, 'Prazo adicionado')
    pg.click('form[action$="/concluir"] button[name=renovar]'); ok(pg, 'Renovado: o próximo vence em 20/11/2027')
    # Garantia a partir do lançamento da TV
    pg.goto(base + '/lancamentos?busca=TV+sala')
    pg.locator('table a[href^="/lancamentos/"]:has-text("TV sala")').first.click()
    pg.click('summary:has-text("Garantia")')
    pg.select_option('form[action$="/garantia"] select[name=meses]', '12'); pg.fill('form[action$="/garantia"] input[name=titulo]', 'TV da sala')
    pg.click('form[action$="/garantia"] button'); ok(pg, 'Garantia registrada')
    pg.goto(base + '/prazos?q=tv')
    texto = pg.locator('main').inner_text()
    assert 'TV da sala' in texto and 'na garantia' in texto
    capturar(pg, '30_prazos_e_garantias')
    assert pg.violacoes == [], pg.violacoes


def test_notas_fiscais_e_precos(app, pagina, tmp_path):
    base, _ = app
    pg = pagina
    cab = 'data;loja;cnpj;chave;item;codigo;quantidade;unidade;preco_unitario;total_item;desconto_nota;total_nota\n'
    csv = tmp_path / 'notas.csv'
    csv.write_text(cab +
                   '12/10/2026;SUPERMERCADO FICTICIO;;;LEITE INT ITALAC 1L;7891111111111;10;UN;5,49;54,90;0,00;1200,00\n'
                   '12/10/2026;SUPERMERCADO FICTICIO;;;CARNE MOIDA KG;;10;KG;45,00;450,00;0,00;1200,00\n'
                   '12/10/2026;SUPERMERCADO FICTICIO;;;DETERG YPE 500ML;;10;UN;4,51;45,10;0,00;1200,00\n'
                   '12/10/2026;SUPERMERCADO FICTICIO;;;ARROZ 5KG;;25;UN;26,00;650,00;0,00;1200,00\n'
                   '01/11/2026;MERCADINHO;;;LT ITALAC INTEGRAL;;2;UN;5,99;11,98;0,00;11,98\n', encoding='utf-8')
    pg.goto(base + '/notas')
    pg.click('summary:has-text("Planilha CSV")')
    pg.set_input_files('form[action="/notas/importar"] input[name=arquivo]', str(csv))
    pg.click('form[action="/notas/importar"] button')
    ok(pg, '2 nota(s) nova(s); 5 item(ns); 1 ligada(s)')
    texto = pg.locator('main').inner_text()
    assert 'Carnes e peixes' in texto and 'Limpeza' in texto        # gasto por tipo
    # A nota de 1.200 casou com o "Supermercado" lançado no cartão em 12/10
    pg.click('table a:has-text("SUPERMERCADO FICTICIO")')
    assert 'ligada' in pg.locator('main').inner_text() and 'Supermercado' in pg.locator('main').inner_text()
    capturar(pg, '31_nota_fiscal')
    # A outra nota não tem lançamento: lançar a partir dela
    pg.goto(base + '/notas'); pg.click('table a:has-text("MERCADINHO")')
    escolher(pg, 'form[action$="/lancar"] select[name=conta]', 'Conta BB')
    escolher(pg, 'form[action$="/lancar"] select[name=categoria]', 'Mercado')
    pg.click('form[action$="/lancar"] button'); ok(pg, 'Compra lançada e ligada')
    # Agrupar "LT ITALAC INTEGRAL" com o produto criado pelo código de barras do leite
    pg.goto(base + '/precos/agrupar')
    pg.locator('section:has(h2:has-text("LT ITALAC INTEGRAL")) form[action="/precos/associar"] button').first.click()
    ok(pg, 'Agrupado')
    pg.goto(base + '/precos?q=italac')
    pg.click('table a:has-text("LEITE INT ITALAC")')
    texto = pg.locator('main').inner_text()
    assert 'MERCADINHO' in texto and 'SUPERMERCADO FICTICIO' in texto and 'Mais barato em' in texto
    assert pg.locator('figure.grafico svg').count() == 1
    capturar(pg, '32_historico_de_preco')
    assert pg.violacoes == [], pg.violacoes


def _png(larg=240, alt=360):
    """PNG de verdade (branco com faixas), feito na hora, para o navegador desenhar."""
    import struct
    import zlib
    linhas = b''.join(b'\x00' + (b'\x30' if (y // 12) % 3 == 0 else b'\xf0') * larg for y in range(alt))
    def bloco(tipo, dados):
        return struct.pack('>I', len(dados)) + tipo + dados + struct.pack('>I', zlib.crc32(tipo + dados) & 0xffffffff)
    return (b'\x89PNG\r\n\x1a\n' + bloco(b'IHDR', struct.pack('>IIBBBBB', larg, alt, 8, 0, 0, 0, 0))
            + bloco(b'IDAT', zlib.compress(linhas)) + bloco(b'IEND', b''))


def test_nota_paulista_pagina_lista_e_foto(app, pagina, tmp_path):
    """Lista da Nota Fiscal Paulista (sem itens) → conferência → página da nota completa os itens → foto completa a outra."""
    base, _ = app
    pg = pagina
    linhas = (('20/11/2026', '55.555.555/0001-55', 'HORTIFRUTI FICTICIO', '31,40'),
              ('21/11/2026', '66.666.666/0001-66', 'EMPORIO FICTICIO', '45,00'))
    lista = tmp_path / 'lista_nfp.html'
    lista.write_bytes(('<html><body><table><tr><th>Emissão</th><th>CNPJ</th><th>Emitente</th><th>Valor</th></tr>'
                       + ''.join(f'<tr><td>{d}</td><td>{c}</td><td>{l}</td><td>R$ {v}</td></tr>' for d, c, l, v in linhas)
                       + '</table></body></html>').encode('cp1252'))
    pg.goto(base + '/notas')
    pg.click('summary:has-text("Lista da Nota Fiscal Paulista")')
    pg.set_input_files('form[action="/notas/importar-lista"] input[name=arquivo]', str(lista))
    pg.click('form[action="/notas/importar-lista"] button')
    ok(pg, '2 nota(s) nova(s); 0 item(ns)')
    assert 'filtro=sem_lancamento' in pg.url
    texto = pg.locator('main').inner_text()
    assert 'compras que podem estar fora do app' in texto and 'HORTIFRUTI FICTICIO' in texto
    capturar(pg, '33_conferencia_nota_paulista')
    # página da nota (leiaute padrão da NFC-e) da primeira compra: completa a mesma nota
    def item(desc, qtd, un, unit, total):
        return (f'<tr><td><span class="txtTit">{desc}</span><span class="RCod">(Código: 7890000000000)</span>'
                f'<span class="Rqtd"><strong>Qtde.:</strong>{qtd}</span><span class="RUN"><strong>UN: </strong>{un}</span>'
                f'<span class="RvlUnit"><strong>Vl. Unit.:</strong> {unit}</span></td>'
                f'<td class="txtTit noWrap">Vl. Total<br><span class="valor">{total}</span></td></tr>')
    nota = tmp_path / 'nota.html'
    nota.write_text('<html><body><div class="txtTopo">HORTIFRUTI FICTICIO LTDA</div><div>CNPJ: 55.555.555/0001-55</div><table>'
                    + item('TOMATE KG', '1,2000', 'KG', '8,50', '10,20') + item('ALFACE CRESPA', '2', 'UN', '3,50', '7,00')
                    + item('MACA GALA KG', '1,5000', 'KG', '9,46', '14,19')
                    + '</table><label>Valor total R$:</label><span class="totalNumb">31,39</span>'
                    '<label>Valor a pagar R$:</label><span class="totalNumb">31,39</span>'
                    '<p>Emissão: 20/11/2026 10:00:00</p></body></html>', encoding='utf-8')
    pg.goto(base + '/notas')
    pg.click('summary:has-text("Página da nota")')
    pg.set_input_files('form[action="/notas/importar-pagina"] input[name=arquivo]', str(nota))
    pg.click('form[action="/notas/importar-pagina"] button')
    assert 'não é' not in pg.locator('main').inner_text()
    # total 31,39 ≠ 31,40 da lista: é outra nota (não completa uma compra de valor diferente)
    ok(pg, '1 nota(s) nova(s); 3 item(ns)')
    assert 'TOMATE KG' in pg.locator('main').inner_text()
    pg.click('button:has-text("Excluir nota…"), summary:has-text("Excluir nota")')
    pg.click('details.excluir[open] button'); ok(pg, 'excluída')
    nota.write_text(nota.read_text(encoding='utf-8').replace('14,19', '14,20').replace('9,46', '9,47').replace('31,39', '31,40'),
                    encoding='utf-8')
    pg.click('summary:has-text("Página da nota")')
    pg.set_input_files('form[action="/notas/importar-pagina"] input[name=arquivo]', str(nota))
    pg.click('form[action="/notas/importar-pagina"] button')
    ok(pg, '1 nota(s) da lista completada(s) com os itens; 3 item(ns)')
    assert 'MACA GALA KG' in pg.locator('main').inner_text() and 'HORTIFRUTI FICTICIO' in pg.locator('main').inner_text()
    # foto da segunda compra
    foto = tmp_path / 'cupom.png'
    foto.write_bytes(_png())
    pg.goto(base + '/notas/fotos')
    pg.set_input_files('form[action="/notas/fotos"] input[name=foto]', str(foto))
    pg.click('form[action="/notas/fotos"] button')
    ok(pg, '1 foto(s) recebida(s)')
    assert pg.evaluate('document.querySelector(".foto-grande img").naturalWidth') == 240
    pg.fill('input[name=loja]', 'EMPORIO FICTICIO'); pg.fill('input[name=data]', '21/11/2026')
    pg.fill('input[name=cnpj]', '66.666.666/0001-66'); pg.fill('input[name=total]', '45,00')
    pg.fill('textarea[name=itens]', 'CAFE 500G 18,90\nQUEIJO MINAS 0,412 KG 49,90 20,56\nPAO DE QUEIJO 1 5,00')
    pg.click('button[value=conferir]')
    assert 'Não fecha' in pg.locator('main').inner_text() and 'faltam R$ 0,54' in pg.locator('main').inner_text()
    capturar(pg, '34_nota_por_foto')
    pg.click('button[value=salvar]')                         # erro: volta com tudo digitado
    assert 'Diferença: R$ 0,54' in pg.locator('.aviso.erro').first.inner_text()
    assert 'QUEIJO MINAS' in pg.input_value('textarea[name=itens]')
    pg.fill('textarea[name=itens]', 'CAFE 500G 18,90\nQUEIJO MINAS 0,412 KG 49,90 20,56\nPAO DE QUEIJO 1 5,54')
    pg.click('button[value=salvar]')
    ok(pg, 'Nota salva a partir da foto')
    assert 'PAO DE QUEIJO' in pg.locator('main').inner_text()
    assert pg.evaluate('document.querySelector(".fotos-nota img").naturalWidth') == 240
    pg.goto(base + '/notas')
    assert 'compras que podem estar fora do app' in pg.locator('main').inner_text()
    pg.violacoes = [v for v in pg.violacoes if '/notas/fotos' not in v or not v.startswith('422')]
    assert pg.violacoes == [], pg.violacoes


def test_quanto_gastei_tres_visoes(app, pagina):
    base, _ = app
    pg = pagina
    pg.goto(base + '/')
    pg.click('.nav-areas >> text=Para onde foi')
    assert pg.url.endswith('/gastos')
    for ver, texto in (('fatura', 'fechou'), ('compra', 'data da compra'), ('caixa', 'dinheiro que saiu')):
        pg.goto(base + f'/gastos?mes=2026-10&ver={ver}')
        assert texto in pg.locator('main').inner_text()
    pg.goto(base + '/gastos?mes=2026-10&ver=compra')
    capturar(pg, '35_quanto_gastei')
    links = pg.locator('main table a')
    if links.count():
        links.first.click()
        assert 'Data no app' in pg.locator('main').inner_text()
    assert pg.violacoes == [], pg.violacoes


def test_cartao_pagamento_como_estorno_e_saldo_inicial(app, pagina, monkeypatch):
    """A fatura do app tem de bater com a do banco: corrigir pagamento lançado como estorno e usar o saldo anterior."""
    base, dados = app
    pg = pagina
    monkeypatch.setenv('FIN404_DATA', str(dados))
    from datetime import date
    from fin404.dados import banco
    from fin404.dominio import razao
    with banco.transacao() as c:
        cid = c.execute("SELECT id FROM contas WHERE subtipo='cartao' ORDER BY id LIMIT 1").fetchone()[0]
        cat = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome='Outras despesas'").fetchone()[0]
        razao.registrar(c, date(2026, 10, 1), 'PGTO. CASH AG. 0000 000000000 200', 'estorno', [(cat, -38000), (cid, 38000)])
        c.execute('''INSERT INTO lotes_importacao(conta_id, formato, arquivo, sha256, fatura_fechamento, fatura_saldo_anterior)
                     VALUES(?,?,?,?,?,?)''', (cid, 'pdf_bb', 'ficticia.pdf', 'e2e-ficticio', '2026-09-05', 123456))
    pg.goto(base + '/cartoes')
    texto = pg.locator('main').inner_text()
    assert 'lançado(s) como estorno' in texto and 'falta a dívida que já existia antes do app' in texto
    capturar(pg, '36_cartao_confere_banco')
    pg.select_option('form[action^="/cartoes/pagamentos/"] select', index=1)
    pg.click('form[action^="/cartoes/pagamentos/"] button')
    ok(pg, 'agora é pagamento de fatura')
    pg.click('form[action$="/saldo-inicial"] button')
    ok(pg, 'Saldo inicial do cartão definido')
    assert 'como estorno' not in pg.locator('main').inner_text()
    pg.goto(base + '/gastos?mes=2026-10&ver=fatura')
    assert 'Conferir com a fatura' in pg.locator('main').inner_text()
    assert pg.violacoes == [], pg.violacoes


def test_navegacao_por_areas_mes_guardado_e_volta_ao_bloco(app, pagina):
    """Menu de 7 áreas que cabe na tela; abas da área; o mês escolhido vale para as outras páginas; depois de salvar, volta ao painel."""
    base, _ = app
    pg = pagina
    pg.set_viewport_size({'width': 1366, 'height': 768})
    pg.goto(base + '/')
    assert pg.locator('.nav-areas a').count() == 7
    altura = pg.evaluate("document.querySelector('.lateral').scrollHeight <= window.innerHeight")
    assert altura, 'o menu precisa caber na tela sem rolar'
    for area, primeira in (('Lançamentos', '/lancamentos'), ('Cartões', '/cartoes'), ('Planejar', '/proximos'), ('Ajustes', '/contas')):
        pg.click(f'.nav-areas >> text={area}')
        assert pg.url.split('?')[0].endswith(primeira)
        assert pg.locator('.abas-area a').count() >= 3
    # mês guardado: escolher outubro numa página vale para Lançamentos e Quanto gastei, até voltar ao mês atual
    pg.goto(base + '/relatorios?mes=2026-10')
    pg.goto(base + '/lancamentos')
    assert pg.locator('input[name=mes]').input_value() == '2026-10'
    assert 'out/2026' in pg.locator('.mes-fixado').inner_text()
    pg.goto(base + '/gastos')
    assert 'out/2026' in pg.locator('.abas .atual').first.inner_text()
    pg.click('.mes-fixado a')
    assert pg.locator('.mes-fixado').count() == 0
    # volta ao painel: salvar o orçamento (no meio da página) volta com #bloco
    pg.goto(base + '/tags')
    form = pg.locator('form[method=post]').first
    bloco = form.locator('input[name=_bloco]')
    assert bloco.count() == 1
    capturar(pg, '37_navegacao_areas')
    assert pg.violacoes == [], pg.violacoes


def test_editar_situacao_pago_a_pagar_e_parte(app, pagina):
    base, _ = app
    pg = pagina
    pg.goto(base + '/novo?tipo=despesa')
    f = 'form[action="/novo"]'
    pg.fill(f'{f} input[name=descricao]', 'Condomínio teste'); pg.fill(f'{f} input[name=valor]', '625,00')
    escolher(pg, f'{f} select[name=categoria]', 'Moradia'); escolher(pg, f'{f} select[name=conta]', 'Conta BB')
    pg.select_option(f'{f} select[name=status]', 'confirmada')
    pg.click(f'{f} button'); ok(pg, 'Despesa registrada')
    pg.goto(base + '/lancamentos?mes=&busca=Condom%C3%ADnio+teste')
    pg.click('table a:has-text("Condomínio teste")')
    g = 'form[action$="/editar"]'
    pg.select_option(f'{g} select[name=situacao]', 'a_pagar'); pg.click(f'{g} button'); ok(pg, 'Salvo como "a pagar"')
    assert 'a pagar' in pg.locator('main').inner_text()
    pg.select_option(f'{g} select[name=situacao]', 'parte'); pg.fill(f'{g} input[name=valor_pago]', '300,00')
    pg.click(f'{g} button'); ok(pg, 'o restante continua a pagar')
    pg.goto(base + '/lancamentos?mes=&busca=Condom%C3%ADnio+teste')
    texto = pg.locator('main').inner_text()
    assert 'Condomínio teste (restante)' in texto and 'R$ 325,00' in texto and 'R$ 300,00' in texto
    capturar(pg, '38_situacao_editavel')
    # em lote, pela lista: o restante foi pago
    pg.locator('tr:has-text("Condomínio teste (restante)") input[name=ids]').check()
    pg.click('#mudar-situacao button[value=pago]'); ok(pg, '1 lançamento(s) marcado(s) como pago')
    assert 'busca=' in pg.url and 'a pagar' not in pg.locator('table').last.inner_text()
    assert pg.violacoes == [], pg.violacoes


def test_previsao_editavel_proximos_meses_e_ordenar(app, pagina):
    base, _ = app
    pg = pagina
    pg.goto(base + '/previsoes')
    linha = pg.locator('tr:has(details.editar-prev)').first
    linha.locator('details.editar-prev summary').click()
    linha.locator('details.editar-prev input[name=valor]').fill('2.000,00')
    linha.locator('details.editar-prev form button').click(); ok(pg, 'Previsão atualizada')
    assert 'R$ 2.000,00' in pg.locator('main').inner_text()
    pg.goto(base + '/proximos')
    texto = pg.locator('main').inner_text()
    assert 'Saldo no fim do mês' in texto and 'Dia a dia' in texto
    capturar(pg, '39_proximos_meses')
    pg.click('a:has-text("12 meses")')
    assert pg.locator('table tbody tr').count() == 12
    # ordenar a lista de lançamentos pelo valor: clicar no título
    pg.goto(base + '/lancamentos?mes=')
    pg.click('table th a.ordenar:has-text("Valor")')
    assert 'aria-sort' in pg.locator('table th:has(a:has-text("Valor"))').last.evaluate('e => e.outerHTML')
    pg.click('table th a.ordenar:has-text("Valor")')
    assert pg.violacoes == [], pg.violacoes


def test_lote_mover_parcelas_e_periodo(app, pagina):
    base, _ = app
    pg = pagina
    f = 'form[action="/novo"]'
    pg.goto(base + '/novo?tipo=despesa')
    pg.fill(f'{f} input[name=descricao]', 'Geladeira lote'); pg.fill(f'{f} input[name=valor]', '1.500,00')
    pg.fill(f'{f} input[name=data]', '2026-11-03')
    escolher(pg, f'{f} select[name=categoria]', 'Casa nova'); escolher(pg, f'{f} select[name=conta]', 'Cartão Inter')
    pg.fill(f'{f} input[name=parcelas]', '3'); pg.select_option(f'{f} select[name=status]', 'confirmada')
    pg.click(f'{f} button'); ok(pg, '3 parcela')
    # categoria em lote, pela lista
    pg.goto(base + '/lancamentos?mes=&busca=Geladeira+lote')
    assert pg.locator('input[name=ids]').count() == 3     # ?mes= vazio = todos os meses (antes o servidor descartava)
    for i in range(3):
        pg.locator('input[name=ids]').nth(i).check()
    escolher(pg, '#mudar-situacao select[name=categoria_lote]', 'Vestuário')
    pg.click('#mudar-situacao button[value=editar]'); ok(pg, '3 lançamento(s) alterado(s)')
    assert pg.locator('table').last.inner_text().count('Vestuário') == 3
    capturar(pg, '40_lote_categoria')
    # mover a compra inteira para o outro cartão
    pg.click('table a:has-text("Geladeira lote (1/3)")')
    pg.locator('#mover summary').click()
    escolher(pg, '#mover select[name=cartao]', 'Ourocard')
    pg.click('#mover button'); ok(pg, '3 parcela(s) passaram para Ourocard')
    pg.goto(base + '/lancamentos?mes=&busca=Geladeira+lote')
    assert pg.locator('table').last.inner_text().count('Ourocard') == 3
    # quanto gastei num período
    pg.goto(base + '/gastos?mes=2026-09&ate=2026-11&ver=compra')
    texto = pg.locator('main').inner_text()
    assert 'Mês a mês' in texto and 'Média por mês' in texto and 'de set/2026 a nov/2026' in texto
    capturar(pg, '41_gastos_periodo')
    assert pg.violacoes == [], pg.violacoes
