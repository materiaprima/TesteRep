import os
import sys
from pathlib import Path

import pytest

RAIZ = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(RAIZ))


@pytest.fixture
def banco(tmp_path, monkeypatch):
    """Banco novo e isolado por teste."""
    monkeypatch.setenv('FIN404_DATA', str(tmp_path))
    from fin404.dados import banco as b
    b.migrar()
    return b


@pytest.fixture
def contas(banco):
    """Contas básicas: corrente, poupança, dinheiro, cartão (fecha 5, vence 12) e categorias."""
    from fin404.dominio import razao
    with banco.transacao() as c:
        ids = {
            'corrente': razao.criar_conta(c, 'Conta BB', 'corrente', instituicao='BB'),
            'poupanca': razao.criar_conta(c, 'Poupança BB', 'poupanca'),
            'dinheiro': razao.criar_conta(c, 'Carteira', 'dinheiro'),
            'cartao': razao.criar_conta(c, 'Cartão Inter', 'cartao', dia_fechamento=5, dia_vencimento=12, limite_centavos=1_000_000),
        }
        for nome in ('Mercado', 'Vestuário', 'Casa nova', 'Restaurantes e delivery', 'Assinaturas', 'Moradia',
                     'Juros, tarifas e IOF', 'Outras despesas'):
            ids[nome] = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome=?", (nome,)).fetchone()[0]
        for nome in ('Salário', 'Outras receitas', 'Rendimentos de investimentos'):
            ids[nome] = c.execute("SELECT id FROM contas WHERE tipo='receita' AND nome=?", (nome,)).fetchone()[0]
    return ids
