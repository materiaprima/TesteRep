"""Fatura Ourocard (BB) em PDF: leitor, trava de soma, ciclo com datas reais, parcelas e migração 0001 -> 0002.

Os dados são sintéticos: o layout imita o PDF do BB (texto como o PyMuPDF extrai), sem nenhum dado real.
"""
import datetime
import sqlite3

import pytest

from fin404.dinheiro import ErroValidacao, formatar
from fin404.dominio import cartoes, operacoes, razao, relatorios
from fin404.importacao import pipeline
from fin404.importacao.adaptadores import pdf_bb


def fatura_texto(fechamento='27/12/2026', vencimento='06/01/2027', proximo='26/01/2027', saldo_anterior='1.000,00',
                 itens=None, total=None, portador='Pessoa Exemplo (Cartão 1234)', parcelado='600,00'):
    itens = itens if itens is not None else [
        ('Pagamentos/Créditos', '05/12', 'PGTO. CASH AG. 9999 000000000 200', None, '-1.000,00'),
        ('Pagamentos/Créditos', '10/12', 'LOJA EXEMPLO ESTORNO', 'BR', '-20,00'),
        ('Restaurantes', '28/11', 'RESTAURANTE FICTICIO CIDADE', 'BR', '150,00'),
        ('Transporte', '02/12', 'Uber UBER TRIP HELP UBSAO PAULO', 'BR', '25,90'),
        ('Transporte', '27/12', 'Uber UBER TRIP HELP UBSAO PAULO', 'BR', '18,10'),
        ('Saúde', '15/12', 'FARMACIA FICTICIA', 'BR', '80,00'),
        ('Outros lançamentos', '20/12', 'IOF - COMPRA NO EXTERIOR', None, '3,50'),
        ('Outros lançamentos', '27/12', 'ANUIDADE DIFERENCIADA TIT-PARC 04/12', 'BR', '17,50'),
        ('Outros lançamentos', '09/12', 'PAGTO. PARCEL PARC 02/02 0000000000', 'BR', '100,00'),
        ('Compras parceladas', '15/03', 'LOJA MOVEIS PARC 10/10 CIDADE', 'BR', '300,00'),
        ('Compras parceladas', '20/11', 'LOJA TV PARC 02/05 CIDADE', 'BR', '200,00'),
    ]
    from fin404.dinheiro import centavos
    soma = sum(centavos(v, permitir_negativo=True) for *_, v in itens) + centavos(saldo_anterior)
    total = total or formatar(soma).replace('R$ ', '')
    linhas = ['Pessoa Exemplo', 'RUA FICTICIA 1, CIDADE', f'Valor\nR${total}', f'Vencimento\n{vencimento}', 'OUROCARD ELO', 'Final 0000',
              'Resumo da fatura', 'Pagamento mínimo\nR$ 123,45', 'Saldo parcelado em faturas', 'futuras', f'R$ {parcelado}', 'Página 1/3',
              'Datas fatura', f'Fatura fechada em\n{fechamento}', f'Fechamento da próxima fatura\n{proximo}',
              'Lançamentos nesta fatura',
              'Confira aqui todas as compras e outros lançamentos realizados nesta fatura, feitas com o seu cartão principal ou adicionais. Lembre-',
              'se: caso ainda tenha faturas em aberto, você pode optar por parcelar uma compra feita à vista.',
              portador, 'Data', '   Descrição', 'País', 'Valor', '    SALDO FATURA ANTERIOR', 'BR', f'R$ {saldo_anterior}']
    secao = None
    for i, (sec, d, desc, pais, v) in enumerate(itens):
        if sec != secao:
            linhas.append('    ' + sec); secao = sec
        linhas += [d, '    ' + desc] + ([pais] if pais else []) + [f'R$ {v}']
        if i == 4:
            linhas.append('Página 2/3')
    linhas += ['Total da Fatura', f'R$ {total}', 'Fale conosco', 'Página 3/3']
    return '\n'.join(linhas)


def test_leitura_e_virada_de_ano():
    r = pdf_bb.ler_texto(fatura_texto())
    f = r['fatura']
    assert f['fechamento'] == datetime.date(2026, 12, 27) and f['vencimento'] == datetime.date(2027, 1, 6)
    assert f['proximo_fechamento'] == datetime.date(2027, 1, 26)
    assert f['saldo_anterior'] == 100000 and f['parcelado_futuro'] == 60000 and f['regra_fechamento'] == 'atual'
    assert len(r['linhas']) == 11 and r['conta_externa'] == 'final 0000'
    datas = {l['descricao']: l['data'] for l in r['linhas']}
    assert datas['LOJA MOVEIS PARC 10/10 CIDADE'] == datetime.date(2026, 3, 15)
    assert datas['RESTAURANTE FICTICIO CIDADE'] == datetime.date(2026, 11, 28)
    pag = next(l for l in r['linhas'] if l['descricao'].startswith('PGTO'))
    assert pag['valor'] == 100000                                  # crédito no cartão = positivo
    assert next(l for l in r['linhas'] if 'FARMACIA' in l['descricao'])['valor'] == -8000
    assert all(l['portador'] == 'Pessoa Exemplo (cartão 1234)' for l in r['linhas'])


def test_fatura_de_janeiro_com_compras_de_dezembro():
    r = pdf_bb.ler_texto(fatura_texto(fechamento='26/01/2027', vencimento='05/02/2027', proximo='25/02/2027',
                                      itens=[('Transporte', '30/12', 'UBER', 'BR', '10,00'), ('Transporte', '03/01', 'UBER', 'BR', '12,00')]))
    assert [l['data'] for l in r['linhas']] == [datetime.date(2026, 12, 30), datetime.date(2027, 1, 3)]


def test_soma_que_nao_bate_recusa_o_arquivo():
    with pytest.raises(ErroValidacao, match='não bate|total da fatura'):
        pdf_bb.ler_texto(fatura_texto(total='9.999,99'))


def test_layout_desconhecido_e_valor_ilegivel():
    with pytest.raises(ErroValidacao, match='Ourocard'):
        pdf_bb.ler_texto('Fatura de outro banco\nTotal 10,00')
    texto = fatura_texto().replace('R$ 80,00', 'R$ oitenta')
    with pytest.raises(ErroValidacao, match='valor'):
        pdf_bb.ler_texto(texto)


def _importar(c, card, texto, nome='fatura.pdf'):
    lido = pdf_bb.ler_texto(texto)
    orig = pipeline.ler_arquivo
    pipeline.ler_arquivo = lambda *a, **k: lido
    try:
        return pipeline.preparar(c, card, nome, texto.encode())
    finally:
        pipeline.ler_arquivo = orig


def test_importacao_concilia_com_o_total_do_banco(banco, contas):
    with banco.transacao() as c:
        card = razao.criar_conta(c, 'Ourocard', 'cartao', dia_fechamento=27, dia_vencimento=6)
        c.execute("INSERT INTO pessoas(nome) VALUES('Pessoa')")
        lote, avisos = _importar(c, card, fatura_texto())
        k = cartoes.completo(c, card)
        assert k['regra_fechamento'] == 'atual'                       # ajustado pela fatura (cartão sem movimento)
        assert k['fech_doc'][datetime.date(2026, 12, 27)] == datetime.date(2027, 1, 6)
        ls = c.execute('SELECT * FROM linhas_importacao WHERE lote_id=? ORDER BY ordem', (lote,)).fetchall()
        inicio, fim = cartoes.ciclo(k, datetime.date(2026, 12, 27))
        assert all(inicio.isoformat() <= l['data'] < fim.isoformat() for l in ls)   # tudo dentro do ciclo da fatura
        assert {l['descricao'][:4]: l['data_original'] is not None for l in ls}['LOJA']
        sug = {l['descricao']: l['sugestao'] for l in ls}
        assert sug['IOF - COMPRA NO EXTERIOR'].startswith('cat:') and sug['RESTAURANTE FICTICIO CIDADE'].startswith('cat:')
        assert sug['PGTO. CASH AG. 9999 000000000 200'] == f'fatura:{contas["corrente"]}'
        antigas = c.execute("SELECT id FROM contas WHERE nome='Dívidas antigas e parcelamentos'").fetchone()[0]
        assert sug['PAGTO. PARCEL PARC 02/02 0000000000'] == f'cat:{antigas}'
        operacoes.saldo_inicial(c, card, inicio - datetime.timedelta(days=1), 100000)
        outras = contas['Outras despesas']
        pipeline.aplicar(c, lote, {l['id']: l['sugestao'] or f'cat:{outras}' for l in ls})
        f = cartoes.fatura(c, card, '2026-12-27', hoje='2027-01-02')
        assert f['diferenca'] == 0 and f['vencimento'] == datetime.date(2027, 1, 6)
        assert relatorios.resumo_mes(c, '2026-12')['por_pessoa'][0][0] == 'Pessoa'
        assert razao.verificar_tudo(c) == []
        with pytest.raises(ErroValidacao, match='já foi importado'):
            _importar(c, card, fatura_texto())
        pipeline.desfazer(c, lote)
        assert not cartoes.completo(c, card)['fech_doc']              # desfazer remove as datas vindas da fatura


def test_parcela_lancada_no_app_e_casada_com_a_da_fatura(banco, contas):
    with banco.transacao() as c:
        card = razao.criar_conta(c, 'Ourocard', 'cartao', dia_fechamento=27, dia_vencimento=6, regra_fechamento='atual')
        ids = operacoes.despesa(c, '2026-11-20', 'Loja TV', 100000, contas['Casa nova'], card, parcelas=5)
        lote, _ = _importar(c, card, fatura_texto())
        tv = c.execute("SELECT * FROM linhas_importacao WHERE lote_id=? AND descricao LIKE 'LOJA TV%'", (lote,)).fetchone()
        assert tv['sugestao'] == f'casar:{ids[1]}'                   # parcela 2/5, no mesmo ciclo


def test_fechamento_real_substitui_o_calculado(banco, contas):
    with banco.transacao() as c:
        card = razao.criar_conta(c, 'Ourocard', 'cartao', dia_fechamento=27, dia_vencimento=6, regra_fechamento='atual')
        cartoes.registrar_fechamento(c, card, '2026-11-25', '2026-12-05')
        k = cartoes.completo(c, card)
    assert cartoes.fechamento_da_compra(k, datetime.date(2026, 11, 25)) == datetime.date(2026, 11, 25)   # regra 'atual'
    assert cartoes.fechamento_da_compra(k, datetime.date(2026, 11, 26)) == datetime.date(2026, 12, 27)
    assert cartoes.vencimento(k, datetime.date(2026, 11, 25)) == datetime.date(2026, 12, 5)
    assert cartoes.fechamento_anterior(k, datetime.date(2026, 12, 27)) == datetime.date(2026, 11, 25)


def test_migracao_0001_para_0002_preserva_dados_e_faz_copia(tmp_path, monkeypatch):
    monkeypatch.setenv('FIN404_DATA', str(tmp_path))
    from fin404.dados import banco
    caminho = banco.caminho_banco()
    sql = (banco.MIGRACOES / '0001_razao.sql').read_text(encoding='utf-8')
    c = sqlite3.connect(caminho)
    c.executescript(sql + '\nPRAGMA user_version=1;')
    c.execute("INSERT INTO contas(nome,tipo,subtipo,dia_fechamento,dia_vencimento) VALUES('Velho','passivo','cartao',5,12)")
    c.commit(); c.close()
    banco.migrar()
    assert banco.versao() == max(n for n, _ in banco.migracoes_disponiveis()) >= 3
    with banco.conexao() as c:
        k = c.execute("SELECT * FROM contas WHERE nome='Velho'").fetchone()
        assert k['regra_fechamento'] == 'proxima'
        assert c.execute("SELECT COUNT(*) FROM contas WHERE nome='Dívidas antigas e parcelamentos'").fetchone()[0] == 1
    assert list((tmp_path / 'copias_pre_migracao').glob('antes_v*_*.sqlite3'))


def test_pdf_real_gerado_passa_pelo_leitor_de_pdf():
    pymupdf = pytest.importorskip('pymupdf')
    doc = pymupdf.open()
    texto = fatura_texto()
    pagina = doc.new_page(width=595, height=842 * 3)
    y = 20
    for linha in texto.split('\n'):
        pagina.insert_text((30, y), linha, fontsize=7)
        y += 9
    dados = doc.tobytes(); doc.close()
    r = pipeline.ler_arquivo('fatura.pdf', dados)
    assert r['formato'] == 'pdf-bb' and len(r['linhas']) == 11
    with pytest.raises(ErroValidacao, match='Layout de PDF não reconhecido'):
        outro = pymupdf.open(); p = outro.new_page(); p.insert_text((30, 30), 'Fatura de outro banco ' * 5)
        pipeline.ler_arquivo('x.pdf', outro.tobytes())


def test_parcelas_futuras_projetadas_a_partir_da_fatura(banco, contas):
    """Só com a fatura: as linhas 'PARC k/n' geram as parcelas que faltam, conferidas com o saldo parcelado do banco."""
    with banco.transacao() as c:
        card = razao.criar_conta(c, 'Ourocard', 'cartao', dia_fechamento=27, dia_vencimento=6, regra_fechamento='atual')
        lote, _ = _importar(c, card, fatura_texto())
        assert pipeline.projecao_parcelas(c, lote) == 60000                     # LOJA TV 02/05: faltam 3 x 200; anuidade não entra
        ls = c.execute('SELECT * FROM linhas_importacao WHERE lote_id=?', (lote,)).fetchall()
        pipeline.aplicar(c, lote, {l['id']: l['sugestao'] or f'cat:{contas["Casa nova"]}' for l in ls})
        futuras = c.execute("SELECT * FROM transacoes WHERE descricao LIKE 'LOJA TV%' ORDER BY parcela_n").fetchall()
        assert [t['parcela_n'] for t in futuras] == [2, 3, 4, 5]
        k = cartoes.completo(c, card)
        fechs = [cartoes.fechamento_da_compra(k, t['data']) for t in futuras]
        assert fechs[0] == datetime.date(2026, 12, 27) and len(set(fechs)) == 4      # uma por fatura, a partir desta
        assert not c.execute("SELECT 1 FROM transacoes WHERE descricao LIKE 'ANUIDADE%' AND parcela_n>4").fetchone()
        assert not c.execute("SELECT 1 FROM transacoes WHERE descricao LIKE 'LOJA MOVEIS%(11/10)'").fetchone()
        comp = relatorios.compromissos(c, 6, hoje='2027-01-02')
        # Em 02/01/2027: a fatura que fechou 27/12 vence 06/01 (TV 2/5 + última parcela dos móveis 10/10 = 500);
        # depois TV 3/5, 4/5 e 5/5, cada uma no mês do vencimento da sua fatura.
        assert [comp[m]['parcelas'] for m in ('2027-01', '2027-02', '2027-03', '2027-04', '2027-05')] == [50000, 20000, 20000, 20000, 0]
        # Fatura seguinte: a parcela 03/05 é casada com a projetada, não duplicada.
        texto2 = fatura_texto(fechamento='26/01/2027', vencimento='05/02/2027', proximo='25/02/2027', parcelado='400,00',
                              itens=[('Compras parceladas', '20/11', 'LOJA TV PARC 03/05 CIDADE', 'BR', '200,00')])
        lote2, _ = _importar(c, card, texto2, 'fatura2.pdf')
        linha = c.execute('SELECT * FROM linhas_importacao WHERE lote_id=?', (lote2,)).fetchone()
        assert linha['sugestao'] == f'casar:{futuras[1]["id"]}'
        pipeline.aplicar(c, lote2, {linha['id']: linha['sugestao']})
        assert c.execute("SELECT COUNT(*) FROM transacoes WHERE descricao LIKE 'LOJA TV%'").fetchone()[0] == 4
        # Desfazer a primeira importação apaga a parcela lida e as projetadas; sobra nada da LOJA TV.
        pipeline.desfazer(c, lote2)
        pipeline.desfazer(c, lote)
        assert c.execute("SELECT COUNT(*) FROM transacoes WHERE descricao LIKE 'LOJA TV%'").fetchone()[0] == 0
        assert c.execute('SELECT COUNT(*) FROM planos_parcelas').fetchone()[0] == 0
        assert razao.verificar_tudo(c) == []


def test_parcela_antecipada_e_detectada_e_o_plano_encerrado(banco, contas):
    """A fatura seguinte não traz a parcela 03/05 (antecipada): o sistema aponta, e encerrar tira 3, 4 e 5 sem tocar na 2."""
    with banco.transacao() as c:
        card = razao.criar_conta(c, 'Ourocard', 'cartao', dia_fechamento=27, dia_vencimento=6, regra_fechamento='atual')
        lote, _ = _importar(c, card, fatura_texto())
        ls = c.execute('SELECT * FROM linhas_importacao WHERE lote_id=?', (lote,)).fetchall()
        pipeline.aplicar(c, lote, {l['id']: l['sugestao'] or f'cat:{contas["Casa nova"]}' for l in ls})
        assert cartoes.parcelas_ausentes(c) == []
        texto2 = fatura_texto(fechamento='26/01/2027', vencimento='05/02/2027', proximo='25/02/2027', parcelado='0,00',
                              itens=[('Outros lançamentos', '10/01', 'ANTECIPACAO LOJA TV CIDADE', 'BR', '570,00')])
        lote2, _ = _importar(c, card, texto2, 'fatura2.pdf')
        em_revisao = cartoes.parcelas_ausentes(c, lote2)
        assert [(x['parcela_n'], x['valor']) for x in em_revisao] == [(3, 20000)]
        linha = c.execute('SELECT * FROM linhas_importacao WHERE lote_id=?', (lote2,)).fetchone()
        pipeline.aplicar(c, lote2, {linha['id']: f'cat:{contas["Casa nova"]}'})
        ausentes = cartoes.parcelas_ausentes(c)
        assert [x['parcela_n'] for x in ausentes] == [3]
        assert any('não vieram na fatura' in t for _, t, _ in relatorios.alertas(c, '2027-01-27'))
        plano = ausentes[0]['plano_id']
        n = cartoes.encerrar_parcelamento(c, plano, 'antecipado', a_partir_de=3, hoje='2027-01-27')
        assert n == 3
        restantes = [t['parcela_n'] for t in c.execute("SELECT parcela_n FROM transacoes WHERE descricao LIKE 'LOJA TV%' ORDER BY parcela_n")]
        assert restantes == [2]                                                   # a que veio na fatura fica
        assert cartoes.parcelas_ausentes(c) == []
        assert len(razao.lixeira(c)) == 3
        comp = relatorios.compromissos(c, 6, hoje='2027-01-27')
        assert all(v['parcelas'] == 0 for m, v in comp.items() if m >= '2027-03')
        with pytest.raises(ErroValidacao):
            cartoes.encerrar_parcelamento(c, plano, 'antecipado')
        assert razao.verificar_tudo(c) == []


def test_encerrar_compra_parcelada_lancada_a_mao(banco, contas):
    with banco.transacao() as c:
        cartoes.compra(c, contas['cartao'], datetime.date(2026, 9, 10), 'GELADEIRA', 300000, contas['Casa nova'], parcelas=10)
        plano = c.execute('SELECT id FROM planos_parcelas').fetchone()[0]
        p = cartoes.planos(c, '2026-11-20')[0]
        assert p['n_futuras'] == 7 and p['restante'] == 210000          # 10/09, 10/10 e 10/11 já passaram
        with pytest.raises(ErroValidacao):
            cartoes.encerrar_parcelamento(c, plano, 'xyz')
        assert cartoes.encerrar_parcelamento(c, plano, 'cancelado', hoje='2026-11-20') == 7
        assert cartoes.planos(c, '2026-11-20') == []
        enc = cartoes.planos(c, '2026-11-20', incluir_encerrados=True)[0]
        assert enc['motivo_encerramento'] == 'cancelado' and len(enc['parcelas']) == 3


def _pdf(texto):
    import pymupdf
    doc = pymupdf.open()
    pagina, y = doc.new_page(), 30
    for linha in texto.splitlines():
        if y > 800:
            pagina, y = doc.new_page(), 30
        pagina.insert_text((30, y), linha, fontsize=7)
        y += 9
    return doc.tobytes()


def test_cartao_novo_criado_a_partir_da_fatura(banco):
    dados = _pdf(fatura_texto())
    with banco.transacao() as c:
        k = pipeline.criar_cartao_da_fatura(c, 'fatura.pdf', dados)
        cartao = cartoes.completo(c, k)
        assert (cartao['nome'], cartao['dia_fechamento'], cartao['dia_vencimento'], cartao['regra_fechamento']) == ('Ourocard', 27, 6, 'atual')
        lote, _ = pipeline.preparar(c, k, 'fatura.pdf', dados)
        assert lote
        assert razao.conta(c, pipeline.criar_cartao_da_fatura(c, 'f2.pdf', dados))['nome'] == 'Ourocard 2'   # não repete o nome
        with pytest.raises(ErroValidacao, match='só funciona com a fatura em PDF'):
            pipeline.criar_cartao_da_fatura(c, 'extrato.ofx', b'OFXHEADER:100')


@pytest.mark.parametrize('n', [2, 3, 10, 24])
def test_encerrar_parcelamento_invariantes_em_todas_as_posicoes(banco, contas, n):
    """Para cada parcela de corte (e para "só as futuras"): o que sai + o que fica = valor da compra; a dívida do cartão
    passa a ser exatamente o que ficou; o razão continua fechado; o plano não encerra duas vezes."""
    hoje = datetime.date(2026, 11, 20)
    total = 123457 * n + n - 1                                   # valor que não divide exato: testa o resto na 1ª parcela
    for corte in [None] + list(range(1, n + 1)):
        with banco.transacao() as c:
            card = razao.criar_conta(c, f'Cartão {n}-{corte}', 'cartao', dia_fechamento=5, dia_vencimento=12)
            cartoes.compra(c, card, datetime.date(2026, 9, 10), 'COMPRA', total, contas['Casa nova'], parcelas=n)
            plano = c.execute('SELECT id FROM planos_parcelas WHERE conta_cartao_id=?', (card,)).fetchone()[0]
            antes = cartoes.parcelas_do_plano(c, plano, hoje)
            assert sum(x['valor'] for x in antes) == total
            esperados = [x for x in antes if (x['situacao'] == 'futura' if corte is None else x['parcela_n'] >= corte)]
            if not esperados:
                with pytest.raises(ErroValidacao, match='Não há parcelas'):
                    cartoes.encerrar_parcelamento(c, plano, 'antecipado', a_partir_de=corte, hoje=hoje)
                continue
            assert cartoes.encerrar_parcelamento(c, plano, 'antecipado', a_partir_de=corte, hoje=hoje) == len(esperados)
            ficou = c.execute('SELECT COALESCE(SUM(valor_centavos),0) FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id '
                              'WHERE t.plano_id=? AND l.conta_id=?', (plano, card)).fetchone()[0]
            assert -ficou + sum(x['valor'] for x in esperados) == total
            assert razao.saldo(c, card) == ficou
            assert razao.verificar_tudo(c) == []
            with pytest.raises(ErroValidacao, match='já foi encerrado'):
                cartoes.encerrar_parcelamento(c, plano, 'antecipado', hoje=hoje)


def test_minimo_vem_do_pdf_da_propria_fatura(banco, contas):
    """R4: o mínimo exibido no pagamento é o do PDF daquela fatura; outra fatura (ou fatura não importada) não tem mínimo."""
    with banco.transacao() as c:
        card = razao.criar_conta(c, 'Ourocard', 'cartao', dia_fechamento=27, dia_vencimento=6)
        lote, _ = _importar(c, card, fatura_texto())
        info = c.execute('SELECT fatura_info FROM lotes_importacao WHERE id=?', (lote,)).fetchone()[0]
        import json
        assert json.loads(info).get('minimo') == 12345
        assert cartoes.minimo_da_fatura(c, card, datetime.date(2026, 12, 27)) == 12345
        assert cartoes.minimo_da_fatura(c, card, datetime.date(2026, 11, 27)) is None
        pipeline.desfazer(c, lote)
        assert cartoes.minimo_da_fatura(c, card, datetime.date(2026, 12, 27)) is None
