"""alpha.31: categoria/conta em lote e mover compra parcelada para outro cartão."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import cartoes, operacoes, razao
from fin404.web import pg_lancamentos
from fin404.web.servidor import Redirecionar, Requisicao


def _contas_de(c, tid):
    return {x['conta_id'] for x in razao.lancamentos_de(c, tid)}


def test_categoria_e_conta_em_lote(banco, contas):
    with banco.transacao() as c:
        [a] = operacoes.despesa(c, date(2026, 10, 3), 'Padaria', 1200, contas['Mercado'], contas['corrente'])
        [b] = operacoes.despesa(c, date(2026, 10, 4), 'Feira', 3400, contas['Mercado'], contas['corrente'], status='agendada')
        r = operacoes.receita(c, date(2026, 10, 5), 'Salário', 500000, contas['Salário'], contas['corrente'])
        ps = cartoes.compra(c, contas['cartao'], date(2026, 10, 6), 'Sofá', 90000, contas['Casa nova'], parcelas=3)
        feitos, pulados = operacoes.editar_em_lote(c, [a, b, r, ps[0]], contas['Restaurantes e delivery'], None)
        assert feitos == 3 and [p[0] for p in pulados] == [r]          # receita não recebe categoria de despesa
        assert contas['Restaurantes e delivery'] in _contas_de(c, a) and contas['Restaurantes e delivery'] in _contas_de(c, ps[0])
        feitos, pulados = operacoes.editar_em_lote(c, [a, b, ps[1]], None, contas['dinheiro'])
        assert feitos == 2 and pulados[0][0] == ps[1]                   # parcela usa "mover"
        assert contas['dinheiro'] in _contas_de(c, a) and contas['corrente'] not in _contas_de(c, b)
        with pytest.raises(ErroValidacao):
            operacoes.editar_em_lote(c, [a], None, None)
        c.execute("INSERT INTO meses_fechados(mes, fechado_em) VALUES('2026-10', '2026-11-01')")
        feitos, pulados = operacoes.editar_em_lote(c, [a], contas['Mercado'], None)
        assert feitos == 0 and len(pulados) == 1                        # mês fechado: fica como estava, sem meia alteração
        assert contas['Restaurantes e delivery'] in _contas_de(c, a)


def test_lote_pela_tela_e_situacao_nao_quebra_no_cartao(banco, contas):
    with banco.transacao() as c:
        [a] = operacoes.despesa(c, date(2026, 10, 3), 'Padaria', 1200, contas['Mercado'], contas['corrente'])
        [k] = cartoes.compra(c, contas['cartao'], date(2026, 10, 6), 'Camisa', 9000, contas['Vestuário'])
    html = pg_lancamentos.lancamentos(Requisicao('GET', '/lancamentos', {'mes': ['2026-10']}, {}, {}, (), ''))[2].decode()
    assert f'name="ids" value="{k}"' in html and 'Trocar categoria / conta' in html
    form = {'ids': [str(a), str(k)], 'situacao': ['a_pagar'], 'volta': ['/lancamentos?mes=2026-10']}
    with pytest.raises(Redirecionar) as r:
        pg_lancamentos.lancamentos_situacao(Requisicao('POST', '/lancamentos/situacao', {}, form, {}, (), ''))
    assert 'ficaram como estavam' in r.value.destino or 'ficaram' in r.value.destino
    with banco.conexao() as c:
        assert razao.transacao(c, a)['status'] == 'agendada' and razao.transacao(c, k)['status'] == 'confirmada'
    form = {'ids': [str(a), str(k)], 'situacao': ['editar'], 'categoria_lote': [str(contas['Outras despesas'])], 'conta_lote': ['']}
    with pytest.raises(Redirecionar):
        pg_lancamentos.lancamentos_situacao(Requisicao('POST', '/lancamentos/situacao', {}, form, {}, (), ''))
    with banco.conexao() as c:
        assert contas['Outras despesas'] in _contas_de(c, a) and contas['Outras despesas'] in _contas_de(c, k)


def test_mover_compra_parcelada(banco, contas):
    with banco.transacao() as c:
        outro = razao.criar_conta(c, 'Cartão Dois', 'cartao', dia_fechamento=20, dia_vencimento=28, limite_centavos=500_000)
        ps = cartoes.compra(c, contas['cartao'], date(2026, 10, 10), 'Geladeira', 300000, contas['Casa nova'], parcelas=3)
        antes = [razao.transacao(c, i)['data'] for i in ps]
        msg = operacoes.mover_parcelas(c, ps[1], outro)
        assert '3 parcela' in msg
        for i in ps:
            assert outro in _contas_de(c, i) and contas['cartao'] not in _contas_de(c, i)
        depois = [razao.transacao(c, i)['data'] for i in ps]
        assert depois == [cartoes.data_da_parcela(cartoes.completo(c, outro), '2026-10-10', n).isoformat() for n in (1, 2, 3)]
        assert c.execute('SELECT conta_cartao_id FROM planos_parcelas WHERE id=?', (razao.transacao(c, ps[0])['plano_id'],)).fetchone()[0] == outro
        with pytest.raises(ErroValidacao, match='já está'):
            operacoes.mover_parcelas(c, ps[0], outro)
        with pytest.raises(ErroValidacao, match='cartão'):
            operacoes.mover_parcelas(c, ps[0], contas['corrente'])
        c.execute("INSERT INTO meses_fechados(mes, fechado_em) VALUES(?, '2026-12-01')", (depois[0][:7],))
        with pytest.raises(ErroValidacao, match='mês fechado'):
            operacoes.mover_parcelas(c, ps[0], contas['cartao'])
    html = pg_lancamentos.lancamento(Requisicao('GET', f'/lancamentos/{ps[2]}', {}, {}, {}, (str(ps[2]),), ''))[2].decode()
    assert 'Mover a compra para outro cartão' in html and 'Cartão Inter' in html


def test_busca_avisa_que_esta_so_no_mes(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 7, 3), 'Netflix', 5590, contas['Assinaturas'], contas['corrente'])
    html = pg_lancamentos.lancamentos(Requisicao('GET', '/lancamentos', {'mes': ['2026-10'], 'busca': ['Netflix']}, {}, {}, (), ''))[2].decode()
    assert 'Procurar em todos os meses' in html and 'busca=Netflix&amp;mes=' in html
    html = pg_lancamentos.lancamentos(Requisicao('GET', '/lancamentos', {'mes': [''], 'busca': ['Netflix']}, {}, {}, (), ''))[2].decode()
    assert '/lancamentos/' in html and 'Procurar em todos os meses' not in html and '>Netflix<' in html


def test_parametro_vazio_fica_na_consulta_mas_q_usa_padrao():
    import urllib.parse
    r = Requisicao('GET', '/x', urllib.parse.parse_qs('mes=&ver=', keep_blank_values=True), {}, {}, (), '')
    assert 'mes' in r.consulta and r.q('mes') == '' and r.q('ver', 'fatura') == 'fatura'
