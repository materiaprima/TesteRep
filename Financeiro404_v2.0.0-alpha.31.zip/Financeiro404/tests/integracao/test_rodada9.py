"""Lançar em lote, dividir por categoria, tags, anexos, evolução e folga."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import analises, anexos, lote, operacoes, razao, relatorios, tags


# ------------------------------------------------------------------ texto em lote

@pytest.mark.parametrize('linha, esperado', [
    ('18,50 padaria pix', ('2026-11-06', 1850, 'padaria', 'pix', 'despesa')),
    ('padaria 18,50', ('2026-11-06', 1850, 'padaria', None, 'despesa')),
    ('05/11 uber 23,90 crédito', ('2026-11-05', 2390, 'uber', 'credito', 'despesa')),
    ('ontem farmácia 32,90', ('2026-11-05', 3290, 'farmácia', None, 'despesa')),
    ('+500 freela pix', ('2026-11-06', 50000, 'freela', 'pix', 'receita')),
    ('R$ 1.234,56 aluguel boleto', ('2026-11-06', 123456, 'aluguel', 'boleto', 'despesa')),
    ('28/12 presente 50', ('2025-12-28', 5000, 'presente', None, 'despesa')),   # dezembro anotado em novembro = ano passado
    ('2x pastel 12', ('2026-11-06', 1200, '2x pastel', None, 'despesa')),
    ('vr 32 almoço', ('2026-11-06', 3200, 'almoço', 'beneficio', 'despesa')),
])
def test_interpretar_linha(linha, esperado):
    r = lote.interpretar_linha(linha, date(2026, 11, 6))
    assert (r['data'].isoformat(), r['valor'], r['descricao'], r['forma'], r['tipo']) == esperado and r['erro'] is None


def test_interpretar_erros_e_limites():
    r = lote.interpretar('só texto\n\n 12 \n', date(2026, 11, 6))
    assert [x['erro'] for x in r] == ['sem valor', 'sem descrição']
    with pytest.raises(ErroValidacao):
        lote.interpretar('   ')
    with pytest.raises(ErroValidacao):
        lote.interpretar('\n'.join(['1 a'] * 201))


# ------------------------------------------------------------------ dividir

def test_dividir_despesa_em_categorias_e_juntar_de_novo(banco, contas):
    with banco.transacao() as c:
        [t] = operacoes.despesa(c, date(2026, 11, 2), 'SUPERMERCADO', 30000, contas['Mercado'], contas['corrente'])
        farm = c.execute("SELECT id FROM contas WHERE nome='Farmácia e remédios'").fetchone()[0]
        with pytest.raises(ErroValidacao, match='faltam R\\$ 100,00'):
            razao.dividir(c, t, [(contas['Mercado'], 15000), (farm, 5000)])
        with pytest.raises(ErroValidacao, match='categorias de despesa'):
            razao.dividir(c, t, [(contas['Mercado'], 20000), (contas['corrente'], 10000)])
        assert razao.dividir(c, t, [(contas['Mercado'], 22000), (farm, 8000)]) == 2
        m = dict((n, v) for _, n, v in relatorios.resumo_mes(c, '2026-11')['despesas'])
        assert m['Mercado'] == 22000 and m['Farmácia e remédios'] == 8000
        assert razao.saldo(c, contas['corrente']) == -30000
        with pytest.raises(ErroValidacao, match='Estorno automático'):
            razao.estornar(c, t, 1000, date(2026, 11, 3))
        assert razao.dividir(c, t, [(contas['Mercado'], 30000)]) == 1     # juntar de novo
        assert razao.verificar_tudo(c) == []


# ------------------------------------------------------------------ tags

def test_tags_definir_filtrar_listar_e_sobreviver_a_lixeira(banco, contas):
    with banco.transacao() as c:
        [a] = operacoes.despesa(c, date(2026, 7, 2), 'HOTEL', 80000, contas['Moradia'], contas['corrente'])
        [b] = operacoes.despesa(c, date(2026, 7, 3), 'RESTAURANTE', 12000, contas['Restaurantes e delivery'], contas['corrente'])
        assert tags.definir(c, a, 'Viagem, praia, viagem') == ['Viagem', 'praia']
        tags.adicionar(c, [b], 'VIAGEM')
        lista = {t['nome']: t for t in tags.listar(c)}
        assert lista['Viagem']['n'] == 2 and lista['Viagem']['despesas'] == 92000 and lista['praia']['n'] == 1
        razao.excluir(c, a)
        aud = razao.lixeira(c)[0]['auditoria_id']
        novo = razao.restaurar(c, aud)
        assert tags.de(c, novo) == ['praia', 'Viagem']
        pid = lista['praia']['id']
        tags.renomear(c, pid, 'viagem')   # junta com a existente
        assert [t['nome'] for t in tags.listar(c)] == ['Viagem']
        with pytest.raises(ErroValidacao):
            tags.separar('x' * 41)


# ------------------------------------------------------------------ anexos

PDF = b'%PDF-1.4\n%fake\n'
PNG = b'\x89PNG\r\n\x1a\n' + b'0' * 20


def test_anexos_validam_tipo_tamanho_e_somem_com_o_lancamento(banco, contas):
    with banco.transacao() as c:
        [t] = operacoes.despesa(c, date(2026, 11, 2), 'CONSULTA', 30000, contas['Mercado'], contas['corrente'])
        a1 = anexos.adicionar(c, t, 'recibo.pdf', PDF)
        anexos.adicionar(c, t, r'C:\\fotos\\nota.png', PNG)
        assert [x['nome'] for x in anexos.listar(c, t)] == ['recibo.pdf', 'nota.png']
        assert bytes(anexos.obter(c, a1)['dados']) == PDF
        for nome, dados in (('x.html', b'<html>'), ('x.pdf', b'<html>'), ('x.exe', PDF), ('vazio.pdf', b'')):
            with pytest.raises(ErroValidacao):
                anexos.adicionar(c, t, nome, dados)
        with pytest.raises(ErroValidacao, match='já está anexado'):
            anexos.adicionar(c, t, 'de-novo.pdf', PDF)
        with pytest.raises(ErroValidacao, match='8 MB'):
            anexos.adicionar(c, t, 'grande.pdf', PDF + b'0' * 8_000_000)
        razao.excluir(c, t)
        assert c.execute('SELECT COUNT(*) FROM anexos').fetchone()[0] == 0


# ------------------------------------------------------------------ evolução e folga

def test_evolucao_mensal_e_folga(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], date(2026, 8, 1), 300000)
        for m in (8, 9, 10):
            operacoes.receita(c, date(2026, m, 5), 'SALARIO', 500000, contas['Salário'], contas['corrente'])
            operacoes.despesa(c, date(2026, m, 6), 'ALUGUEL', 300000, contas['Moradia'], contas['corrente'])
        ev = analises.evolucao(c, date(2026, 10, 31), meses=4)
        assert ev['meses'] == ['2026-07', '2026-08', '2026-09', '2026-10']
        assert ev['disponivel'] == [0, 500000, 700000, 900000]
        assert ev['entradas'] == [0, 500000, 500000, 500000] and ev['saidas'] == [0, 300000, 300000, 300000]
        assert ev['categorias'][0] == ('Moradia', [0, 300000, 300000, 300000])
        f = analises.folga_dias(c, date(2026, 10, 31))
        # 9.000 disponíveis; 9.000 gastos desde a 1ª despesa (06/08 a 31/10 = 87 dias) → 87 dias de folga
        assert f['janela'] == 87 and f['gasto_dia'] == 900000 // 87 and f['dias'] == 87


def test_grafico_svg_sem_estilo_inline():
    from fin404.web.componentes import grafico_linhas
    svg = grafico_linhas(['jan/26', 'fev/26', 'mar/26'], [('A', [100000, -50000, 2500000]), ('B <x>', [0, 0, 0])])
    assert '<svg' in svg and 'style=' not in svg and '<script' not in svg and 'B &lt;x&gt;' in svg
    assert 'R$ 25.000,00' in svg   # valor exato no título do ponto
    assert grafico_linhas([], []).startswith('<div class="vazio"')


# ------------------------------------------------------------------ mais opções: frequências, parcelas fora do cartão, formas, cheque especial

def _datas(c, desc):
    return [r[0] for r in c.execute("SELECT data FROM transacoes WHERE descricao=? AND status='agendada' ORDER BY data", (desc,))]


def test_frequencias_das_previsoes(banco, contas):
    hoje = date(2026, 11, 6)
    with banco.transacao() as c:
        operacoes.criar_previsao(c, 'DIARISTA', 15000, contas['corrente'], contas['Moradia'], 'saida', 1, '2026-11',
                                 periodicidade='semanal', data_base='2026-10-30')          # sexta-feira, já passou
        operacoes.criar_previsao(c, 'MESADA', 5000, contas['corrente'], contas['Moradia'], 'saida', 1, '2026-11',
                                 periodicidade='quinzenal', data_base='2026-11-10')
        operacoes.criar_previsao(c, 'SEGURO', 60000, contas['corrente'], contas['Moradia'], 'saida', 20, '2026-12',
                                 periodicidade='semestral')
        operacoes.criar_previsao(c, 'ACADEMIA', 30000, contas['corrente'], contas['Moradia'], 'saida', 10, '2026-11',
                                 periodicidade='trimestral')
        with pytest.raises(ErroValidacao, match='primeira vez'):
            operacoes.criar_previsao(c, 'X', 100, contas['corrente'], contas['Moradia'], 'saida', 1, '2026-11', periodicidade='semanal')
        with pytest.raises(ErroValidacao):
            operacoes.criar_previsao(c, 'X', 100, contas['corrente'], contas['Moradia'], 'saida', 1, '2026-11', periodicidade='diaria')
        operacoes.gerar_previsoes(c, '2027-06', hoje=hoje)
        operacoes.gerar_previsoes(c, '2027-06', hoje=hoje)   # idempotente
        diarista = _datas(c, 'DIARISTA')
        assert diarista[:3] == ['2026-11-06', '2026-11-13', '2026-11-20'] and len(set(diarista)) == len(diarista)
        assert _datas(c, 'MESADA')[:3] == ['2026-11-10', '2026-11-24', '2026-12-08']
        assert _datas(c, 'SEGURO') == ['2026-12-20', '2027-06-20']
        assert _datas(c, 'ACADEMIA') == ['2026-11-10', '2027-02-10', '2027-05-10']
        prov = operacoes.provisoes_anuais(c)
        assert {x['descricao'] for x in prov['itens']} == {'SEGURO', 'ACADEMIA'}
        assert prov['total_ano'] == 60000 * 2 + 30000 * 4 and prov['por_mes'] == 20000


def test_repetir_semanal_e_dividido_nao_repete(banco, contas):
    with banco.transacao() as c:
        [t] = operacoes.despesa(c, date(2026, 11, 6), 'FEIRA', 8000, contas['Mercado'], contas['corrente'])
        operacoes.repetir(c, t, 'semanal', hoje=date(2026, 11, 6))
        assert _datas(c, 'FEIRA')[:2] == ['2026-11-13', '2026-11-20']
        farm = c.execute("SELECT id FROM contas WHERE nome='Farmácia e remédios'").fetchone()[0]
        [t2] = operacoes.despesa(c, date(2026, 11, 6), 'NOTA', 8000, contas['Mercado'], contas['corrente'])
        razao.dividir(c, t2, [(contas['Mercado'], 5000), (farm, 3000)])
        with pytest.raises(ErroValidacao, match='dividido'):
            operacoes.repetir(c, t2, 'mensal')


def test_parcelado_no_carne_fora_do_cartao(banco, contas):
    from fin404.dominio import cartoes
    with banco.transacao() as c:
        ids = operacoes.despesa(c, date(2026, 1, 31), 'SOFA CARNE', 100000, contas['Moradia'], contas['corrente'], parcelas=3)
        ts = [razao.transacao(c, i) for i in ids]
        assert [(t['data'], t['status']) for t in ts] == [('2026-01-31', 'confirmada'), ('2026-02-28', 'agendada'), ('2026-03-31', 'agendada')]
        assert razao.saldo(c, contas['corrente']) == -33334      # só a 1ª saiu
        plano = cartoes.planos(c, '2026-02-01')[0]
        assert plano['n_futuras'] == 2 and plano['restante'] == 66666
        assert razao.verificar_tudo(c) == []


def test_cheque_especial_e_novas_formas(banco, contas):
    with banco.transacao() as c:
        [t] = operacoes.despesa(c, date(2026, 11, 2), 'BOLETO', 5000, contas['Moradia'], contas['corrente'])
        assert any('cheque especial' in x for _, x, _ in relatorios.alertas(c, date(2026, 11, 3)))
        operacoes.definir_forma(c, [t], 'crediario')
        assert razao.transacao(c, t)['meio_pagamento'] == 'crediario'
        nomes = {r[0] for r in c.execute("SELECT nome FROM contas WHERE subtipo='categoria'")}
        assert {'Contas da casa', 'Pets', 'Trabalhos extras', 'Restituição do Imposto de Renda'} <= nomes
        from fin404.dominio import categorias
        cid = categorias.inferir(c, 'CPFL ENERGIA')[0]
        assert c.execute('SELECT nome FROM contas WHERE id=?', (cid,)).fetchone()[0] == 'Contas da casa'
    assert lote.interpretar_linha('120 tênis carnê', date(2026, 11, 6))['forma'] == 'crediario'
