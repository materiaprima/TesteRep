"""'Quanto gastei em outubro?' pelos três jeitos de olhar (pedido do uso real: o mês parecia bagunçado).
Cartão do fixture: fecha dia 5, vence dia 12."""
from datetime import date

from fin404.dominio import cartoes, operacoes, relatorios


def _cenario(c, contas):
    operacoes.despesa(c, date(2026, 9, 20), 'COMPRA SETEMBRO', 10000, contas['Mercado'], contas['cartao'])   # fatura fecha 05/10
    operacoes.despesa(c, date(2026, 10, 3), 'COMPRA 3 OUT', 20000, contas['Vestuário'], contas['cartao'])    # fatura fecha 05/10
    operacoes.despesa(c, date(2026, 10, 20), 'COMPRA 20 OUT', 40000, contas['Mercado'], contas['cartao'])    # fatura fecha 05/11
    operacoes.despesa(c, date(2026, 10, 15), 'PIX FEIRA', 5000, contas['Mercado'], contas['corrente'])
    cartoes.pagar(c, contas['corrente'], contas['cartao'], 30000, date(2026, 10, 12))                       # paga a fatura de 05/10


def test_tres_jeitos_de_olhar_outubro(banco, contas):
    with banco.transacao() as c:
        _cenario(c, contas)
        fat = relatorios.gastos_do_mes(c, '2026-10', 'fatura')
        compra = relatorios.gastos_do_mes(c, '2026-10', 'compra')
        caixa = relatorios.gastos_do_mes(c, '2026-10', 'caixa')
    # pela fatura: a que fechou em 05/10 (compras de 05/09 a 04/10) + o Pix
    assert fat['total'] == 10000 + 20000 + 5000
    assert dict(fat['subtotais']) == {'Cartão Inter': 30000, 'Fora do cartão': 5000}
    assert 'fechou em 05/10' in fat['explica'][0]
    # pela data da compra: 03/10, 20/10 e o Pix
    assert compra['total'] == 20000 + 40000 + 5000
    # pelo dinheiro que saiu: o Pix e o pagamento da fatura
    assert caixa['total'] == 5000 + 30000 and caixa['pagamentos'] == [('Cartão Inter', 30000, 1)]
    assert {x['nome']: x['v'] for x in compra['categorias']} == {'Mercado': 45000, 'Vestuário': 20000}


def test_avisa_o_que_falta_chegar_e_lista_itens(banco, contas):
    with banco.transacao() as c:
        _cenario(c, contas)
        lote = c.execute("INSERT INTO lotes_importacao(conta_id, formato, arquivo, sha256, fatura_fechamento) VALUES(?,?,?,?,?)",
                         (contas['cartao'], 'pdf_bb', 'f.pdf', 'x', '2026-10-05')).lastrowid
        compra = relatorios.gastos_do_mes(c, '2026-10', 'compra')
        assert any('05/10 a 31/10' in f and '05/11/2026' in f for f in compra['faltando'])
        assert relatorios.gastos_do_mes(c, '2026-10', 'fatura')['faltando'] == []
        assert relatorios.gastos_do_mes(c, '2026-11', 'fatura')['faltando']        # a de 05/11 não veio
        c.execute("UPDATE lotes_importacao SET desfeito_em='x' WHERE id=?", (lote,))
        itens = relatorios.gastos_itens(c, '2026-10', 'fatura', contas['Mercado'])
        assert [t['descricao'] for t in itens] == ['COMPRA SETEMBRO', 'PIX FEIRA']


def test_conta_a_pagar_nao_entra_ate_ser_paga(banco, contas):
    """Lançamento 'a pagar' (previsto): não conta como gasto até ser marcado como pago."""
    from fin404.dominio import razao
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 10, 10), 'CONTA DE LUZ', 18000, contas['Moradia'], contas['corrente'], status='agendada')
        assert relatorios.gastos_do_mes(c, '2026-10', 'fatura')['total'] == 0
        operacoes.confirmar_previsto(c, tid, 18500, '2026-10-12')
        assert razao.transacao(c, tid)['status'] == 'confirmada'
        assert relatorios.gastos_do_mes(c, '2026-10', 'fatura')['total'] == 18500


def test_periodo_de_varios_meses(banco, contas):
    from fin404.web import pg_relatorios
    from fin404.web.servidor import Requisicao
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 8, 10), 'Mercado ago', 10000, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, date(2026, 9, 10), 'Mercado set', 20000, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, date(2026, 10, 10), 'Luz out', 5000, contas['Moradia'], contas['corrente'])
        r = relatorios.gastos_periodo(c, '2026-08', '2026-10', 'compra')
        assert r['total'] == 35000 and r['meses'] == [('2026-08', 10000), ('2026-09', 20000), ('2026-10', 5000)]
        assert [x['v'] for x in r['categorias']] == [30000, 5000]
        assert relatorios.gastos_periodo(c, '2026-10', '2026-08', 'compra')['total'] == 35000      # ordem invertida
        assert len(relatorios.gastos_itens(c, '2026-08', 'compra', contas['Mercado'], '2026-10')) == 2
        assert relatorios.gastos_periodo(c, '2026-09', '2026-09', 'compra')['total'] == 20000
    html = pg_relatorios.gastos_mes(Requisicao('GET', '/gastos', {'mes': ['2026-08'], 'ate': ['2026-10'], 'ver': ['compra']}, {}, {}, (), ''))[2].decode()
    assert 'Mês a mês' in html and 'Média por mês' in html and 'ate=2026-10' in html
