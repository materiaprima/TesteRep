"""Pipeline de importação: staging, casamento, revisão, idempotência, formatos cruzados e falha segura."""
from pathlib import Path

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import cartoes, operacoes, razao, relatorios
from fin404.importacao import pipeline

FIX = Path(__file__).resolve().parents[1] / 'fixtures'


def ler(nome):
    return (FIX / nome).read_bytes()


def linhas(c, lote):
    return c.execute('SELECT * FROM linhas_importacao WHERE lote_id=? ORDER BY ordem', (lote,)).fetchall()


def contagem_transacoes(c):
    return c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0]


def test_staging_nao_toca_o_razao(banco, contas):
    with banco.transacao() as c:
        lote, avisos = pipeline.preparar(c, contas['corrente'], 'extrato_nov.ofx', ler('extrato_nov.ofx'))
        assert contagem_transacoes(c) == 0
        ls = linhas(c, lote)
        assert len(ls) == 6
        assert ls[3]['descricao'] == 'CONCESSIONÁRIA ÁGUA'            # charset 1252 respeitado
        assert ls[1]['sugestao'] == f'fatura:{contas["cartao"]}'      # pagamento de fatura reconhecido
        assert ls[0]['valor_centavos'] == 800000 and ls[1]['valor_centavos'] == -150000


def test_mes_importado_sem_dupla_contagem(banco, contas):
    """Cenário S1 via importação: o extrato não gera despesa para pagamento de fatura nem para Pix à poupança."""
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], '2026-10-31', 500000)
        operacoes.receita(c, '2026-11-05', 'Salário', 800000, contas['Salário'], contas['corrente'])   # lançado à mão antes
        operacoes.despesa(c, '2026-10-12', 'Mercado', 120000, contas['Mercado'], contas['cartao'])
        operacoes.despesa(c, '2026-10-20', 'Restaurante', 30000, contas['Restaurantes e delivery'], contas['cartao'])
        lote, _ = pipeline.preparar(c, contas['corrente'], 'extrato_nov.ofx', ler('extrato_nov.ofx'))
        ls = linhas(c, lote)
        assert ls[0]['sugestao'].startswith('casar:')                 # salário manual casado, não duplicado
        escolhas = {ls[0]['id']: ls[0]['sugestao'], ls[1]['id']: ls[1]['sugestao'],
                    ls[2]['id']: f'transf:{contas["poupanca"]}', ls[3]['id']: f'cat:{contas["Moradia"]}',
                    ls[4]['id']: f'cat:{contas["Restaurantes e delivery"]}', ls[5]['id']: f'cat:{contas["Restaurantes e delivery"]}'}
        assert pipeline.aplicar(c, lote, escolhas) == 6
        nov = relatorios.resumo_mes(c, '2026-11')
        assert nov['total_receitas'] == 800000
        assert nov['total_despesas'] == 8990 + 2 * 2590               # só água e as duas corridas
        assert razao.saldo(c, contas['corrente'], '2026-11-30') == 500000 + 800000 - 150000 - 20000 - 8990 - 5180
        assert razao.saldo(c, contas['poupanca'], '2026-11-30') == 20000
        assert cartoes.fatura(c, contas['cartao'], '2026-11-05', hoje='2026-11-30')['situacao'] == 'paga'
        assert razao.verificar_tudo(c) == []


def test_reimportar_mesmo_arquivo_e_recusado(banco, contas):
    with banco.transacao() as c:
        pipeline.preparar(c, contas['corrente'], 'a.ofx', ler('extrato_nov.ofx'))
        with pytest.raises(ErroValidacao, match='já foi importado'):
            pipeline.preparar(c, contas['corrente'], 'b.ofx', ler('extrato_nov.ofx'))


def _confirmar_tudo(c, lote, contas):
    escolhas = {}
    for l in linhas(c, lote):
        if l['situacao'] == 'duplicada':
            escolhas[l['id']] = 'ignorar'
        elif l['sugestao']:
            escolhas[l['id']] = l['sugestao']
        else:
            escolhas[l['id']] = f'cat:{contas["Outras despesas"]}' if l['valor_centavos'] < 0 else f'cat:{contas["Outras receitas"]}'
    return pipeline.aplicar(c, lote, escolhas)


def test_mesmo_extrato_em_ofx_e_csv_nao_duplica(banco, contas):
    """Cenário S5: na v0.9, o mesmo lançamento por três caminhos virava três registros."""
    with banco.transacao() as c:
        l1, _ = pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))
        _confirmar_tudo(c, l1, contas)
        antes = contagem_transacoes(c)
        l2, avisos = pipeline.preparar(c, contas['corrente'], 'nov.csv', ler('extrato_nov_bb.csv'))
        ls = linhas(c, l2)
        assert [l['situacao'] for l in ls].count('duplicada') == 6       # as seis do OFX, incluindo as duas Uber
        novas = [l for l in ls if l['situacao'] == 'nova']
        assert [l['descricao'] for l in novas] == ['PADARIA SÃO JOSÉ']
        assert any('saldo' in a for a in avisos)                         # linhas de saldo descartadas
        _confirmar_tudo(c, l2, contas)
        assert contagem_transacoes(c) == antes + 1


def test_compras_identicas_legitimas_sao_preservadas(banco, contas):
    with banco.transacao() as c:
        lote, _ = pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))
        ubers = [l for l in linhas(c, lote) if l['descricao'] == 'UBER *TRIP']
        assert len(ubers) == 2 and all(l['situacao'] == 'nova' for l in ubers)


def test_desfazer_lote_volta_ao_estado_anterior(banco, contas):
    with banco.transacao() as c:
        operacoes.receita(c, '2026-11-05', 'Salário', 800000, contas['Salário'], contas['corrente'])
        antes = c.execute('SELECT id, status FROM transacoes ORDER BY id').fetchall()
        lote, _ = pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))
        _confirmar_tudo(c, lote, contas)
        assert contagem_transacoes(c) > 1
        pipeline.desfazer(c, lote)
        depois = c.execute('SELECT id, status FROM transacoes ORDER BY id').fetchall()
        assert [tuple(r) for r in depois] == [tuple(r) for r in antes]
        # Desfeito, o arquivo pode ser importado de novo.
        pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))


def test_fatura_csv_no_cartao_com_sinal_invertido_e_pagamento(banco, contas):
    with banco.transacao() as c:
        cartoes.pagar(c, contas['corrente'], contas['cartao'], 90000, '2026-10-25')   # já lançado pelo extrato do banco
        lote, _ = pipeline.preparar(c, contas['cartao'], 'fatura.csv', ler('fatura_inter_nov.csv'))
        ls = linhas(c, lote)
        assert [l['valor_centavos'] for l in ls] == [-120000, -30000, -30000, 90000]
        assert ls[3]['sugestao'].startswith('casar:')                    # pagamento já existente é casado


def test_ofx_de_outra_conta_e_recusado(banco, contas):
    with banco.transacao() as c:
        razao.atualizar_conta(c, contas['corrente'], 'Conta BB', identificador_externo='99999-9')
        with pytest.raises(ErroValidacao, match='Escolha a conta certa'):
            pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))


def test_fitid_repetido_vira_aviso_e_nao_recusa(banco, contas):
    with banco.transacao() as c:
        lote, avisos = pipeline.preparar(c, contas['corrente'], 'f.ofx', ler('fitid_repetido.ofx'))
        assert len(linhas(c, lote)) == 2 and any('repete' in a for a in avisos)


@pytest.mark.parametrize('arquivo,mensagem', [
    ('ruim_truncado.ofx', 'incompleto'),
    ('ruim_valor.ofx', 'valor inválido'),
    ('ruim_data.csv', 'Linha 3'),
    ('ruim_valor.csv', 'Linha 3'),
    ('ruim_sem_cabecalho.csv', 'cabeçalho'),
    ('ruim_vazio.csv', 'cabeçalho'),
    ('ruim_binario.csv', '.'),
])
def test_arquivo_malformado_e_recusado_inteiro(banco, contas, arquivo, mensagem):
    with banco.transacao() as c:
        with pytest.raises(ErroValidacao, match=mensagem):
            pipeline.preparar(c, contas['corrente'], arquivo, ler(arquivo))
    with banco.conexao() as c:
        assert c.execute('SELECT COUNT(*) FROM linhas_importacao').fetchone()[0] == 0
        assert c.execute('SELECT COUNT(*) FROM lotes_importacao').fetchone()[0] == 0


def test_regra_aprendida_e_reaplicada(banco, contas):
    with banco.transacao() as c:
        lote, _ = pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))
        agua = next(l for l in linhas(c, lote) if 'GUA' in l['descricao'])
        pipeline.aplicar(c, lote, {agua['id']: f'cat:{contas["Moradia"]}'}, regras_novas={agua['id']})
        assert c.execute('SELECT COUNT(*) FROM regras').fetchone()[0] == 1
        lote2, _ = pipeline.preparar(c, contas['corrente'], 'nov.csv', ler('extrato_nov_bb.csv'))
        padaria = next(l for l in linhas(c, lote2) if 'PADARIA' in l['descricao'])
        # Sem histórico, a sugestão vem de palavras comuns e o motivo diz isso.
        assert padaria['sugestao'] == f'cat:{contas["Mercado"]}' and padaria['motivo'].startswith('Pela descrição')


def test_regra_criada_de_uma_linha_casa_com_descricao_com_pontuacao(banco, contas):
    """Defeito encontrado: a regra era gravada sem pontuação e comparada com a descrição com pontuação."""
    with banco.transacao() as c:
        lote, _ = pipeline.preparar(c, contas['corrente'], 'nov.ofx', ler('extrato_nov.ofx'))
        uber = next(l for l in linhas(c, lote) if l['descricao'] == 'UBER *TRIP')
        pipeline.aplicar(c, lote, {uber['id']: f'cat:{contas["Restaurantes e delivery"]}'}, regras_novas={uber['id']})
        assert pipeline._regra(c, 'UBER *TRIP')['conta_id'] == contas['Restaurantes e delivery']


def test_estorno_sugerido_e_agrupamento(banco, contas):
    from fin404.dominio import categorias as cats
    with banco.transacao() as c:
        operacoes.despesa(c, '2026-10-01', 'MERCADOLIVRE*LOJA X', 9000, contas['Vestuário'], contas['cartao'])
        csv = ('data,descricao,valor\n2026-10-10,MERCADOLIVRE*LOJA X,-77.66\n' +
               ''.join(f'2026-10-{d:02d},UBER *TRIP HELP.U{"SAO" if d % 2 else " SAO"} PAULO,{20 + d}.00\n' for d in range(11, 20))).encode()
        lote, _ = pipeline.preparar(c, contas['cartao'], 'fat.csv', csv)
        ls = linhas(c, lote)
        estorno = next(l for l in ls if 'MERCADOLIVRE' in l['descricao'])
        assert estorno['sugestao'] == f'cat:{contas["Vestuário"]}' and 'estorno' in estorno['motivo']
        grupos = pipeline.grupos_pendentes(c, lote)
        assert len(grupos) == 1 and len(grupos[0][1]) == 9 and grupos[0][0] == 'uber trip'
        assert cats.inferir(c, 'Posto Shell gasolina')[1].startswith('Pela descrição')


def test_casamento_ambiguo_pede_conferencia(banco, contas):
    """Dois lançamentos manuais iguais (mesmo valor, datas próximas): casa com o mais próximo e avisa."""
    with banco.transacao() as c:
        operacoes.despesa(c, '2026-10-10', 'Pix padaria', 1850, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, '2026-10-11', 'Pix padaria', 1850, contas['Mercado'], contas['corrente'])
        csv = b'data,descricao,valor\n2026-10-10,PIX PADARIA,-18.50\n2026-10-20,PIX PADARIA,-18.50\n'
        lote, _ = pipeline.preparar(c, contas['corrente'], 'ext.csv', csv)
        a, b = linhas(c, lote)
        assert a['sugestao'].startswith('casar:') and a['motivo'].startswith('CONFIRA: 2 lançamentos')
        # o segundo sobra só um candidato livre (o outro já foi reservado) e ele está longe: sem alerta de ambiguidade
        assert not b['motivo'].startswith('CONFIRA')


def test_csv_exportado_volta_sem_o_apostrofo_anti_formula():
    """Ida e volta: o export põe apóstrofo em texto que começa com = + - @; a reimportação tira e preserva o original."""
    from fin404.importacao.adaptadores import csv_generico
    from fin404.web.pg_lancamentos import texto_planilha
    original = '=HYPERLINK("http://x";"clique")'
    csv = ('data;descricao;valor\n05/10/2026;' + texto_planilha(original).replace('"', '""').join('""') + ';-10,00\n'
           '06/10/2026;' + texto_planilha("'apostrofo normal") + ';-5,00\n').encode('utf-8')
    linhas = csv_generico.ler(csv)['linhas']
    assert [l['descricao'] for l in linhas] == [original, "'apostrofo normal"]
