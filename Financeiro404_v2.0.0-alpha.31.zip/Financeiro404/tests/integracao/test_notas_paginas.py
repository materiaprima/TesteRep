"""R10 — páginas de NFC-e salvas, lista da Nota Fiscal Paulista e nota por foto. Tudo fictício: páginas montadas no leiaute
padrão da consulta de NFC-e, sem nenhum dado real (nome, CPF, CNPJ e chave inventados)."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import fotos_nota, nfce_pagina, notas, operacoes

CHAVE = '35261199999999000199650010000123451000123456'
CNPJ_FMT = '99.999.999/0001-99'
CNPJ = '99999999000199'


def _item(desc, cod, qtd, un, unit, total):
    return f'''<tr id="Item + 1"><td valign="top"><span class="txtTit">{desc}</span>
<span class="RCod">(Código: {cod} )</span><br><span class="Rqtd"><strong>Qtde.:</strong>{qtd}</span>
<span class="RUN"><strong>UN: </strong>{un}</span><span class="RvlUnit"><strong>Vl. Unit.:</strong>&nbsp;{unit}</span></td>
<td align="right" valign="top" class="txtTit noWrap">Vl. Total<br><span class="valor">{total}</span></td></tr>'''


def pagina(itens=None, total='24,92', desconto='1,00', chave=CHAVE, data='05/11/2026'):
    itens = itens or [_item('LEITE INTEGRAL 1L', '7890000000017', '2', 'UN', '5,49', '10,98'),
                      _item('BANANA PRATA KG', '0000000000001', '0,8500', 'KG', '6,99', '5,94'),
                      _item('DETERGENTE 500ML', '7890000000024', '2', 'UN', '4,50', '9,00')]
    return f'''<!DOCTYPE html><html><head><meta charset="utf-8"><title>NFC-e</title><script>var x = "<span class='valor'>99,99</span>";</script></head>
<body><div id="conteudo"><div class="txtCenter"><div id="u20" class="txtTopo">MERCADO EXEMPLO LTDA</div>
<div class="text">CNPJ: {CNPJ_FMT}</div><div class="text">RUA DE TESTE, 1, CENTRO, CIDADE, SP</div></div>
<table id="tabResult">{''.join(itens)}</table>
<div id="totalNota"><div id="linhaTotal"><label>Qtd. total de itens:</label><span class="totalNumb">{len(itens)}</span></div>
<div id="linhaTotal"><label>Valor total R$:</label><span class="totalNumb">25,92</span></div>
<div id="linhaTotal"><label>Descontos R$:</label><span class="totalNumb">{desconto}</span></div>
<div id="linhaTotal" class="linhaShade"><label>Valor a pagar R$:</label><span class="totalNumb txtMax">{total}</span></div>
<div id="linhaForma"><label>Forma de pagamento:</label><span class="totalNumb txtTitR">Valor pago R$:</span></div>
<div id="linhaTotal"><label class="tx">Cartão de Crédito</label><span class="totalNumb">{total}</span></div></div>
<div id="infos"><ul><li><strong>Número: </strong>12345<strong> Série: </strong>1<strong> Emissão: </strong>{data} 18:42:10 - Via Consumidor</li></ul>
<ul><li>Chave de acesso:<br><span class="chave">{' '.join(chave[i:i + 4] for i in range(0, 44, 4))}</span></li></ul>
<ul><li>Consumidor: CPF 000.000.000-00 FULANO DE TESTE</li></ul></div></div></body></html>'''.encode('utf-8')


def lista(*linhas):
    corpo = ''.join(f'<tr><td>{d}</td><td>{cnpj}</td><td>{loja}</td><td>NFC-e</td><td>R$ {v}</td><td>{ch}</td></tr>'
                    for d, cnpj, loja, v, ch in linhas)
    return (f'<html><body><table><tr><th>Emissão</th><th>CNPJ</th><th>Emitente</th><th>Tipo</th><th>Valor</th><th>Chave</th></tr>'
            f'{corpo}</table></body></html>').encode('cp1252')


PNG = b'\x89PNG\r\n\x1a\n' + b'\x00' * 64


def test_le_pagina_padrao(banco):
    n = nfce_pagina.ler_pagina(pagina())
    assert (n['loja'], n['cnpj'], n['chave'], n['data'], n['total'], n['desconto']) == (
        'MERCADO EXEMPLO LTDA', CNPJ, CHAVE, date(2026, 11, 5), 2492, 100)
    assert [(i['descricao'], i['quantidade_mil'], i['unidade'], i['preco'], i['total'], i['gtin']) for i in n['itens']] == [
        ('LEITE INTEGRAL 1L', 2000, 'UN', 549, 1098, '7890000000017'),
        ('BANANA PRATA KG', 850, 'KG', 699, 594, '0000000000001'),
        ('DETERGENTE 500ML', 2000, 'UN', 450, 900, '7890000000024')]


def test_le_pagina_em_tabela_simples():
    html = ('<html><body><h1>EMPORIO TESTE</h1><p>Emitente: EMPORIO TESTE CNPJ 11.111.111/0001-11</p><p>Emissão: 01/11/2026</p>'
            '<table><tr><th>Descrição</th><th>Qtde</th><th>Un</th><th>Vl Unit</th><th>Vl Total</th></tr>'
            '<tr><td>CAFE 500G</td><td>1</td><td>UN</td><td>18,90</td><td>18,90</td></tr>'
            '<tr><td>ACUCAR 1KG</td><td>2</td><td>UN</td><td>4,55</td><td>9,10</td></tr></table>'
            '<p>Valor a pagar R$ 28,00</p></body></html>').encode()
    n = nfce_pagina.ler_pagina(html)
    assert n['total'] == 2800 and len(n['itens']) == 2 and n['cnpj'] == '11111111000111' and n['loja'] == 'EMPORIO TESTE'


def test_pagina_nao_reconhecida_ou_que_nao_fecha():
    with pytest.raises(ErroValidacao, match='Não reconheci'):
        nfce_pagina.ler_pagina(b'<html><body><p>Ola</p></body></html>')
    with pytest.raises(ErroValidacao, match='somam'):
        nfce_pagina.ler_pagina(pagina(total='30,00'))


def test_importa_paginas_liga_e_e_atomico(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 11, 5), 'MERCADO EXEMPLO', 2492, contas['Mercado'], contas['cartao'])
        r = notas.importar_paginas(c, [('nota.html', pagina())])
        assert (r['notas'], r['itens'], r['ligadas']) == (1, 3, 1)
        n = notas.uma(c, r['ids'][0])
        assert n['origem'] == 'pagina' and n['transacao_id'] == tid
        with pytest.raises(ErroValidacao, match='já foi importado'):
            notas.importar_paginas(c, [('nota.html', pagina())])
        # um arquivo ruim no lote: nada entra
        with pytest.raises(ErroValidacao, match='Nada foi gravado.*ruim.html'):
            notas.importar_paginas(c, [('boa.html', pagina(chave='1' * 44)), ('ruim.html', b'<html></html>')])
        assert c.execute('SELECT COUNT(*) FROM notas_fiscais').fetchone()[0] == 1


def test_lista_nfp_confere_e_pagina_completa_sem_duplicar(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 11, 2), 'PADARIA', 1250, contas['Mercado'], contas['cartao'])
        docs = nfce_pagina.ler_lista(lista(('05/11/2026', CNPJ_FMT, 'MERCADO EXEMPLO LTDA', '24,92', ''),
                                           ('02/11/2026', '88.888.888/0001-88', 'PADARIA DO TESTE', '12,50', ''),
                                           ('03/11/2026', '77.777.777/0001-77', 'FARMÁCIA TESTE', '1.234,56', '')))
        assert [d['total'] for d in docs] == [2492, 1250, 123456] and docs[2]['loja'] == 'FARMÁCIA TESTE'
        r = notas.importar_lista(c, 'lista.html', lista(('05/11/2026', CNPJ_FMT, 'MERCADO EXEMPLO LTDA', '24,92', ''),
                                                        ('02/11/2026', '88.888.888/0001-88', 'PADARIA DO TESTE', '12,50', ''),
                                                        ('03/11/2026', '77.777.777/0001-77', 'FARMÁCIA TESTE', '1.234,56', '')))
        assert (r['notas'], r['itens'], r['ligadas']) == (3, 0, 1)
        conf = notas.conferencia(c)
        assert (conf['sem_lancamento'], conf['sem_lancamento_total'], conf['sem_itens']) == (2, 2492 + 123456, 3)
        assert len(notas.listar(c, filtro='sem_lancamento')) == 2
        # a página da mesma compra completa a nota da lista (mesma data + CNPJ + total), não cria outra
        r2 = notas.importar_paginas(c, [('nota.html', pagina())])
        assert (r2['notas'], r2['completadas'], r2['itens']) == (0, 1, 3)
        assert c.execute('SELECT COUNT(*) FROM notas_fiscais').fetchone()[0] == 3
        n = c.execute('SELECT * FROM notas_fiscais WHERE cnpj=?', (CNPJ,)).fetchone()
        assert n['chave'] == CHAVE and n['desconto_centavos'] == 100 and n['origem'] == 'lista_nfp'
        # a mesma lista de novo (outro arquivo, mesmas linhas): nada duplica
        r3 = notas.importar_lista(c, 'lista2.html', lista(('05/11/2026', CNPJ_FMT, 'MERCADO EXEMPLO LTDA', '24,92', '')))
        assert r3['notas'] == 0 and len(r3['puladas']) == 1
        # desfazer a página: a nota volta a ser só da lista, sem itens
        notas.desfazer(c, r2['importacao'])
        assert notas.itens(c, n['id']) == [] and notas.uma(c, n['id'])['desconto_centavos'] == 0


def test_desfazer_lista_mantem_nota_completada(banco, contas):
    with banco.transacao() as c:
        r = notas.importar_lista(c, 'lista.html', lista(('05/11/2026', CNPJ_FMT, 'MERCADO EXEMPLO LTDA', '24,92', CHAVE)))
        r2 = notas.importar_paginas(c, [('nota.html', pagina())])
        assert r2['completadas'] == 1
        notas.desfazer(c, r['importacao'])
        [n] = c.execute('SELECT * FROM notas_fiscais').fetchall()
        assert n['importacao_id'] == r2['importacao'] and len(notas.itens(c, n['id'])) == 3
        # agora desfazer a página apaga a nota
        notas.desfazer(c, r2['importacao'])
        assert c.execute('SELECT COUNT(*) FROM notas_fiscais').fetchone()[0] == 0


def test_lista_sem_documentos():
    with pytest.raises(ErroValidacao, match='Não achei documentos'):
        nfce_pagina.ler_lista(b'<html><table><tr><td>nada</td></tr></table></html>')


def test_ler_itens_digitados():
    itens, erros = fotos_nota.ler_itens('ARROZ 5KG 24,90\nLEITE INTEGRAL 1L 2 5,49\n\nBANANA PRATA 0,850 KG 6,99 5,94\n'
                                        '7891000100103 CAFE 500G 1 x 18,90\nPAO; 0,512; 15,00; 7,68\nSEM VALOR\n'
                                        'ERRADO 2 5,00 11,00')
    assert [(i['descricao'], i['quantidade_mil'], i['preco'], i['total'], i['unidade'], i['gtin']) for i in itens] == [
        ('ARROZ 5KG', 1000, 2490, 2490, 'UN', ''), ('LEITE INTEGRAL 1L', 2000, 549, 1098, 'UN', ''),
        ('BANANA PRATA', 850, 699, 594, 'KG', ''), ('CAFE 500G', 1000, 1890, 1890, 'UN', '7891000100103'),
        ('PAO', 512, 1500, 768, 'UN', '')]
    assert len(erros) == 2 and 'Linha 7' in erros[0] and 'Linha 8' in erros[1]


def test_foto_guarda_valida_e_vira_nota(banco, contas):
    with banco.transacao() as c:
        with pytest.raises(ErroValidacao, match='JPG, PNG ou WEBP'):
            fotos_nota.guardar(c, 'x.gif', b'GIF89a....')
        with pytest.raises(ErroValidacao, match='HEIC'):
            fotos_nota.guardar(c, 'x.heic', b'\x00\x00\x00\x18ftypheic' + b'\x00' * 20)
        novas, rep = fotos_nota.guardar_varias(c, [('a.png', PNG), ('a-copia.png', PNG)])
        assert len(novas) == 1 and rep == 1
        fid = novas[0]
        campos = {'loja': 'MERCADO EXEMPLO LTDA', 'data': '05/11/2026', 'cnpj': CNPJ_FMT, 'total': '24,92', 'desconto': '1,00',
                  'itens': 'LEITE INTEGRAL 1L 2 5,49\nBANANA PRATA 0,850 KG 6,99 5,94\nDETERGENTE 500ML 2 4,50'}
        with pytest.raises(ErroValidacao, match='Diferença: R\\$ 1,00'):
            fotos_nota.salvar_nota(c, fid, {**campos, 'total': '25,92'})
        assert fotos_nota.uma(c, fid)['nota_id'] is None
    # a lista já tinha a compra sem itens: a foto completa a mesma nota
    with banco.transacao() as c:
        notas.importar_lista(c, 'lista.html', lista(('05/11/2026', CNPJ_FMT, 'MERCADO EXEMPLO LTDA', '24,92', '')))
        nid, res = fotos_nota.salvar_nota(c, fid, campos)
        assert res['completadas'] == 1 and len(notas.itens(c, nid)) == 3
        assert fotos_nota.uma(c, fid)['nota_id'] == nid and [f['id'] for f in fotos_nota.da_nota(c, nid)] == [fid]
        with pytest.raises(ErroValidacao, match='já virou nota'):
            fotos_nota.descartar(c, fid)
        # desfazer a importação da foto: itens saem, a foto volta para "para digitar"
        notas.desfazer(c, res['importacao'])
        assert notas.itens(c, nid) == [] and fotos_nota.uma(c, fid)['nota_id'] is None
        assert notas.uma(c, nid)['origem'] == 'lista_nfp'           # a nota da lista continua, sem itens


def test_foto_nova_nota_e_descartar(banco, contas):
    with banco.transacao() as c:
        [fid], _ = fotos_nota.guardar_varias(c, [('b.png', PNG + b'1')])
        nid, res = fotos_nota.salvar_nota(c, fid, {'loja': 'FEIRA', 'data': '06/11/2026', 'total': '12,00', 'itens': 'TOMATE 1,000 KG 12,00'})
        assert res['notas'] == 1 and notas.uma(c, nid)['origem'] == 'foto'
        notas.desfazer(c, res['importacao'])                      # a nota sai; a foto volta a esperar
        assert fotos_nota.uma(c, fid)['nota_id'] is None and fotos_nota.pendentes(c)[0]['id'] == fid
        fotos_nota.descartar(c, fid)
        assert fotos_nota.pendentes(c) == []


def test_upload_de_varios_arquivos_no_mesmo_campo():
    from fin404.web.servidor import _ler_multipart
    b = 'XyZ'
    corpo = (f'--{b}\r\nContent-Disposition: form-data; name="csrf"\r\n\r\nt\r\n'
             f'--{b}\r\nContent-Disposition: form-data; name="arquivo"; filename="a.html"\r\nContent-Type: text/html\r\n\r\nAAA\r\n'
             f'--{b}\r\nContent-Disposition: form-data; name="arquivo"; filename="C:\\\\x\\\\b.html"\r\nContent-Type: text/html\r\n\r\nBBB\r\n'
             f'--{b}--\r\n').encode()
    form, arquivos = _ler_multipart(f'multipart/form-data; boundary={b}', corpo)
    assert [n for n, _ in arquivos['arquivo[]']] == ['a.html', 'b.html'] and arquivos['arquivo'][1] == b'BBB'
    assert form['csrf'] == ['t']


def test_pagina_estranha_nao_quebra():
    lixo = b'<html><table><tr><td>' * 3000 + b'\xff\xfe<span class="txtTit">X' + b'</b>' * 50
    with pytest.raises(ErroValidacao):
        nfce_pagina.ler_pagina(lixo)
    with pytest.raises(ErroValidacao):
        nfce_pagina.ler_lista(lixo)


def test_volta_ao_painel_depois_de_salvar_e_blocos():
    from fin404.web.componentes import _blocos, onde_estou
    from fin404.web.servidor import Requisicao, _voltar_ao_bloco
    html = _blocos('<section class="painel"><form method="post" action="/x"></form></section>'
                   '<section class="painel" id="pagar"><form method="post" action="/y"></form></section>')
    assert 'id="b1"' in html and 'name="_bloco" value="b1"' in html and 'name="_bloco" value="pagar"' in html
    req = Requisicao('POST', '/x', {}, {'_bloco': ['b1']}, {}, (), 'http://127.0.0.1:8000/orcamento?mes=2026-10')
    assert _voltar_ao_bloco('/orcamento?msg=ok', req) == '/orcamento?msg=ok#b1'
    assert _voltar_ao_bloco('/outra?msg=ok', req) == '/outra?msg=ok'                  # outra página: não desce
    req2 = Requisicao('POST', '/x', {}, {'_bloco': ['"><script>']}, {}, (), 'http://127.0.0.1:8000/orcamento')
    assert _voltar_ao_bloco('/orcamento', req2) == '/orcamento'                         # valor estranho é ignorado
    assert onde_estou('/cartoes/3/fatura/2026-10-27')[1][0] == '/cartoes'
    assert onde_estou('/importacoes/5')[1][0] == '/importar' and onde_estou('/relatorios/ano')[1][0] == '/relatorios/ano'
    assert onde_estou('/notas/fotos/2')[0][0] == 'compras'
