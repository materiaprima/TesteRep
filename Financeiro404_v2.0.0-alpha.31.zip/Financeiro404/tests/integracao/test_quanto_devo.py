"""Quanto devo e totais da lista com o que falta pagar (pedido do uso real: 'só mostra 7/8k, eu devo uns 13')."""
from datetime import date, timedelta

from fin404.dominio import cartoes, operacoes, razao


def test_lista_soma_a_pagar_e_avisa_pagamento_como_estorno(banco, contas, monkeypatch):
    from fin404.web import pg_lancamentos
    from fin404.web.servidor import Requisicao
    hoje = date.today()
    with banco.transacao() as c:
        operacoes.despesa(c, hoje, 'COMPRA', 100000, contas['Mercado'], contas['cartao'])
        operacoes.despesa(c, hoje + timedelta(days=3), 'OBRA', 141400, contas['Casa nova'], contas['corrente'], status='agendada')
        razao.registrar(c, hoje, 'PGTO. CASH AG. 0000', 'estorno', [(contas['Outras despesas'], -38000), (contas['cartao'], 38000)])
    q = {'de': [(hoje - timedelta(days=1)).isoformat()], 'ate': [(hoje + timedelta(days=10)).isoformat()]}
    status, _, corpo, _ = pg_lancamentos.lancamentos(Requisicao('GET', '/lancamentos', q, {}, {}, (), ''))
    html = corpo.decode()
    assert 'A pagar no período' in html and 'R$ 1.414,00' in html
    assert 'R$ 620,00' in html                    # 1.000 de despesa − 380 do pagamento lançado como estorno
    assert 'R$ 2.034,00' in html                  # já feitas + a pagar
    assert 'lançado(s) como estorno' in html and 'R$ 380,00' in html
    assert '>no cartão<' in html and '>a pagar<' in html     # compra no cartão não aparece como "pago"


def test_quanto_devo(banco, contas):
    from fin404.web import pg_inicio
    from fin404.web.servidor import Requisicao
    hoje = date.today()
    with banco.transacao() as c:
        operacoes.despesa(c, hoje - timedelta(days=2), 'COMPRA', 50000, contas['Mercado'], contas['cartao'])
        operacoes.saldo_inicial(c, contas['cartao'], hoje - timedelta(days=60), 200000)
        operacoes.despesa(c, hoje + timedelta(days=5), 'ENTRADA 404', 81700, contas['Casa nova'], contas['corrente'], status='agendada')
        operacoes.despesa(c, hoje - timedelta(days=1), 'LUZ', 20000, contas['Moradia'], contas['corrente'], status='agendada')
        assert cartoes.saldo_inicial_pendente(c, contas['cartao']) is None
    _, _, corpo, _ = pg_inicio.quanto_devo(Requisicao('GET', '/devo', {}, {}, {}, (), ''))
    html = corpo.decode()
    assert 'R$ 3.517,00' in html                  # 2.500 nos cartões + 817 + 200 a pagar
    assert 'A receber' in html
    assert '<span class="v">R$ 200,00</span> atrasado' in html and 'ENTRADA 404' in html
    assert 'Fatura Cartão Inter' in html and 'Não lance a fatura como conta a pagar' in html


def test_pagamento_parcial_deixa_o_resto_a_pagar(banco, contas):
    import pytest
    from fin404.dinheiro import ErroValidacao
    hoje = date.today()
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, hoje + timedelta(days=9), 'Evolução da Obra', 141400, contas['Casa nova'], contas['corrente'], status='agendada')
        _, nova = operacoes.pagar_parte(c, tid, 70000, hoje)
        t, r = razao.transacao(c, tid), razao.transacao(c, nova)
        assert t['status'] == 'confirmada' and t['data'] == hoje.isoformat() and 'parcial' in t['observacao']
        assert r['status'] == 'agendada' and r['descricao'] == 'Evolução da Obra (restante)' and r['data'] == (hoje + timedelta(days=9)).isoformat()
        assert razao.saldo(c, contas['Casa nova']) == 70000                         # só o pago conta como gasto
        assert razao.saldo(c, contas['Casa nova'], incluir_agendadas=True) == 141400
        _, nada = operacoes.pagar_parte(c, nova, 71400)                               # o resto todo: só confirma
        assert nada is None and razao.transacao(c, nova)['status'] == 'confirmada'
        with pytest.raises(ErroValidacao):
            operacoes.pagar_parte(c, nova, 100)
        assert razao.verificar_tudo(c) == []


def test_desmarcar_pago(banco, contas):
    import pytest
    from fin404.dinheiro import ErroValidacao
    hoje = date.today()
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, hoje, 'Condomínio', 62500, contas['Moradia'], contas['corrente'])
        operacoes.desmarcar_pago(c, tid)
        assert razao.transacao(c, tid)['status'] == 'agendada'
        operacoes.confirmar_previsto(c, tid)
        assert razao.transacao(c, tid)['status'] == 'confirmada'
        [cartao] = operacoes.despesa(c, hoje, 'Compra', 1000, contas['Mercado'], contas['cartao'])
        with pytest.raises(ErroValidacao, match='quem se paga é a fatura'):
            operacoes.desmarcar_pago(c, cartao)
    from fin404.web import pg_lancamentos
    from fin404.web.servidor import Requisicao
    html = pg_lancamentos.lancamento(Requisicao('GET', f'/lancamentos/{tid}', {}, {}, {}, (str(tid),), ''))[2].decode()
    assert 'voltar para &quot;a pagar&quot;' in html or 'voltar para "a pagar"' in html


def test_editar_troca_conta_e_parcelas_e_filtros(banco, contas):
    import pytest
    from fin404.dinheiro import ErroValidacao
    from fin404.dominio import cartoes
    from fin404.web import pg_lancamentos
    from fin404.web.servidor import Requisicao
    hoje = date.today()
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, hoje, 'Remedinho', 5000, contas['Moradia'], contas['corrente'])
        razao.editar(c, tid, 'Remedinho', hoje, '', None, None, None, contas['cartao'])      # era no cartão, não na conta
        assert {x['conta_id'] for x in razao.lancamentos_de(c, tid)} == {contas['Moradia'], contas['cartao']}
        with pytest.raises(ErroValidacao):
            razao.editar(c, tid, 'Remedinho', hoje, '', None, None, None, contas['Moradia'])
        ids = cartoes.compra(c, contas['cartao'], hoje, 'TV', 300000, contas['Casa nova'], parcelas=3)
        razao.editar(c, ids[0], 'TV sala (1/3)', hoje, '', None, contas['Vestuário'])
        msg = operacoes.editar_parcelas(c, ids[0])
        assert 'mais 2 parcela' in msg
        for i in ids:
            t = razao.transacao(c, i)
            assert t['descricao'].startswith('TV sala (') and contas['Vestuário'] in {x['conta_id'] for x in razao.lancamentos_de(c, i)}
        with pytest.raises(ErroValidacao, match='não muda de cartão'):
            razao.editar(c, ids[1], razao.transacao(c, ids[1])['descricao'], razao.transacao(c, ids[1])['data'], '', None, None, None, contas['corrente'])
        operacoes.despesa(c, hoje - timedelta(days=40), 'Luz atrasada', 20000, contas['Moradia'], contas['corrente'], status='agendada')
    for st, esperado in (('atrasado', ['Luz atrasada']), ('aberto', ['Luz atrasada'])):
        html = pg_lancamentos.lancamentos(Requisicao('GET', '/lancamentos', {'status': [st]}, {}, {}, (), ''))[2].decode()
        assert all(x in html for x in esperado) and 'Remedinho' not in html
        assert 'Atrasados (1)' in html


def test_reabrir_mes_pelo_lancamento_volta_para_ele(banco, contas):
    import pytest
    from fin404.web import pg_planejamento, pg_lancamentos
    from fin404.web.servidor import Requisicao, Redirecionar
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 9, 10), 'Mercado velho', 1000, contas['Moradia'], contas['corrente'])
        c.execute("INSERT INTO meses_fechados(mes, fechado_em) VALUES('2026-09', '2026-10-01')")
    html = pg_lancamentos.lancamento(Requisicao('GET', f'/lancamentos/{tid}', {}, {}, {}, (str(tid),), ''))[2].decode()
    assert 'Reabrir' in html and f'/lancamentos/{tid}' in html
    form = {'mes': ['2026-09'], 'acao': ['reabrir'], 'volta': [f'/lancamentos/{tid}']}
    with pytest.raises(Redirecionar) as r:
        pg_planejamento.fechamento_acao(Requisicao('POST', '/fechamento', {}, form, {}, (), ''))
    assert r.value.destino.startswith(f'/lancamentos/{tid}')
    with banco.conexao() as c:
        assert not c.execute("SELECT 1 FROM meses_fechados WHERE mes='2026-09'").fetchone()
    form['volta'] = ['https://fora.example/']          # não vira redirecionamento aberto
    with pytest.raises(Redirecionar) as r:
        pg_planejamento.fechamento_acao(Requisicao('POST', '/fechamento', {}, form, {}, (), ''))
    assert r.value.destino.startswith('/fechamento')


def test_atrasado_entra_no_fluxo_e_na_previsao(banco, contas):
    from fin404.dominio import relatorios
    hoje = date.today()
    with banco.transacao() as c:
        operacoes.despesa(c, hoje - timedelta(days=10), 'Luz esquecida', 20000, contas['Moradia'], contas['corrente'], status='agendada')
        f = relatorios.fluxo_caixa(c, 30, hoje)
        assert any('Luz esquecida' in x['descricao'] and x['valor'] == -20000 for x in f['linhas'])
        p = relatorios.proximos_meses(c, 3, False, hoje)
        assert p['meses'][0]['contas'] >= 20000 if 'meses' in p else True
