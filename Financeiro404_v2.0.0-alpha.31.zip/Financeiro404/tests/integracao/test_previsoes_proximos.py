"""Pedidos do uso real (13/11): editar previsões, valor corrigido valer para os próximos meses, previsão dos próximos meses e
ordenar tabelas."""
from datetime import date, timedelta

from fin404.dinheiro import somar_meses
from fin404.dominio import operacoes, razao, relatorios


def _futuras(c, pid):
    return c.execute("SELECT data, (SELECT MAX(ABS(valor_centavos)) FROM lancamentos WHERE transacao_id=t.id) v, descricao "
                     "FROM transacoes t WHERE previsao_id=? AND status='agendada' ORDER BY data", (pid,)).fetchall()


def test_editar_previsao_refaz_os_proximos(banco, contas):
    hoje = date(2026, 11, 13)
    with banco.transacao() as c:
        pid = operacoes.criar_previsao(c, 'Remédios', 25000, contas['corrente'], contas['Moradia'], 'saida', 7, '2026-11')
        operacoes.gerar_previsoes(c, '2027-02', hoje)
        [nov] = [r for r in _futuras(c, pid) if r['data'].startswith('2026-11')] or [None]
        n = operacoes.atualizar_previsao(c, pid, 'Remédios Zé', 30000, 10, contas['corrente'], contas['Moradia'], '', hoje)
        fut = _futuras(c, pid)
        assert n == 3 and all(r['v'] == 30000 and r['descricao'] == 'Remédios Zé' and r['data'][8:] == '10' for r in fut)
        assert [r['data'][:7] for r in fut][:3] == ['2026-12', '2027-01', '2027-02'] and len(fut) >= 3
        assert c.execute('SELECT valor_centavos FROM previsoes WHERE id=?', (pid,)).fetchone()[0] == 30000
        assert razao.verificar_tudo(c) == []


def test_corrigir_um_mes_vale_para_os_proximos(banco, contas):
    from fin404.web import pg_lancamentos
    from fin404.web.servidor import Redirecionar, Requisicao
    hoje = date.today()
    with banco.transacao() as c:
        pid = operacoes.criar_previsao(c, 'Remédios', 25000, contas['corrente'], contas['Moradia'], 'saida', 28,
                                       somar_meses(hoje.replace(day=1), 1).strftime('%Y-%m'))
        operacoes.gerar_previsoes(c, somar_meses(hoje.replace(day=1), 4).strftime('%Y-%m'), hoje)
        primeira = _futuras(c, pid)[0]
        tid = c.execute("SELECT id FROM transacoes WHERE previsao_id=? AND data=?", (pid, primeira['data'])).fetchone()[0]
    form = {'descricao': ['Remédios'], 'data': [primeira['data']], 'valor': ['300,00'], 'observacao': [''], 'proximos': ['1'],
            'situacao': ['a_pagar']}
    try:
        pg_lancamentos.lancamento_editar(Requisicao('POST', f'/lancamentos/{tid}/editar', {}, form, {}, (str(tid),), ''))
    except Redirecionar as r:
        assert 'Próximos meses atualizados' in r.destino or 'Pr%C3%B3ximos' in r.destino
    with banco.conexao() as c:
        assert [r['v'] for r in _futuras(c, pid)] == [30000] * len(_futuras(c, pid))
        assert c.execute("SELECT COUNT(*) FROM transacoes WHERE previsao_id=? AND data=?", (pid, primeira['data'])).fetchone()[0] == 1


def test_proximos_meses_conta_fatura_vencida_e_estimativa(banco, contas):
    hoje = date(2026, 11, 13)       # cartão do fixture: fecha dia 5, vence dia 12 → a fatura de 05/11 venceu ontem
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 10, 20), 'COMPRA OUT', 100000, contas['Mercado'], contas['cartao'])
        for m in (8, 9, 10):
            operacoes.despesa(c, date(2026, m, 15), 'MERCADO', 60000, contas['Mercado'], contas['corrente'])
        operacoes.receita(c, date(2026, 12, 5), 'Salário', 500000, contas['Salário'], contas['corrente'], status='agendada')
        r = relatorios.proximos_meses(c, 3, True, hoje)
    nov, dez, jan = r['meses']
    assert nov['faturas'] == 100000                      # a vencida e não paga entra agora
    assert r['media_dia_a_dia'] == -(-(60000 * 3 + 100000) // 3)
    assert dez['entradas'] == 500000 and dez['estimativa'] == r['media_dia_a_dia']
    assert jan['saldo_fim'] == r['inicial'] + sum(x['entradas'] - x['saidas'] for x in r['meses'])


def test_tabela_ordena_por_valor_e_data_e_mantem_total_no_fim():
    from fin404.web.componentes import REQ_ATUAL, _N_TABELA, tabela, dinheiro
    from fin404.web.servidor import Requisicao
    linhas = [['01/12/2026', 'b', dinheiro(-5000)], ['15/11/2026', 'a', dinheiro(120000)], ['03/01/2027', 'c', dinheiro(900)],
              ['<strong>Total</strong>', '', dinheiro(116000)]]
    REQ_ATUAL.set(Requisicao('GET', '/x', {'o1': ['2d']}, {}, {}, (), '')); _N_TABELA.set(0)
    html = tabela(['Data', 'Nome', 'Valor'], linhas)
    assert html.index('15/11/2026') < html.index('03/01/2027') < html.index('01/12/2026') < html.index('Total')
    assert 'aria-sort="descending"' in html and 'o1=2a' in html
    REQ_ATUAL.set(Requisicao('GET', '/x', {'o1': ['0a']}, {}, {}, (), '')); _N_TABELA.set(0)
    html = tabela(['Data', 'Nome', 'Valor'], linhas)
    assert html.index('15/11/2026') < html.index('01/12/2026') < html.index('03/01/2027')
    REQ_ATUAL.set(None)
