"""Lista de cartões: total devido hoje, fatura a pagar e aberta que já carrega o saldo anterior (pedido do uso real)."""
from datetime import date, timedelta
from fin404.dominio import operacoes, cartoes
from fin404.web import pg_cartoes
def test_lista_de_cartoes_mostra_total_e_nao_soma_duas_vezes(banco, contas, monkeypatch):
    with banco.transacao() as c:
        k = cartoes.completo(c, contas['cartao'])
        hoje = date.today()
        atual = cartoes.fechamento_da_compra(k, hoje)
        ant = cartoes.fechamento_anterior(k, atual)
        ini_ant, _ = cartoes.ciclo(k, ant)
        operacoes.despesa(c, ini_ant + timedelta(days=1), 'COMPRA VELHA', 259408, contas['Mercado'], contas['cartao'])
        ini, _ = cartoes.ciclo(k, atual)
        operacoes.despesa(c, ini, 'COMPRA NOVA', 92117, contas['Mercado'], contas['cartao'])
        fa, fb = cartoes.fatura(c, k['id'], ant), cartoes.fatura(c, k['id'], atual)
        from fin404.dominio import razao
        html = pg_cartoes._bloco_cartao(k, fa, fb, cartoes.limite(c, k['id']), -razao.saldo(c, k['id'], hoje))
    assert 'Devendo no cartão hoje' in html and 'R$ 3.515,25' in html and 'R$ 921,17' in html
    if fa['situacao'] in ('vencida', 'fechada'):
        assert 'já inclui R$ 2.594,08 da fatura anterior' in html and 'Não some as duas linhas' in html
