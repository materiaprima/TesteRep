"""Compras planejadas: quanto separar por mês, o que cabe na sobra e o ciclo planejada → comprada."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import compras, razao

HOJE = date(2026, 11, 6)


def test_calendario_guardar_parcelar_e_cabe_pela_prioridade(banco, contas):
    with banco.transacao() as c:
        # Necessário, à vista em jan/2027 (3 meses contando novembro): falta 1.200 − 300 = 900 → 300/mês nov, dez, jan
        geladeira = compras.criar(c, 'Geladeira', 120000, contas['Casa nova'], 'necessario', '2027-01', guardado=30000)
        # Importante, 10x a partir de fev/2027: 2.000 / 10 = 200/mês de fev a nov/2027
        notebook = compras.criar(c, 'Notebook', 200000, None, 'importante', '2027-02', parcelas=10)
        # Desejo, à vista em dez/2026 (2 meses): 600 → 300/mês. Com sobra de 500, não cabe junto com a geladeira.
        viagem = compras.criar(c, 'Fim de semana na praia', 60000, None, 'desejo', '2026-12')
        sem_data = compras.criar(c, 'Sofá novo', 300000, None, 'desejo')
        p = compras.plano(c, HOJE, sobra=50000)
    cal = {m['ym']: m for m in p['calendario']}
    assert len(p['calendario']) == 12 and p['calendario'][0]['ym'] == '2026-11'
    assert cal['2026-11']['guardar'] == 60000 and cal['2026-11']['folga'] == -10000
    assert cal['2027-01']['guardar'] == 30000 and cal['2027-02']['parcelas'] == 20000 and cal['2027-10']['parcelas'] == 20000
    itens = {it['id']: it for it in p['itens']}
    assert [it['id'] for it in p['itens']] == [geladeira, notebook, viagem, sem_data]      # prioridade, depois data
    assert itens[geladeira]['por_mes'] == 30000 and itens[geladeira]['cabe'] is True and itens[geladeira]['falta'] == 90000
    assert itens[notebook]['por_mes'] == 20000 and itens[notebook]['estado'] == 'parcelado' and itens[notebook]['cabe'] is True
    assert itens[viagem]['cabe'] is False and p['nao_cabem'] == 1
    assert itens[sem_data]['estado'] == 'sem data' and itens[sem_data]['cabe'] is None
    assert p['este_mes'] == 60000 and p['total_falta'] == 90000 + 200000 + 60000 + 300000
    assert p['por_prioridade']['desejo'] == {'n': 2, 'falta': 360000}
    assert p['por_categoria'][0][0] == 'Sem categoria'


def test_atrasada_dinheiro_separado_e_sem_renda(banco, contas):
    with banco.transacao() as c:
        a = compras.criar(c, 'Pneus', 80000, None, 'necessario', '2026-09')
        b = compras.criar(c, 'Óculos', 50000, None, 'importante', '2027-03', guardado=50000)
        p = compras.plano(c, HOJE)          # sem lançamentos: sem sobra conhecida
    itens = {it['id']: it for it in p['itens']}
    assert itens[a]['estado'] == 'atrasada' and p['calendario'][0]['guardar'] == 80000
    assert itens[b]['estado'] == 'dinheiro separado' and itens[b]['falta'] == 0
    assert p['sobra'] is None and itens[a]['cabe'] is None and p['calendario'][0]['folga'] is None


def test_comprar_lanca_a_despesa_e_sai_do_plano(banco, contas):
    with banco.transacao() as c:
        cid = compras.criar(c, 'Máquina de lavar', 250000, contas['Casa nova'], 'necessario', '2026-12', parcelas=5)
        ids, proxima = compras.comprar(c, cid, '2026-11-20', contas['cartao'])
        assert proxima is None
        assert len(ids) == 5                                         # caiu no cartão em 5 parcelas
        item = compras.uma(c, cid)
        assert item['situacao'] == 'comprada' and item['transacao_id'] == ids[0] and item['valor_pago_centavos'] == 250000
        assert compras.plano(c, HOJE, sobra=0)['itens'] == []
        with pytest.raises(ErroValidacao, match='tem lançamento'):
            compras.reabrir(c, cid)
        with pytest.raises(ErroValidacao, match='já foi concluída'):
            compras.desistir(c, cid)
        # sem categoria no plano: precisa escolher na hora de comprar
        x = compras.criar(c, 'Presente', 10000, None, 'desejo', '2026-12')
        with pytest.raises(ErroValidacao, match='categoria'):
            compras.comprar(c, x, '2026-11-20', contas['corrente'])
        compras.comprar(c, x, '2026-11-20', contas['corrente'], valor=9500, categoria_id=contas['Outras despesas'])
        assert razao.saldo(c, contas['corrente']) == -9500
        assert compras.plano(c, HOJE)['historico'][0]['valor_pago_centavos'] in (9500, 250000)


def test_marcar_desistir_reabrir_excluir_e_validacoes(banco, contas):
    with banco.transacao() as c:
        a = compras.criar(c, 'Cadeira', 40000, None, 'importante', '2027-01')
        compras.marcar_comprada(c, a, 38000, hoje=HOJE)
        assert compras.uma(c, a)['situacao'] == 'comprada'
        compras.reabrir(c, a)
        compras.desistir(c, a, hoje=HOJE)
        assert compras.uma(c, a)['situacao'] == 'desistiu'
        compras.reabrir(c, a)
        compras.atualizar(c, a, 'Cadeira de escritório', 45000, contas['Casa nova'], 'necessario', '2027-02', 1, 5000)
        assert compras.uma(c, a)['categoria'] == 'Casa nova'
        assert compras.excluir(c, a) == 'Cadeira de escritório'
        for args, msg in [(('', 100), 'Diga'), (('X', 0), 'maior que zero'), (('X', 100, None, 'desejo', None, 1, 0, '', None, '', 'brinde'), 'tipo do item'), (('X', 100, None, 'urgente'), 'prioridade'),
                          (('X', 100, None, 'desejo', '2026-13'), 'Mês inválido'), (('X', 5, None, 'desejo', None, 10), 'menor que'),
                          (('X', 100, contas['Salário']), 'categoria de despesa')]:
            with pytest.raises(ErroValidacao, match=msg):
                compras.criar(c, *args)


def test_categoria_excluida_nao_apaga_o_plano(banco, contas):
    with banco.transacao() as c:
        cat = razao.criar_conta(c, 'Bebê', 'categoria', tipo_categoria='despesa')
        a = compras.criar(c, 'Carrinho', 90000, cat, 'necessario', '2027-04')
        razao.excluir_conta(c, cat)
        assert compras.uma(c, a)['categoria_id'] is None



# ------------------------------------------------------------------ projetos, modelos, cotações e reposição

def test_projeto_a_partir_de_modelo_agrupa_por_ambiente(banco, contas):
    with banco.transacao() as c:
        pid = compras.criar_plano(c, 'Casa 404', 'casa', orcamento=3000000, mes_alvo='2027-03', usar_modelo=True)
        d = compras.detalhe_plano(c, pid, HOJE, sobra=None)
        assert {'Cozinha', 'Quarto', 'Sala', 'Lavanderia', 'Banheiro', 'Mudança e serviços'} <= set(d['grupos'])
        geladeira = next(i for i in d['grupos']['Cozinha']['itens'] if i['descricao'] == 'Geladeira')
        assert geladeira['estado'] == 'a cotar' and geladeira['valor_centavos'] is None and geladeira['mes_alvo'] == '2027-03'
        assert geladeira['categoria'] == 'Casa nova' and geladeira['vida_util_meses'] == 120
        n = d['plano']['n_abertos']
        assert d['plano']['n_sem_preco'] == n and d['plano']['livre'] == 3000000
        assert compras.aplicar_modelo(c, pid) == 0                      # não duplica
        # carro: IPVA e seguro caem nas categorias certas
        carro = compras.criar_plano(c, 'Carro', 'carro', usar_modelo=True)
        cats = {i['descricao']: i['categoria'] for g in compras.detalhe_plano(c, carro, HOJE, sobra=None)['grupos'].values() for i in g['itens']}
        assert cats['IPVA'] == 'Impostos e taxas' and cats['Seguro do carro'] == 'Seguros' and cats['Pneus'] == 'Transporte'
        # sem preço não entra no calendário nem no total
        p = compras.plano(c, HOJE, sobra=100000)
        assert p['total_falta'] == 0 and len(p['sem_preco']) == len(p['itens']) and p['este_mes'] == 0


def test_resumo_do_projeto_orcamento_gasto_e_progresso(banco, contas):
    with banco.transacao() as c:
        pid = compras.criar_plano(c, 'Viagem Nordeste', 'viagem', orcamento=800000, mes_alvo='2027-07')
        a = compras.criar(c, 'Passagens', 300000, None, 'necessario', '2027-03', plano_id=pid, grupo='Transporte')
        compras.criar(c, 'Hotel', 400000, None, 'necessario', '2027-07', plano_id=pid, grupo='Hospedagem', guardado=100000)
        compras.criar(c, 'Passeios', None, None, 'desejo', '2027-07', plano_id=pid, grupo='Passeios')
        compras.comprar(c, a, '2026-11-10', contas['corrente'], valor=280000, categoria_id=contas['Outras despesas'])
        r = compras.resumo_plano(c, compras.um_plano(c, pid))
    assert (r['n_abertos'], r['n_comprados'], r['n_sem_preco']) == (2, 1, 1)
    assert r['gasto'] == 280000 and r['planejado'] == 400000 and r['falta'] == 300000
    assert r['livre'] == 800000 - 280000 - 400000 and r['pct'] == 33


def test_revenda_do_usado_abate_a_falta(banco, contas):
    with banco.transacao() as c:
        t = compras.criar(c, 'Trocar de carro', 6000000, None, 'importante', '2027-10', guardado=1500000, revenda=3000000,
                          tipo_item='troca')
        it = next(i for i in compras.plano(c, HOJE, sobra=None)['itens'] if i['id'] == t)
    assert it['falta'] == 1500000 and it['por_mes'] == 125000      # 15.000 em 12 meses (nov/26 a out/27)


def test_cotacoes_menor_preco_com_frete_e_usar_no_item(banco, contas):
    with banco.transacao() as c:
        x = compras.criar(c, 'Geladeira', None, None, 'necessario', '2027-01')
        compras.adicionar_cotacao(c, x, 'Loja A', 350000, parcelas=10, frete=0)
        b = compras.adicionar_cotacao(c, x, 'Loja B', 320000, parcelas=1, frete=15000, link='javascript:alert(1)')
        compras.adicionar_cotacao(c, x, 'Loja C', 329000, link='https://loja.example/geladeira')
        cs = compras.cotacoes(c, x)
        assert [q['loja'] for q in cs] == ['Loja C', 'Loja B', 'Loja A'] and cs[1]['total'] == 335000
        assert cs[1]['link'] == '' and cs[0]['link'].startswith('https://')        # link perigoso descartado
        compras.usar_cotacao(c, cs[2]['id'])
        it = compras.uma(c, x)
        assert it['valor_centavos'] == 350000 and it['parcelas'] == 10
        compras.usar_cotacao(c, b)
        assert compras.uma(c, x)['valor_centavos'] == 335000 and compras.uma(c, x)['parcelas'] == 1
        compras.excluir_cotacao(c, b)
        assert len(compras.cotacoes(c, x)) == 2
        compras.excluir(c, x)
        assert c.execute('SELECT COUNT(*) FROM cotacoes').fetchone()[0] == 0       # cascata
        with pytest.raises(ErroValidacao, match='loja'):
            compras.adicionar_cotacao(c, compras.criar(c, 'Y', None), '', 100)


def test_vida_util_planeja_a_proxima_troca(banco, contas):
    with banco.transacao() as c:
        pid = compras.criar_plano(c, 'Carro', 'carro')
        oleo = compras.criar(c, 'Troca de óleo', 30000, contas['Outras despesas'], 'necessario', '2026-11', plano_id=pid,
                             grupo='Manutenção', tipo_item='manutencao', vida_util_meses=6)
        _, proxima = compras.comprar(c, oleo, '2026-11-15', contas['corrente'], valor=32000)
        n = compras.uma(c, proxima)
        assert (n['mes_alvo'], n['valor_centavos'], n['plano_id'], n['grupo'], n['tipo_item'], n['origem_id']) == \
            ('2027-05', 32000, pid, 'Manutenção', 'manutencao', oleo)
        # marcar como comprada (veio na fatura) também planeja a próxima
        p = compras.criar(c, 'Pneus', 160000, None, 'necessario', '2026-12', tipo_item='compra', vida_util_meses=48)
        prox = compras.marcar_comprada(c, p, hoje=HOJE)
        assert compras.uma(c, prox)['mes_alvo'] == '2030-11' and compras.uma(c, prox)['tipo_item'] == 'troca'
        assert any(i['id'] == proxima for i in compras.plano(c, date(2027, 3, 1), sobra=None)['proximas_trocas'])


def test_projeto_arquivado_sai_do_calendario_e_excluir_preserva_historico(banco, contas):
    with banco.transacao() as c:
        pid = compras.criar_plano(c, 'Reforma', 'reforma')
        a = compras.criar(c, 'Pintura', 200000, None, 'importante', '2027-01', plano_id=pid)
        b = compras.criar(c, 'Tinta', 50000, contas['Outras despesas'], 'importante', '2026-11', plano_id=pid)
        compras.comprar(c, b, '2026-11-05', contas['corrente'])
        assert compras.plano(c, HOJE, sobra=None)['este_mes'] > 0
        compras.mudar_situacao_plano(c, pid, 'arquivado')
        assert compras.plano(c, HOJE, sobra=None)['itens'] == []
        assert compras.detalhe_plano(c, pid, HOJE, sobra=None)['grupos']['Geral']['n'] == 2
        compras.mudar_situacao_plano(c, pid, 'ativo')
        assert compras.excluir_plano(c, pid) == ('Reforma', 1)
        with pytest.raises(ErroValidacao):
            compras.uma(c, a)
        h = compras.uma(c, b)
        assert h['situacao'] == 'comprada' and h['plano_id'] is None


def test_filtros_da_lista(banco, contas):
    with banco.transacao() as c:
        pid = compras.criar_plano(c, 'Casa', 'casa')
        a = compras.criar(c, 'A', 10000, None, 'necessario', '2027-01', plano_id=pid, tipo_item='troca')
        b = compras.criar(c, 'B', None, None, 'desejo')
        itens = compras.plano(c, HOJE, sobra=0)['itens']
    assert [i['id'] for i in compras.filtrar(itens, plano_id=pid)] == [a]
    assert [i['id'] for i in compras.filtrar(itens, plano_id=0)] == [b]
    assert [i['id'] for i in compras.filtrar(itens, estado='a cotar')] == [b]
    assert [i['id'] for i in compras.filtrar(itens, estado='nao_cabe')] == [a]
    assert [i['id'] for i in compras.filtrar(itens, tipo_item='troca', prioridade='necessario')] == [a]


def test_atualizar_da_alpha12_preserva_as_compras(tmp_path, monkeypatch):
    """A 0011 refaz compras_planejadas (para aceitar item sem preço): nada da 0010 pode se perder."""
    import shutil
    monkeypatch.setenv('FIN404_DATA', str(tmp_path / 'dados'))
    from fin404.dados import banco as b
    from fin404.dominio import operacoes
    so_ate_10 = tmp_path / 'mig'; so_ate_10.mkdir()
    for p in b.MIGRACOES.glob('*.sql'):
        if int(p.name[:4]) <= 10:
            shutil.copy(p, so_ate_10)
    original = b.MIGRACOES
    monkeypatch.setattr(b, 'MIGRACOES', so_ate_10)
    b.migrar()
    with b.transacao() as c:
        k = razao.criar_conta(c, 'CC', 'corrente')
        cat = c.execute("SELECT id FROM contas WHERE nome='Casa nova'").fetchone()[0]
        [t] = operacoes.despesa(c, '2026-11-06', 'Geladeira', 300000, cat, k)
        c.execute('''INSERT INTO compras_planejadas(descricao, valor_centavos, categoria_id, prioridade, mes_alvo, situacao,
                     transacao_id, valor_pago_centavos) VALUES('Geladeira', 300000, ?, 'necessario', '2026-12', 'comprada', ?, 300000)''',
                  (cat, t))
        c.execute("INSERT INTO compras_planejadas(descricao, valor_centavos, guardado_centavos, prioridade, parcelas) VALUES('Sofá', 350000, 5000, 'desejo', 3)")
    monkeypatch.setattr(b, 'MIGRACOES', original)
    b.migrar()
    with b.conexao() as c:
        g, s = compras.uma(c, 1), compras.uma(c, 2)
        assert (g['situacao'], g['transacao_id'], g['valor_pago_centavos'], g['categoria']) == ('comprada', t, 300000, 'Casa nova')
        assert (s['valor_centavos'], s['guardado_centavos'], s['parcelas'], s['tipo_item'], s['quantidade']) == (350000, 5000, 3, 'compra', 1)
        assert c.execute('PRAGMA foreign_key_check').fetchall() == [] and razao.verificar_tudo(c) == []
    assert any((tmp_path / 'dados' / 'copias_pre_migracao').iterdir())


def test_remover_sugestoes_da_lista_pronta(banco, contas):
    from fin404.dominio import compras
    with banco.transacao() as c:
        pid = compras.criar_plano(c, 'Casa', 'casa', usar_modelo=True)
        total = c.execute('SELECT COUNT(*) FROM compras_planejadas WHERE plano_id=?', (pid,)).fetchone()[0]
        usado = c.execute("SELECT id FROM compras_planejadas WHERE plano_id=? AND descricao='Geladeira'", (pid,)).fetchone()[0]
        c.execute('UPDATE compras_planejadas SET valor_centavos=300000 WHERE id=?', (usado,))
        compras.criar(c, 'Rack', 90000, None, 'desejo', None, plano_id=pid, grupo='Sala')
        n = compras.remover_sugestoes(c, pid)
        assert n == total - 1
        restantes = {r[0] for r in c.execute('SELECT descricao FROM compras_planejadas WHERE plano_id=?', (pid,))}
        assert restantes == {'Geladeira', 'Rack'}
