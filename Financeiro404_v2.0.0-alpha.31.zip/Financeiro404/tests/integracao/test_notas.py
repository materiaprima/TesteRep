"""R10 — notas fiscais (CSV local), catálogo por código de barras, agrupamento e histórico de preços. Dados fictícios."""
from datetime import date
import io

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import catalogo, notas, operacoes, razao

CAB = 'data;loja;cnpj;chave;item;codigo;quantidade;unidade;preco_unitario;total_item;desconto_nota;total_nota\n'
CHAVE1 = '3' * 44
CHAVE2 = '4' * 44


def _csv(*linhas):
    return (CAB + '\n'.join(linhas) + '\n').encode('utf-8')


NOTA_A = [f'05/10/2026;MERCADO A;11111111000111;{CHAVE1};LEITE INT ITALAC 1L;7891111111111;2;UN;5,49;10,98;1,00;24,92',
          f'05/10/2026;MERCADO A;11111111000111;{CHAVE1};BANANA PRATA KG;;0,850;KG;6,99;5,94;1,00;24,92',
          f'05/10/2026;MERCADO A;11111111000111;{CHAVE1};DETERG YPE 500ML;;2;UN;4,50;9,00;1,00;24,92']
NOTA_B = [f'02/11/2026;MERCADO B;22222222000122;{CHAVE2};LT ITALAC INTEGRAL;;3;UN;5,99;17,97;0,00;17,97']


def test_importa_com_travas_liga_ao_lancamento_e_desfaz(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 10, 6), 'MERCADO A', 2492, contas['Mercado'], contas['cartao'])
        r = notas.importar_csv(c, 'notas.csv', _csv(*NOTA_A, *NOTA_B))
        assert (r['notas'], r['itens'], r['ligadas'], r['puladas']) == (2, 4, 1, [])
        a = c.execute('SELECT * FROM notas_fiscais WHERE chave=?', (CHAVE1,)).fetchone()
        assert a['transacao_id'] == tid and a['desconto_centavos'] == 100                     # 1 dia de diferença, mesmo valor
        tipos = [i['tipo'] for i in notas.itens(c, a['id'])]
        assert tipos == ['Frios e laticínios', 'Hortifrúti', 'Limpeza']
        assert notas.itens(c, a['id'])[1]['quantidade_mil'] == 850
        # a despesa não duplicou
        assert c.execute("SELECT COUNT(*) FROM transacoes WHERE tipo='despesa'").fetchone()[0] == 1
        with pytest.raises(ErroValidacao, match='já foi importado'):
            notas.importar_csv(c, 'notas.csv', _csv(*NOTA_A, *NOTA_B))
        # mesma chave em outro arquivo: pula, não duplica
        r2 = notas.importar_csv(c, 'outra.csv', _csv(*NOTA_B, '03/11/2026;MERCADO C;;;PAO FRANCES;;0,500;KG;15,00;7,50;;7,50'))
        assert r2['notas'] == 1 and len(r2['puladas']) == 1
        assert notas.desfazer(c, r['importacao']) == 2
        assert c.execute('SELECT COUNT(*) FROM notas_fiscais').fetchone()[0] == 1
        assert razao.transacao(c, tid)['descricao'] == 'MERCADO A'                         # o lançamento fica


def test_travas_recusam_o_arquivo_inteiro(banco, contas):
    with banco.transacao() as c:
        ruim_soma = [l.replace(';24,92', ';25,92') for l in NOTA_A]
        with pytest.raises(ErroValidacao, match='Nada foi gravado.*itens somam'):
            notas.importar_csv(c, 'a.csv', _csv(*ruim_soma, *NOTA_B))
        ruim_item = ['05/10/2026;MERCADO A;;;ARROZ 5KG;;2;UN;20,00;30,00;;30,00']
        with pytest.raises(ErroValidacao, match='quantidade × preço'):
            notas.importar_csv(c, 'b.csv', _csv(*ruim_item))
        with pytest.raises(ErroValidacao, match='44 dígitos'):
            notas.importar_csv(c, 'c.csv', _csv('05/10/2026;MERCADO A;;123;ARROZ;;1;UN;20,00;20,00;;20,00'))
        with pytest.raises(ErroValidacao, match='Faltam colunas'):
            notas.importar_csv(c, 'd.csv', b'data;loja\n01/01/2026;X\n')
        assert c.execute('SELECT COUNT(*) FROM notas_fiscais').fetchone()[0] == 0
        assert c.execute('SELECT COUNT(*) FROM importacoes_notas').fetchone()[0] == 0


def test_nota_de_compra_parcelada_e_lancar_a_partir_da_nota(banco, contas):
    with banco.transacao() as c:
        ids = operacoes.despesa(c, date(2026, 10, 20), 'LOJA MOVEIS', 120000, contas['Casa nova'], contas['cartao'], 4)
        r = notas.importar_csv(c, 'm.csv', _csv('20/10/2026;LOJA MOVEIS;;;SOFA 3 LUGARES;;1;UN;1200,00;1200,00;;1200,00',
                                                  '21/10/2026;FARMACIA X;;;DIPIRONA;;1;UN;12,00;12,00;;12,00'))
        assert r['ligadas'] == 1
        sofa, farm = c.execute('SELECT id, transacao_id FROM notas_fiscais ORDER BY data').fetchall()
        assert sofa['transacao_id'] == ids[0]                                                   # pelo total do parcelamento
        assert farm['transacao_id'] is None
        [t] = notas.lancar(c, farm['id'], contas['corrente'], contas['Outras despesas'])
        assert notas.uma(c, farm['id'])['transacao_id'] == t
        with pytest.raises(ErroValidacao, match='já está ligada'):
            notas.lancar(c, farm['id'], contas['corrente'], contas['Outras despesas'])
        assert [n['id'] for n in notas.de_transacao(c, ids[2])] == [sofa['id']]               # qualquer parcela acha a nota


def test_catalogo_por_codigo_de_barras_atribuicao_e_agrupamento(banco, contas):
    off = ('code\tproduct_name\tbrands\tquantity\tcountries_tags\n'
           '7891111111111\tLeite integral\tItalac\t1 L\ten:brazil\n'
           '7892222222222\tLeite desnatado\tItalac\t1 L\ten:brazil\n'
           '3017620422003\tNutella\tFerrero\t400 g\ten:france\n'
           '123\tCódigo curto\tX\t1\ten:brazil\n')
    with banco.transacao() as c:
        notas.importar_csv(c, 'n.csv', _csv(*NOTA_A, *NOTA_B))
        r = catalogo.importar(c, io.StringIO(off, newline=''), 'off', pais='brazil')
        assert (r['lidos'], r['gravados'], r['ignorados']) == (4, 2, 2)                      # França e código inválido fora
        assert 'ODbL' in catalogo.atribuicoes(c)[0]['atribuicao']
        leite = c.execute("SELECT * FROM produtos WHERE gtin='7891111111111'").fetchone()
        assert (leite['nome'], leite['marca'], leite['fonte']) == ('Leite integral', 'Italac', 'Open Food Facts')
        item_a = c.execute("SELECT * FROM itens_nota WHERE gtin='7891111111111'").fetchone()
        assert item_a['produto_id'] == leite['id']                                             # nota casou pelo código
        # "LT ITALAC INTEGRAL" (outra loja, sem código) recebe o leite como sugestão e é agrupado
        sug = catalogo.sugestoes(c, notas.normalizar('LT ITALAC INTEGRAL'))
        assert sug and sug[0]['id'] == leite['id']
        assert catalogo.associar(c, notas.normalizar('LT ITALAC INTEGRAL'), leite['id']) == 1
        h = catalogo.historico_preco(c, f'p{leite["id"]}')
        assert [x['preco_unit_centavos'] for x in h['compras']] == [549, 599]
        assert [(x['loja'], x['menor']) for x in h['por_loja']] == [('MERCADO A', 549), ('MERCADO B', 599)]
        linha = [x for x in catalogo.lista_precos(c) if x['chave'] == f'p{leite["id"]}'][0]
        assert linha['n'] == 2 and linha['variacao'] == 9 and linha['lojas'] == 2               # (599−549)×100//549
        # nova importação da mesma descrição já cai no produto (apelido)
        notas.importar_csv(c, 'n2.csv', _csv('10/11/2026;MERCADO B;;;LT ITALAC INTEGRAL;;1;UN;6,19;6,19;;6,19'))
        assert len(catalogo.historico_preco(c, f'p{leite["id"]}')['compras']) == 3
        catalogo.separar(c, notas.normalizar('LT ITALAC INTEGRAL'))
        assert len(catalogo.historico_preco(c, f'p{leite["id"]}')['compras']) == 1
        g = catalogo.gasto_por_tipo(c, date(2026, 10, 1), date(2026, 11, 30))
        assert dict((t['tipo'], t['v']) for t in g['tipos'])['Limpeza'] == 900 and g['desconto'] == 100
        sem = {x['descricao_norm'] for x in catalogo.sem_produto(c)}
        assert 'banana prata kg' in sem and 'leite int italac 1l' not in sem
        pid = catalogo.novo_produto(c, 'Banana prata', tipo='Hortifrúti')
        catalogo.associar(c, 'banana prata kg', pid)
        catalogo.definir_tipo(c, pid, 'Hortifrúti')
        with pytest.raises(ErroValidacao):
            catalogo.definir_tipo(c, pid, 'Inventado')


def test_ferramenta_de_catalogo_le_gz_em_fluxo(tmp_path, monkeypatch):
    """O arquivo grande vem .csv.gz: a ferramenta lê em fluxo, filtra o país e grava a atribuição."""
    import gzip
    import subprocess
    import sys
    from pathlib import Path
    arq = tmp_path / 'produtos.csv.gz'
    with gzip.open(arq, 'wt', encoding='utf-8') as f:
        f.write('code\tproduct_name\tbrands\tquantity\tcountries_tags\n')
        for i in range(500):
            f.write(f'789{i:010d}\tProduto {i}\tMarca\t1 un\t{"en:brazil" if i % 2 else "en:portugal"}\n')
    dados = tmp_path / 'dados'
    raiz = Path(__file__).resolve().parents[2]
    r = subprocess.run([sys.executable, str(raiz / 'ferramentas' / 'importar_catalogo.py'), str(arq), '--fonte', 'off'],
                       capture_output=True, text=True, env={**__import__('os').environ, 'FIN404_DATA': str(dados)})
    assert r.returncode == 0, r.stderr
    assert 'Pronto: 250 produto(s) gravados de 500 lidos' in r.stdout


def test_semelhanca_conta_abreviacao_uma_vez():
    t = catalogo._tokens
    assert catalogo._parecido(t('lt italac integral'), t('leite int italac 1l')) == 40       # italac + int~integral
    assert catalogo._parecido(t('arroz tio joao'), t('detergente ype')) == 0
    assert catalogo._parecido(t('cafe pilao'), t('cafe pilao')) == 100
