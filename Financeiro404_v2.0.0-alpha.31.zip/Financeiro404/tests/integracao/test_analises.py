"""Simulador de dívidas, cobranças fixas, gastos fora do padrão, limite, metas e apoio ao IRPF."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao, centavos
from fin404.dominio import analises, cartoes, metas, operacoes, razao, relatorios, simulador


# ------------------------------------------------------------------ simulador

def test_rotativo_respeita_teto_legal():
    # 16,53% a.m. pagando R$ 1.500: sem teto os juros passariam de R$ 16 mil; com o teto, ficam em 100% da dívida.
    r = simulador.rotativo(812345, '16.53', 150000)
    assert r['teto'] is True
    assert r['juros'] == 812345
    assert r['total'] == 2 * 812345


def test_rotativo_sem_bater_teto():
    r = simulador.rotativo(100000, '2', 50000)
    assert r['teto'] is False and r['meses'] == 3
    assert 0 < r['juros'] < 10000


def test_parcelamento_com_teto_e_emprestimo_sem_teto():
    p = simulador.price(100000, '15', 24, teto_legal=True)
    assert p['teto'] is True and p['juros'] <= 100000
    e = simulador.price(100000, '15', 24, teto_legal=False)
    assert e['teto'] is False and e['juros'] > 100000


def test_comparar_ordem_e_validacao():
    ops = simulador.comparar(812345, 150000, '16.53', '6.09', 12, '3.5', 12)
    assert [o['nome'][:8] for o in ops] == ['Pagar tu', 'Rotativo', 'Parcelar', 'Emprésti']
    assert ops[2]['parcela'] == 97373   # conferido com a calculadora Price
    assert ops[3]['juros'] < ops[2]['juros'] < ops[1]['juros']
    with pytest.raises(ErroValidacao):
        simulador.comparar(0, 1, '1', '1', 12)


def test_rotativo_pagamento_minusculo_nao_quita_em_dez_anos():
    r = simulador.rotativo(812345, '16.53', 100)
    assert r['nunca_quita'] is True


# ------------------------------------------------------------------ cobranças fixas e padrões

def test_recorrentes_acha_assinatura_e_aumento(banco, contas):
    with banco.transacao() as c:
        for m, v in ((6, '39,90'), (7, '39,90'), (8, '39,90'), (9, '44,90')):
            cartoes.compra(c, contas['cartao'], date(2026, m, 10), 'NETFLIX.COM', centavos(v),
                           contas['Assinaturas'])
        for m in (6, 7, 8, 9):
            for d in (2, 9, 16):  # padaria várias vezes no mês: não é cobrança fixa
                operacoes.despesa(c, date(2026, m, d), 'PADARIA PAO QUENTE', 1500, contas['Mercado'], contas['dinheiro'])
        cartoes.compra(c, contas['cartao'], date(2026, 6, 20), 'LOJA TV', 300000, contas['Casa nova'], parcelas=6)
        itens = analises.recorrentes(c, date(2026, 9, 20))
    nomes = [x['descricao'] for x in itens]
    assert nomes == ['NETFLIX.COM']
    x = itens[0]
    assert x['ultimo'] == 4490 and x['anterior'] == 3990 and x['aumento'] == 500 and x['meses'] == 4


def test_gasto_fora_do_padrao(banco, contas):
    with banco.transacao() as c:
        for m in (6, 7, 8):
            operacoes.despesa(c, date(2026, m, 5), 'MERCADO', 100000, contas['Mercado'], contas['dinheiro'])
        operacoes.despesa(c, date(2026, 9, 5), 'MERCADO', 145000, contas['Mercado'], contas['dinheiro'])
        operacoes.despesa(c, date(2026, 9, 6), 'IFOOD', 9000, contas['Restaurantes e delivery'], contas['dinheiro'])  # sem histórico
        itens = analises.gastos_fora_do_padrao(c, '2026-09')
    assert [(x['categoria'], x['atual'], x['media']) for x in itens] == [('Mercado', 145000, 100000)]


def test_limite_apertado_vira_alerta(banco, contas):
    with banco.transacao() as c:
        cartoes.compra(c, contas['cartao'], date(2026, 9, 1), 'NOTEBOOK', 950000, contas['Casa nova'], parcelas=10)
        assert analises.limites_apertados(c)[0]['uso_pct'] == 95
        textos = [t for _, t, _ in relatorios.alertas(c, date(2026, 9, 2))]
    assert any('95% do limite' in t for t in textos)


def test_custo_do_credito_no_mes(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 9, 3), 'IOF ROTATIVO', 1234, contas['Juros, tarifas e IOF'], contas['corrente'])
        operacoes.despesa(c, date(2026, 9, 4), 'JUROS ROTATIVO', 20000, contas['Juros, tarifas e IOF'], contas['corrente'])
        assert relatorios.resumo_mes(c, '2026-09')['custo_credito'] == 21234
        assert analises.custo_credito(c, '2026-09-01', '2026-09-30') == 21234
        assert relatorios.resumo_mes(c, '2026-08')['custo_credito'] == 0


# ------------------------------------------------------------------ metas

def test_meta_manual_e_por_conta(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['poupanca'], date(2026, 1, 1), 300000)
        m1 = metas.criar(c, 'Reserva', 1200000, conta_id=contas['poupanca'], prazo='2026-12')
        m2 = metas.criar(c, 'Viagem', 100000, guardado=25000)
        with pytest.raises(ErroValidacao):
            metas.criar(c, 'Errada', 1000, conta_id=contas['cartao'])
        with pytest.raises(ErroValidacao):
            metas.criar(c, '', 1000)
        lista = {m['id']: m for m in metas.listar(c, date(2026, 11, 5))}
    r = lista[m1]
    assert r['atual'] == 300000 and r['falta'] == 900000 and r['meses'] == 2 and r['por_mes'] == 450000 and r['pct'] == 25
    v = lista[m2]
    assert v['atual'] == 25000 and v['por_mes'] is None and v['origem'] == 'informado'


def test_meta_arredonda_para_cima_e_prazo_vencido(banco, contas):
    with banco.transacao() as c:
        m = metas.criar(c, 'Curso', 100001, prazo='2027-01')
        atrasada = metas.criar(c, 'Antiga', 5000, prazo='2026-01')
        lista = {x['id']: x for x in metas.listar(c, date(2026, 11, 5))}
        metas.encerrar(c, atrasada)
        ativas = [x['id'] for x in metas.listar(c, date(2026, 11, 5))]
    assert lista[m]['por_mes'] == 33334  # 3 meses; 33.333,67 arredondado para cima
    assert lista[atrasada]['atrasada'] is True
    assert ativas == [m]


# ------------------------------------------------------------------ IRPF

def test_irpf_reune_saude_educacao_e_saldos(banco, contas):
    with banco.transacao() as c:
        saude = c.execute("SELECT id FROM contas WHERE nome='Saúde'").fetchone()[0]
        educ = c.execute("SELECT id FROM contas WHERE nome='Educação'").fetchone()[0]
        operacoes.saldo_inicial(c, contas['corrente'], date(2025, 1, 1), 500000)
        operacoes.despesa(c, date(2025, 3, 10), 'CONSULTA DR SILVA', 35000, saude, contas['corrente'])
        operacoes.despesa(c, date(2025, 4, 2), 'ESCOLA ABC', 120000, educ, contas['corrente'])
        operacoes.despesa(c, date(2026, 1, 5), 'ESCOLA ABC', 120000, educ, contas['corrente'])  # outro ano
        r = analises.irpf(c, 2025)
    assert r['total_saude'] == 35000 and r['total_educacao'] == 120000
    corrente = next(k for k in r['bens'] if k['id'] == contas['corrente'])
    assert corrente['saldo_natural'] == 500000 - 35000 - 120000 and corrente['saldo_anterior'] == 0


def test_irpf_separa_farmacia_e_aponta_farmacia_em_saude(banco, contas):
    with banco.transacao() as c:
        ids = {n: c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome=?", (n,)).fetchone()[0]
               for n in ('Saúde', 'Farmácia e remédios')}
        operacoes.despesa(c, date(2025, 2, 1), 'DROGASIL 123', 5000, ids['Saúde'], contas['corrente'])        # erro comum
        operacoes.despesa(c, date(2025, 2, 2), 'DROGARIA SAO PAULO', 7000, ids['Farmácia e remédios'], contas['corrente'])
        operacoes.despesa(c, date(2025, 2, 3), 'CLINICA SORRISO', 20000, ids['Saúde'], contas['corrente'])
        r = analises.irpf(c, 2025)
    assert r['total_saude'] == 25000 and r['total_farmacia'] == 7000
    assert [x['parece_farmacia'] for x in r['despesas'][analises.SAUDE]] == [True, False]


def test_categoria_inferida_separa_farmacia_de_saude(banco, contas):
    from fin404.dominio import categorias
    with banco.conexao() as c:
        nomes = {d: c.execute('SELECT nome FROM contas WHERE id=?', (categorias.inferir(c, d)[0],)).fetchone()[0]
                 for d in ('DROGARIA SAO PAULO', 'CONSULTA DR SILVA', 'LABORATORIO FLEURY')}
    assert nomes == {'DROGARIA SAO PAULO': 'Farmácia e remédios', 'CONSULTA DR SILVA': 'Saúde', 'LABORATORIO FLEURY': 'Saúde'}


def test_dispensar_alerta_e_reexibir(banco, contas):
    with banco.transacao() as c:
        cartoes.compra(c, contas['cartao'], date(2026, 9, 1), 'NOTEBOOK', 950000, contas['Casa nova'], parcelas=10)
        vis, ocultos = relatorios.alertas_visiveis(c, date(2026, 9, 2))
        alvo = next(a for a in vis if 'limite' in a[1])
        assert relatorios.dispensar_alerta(c, alvo[3], alvo[0], date(2026, 9, 2)) == 30
        vis2, ocultos2 = relatorios.alertas_visiveis(c, date(2026, 9, 2))
        assert ocultos2 == ocultos + 1 and not any('limite' in a[1] for a in vis2)
        # Mesmo alerta com números diferentes continua dispensado; depois de 30 dias volta.
        cartoes.compra(c, contas['cartao'], date(2026, 9, 1), 'CABO', 1000, contas['Casa nova'])
        assert not any('limite' in a[1] for a in relatorios.alertas_visiveis(c, date(2026, 9, 3))[0])
        assert any('limite' in a[1] for a in relatorios.alertas_visiveis(c, date(2026, 10, 5))[0])
        with pytest.raises(ErroValidacao):
            relatorios.dispensar_alerta(c, 'x" onmouseover="', 'conferir')
        relatorios.reexibir_alertas(c)
        assert relatorios.alertas_visiveis(c, date(2026, 9, 2))[1] == 0


def test_limite_estourado_fala_como_o_banco(banco, contas):
    with banco.transacao() as c:
        cartoes.compra(c, contas['cartao'], date(2026, 9, 1), 'TV', 1025293, contas['Casa nova'], parcelas=10)
        textos = [t for _, t, _ in relatorios.alertas(c, date(2026, 9, 2))]
    assert any('todo usado' in t and 'R$ 252,93 acima do limite' in t for t in textos)


def test_restaurar_da_lixeira_em_mes_fechado_da_mensagem_clara(banco, contas):
    from fin404.dominio import razao
    with banco.transacao() as c:
        t = operacoes.despesa(c, date(2026, 9, 5), 'MERCADO', 1000, contas['Mercado'], contas['corrente'])
        razao.excluir(c, t[0] if isinstance(t, list) else t)
        c.execute("INSERT INTO meses_fechados(mes) VALUES('2026-09')")
        aud = razao.lixeira(c)[0]['auditoria_id']
        with pytest.raises(ErroValidacao, match='mês está fechado'):
            razao.restaurar(c, aud)
        c.execute("DELETE FROM meses_fechados WHERE mes='2026-09'")
        assert razao.restaurar(c, aud)


# ------------------------------------------------------------------ raio-x, provisões, tendência, pistas

def _cat(c, nome, tipo='despesa'):
    return c.execute('SELECT id FROM contas WHERE tipo=? AND nome=?', (tipo, nome)).fetchone()[0]


def test_raio_x_custo_minimo_reserva_e_cenarios(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['poupanca'], date(2026, 1, 1), 1200000)
        operacoes.saldo_inicial(c, contas['corrente'], date(2026, 1, 1), 0)
        for m in (8, 9, 10):
            operacoes.receita(c, date(2026, m, 5), 'SALARIO', 800000, contas['Salário'], contas['corrente'])
            operacoes.despesa(c, date(2026, m, 6), 'ALUGUEL', 300000, contas['Moradia'], contas['corrente'])          # essencial
            operacoes.despesa(c, date(2026, m, 7), 'MERCADO', 150000, contas['Mercado'], contas['corrente'])          # essencial
            operacoes.despesa(c, date(2026, m, 8), 'JUROS', 50000, contas['Juros, tarifas e IOF'], contas['corrente'])  # comprometido
            operacoes.despesa(c, date(2026, m, 9), 'RESTAURANTE', 100000, contas['Restaurantes e delivery'], contas['corrente'])
        # Despesa anual prevista (IPVA 2.400 em março): entra como 200/mês e não é contada na média quando acontece.
        operacoes.criar_previsao(c, 'IPVA', 240000, contas['corrente'], contas['Outras despesas'], 'saida', 15, '2026-01',
                                 periodicidade='anual', mes_do_ano=3)
        r = analises.raio_x(c, date(2026, 11, 5), queda_pct=50)
    assert r['janela'] == ['2026-08', '2026-09', '2026-10'] and r['meses_com_dados'] == 3
    assert r['media']['essencial'] == 450000 and r['media']['comprometido'] == 50000 and r['media']['discricionario'] == 100000
    assert r['provisao_mes'] == 20000
    assert r['custo_minimo'] == 520000 and r['custo_total'] == 620000 and r['renda'] == 800000 and r['sobra'] == 180000
    # Reserva = poupança 12.000 + corrente (3 x (8.000 - 6.000)) = 18.000; cobre 18.000 / 5.200 = 3,4 meses
    assert r['reserva'] == 1800000 and r['cobertura_minimo'] == 34
    # Renda cai 50% (4.000): mantendo os gastos faltam 2.200/mês (8,1 meses); cortando o discricionário faltam 1.200 (15 meses).
    assert r['mantendo']['deficit'] == 220000 and r['mantendo']['meses'] == 81
    assert r['cortando']['deficit'] == 120000 and r['cortando']['meses'] == 150
    assert [x['nome'] for x in r['cortes']] == ['Restaurantes e delivery']


def test_previsao_anual_gera_so_no_mes_certo(banco, contas):
    with banco.transacao() as c:
        operacoes.criar_previsao(c, 'IPTU', 120000, contas['corrente'], contas['Moradia'], 'saida', 10, '2026-01',
                                 periodicidade='anual', mes_do_ano=2)
        with pytest.raises(ErroValidacao):
            operacoes.criar_previsao(c, 'X', 100, contas['corrente'], contas['Moradia'], 'saida', 10, '2026-01', periodicidade='anual')
        n = operacoes.gerar_previsoes(c, '2028-12', hoje=date(2026, 11, 5))
        datas = [r[0] for r in c.execute("SELECT data FROM transacoes WHERE descricao='IPTU' ORDER BY data")]
        assert operacoes.provisoes_anuais(c)['por_mes'] == 10000
    assert n == 2 and datas == ['2027-02-10', '2028-02-10']


def test_tendencia_de_alta_por_tres_meses(banco, contas):
    with banco.transacao() as c:
        for m, v in ((8, 40000), (9, 50000), (10, 65000)):
            operacoes.despesa(c, date(2026, m, 10), 'IFOOD', v, contas['Restaurantes e delivery'], contas['dinheiro'])
        for m, v in ((8, 40000), (9, 30000), (10, 65000)):  # subiu, mas não de forma contínua
            operacoes.despesa(c, date(2026, m, 10), 'MERCADO', v, contas['Mercado'], contas['dinheiro'])
        itens = analises.tendencias(c, date(2026, 11, 5))
        textos = [t for _, t, _ in relatorios.alertas(c, date(2026, 11, 5))]
    assert [x['categoria'] for x in itens] == ['Restaurantes e delivery']
    assert any('sobe há 3 meses' in t for t in textos)


def test_pistas_da_diferenca(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], date(2026, 10, 1), 500000)
        operacoes.criar_previsao(c, 'ALUGUEL', 200000, contas['corrente'], contas['Moradia'], 'saida', 5, '2026-11')
        operacoes.gerar_previsoes(c, '2026-12', hoje=date(2026, 11, 1))
        operacoes.despesa(c, date(2026, 11, 2), 'PIX PADARIA', 1850, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, date(2026, 11, 3), 'PIX PADARIA', 1850, contas['Mercado'], contas['corrente'])   # em dobro
        operacoes.receita(c, date(2026, 11, 4), 'CONTA DE LUZ', 15000, contas['Outras receitas'], contas['corrente'])  # sentido errado
        calc = operacoes.conciliar_saldo(c, contas['corrente'], '2026-11-06', 0)['calculado']
        # Banco: aluguel saiu, padaria uma vez só, luz foi saída.
        banco_real = 500000 - 200000 - 1850 - 15000
        dif = banco_real - calc
        pistas = operacoes.pistas_da_diferenca(c, contas['corrente'], '2026-11-06', dif)
        assert [p['tipo'] for p in pistas] and all(not p['exata'] for p in pistas if p['tipo'] == 'duplicado')
        tipos = {p['tipo'] for p in pistas}
        assert {'previsto', 'duplicado'} <= tipos
        # Cada causa isolada é reconhecida como exata
        assert any(p['exata'] for p in operacoes.pistas_da_diferenca(c, contas['corrente'], '2026-11-06', -200000) if p['tipo'] == 'previsto')
        assert any(p['exata'] for p in operacoes.pistas_da_diferenca(c, contas['corrente'], '2026-11-06', 1850) if p['tipo'] == 'duplicado')  # o banco tem 18,50 a mais
        assert any(p['tipo'] == 'sinal' for p in operacoes.pistas_da_diferenca(c, contas['corrente'], '2026-11-06', -30000))


def test_natureza_das_categorias_semeada(banco):
    with banco.conexao() as c:
        nat = {r['nome']: r['natureza'] for r in c.execute("SELECT nome, natureza FROM contas WHERE tipo='despesa'")}
    assert nat['Moradia'] == 'essencial' and nat['Juros, tarifas e IOF'] == 'comprometido'
    assert nat['Lazer e viagens'] == 'discricionario' and nat['Farmácia e remédios'] == 'essencial'
    assert 'Saúde e farmácia' not in nat


def test_raio_x_separa_liquidez_imediata_de_investimentos(banco, contas):
    """Investimento entra na reserva, mas a cobertura 'sem investimentos' mostra o que as contas aguentam sozinhas."""
    with banco.transacao() as c:
        tesouro = razao.criar_conta(c, 'Tesouro IPCA 2035', 'investimento')
        carro = razao.criar_conta(c, 'Carro', 'bem')
        operacoes.saldo_inicial(c, contas['corrente'], date(2026, 1, 1), 500000)
        operacoes.saldo_inicial(c, tesouro, date(2026, 1, 1), 2000000)
        operacoes.saldo_inicial(c, carro, date(2026, 1, 1), 5000000)
        operacoes.despesa(c, date(2026, 11, 2), 'MERCADO', 100000, contas['Mercado'], contas['cartao'])
        for m in (8, 9, 10):
            operacoes.despesa(c, date(2026, m, 6), 'ALUGUEL', 200000, contas['Moradia'], contas['corrente'])
        r = analises.raio_x(c, date(2026, 11, 5))
        f = analises.folga_dias(c, date(2026, 11, 5))
    assert f['livre'] == -200000 and f['dias'] == 0   # a fatura sai do mesmo dinheiro: folga não pode ignorar o cartão
    # corrente 5.000 − 3×2.000 = −1.000; menos 1.000 do cartão = −2.000 na mão; + 20.000 do Tesouro = 18.000. O carro não entra.
    assert r['reserva_imediata'] == -200000 and r['reserva'] == 1800000
    assert r['cobertura_imediata'] == 0 and r['cobertura_minimo'] == 90
