"""R3 — valores a receber: nunca despesa nem receita; saldo por pessoa; devolução parcial; conversão de despesa."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import analises, operacoes, razao, receber, relatorios

HOJE = date(2026, 11, 20)


def test_a_receber_nao_e_despesa_e_entra_so_no_patrimonio(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], date(2026, 10, 1), 500000)
        antes = relatorios.posicao(c, HOJE)
        mae = receber.pessoa(c, nome='Mãe')
        receber.emprestar(c, date(2026, 11, 5), mae, 120000, contas['corrente'], 'Remédio da mãe')
        receber.emprestar(c, date(2026, 11, 6), mae, 30000, contas['cartao'], 'Ingresso')           # no cartão também
        r = relatorios.resumo_mes(c, '2026-11')
        p = relatorios.posicao(c, HOJE)
        assert r['total_despesas'] == 0 and r['total_receitas'] == 0
        assert p['a_receber'] == 150000 and p['disponivel'] == antes['disponivel'] - 120000 and p['cartoes'] == 30000
        assert p['patrimonio_liquido'] == antes['patrimonio_liquido']           # só mudou de forma
        assert p['bens'] == 0                                                   # não é bem
        rx = analises.raio_x(c, HOJE)
        assert rx['reserva'] == p['disponivel'] + p['investimentos'] - p['cartoes']   # a receber fora da reserva
        assert razao.verificar_tudo(c) == []
        # a conta especial não aparece nas listas de escolha
        assert receber.conta(c) not in [k['id'] for k in razao.contas(c)]
        assert receber.conta(c) in [k['id'] for k in razao.contas(c, incluir_papeis=True)]


def test_devolucao_parcial_e_quem_deve_fifo(banco, contas):
    with banco.transacao() as c:
        carlos = receber.pessoa(c, nome='Carlos')
        ana = receber.pessoa(c, nome='Ana')
        assert receber.pessoa(c, nome='carlos') == carlos                    # não duplica pelo nome
        receber.emprestar(c, date(2026, 6, 1), carlos, 50000, contas['corrente'], 'Empréstimo')
        receber.emprestar(c, date(2026, 9, 1), carlos, 20000, contas['corrente'], 'Pizza')
        receber.emprestar(c, date(2026, 11, 1), ana, 10000, contas['corrente'], 'Uber')
        receber.receber(c, date(2026, 10, 1), carlos, 60000, contas['corrente'])                   # parcial
        assert relatorios.resumo_mes(c, '2026-10')['total_receitas'] == 0
        devem = {x['nome']: x for x in receber.quem_deve(c, HOJE)}
        assert devem['Carlos']['aberto'] == 10000 and devem['Carlos']['desde'] == '2026-09-01'      # o mais antigo foi quitado
        assert [(i['descricao'], i['restante']) for i in devem['Carlos']['itens']] == [('Pizza', 10000)]
        assert devem['Ana']['aberto'] == 10000 and devem['Carlos']['devolvido'] == 60000
        with pytest.raises(ErroValidacao, match='deve R\\$ 100,00'):
            receber.receber(c, date(2026, 11, 2), ana, 20000, contas['corrente'])
        with pytest.raises(ErroValidacao, match='não num cartão'):
            receber.receber(c, date(2026, 11, 2), ana, 5000, contas['cartao'])
        receber.receber(c, date(2026, 11, 3), ana, 10000, contas['corrente'])
        assert [x['nome'] for x in receber.quem_deve(c, HOJE)] == ['Carlos']
        assert receber.alertas(c, HOJE) == []                                  # 80 dias: ainda não alerta
        assert 'Carlos deve R$ 100,00 desde 01/09/2026' in receber.alertas(c, date(2026, 12, 15))[0][1]


def test_converter_despesa_importada_em_a_receber(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 11, 10), 'SHOW INGRESSO', 25000, contas['Restaurantes e delivery'], contas['cartao'])
        assert relatorios.resumo_mes(c, '2026-11')['total_despesas'] == 25000
        joao = receber.pessoa(c, nome='João')
        receber.converter_despesa(c, tid, joao)
        assert relatorios.resumo_mes(c, '2026-11')['total_despesas'] == 0
        assert razao.transacao(c, tid)['tipo'] == 'transferencia'
        assert receber.saldo_da_pessoa(c, joao) == 25000
        assert razao.saldo(c, contas['cartao']) == -25000                      # o cartão continua devendo
        with pytest.raises(ErroValidacao, match='Só uma despesa'):
            receber.converter_despesa(c, tid, joao)
        [t2] = operacoes.despesa(c, date(2026, 11, 11), 'MERCADO', 9000, contas['Mercado'], contas['cartao'])
        razao.dividir(c, t2, [(contas['Mercado'], 5000), (contas['Restaurantes e delivery'], 4000)])
        with pytest.raises(ErroValidacao, match='dividido'):
            receber.converter_despesa(c, t2, joao)
        assert razao.verificar_tudo(c) == []


def test_converter_respeita_mes_fechado(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 9, 10), 'PRESENTE', 10000, contas['Restaurantes e delivery'], contas['corrente'])
        c.execute("INSERT INTO meses_fechados(mes) VALUES('2026-09')")
        with pytest.raises(ErroValidacao, match='mês está fechado'):
            receber.converter_despesa(c, tid, receber.pessoa(c, nome='Zé'))
