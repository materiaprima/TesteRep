"""R12 — prazos e garantias: aviso configurável, garantia some depois de acabar, renovação, busca e garantia de compra."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import anexos, compras, operacoes, prazos, relatorios

HOJE = date(2026, 11, 8)


def test_garantia_avisa_30_dias_e_some_depois_de_acabar(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2025, 12, 10), 'GELADEIRA FROST FREE', 350000, contas['Casa nova'], contas['cartao'])
        pid = prazos.garantia(c, 'Geladeira', date(2025, 12, 10), 12, transacao_id=tid)
        assert prazos.um(c, pid)['data_fim'] == '2026-12-10'
        assert prazos.alertas(c, date(2026, 11, 9)) == []                                       # 31 dias: ainda não
        nivel, texto, _ = prazos.alertas(c, date(2026, 11, 10))[0]                             # 30 dias: avisa
        assert nivel == 'conferir' and 'garantia de Geladeira acaba em 10/12/2026 (30 dias)' in texto
        assert any('garantia de Geladeira' in t for _, t, _ in relatorios.alertas(c, date(2026, 11, 10)))
        assert prazos.alertas(c, date(2026, 12, 11)) == []                                      # acabou: some
        assert prazos.abertos(c, date(2026, 12, 11)) == [] and prazos.encerrados(c, date(2026, 12, 11))[0]['id'] == pid
        assert [g['id'] for g in prazos.de_transacao(c, tid)] == [pid]


def test_prazo_nao_financeiro_aviso_configuravel_vencido_e_renovacao(banco, contas):
    with banco.transacao() as c:
        cnh = prazos.criar(c, 'cnh', 'CNH do José', date(2027, 1, 20), avisar_dias=90)
        lic = prazos.criar(c, 'licenciamento', 'Licenciamento do carro', date(2026, 11, 30), avisar_dias=15)
        assert {p['id'] for _, _, p in prazos.alertas(c, HOJE)} == {cnh}                        # 73 dias ≤ 90; 22 > 15
        assert {p['id'] for _, _, p in prazos.alertas(c, date(2026, 11, 16))} == {cnh, lic}
        nivel, texto, _ = [a for a in prazos.alertas(c, date(2026, 12, 2)) if a[2]['id'] == lic][0]
        assert nivel == 'urgente' and 'venceu' in texto                                         # vencido segue avisando
        novo = prazos.concluir(c, lic, renovar=True, hoje=date(2026, 12, 2))                    # licenciamento: 12 meses por padrão
        assert prazos.um(c, novo)['data_fim'] == '2027-11-30' and prazos.um(c, novo)['repete_meses'] == 12
        outro = prazos.criar(c, 'documento', 'Passaporte', date(2027, 5, 1))
        with pytest.raises(ErroValidacao, match='de quanto em quanto tempo'):
            prazos.concluir(c, outro, renovar=True)
        with pytest.raises(ErroValidacao, match='Escolha o tipo'):
            prazos.criar(c, 'xyz', 'X', HOJE)
        assert prazos.excluir(c, cnh) == 'CNH do José'


def test_busca_acha_garantia_e_comprovante(banco, contas):
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 3, 1), 'MAGAZINE GELADEIRA', 350000, contas['Casa nova'], contas['cartao'])
        anexos.adicionar(c, tid, 'nota.pdf', b'%PDF-1.4 nota fiscal ficticia')
        prazos.garantia(c, 'Geladeira', date(2026, 3, 1), 12, transacao_id=tid)
        operacoes.despesa(c, date(2026, 4, 1), 'GELADEIRA DA MAE', 10000, contas['Casa nova'], contas['corrente'])
        r = prazos.buscar(c, 'geladeira', HOJE)
        assert r['prazos'][0]['estado'] == 'na garantia' and r['prazos'][0]['anexos'][0]['nome'] == 'nota.pdf'
        assert [t['descricao'] for t in r['lancamentos']] == ['GELADEIRA DA MAE']              # sem garantia registrada
        assert prazos.buscar(c, 'g') == {'prazos': [], 'lancamentos': []}


def test_compra_planejada_com_garantia_vira_prazo_ao_comprar(banco, contas):
    with banco.transacao() as c:
        item = compras.criar(c, 'Máquina de lavar', 250000, contas['Casa nova'], 'necessario', '2026-12', garantia_meses=12)
        ids, _ = compras.comprar(c, item, '2026-11-20', contas['cartao'])
        g = prazos.de_transacao(c, ids[0])[0]
        assert (g['tipo'], g['titulo'], g['data_fim'], g['compra_id']) == ('garantia', 'Máquina de lavar', '2027-11-20', item)
        sem = compras.criar(c, 'Rodo', 3000, None, 'desejo', '2026-12')
        compras.marcar_comprada(c, sem, hoje=HOJE)
        assert c.execute('SELECT COUNT(*) FROM prazos').fetchone()[0] == 1
        with pytest.raises(ErroValidacao, match='Garantia entre'):
            compras.criar(c, 'X', 100, garantia_meses=500)


def test_garantia_de_compra_parcelada_conta_da_compra_e_vale_para_todas_as_parcelas(banco, contas):
    with banco.transacao() as c:
        ids = operacoes.despesa(c, date(2026, 10, 31), 'TV SALA', 300000, contas['Casa nova'], contas['cartao'], 10)
        terceira = ids[2]
        pid = prazos.garantia_de_lancamento(c, terceira, 'TV da sala', 12)
        g = prazos.um(c, pid)
        assert g['data_fim'] == '2027-10-31' and g['transacao_id'] == ids[0]        # da compra, ligada à 1ª parcela
        assert all(prazos.de_transacao(c, t)[0]['id'] == pid for t in ids)
        assert prazos.buscar(c, 'TV', date(2026, 11, 8))['lancamentos'] == []     # nenhuma parcela "sem garantia"
