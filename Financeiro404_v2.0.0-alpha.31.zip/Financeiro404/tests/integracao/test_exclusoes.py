"""Exclusão de cadastros: só o que não tem histórico; o resto se desativa."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import cartoes, metas, operacoes, razao


def test_conta_sem_historico_e_excluida_com_saldo_inicial_e_previsoes(banco, contas):
    with banco.transacao() as c:
        k = razao.criar_conta(c, 'CC criada por engano', 'corrente')
        operacoes.saldo_inicial(c, k, date(2026, 11, 1), 50000)
        operacoes.criar_previsao(c, 'Luz', 20000, k, contas['Moradia'], 'saida', 10, '2026-11')
        operacoes.gerar_previsoes(c, '2027-01', hoje=date(2026, 11, 6))
        u = razao.uso_da_conta(c, k)
        assert u['lancamentos'] == 0 and u['aberturas'] == 1 and u['previsoes'] == 1
        assert razao.excluir_conta(c, k) == 'CC criada por engano'
        assert c.execute('SELECT COUNT(*) FROM contas WHERE id=?', (k,)).fetchone()[0] == 0
        assert c.execute("SELECT COUNT(*) FROM previsoes WHERE descricao='Luz'").fetchone()[0] == 0
        assert c.execute("SELECT COUNT(*) FROM transacoes WHERE descricao='Luz'").fetchone()[0] == 0
        assert razao.verificar_tudo(c) == []


def test_conta_com_lancamentos_nao_e_excluida(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 11, 2), 'MERCADO', 1000, contas['Mercado'], contas['corrente'])
        with pytest.raises(ErroValidacao, match='desative'):
            razao.excluir_conta(c, contas['corrente'])
        with pytest.raises(ErroValidacao, match='desative'):
            razao.excluir_conta(c, contas['Mercado'])
        cartoes.compra(c, contas['cartao'], date(2026, 11, 2), 'TV', 100000, contas['Casa nova'], parcelas=2)
        with pytest.raises(ErroValidacao):
            razao.excluir_conta(c, contas['cartao'])


def test_categoria_sem_uso_excluida_e_protegidas_nao(banco):
    with banco.transacao() as c:
        k = razao.criar_conta(c, 'Aquário', 'categoria', tipo_categoria='despesa')
        c.execute("INSERT INTO orcamentos(mes, conta_id, valor_centavos) VALUES('2026-11', ?, 1000)", (k,))
        assert razao.excluir_conta(c, k) == 'Aquário'
        assert c.execute('SELECT COUNT(*) FROM orcamentos WHERE conta_id=?', (k,)).fetchone()[0] == 0
        gni = c.execute("SELECT id FROM contas WHERE nome='Gastos não identificados'").fetchone()[0]
        with pytest.raises(ErroValidacao, match='internamente'):
            razao.excluir_conta(c, gni)


def test_excluir_pessoa_meta_e_previsao(banco, contas):
    with banco.transacao() as c:
        pid = c.execute("INSERT INTO pessoas(nome) VALUES('Fulana')").lastrowid
        operacoes.despesa(c, date(2026, 11, 2), 'MERCADO', 1000, contas['Mercado'], contas['corrente'], pessoa_id=pid)
        assert razao.excluir_pessoa(c, pid) == ('Fulana', 1)
        assert c.execute("SELECT COUNT(*) FROM pessoas WHERE nome='Fulana'").fetchone()[0] == 0
        assert c.execute("SELECT COUNT(*) FROM transacoes WHERE descricao='MERCADO'").fetchone()[0] == 1   # o lançamento fica
        m = metas.criar(c, 'Viagem', 100000)
        assert metas.excluir(c, m) == 'Viagem' and metas.listar(c, todas=True) == []
        p = operacoes.criar_previsao(c, 'Internet', 10000, contas['corrente'], contas['Moradia'], 'saida', 10, '2026-11')
        operacoes.gerar_previsoes(c, '2027-02', hoje=date(2026, 11, 1))
        tid = c.execute("SELECT id FROM transacoes WHERE descricao='Internet' ORDER BY data LIMIT 1").fetchone()[0]
        operacoes.confirmar_previsto(c, tid)
        nome, n = operacoes.excluir_previsao(c, p)
        assert nome == 'Internet' and n == 3
        assert [r[0] for r in c.execute("SELECT status FROM transacoes WHERE descricao='Internet'")] == ['confirmada']
        assert razao.verificar_tudo(c) == []


# ------------------------------------------------------------------ recorrência e forma de pagamento

def test_despesa_recorrente_gera_previstos_e_casa_forma(banco, contas):
    from fin404.dominio import relatorios
    with banco.transacao() as c:
        [tid] = operacoes.despesa(c, date(2026, 11, 6), 'NETFLIX', 5590, contas['Assinaturas'], contas['cartao'])
        operacoes.definir_forma(c, [tid], operacoes.forma_padrao(c, contas['cartao']))
        pid = operacoes.repetir(c, tid, 'mensal', hoje=date(2026, 11, 6))
        datas = [r[0] for r in c.execute("SELECT data FROM transacoes WHERE descricao='NETFLIX' AND status='agendada' ORDER BY data")]
        assert datas[0] == '2026-12-06' and len(datas) == 13
        assert {r[0] for r in c.execute("SELECT meio_pagamento FROM transacoes WHERE descricao='NETFLIX'")} == {'credito'}
        assert razao.transacao(c, tid)['previsao_id'] == pid
        with pytest.raises(ErroValidacao):
            operacoes.repetir(c, tid, 'diaria')
        # Anual, com fim
        [t2] = operacoes.despesa(c, date(2026, 3, 15), 'IPVA', 240000, contas['Moradia'], contas['corrente'])
        operacoes.repetir(c, t2, 'anual', ate='2027-12', hoje=date(2026, 11, 6))
        assert [r[0] for r in c.execute("SELECT data FROM transacoes WHERE descricao='IPVA' AND status='agendada'")] == ['2027-03-15']
        # Parcelada não repete
        ids = cartoes.compra(c, contas['cartao'], date(2026, 11, 6), 'SOFA', 300000, contas['Casa nova'], parcelas=3)
        with pytest.raises(ErroValidacao, match='parcelada'):
            operacoes.repetir(c, ids[0], 'mensal')
        operacoes.definir_forma(c, [t2], 'pix')
        with pytest.raises(ErroValidacao):
            operacoes.definir_forma(c, [t2], 'cheque-voador')
        r = dict(relatorios.resumo_mes(c, '2026-03')['por_forma'])
        assert r == {'pix': 240000}
        assert razao.verificar_tudo(c) == []
