"""Fatura do app igual à do banco (pedido do uso real, valores fictícios): dívida anterior ao app como saldo inicial,
e pagamento de fatura que entrou como estorno de categoria."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import cartoes, operacoes, razao, relatorios


def _pagamento_como_estorno(c, contas, valor=380000, quando=date(2026, 10, 1)):
    return razao.registrar(c, quando, 'PGTO. CASH AG. 0000 000000000 200', 'estorno',
                           [(contas['Outras despesas'], -valor), (contas['cartao'], valor)])


def test_pagamento_lancado_como_estorno_e_corrigido(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 9, 20), 'COMPRA', 500000, contas['Mercado'], contas['cartao'])
        tid = _pagamento_como_estorno(c, contas, 380000, date(2026, 9, 25))
        assert relatorios.gastos_do_mes(c, '2026-10', 'fatura')['total'] == 120000          # errado: o pagamento abateu o gasto
        [p] = cartoes.pagamentos_como_gasto(c)
        assert p['id'] == tid and p['valor'] == 380000
        assert any('como estorno' in a[1] for a in relatorios.alertas(c, date(2026, 10, 2)))
        assert cartoes.origem_sugerida(c, p['descricao'])['id'] == contas['corrente']
        with pytest.raises(ErroValidacao):
            cartoes.virar_pagamento(c, tid, contas['Mercado'])
        cartoes.virar_pagamento(c, tid, contas['dinheiro'])
        assert cartoes.pagamentos_como_gasto(c) == []
        assert relatorios.gastos_do_mes(c, '2026-10', 'fatura')['total'] == 500000
        assert razao.transacao(c, tid)['tipo'] == 'pagamento_fatura'
        assert razao.saldo(c, contas['dinheiro']) == -380000 and razao.verificar_tudo(c) == []
        with pytest.raises(ErroValidacao):
            cartoes.virar_pagamento(c, tid, contas['dinheiro'])


def test_saldo_inicial_do_cartao_pela_primeira_fatura(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 9, 20), 'COMPRA', 100000, contas['Mercado'], contas['cartao'])
        c.execute('''INSERT INTO lotes_importacao(conta_id, formato, arquivo, sha256, fatura_fechamento, fatura_saldo_anterior)
                     VALUES(?,?,?,?,?,?)''', (contas['cartao'], 'pdf_bb', 'f.pdf', 'x', '2026-10-05', 250000))
        si = cartoes.saldo_inicial_pendente(c, contas['cartao'])
        assert si['banco'] == 250000 and si['no_app'] == 0 and si['data'] == date(2026, 9, 4)
        assert cartoes.fatura(c, contas['cartao'], date(2026, 10, 5))['valor'] == 100000
        operacoes.saldo_inicial(c, contas['cartao'], si['data'], si['banco'])
        assert cartoes.saldo_inicial_pendente(c, contas['cartao']) is None
        assert cartoes.fatura(c, contas['cartao'], date(2026, 10, 5))['valor'] == 350000
        assert relatorios.gastos_do_mes(c, '2026-10', 'fatura')['total'] == 100000        # dívida antiga não é gasto do mês
