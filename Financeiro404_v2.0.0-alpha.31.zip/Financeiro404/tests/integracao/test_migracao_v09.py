"""Migração da versão antiga (tabela `entries`): totais por mês conferem, nada fica desequilibrado e o banco antigo é só lido."""
import sqlite3

import pytest

from fin404 import migracao_v09
from fin404.dinheiro import ErroValidacao

ESQUEMA = '''
CREATE TABLE accounts(id INTEGER PRIMARY KEY, name TEXT, kind TEXT);
CREATE TABLE entries(id INTEGER PRIMARY KEY, account_id INTEGER, kind TEXT, amount_cents INTEGER, due_date TEXT, event_date TEXT,
                     description TEXT, notes TEXT, status TEXT, category TEXT, installment INTEGER, installments INTEGER);
CREATE TABLE treasury_movements(id INTEGER PRIMARY KEY, operation TEXT, amount_cents INTEGER, effective_date TEXT, description TEXT,
                                source_account INTEGER, destination_account INTEGER, entry_id INTEGER);
CREATE TABLE opening_balances(account_id INTEGER, as_of TEXT, cents INTEGER);
CREATE TABLE card_statements(card_account INTEGER, closing_date TEXT, stated_total_cents INTEGER);
CREATE TABLE recurring(description TEXT, amount_cents INTEGER, account_id INTEGER, category TEXT, kind TEXT, day INTEGER,
                       start_month TEXT, end_month TEXT);
CREATE TABLE budgets(month TEXT, category TEXT, limit_cents INTEGER);
CREATE TABLE goals(id INTEGER PRIMARY KEY, name TEXT);
'''


def _legado(caminho):
    c = sqlite3.connect(caminho)
    c.executescript(ESQUEMA)
    c.executemany('INSERT INTO accounts VALUES(?,?,?)', [(1, 'Conta BB', 'bank'), (2, 'Ourocard', 'card'), (3, 'Carteira', 'cash')])
    c.executemany('INSERT INTO entries VALUES(?,?,?,?,?,?,?,?,?,?,?,?)', [
        (1, 1, 'income', 800000, '2026-09-05', '2026-09-05', 'Salário', '', 'paid', 'Salário', 1, 1),
        (2, 1, 'expense', 150000, '2026-09-10', '2026-09-10', 'Aluguel', '', 'paid', 'Moradia', 1, 1),
        (3, 2, 'expense', 30000, '2026-09-12', '2026-09-12', 'Mercado', 'Importado do CSV', 'pending', 'Mercado', 1, 1),
        (4, 2, 'expense', 20000, '2026-10-12', '2026-09-12', 'Tênis', '', 'pending', 'Vestuário', 2, 3),
        (5, 1, 'expense', 9000, '2026-10-20', '2026-10-20', 'Internet', '', 'pending', 'Assinaturas', 1, 1),
        (6, 1, 'transfer', 5000, '2026-10-01', '2026-10-01', 'Pix sem destino', '', 'paid', '', 1, 1),
        (7, 3, 'expense', 4000, '2026-10-02', '2026-10-02', 'Feira', '', 'paid', 'Categoria que sumiu', 1, 1),
    ])
    c.executemany('INSERT INTO treasury_movements VALUES(?,?,?,?,?,?,?,?)', [
        (1, 'transfer', 10000, '2026-09-15', 'Saque', 1, 3, None),
        (2, 'card_payment', 30000, '2026-10-06', 'Pagamento fatura', 1, 2, None),
        (3, 'refund', 5000, '2026-09-20', 'Estorno mercado', 2, 2, 3),
        (4, 'weird', 1, '2026-09-20', 'Desconhecido', 1, 1, None),
    ])
    c.execute("INSERT INTO opening_balances VALUES(1, '2026-08-31', 100000)")
    c.execute("INSERT INTO card_statements VALUES(2, '2026-09-27', 25000)")
    c.execute("INSERT INTO recurring VALUES('Academia', 12000, 1, 'Lazer', 'expense', 10, '2026-09', NULL)")
    c.execute("INSERT INTO budgets VALUES('2026-10', 'Mercado', 120000)")
    c.execute("INSERT INTO goals(name) VALUES('Viagem')")
    c.commit()
    c.close()


def test_simular_e_executar_conferem_os_totais(banco, tmp_path):
    antigo = tmp_path / 'financeiro.sqlite3'
    _legado(antigo)
    tamanho_antes = antigo.read_bytes()
    rel = migracao_v09.simular(antigo)
    assert rel['totais_conferem'] and rel['contas'] == 3 and rel['lancamentos'] == 7
    assert (rel['transferencias'], rel['pagamentos'], rel['estornos'], rel['saldos_iniciais']) == (1, 1, 1, 1)
    assert rel['agendados'] == 1                          # só a internet: compra no cartão é real mesmo "pendente"
    assert rel['previsoes'] == 1 and rel['orcamentos'] == 1
    assert any('Movimento 4' in x for x in rel['nao_migrado']) and any('Metas' in x for x in rel['nao_migrado'])
    assert any('fechamento e vencimento' in x for x in rel['revisar']) and any('transferência sem conta' in x for x in rel['revisar'])
    with banco.conexao() as c:                            # simulação não grava nada no banco real
        assert c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0] == 0
    rel = migracao_v09.executar(antigo)
    with banco.conexao() as c:
        from fin404.dominio import razao
        assert razao.verificar_tudo(c) == []
        assert c.execute("SELECT nome FROM contas WHERE nome='Categoria que sumiu'").fetchone() is None   # vira Outras despesas
        assert c.execute("SELECT COUNT(*) FROM faturas_documento WHERE origem='v0.9'").fetchone()[0] == 1
    assert antigo.read_bytes() == tamanho_antes            # arquivo antigo intocado
    with pytest.raises(ErroValidacao, match='banco vazio'):
        migracao_v09.executar(antigo)


def test_arquivo_inexistente(banco, tmp_path):
    with pytest.raises(ErroValidacao, match='não encontrado'):
        migracao_v09.simular(tmp_path / 'nao_existe.sqlite3')
