"""R13 — reunião do mês: pauta a partir dos números, registro das decisões e lembrete a partir do dia 10."""
from datetime import date

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import compras, operacoes, relatorios, reuniao


def test_pauta_registro_e_lembrete(banco, contas):
    with banco.transacao() as c:
        operacoes.receita(c, date(2026, 10, 5), 'SALARIO', 300000, contas['Salário'], contas['corrente'])
        operacoes.despesa(c, date(2026, 10, 10), 'ALUGUEL', 350000, contas['Moradia'], contas['corrente'])
        compras.criar(c, 'Pneus', 120000, None, 'necessario', '2026-12')
        p = reuniao.pauta(c, '2026-10', date(2026, 11, 11))
        assert p['resumo']['resultado'] == -50000
        assert any('no negativo' in s for s in p['sugestoes'])
        assert [it['descricao'] for it in p['proximas']] == ['Pneus']
        assert p['registro'] is None
        # dia 9: ainda não lembra; dia 11: lembra; registrada: para de lembrar
        assert reuniao.lembrete(c, date(2026, 11, 9)) is None
        assert reuniao.lembrete(c, date(2026, 11, 11)) == '2026-10'
        assert any('reunião financeira de' in t for _, t, _ in relatorios.alertas(c, date(2026, 11, 11)))
        with pytest.raises(ErroValidacao, match='depois que ele começa'):
            reuniao.registrar(c, '2026-10', date(2026, 9, 30), 'x')
        reuniao.registrar(c, '2026-10', date(2026, 11, 11), '- cortar delivery\n- pneus em dezembro')
        assert reuniao.lembrete(c, date(2026, 11, 11)) is None
        reuniao.registrar(c, '2026-10', date(2026, 11, 12), '- só pneus')                   # atualiza, não duplica
        assert [(h['mes'], h['decisoes']) for h in reuniao.historico(c)] == [('2026-10', '- só pneus')]
        # mês sem nenhum lançamento não gera lembrete (quem está começando)
        assert reuniao.lembrete(c, date(2027, 2, 15)) is None
