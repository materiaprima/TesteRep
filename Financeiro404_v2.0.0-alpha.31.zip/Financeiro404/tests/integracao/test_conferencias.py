"""R11 — completude dos dados: conferências, alerta de 35 dias, trava do fechamento e gasto fora do cartão."""
from datetime import date, timedelta

import pytest

from fin404.dinheiro import ErroValidacao
from fin404.dominio import conferencias, operacoes, razao, relatorios

HOJE = date.today()


def test_conferencia_grava_historico_e_alerta_35_dias(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], HOJE - timedelta(days=60), 100000)
        # Recém-criada e nunca conferida: conta a partir da criação
        assert not [k for k, _, _ in conferencias.alertas(c, HOJE + timedelta(days=30)) if k['id'] == contas['corrente']]
        avisos = {k['id']: t for k, _, t in conferencias.alertas(c, HOJE + timedelta(days=40))}
        assert 'nunca foi conferida' in avisos[contas['corrente']]
        assert contas['cartao'] not in avisos                            # cartão, investimento etc. nunca entram
        # Conferência que não bate não zera o relógio e aparece no texto
        r = conferencias.registrar(c, contas['corrente'], HOJE, 99000)
        assert r['diferenca'] == -1000
        assert 'não bateu' in {k['id']: t for k, _, t in conferencias.alertas(c, HOJE + timedelta(days=40))}[contas['corrente']]
        # Lançar a diferença + nova conferência zerada
        operacoes.lancar_diferenca(c, contas['corrente'], HOJE, 99000)
        assert conferencias.registrar(c, contas['corrente'], HOJE, 99000)['diferenca'] == 0
        assert contas['corrente'] not in {k['id'] for k, _, _ in conferencias.alertas(c, HOJE + timedelta(days=30))}
        assert contas['corrente'] in {k['id'] for k, _, _ in conferencias.alertas(c, HOJE + timedelta(days=36))}
        assert [x['diferenca'] for x in conferencias.historico(c, contas['corrente'])] == [0, -1000]
        assert any('não é conferida' in t for _, t, _ in relatorios.alertas(c, HOJE + timedelta(days=36)))


def test_fechamento_exige_conferir_ou_dispensar(banco, contas):
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, contas['corrente'], date(2026, 9, 1), 100000)
        operacoes.despesa(c, date(2026, 9, 10), 'PIX MERCADO', 20000, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, date(2026, 9, 12), 'FEIRA', 3000, contas['Mercado'], contas['dinheiro'])
        situ = {s['conta']['id']: s['estado'] for s in conferencias.situacao_do_mes(c, '2026-09')}
        assert situ == {contas['corrente']: 'pendente', contas['dinheiro']: 'pendente'}     # poupança sem movimento fica fora
        with pytest.raises(ErroValidacao, match='Antes de fechar'):
            conferencias.fechar_mes(c, '2026-09')
        conferencias.registrar(c, contas['corrente'], '2026-09-30', 79000)             # banco diz 790; calculado 800
        estados = {s['conta']['id']: s['estado'] for s in conferencias.situacao_do_mes(c, '2026-09')}
        assert estados[contas['corrente']] == 'diferenca'                                # 80.000 calculado ≠ 79.000
        conferencias.registrar(c, contas['corrente'], '2026-09-30', 80000)
        # Conferência com data fora do mês não vale para setembro
        conferencias.registrar(c, contas['dinheiro'], '2026-10-01', -3000)
        estados = {s['conta']['id']: s['estado'] for s in conferencias.situacao_do_mes(c, '2026-09')}
        assert estados == {contas['corrente']: 'conferida', contas['dinheiro']: 'pendente'}
        # Uma conferência posterior que não bate desfaz o "conferida"
        conferencias.registrar(c, contas['corrente'], '2026-09-30', 70000)
        assert {s['conta']['id']: s['estado'] for s in conferencias.situacao_do_mes(c, '2026-09')}[contas['corrente']] == 'diferenca'
        conferencias.registrar(c, contas['corrente'], '2026-09-30', 80000)
        with pytest.raises(ErroValidacao, match='Carteira'):
            conferencias.fechar_mes(c, '2026-09')
        conferencias.dispensar(c, '2026-09', contas['dinheiro'], 'carteira não contada')
        conferencias.fechar_mes(c, '2026-09')
        assert c.execute("SELECT 1 FROM meses_fechados WHERE mes='2026-09'").fetchone()
        auditoria = [r[0] for r in c.execute("SELECT detalhes FROM auditoria WHERE acao='dispensar_conferencia'")]
        assert auditoria and 'carteira não contada' in auditoria[0]


def test_gasto_fora_do_cartao_no_resumo(banco, contas):
    with banco.transacao() as c:
        operacoes.despesa(c, date(2026, 9, 10), 'LOJA', 50000, contas['Mercado'], contas['cartao'])
        r = relatorios.resumo_mes(c, '2026-09')
        assert (r['despesas_no_cartao'], r['despesas_fora_cartao']) == (50000, 0)
        operacoes.despesa(c, date(2026, 9, 11), 'PIX', 12000, contas['Mercado'], contas['corrente'])
        operacoes.despesa(c, date(2026, 9, 12), 'BOLETO LUZ', 8000, contas['Moradia'], contas['corrente'])
        r = relatorios.resumo_mes(c, '2026-09')
        assert (r['despesas_no_cartao'], r['despesas_fora_cartao']) == (50000, 20000)
        assert r['despesas_no_cartao'] + r['despesas_fora_cartao'] == r['total_despesas']    # mesma base, sem 2º caminho


def test_atualizar_da_alpha14_acrescenta_conferencias_e_papel(tmp_path, monkeypatch):
    """0012 e 0013 só acrescentam: dados da 0011 intactos, tabelas novas vazias, contas antigas sem papel."""
    import shutil
    monkeypatch.setenv('FIN404_DATA', str(tmp_path / 'dados'))
    from fin404.dados import banco as b
    ate_11 = tmp_path / 'mig'; ate_11.mkdir()
    for p in b.MIGRACOES.glob('*.sql'):
        if int(p.name[:4]) <= 11:
            shutil.copy(p, ate_11)
    original = b.MIGRACOES
    monkeypatch.setattr(b, 'MIGRACOES', ate_11)
    b.migrar()
    with b.transacao() as c:
        k = razao.criar_conta(c, 'Conta', 'corrente')
        cat = c.execute("SELECT id FROM contas WHERE nome='Mercado'").fetchone()[0]
        operacoes.despesa(c, date(2026, 9, 5), 'MERCADO', 1000, cat, k)
    monkeypatch.setattr(b, 'MIGRACOES', original)
    b.migrar()
    with b.conexao() as c:
        assert c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0] == 1
        assert c.execute('SELECT COUNT(*) FROM conferencias').fetchone()[0] == 0
        assert c.execute('SELECT COUNT(*) FROM contas WHERE papel IS NOT NULL').fetchone()[0] == 0
        assert c.execute('PRAGMA foreign_key_check').fetchall() == [] and razao.verificar_tudo(c) == []
