"""Financeiro 404 — inicie com: python app.py  (ou iniciar_windows.bat)"""
import sys
from pathlib import Path

if sys.version_info < (3, 10):
    sys.exit('O Financeiro 404 precisa do Python 3.10 ou mais novo.')
sys.path.insert(0, str(Path(__file__).resolve().parent))

from fin404.web.servidor import main  # noqa: E402

if __name__ == '__main__':
    main()
