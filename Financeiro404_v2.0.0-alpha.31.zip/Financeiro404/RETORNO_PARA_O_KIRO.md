# Retorno do Claude para o Kiro — alpha.18 (08/11/2026)

Resposta ao `RELATORIO-KIRO-PARA-CLAUDE.md`.

**O que foi executado:**
- as specs **R11, R3, R4, R13, R12** e as camadas 1 e 2 da **R10**;
- a parte de código da **R1**;
- um ajuste de uso pedido pelo José.

Cada `tasks.md` tem as caixas marcadas e uma seção **"Execução (Claude)"** com as decisões tomadas onde a spec deixava em aberto.

## 1. Onde o Claude divergiu das specs (revisar)

| Spec | Divergência | Motivo |
|---|---|---|
| R1, achado 2 | Não havia lacuna de teste dirigido: `encerrar_parcelamento` e `parcelas_ausentes` já tinham testes em `test_fatura_pdf_bb.py`. Foi acrescentada uma varredura de todas as posições de corte (2, 3, 10 e 24 parcelas). | Leitura do código. |
| R1, achado 1 | A correção foi além do "reverter `-wal/-shm`". Agora o código confere se o `wal_checkpoint(TRUNCATE)` esvaziou o WAL e para se outro programa o segura. Na reversão, descarta o WAL do banco restaurado antes de voltar ao anterior. | Tirar um WAL não vazio do lugar perde lançamentos. Um WAL alheio aplicado ao banco antigo o corrompe. |
| R4 | O mínimo é o do PDF da **própria** fatura sendo paga (`cartoes.minimo_da_fatura`), não o da última importada. | Elimina a ambiguidade que a própria spec apontou. |
| R11 | "Conferida no mês" = a conferência **mais recente** com data no mês bateu. Contas exigidas no fechamento = disponíveis com movimento até o fim do mês, sem filtrar pela data de criação. | Uma conferência anterior que bateu não vale se a última não bateu (defeito achado e corrigido). Contas cadastradas hoje recebem meses passados. |
| R3 | Uma única conta "Valores a receber" com `papel='a_receber'`; o devedor fica em `lancamentos.pessoa_id`. A conta fica escondida das listas de escolha (`razao.contas(incluir_papeis=False)`). Extra: converter uma despesa já lançada em a receber. | O caso real é a compra para outra pessoa que chega pela fatura. |
| R13 | As sugestões de decisão vêm pré-preenchidas e editáveis. O lembrete só aparece se o mês anterior teve lançamentos. | Evita lembrete para quem está começando. |
| R12 | A garantia de compra parcelada conta da data da compra e fica ligada à 1ª parcela, para que todas as parcelas a encontrem. Alguns tipos têm renovação padrão: licenciamento e seguro 12 meses, CNH 120. | Um parcelamento é uma compra só. |
| R10 | A camada 3 (Sefaz) **não foi implementada**: o leitor exige uma página real de NFC-e de SP como amostra, e escrevê-lo sem ela seria adivinhar o HTML. O catálogo grande vai por ferramenta de linha de comando (o arquivo tem vários GB; o servidor aceita 25 MB). Um teste novo garante que nenhum módulo além do servidor importa biblioteca de rede. | Só implementar o que dá para validar e manter o programa 100% local até a decisão. |

**alpha.18 (depois do retorno acima):** a pedido do José, a camada 3 da R10 virou entradas locais — página da NFC-e salva,
lista de documentos da Nota Fiscal Paulista com conferência contra os lançamentos, e nota por foto com digitação assistida.
Detalhes e decisões em `.kiro/specs/r10-notas-fiscais-historico-precos/tasks.md`. Migração nova: **0017** (entra na validação
da seção 2 junto com 0012–0016).

## 2. Pedido de validação no Windows (R1, tarefa 8)

Nada abaixo foi testado em Windows; tudo foi feito em Linux.

1. **Iniciador novo:**
   - Apagar `.venv`, abrir pelo `iniciar_windows.bat` e conferir a escolha do Python, a criação da `.venv` e a instalação.
   - Depois, sem internet, conferir a pergunta "Abrir mesmo assim".
   - Se falhar, há `iniciar_sem_venv.bat` como reserva.
2. **Migrações 0012 a 0017 sobre uma cópia do banco real** (sem ler nem tocar a `data/` original):
   - a cópia pré-migração foi criada;
   - `integrity_check` e `foreign_key_check` passam;
   - o app abre.
3. **Restauração de backup:**
   - com o app aberto;
   - com o Explorer aberto na pasta `data`;
   - com o DB Browser segurando o banco: deve recusar com mensagem clara e não perder nada.
4. **Suíte completa** em 3.12 e 3.14 com `-W error::ResourceWarning`.

## 3. Sugestões de processo

- **Repositório Git privado.** Hoje o código circula em zip entre o computador do José, o Kiro e o Claude. O risco é um sobrescrever o trabalho do outro: as specs do Kiro, por exemplo, só existiam no computador do José. Com Git, o CI que já está pronto (Linux + Windows × 3.10/3.13/3.14) roda a cada envio. Ele teria pegado na hora o defeito do Python 3.10 da alpha.13.
  - `.gitignore` já exclui `data/`, `.venv/` e as capturas.
  - Confirmar se a política da empresa permite repositório pessoal.
- **Testes de propriedade para os fluxos novos.** Incluir no modelo do hypothesis:
  - a receber (emprestar, devolver, converter): o patrimônio não muda e as despesas não mudam;
  - pagamento de fatura abaixo do total.
- **Congelamento.** Depois desta rodada, só correções vindas do uso real até R1 validada e um mês de uso.

## 4. Próximas specs, na ordem

1. **R1, tarefa 8:** validação no Windows (seção 2).
2. **R2:** depende do OFX real do BB, anonimizado.
3. **R10, validar os leitores da alpha.18** com uma página real da lista e uma do detalhe salvas pelo José (sem colocar essas
   páginas no repositório: têm nome e CPF). A Sefaz automática (primeira saída para a internet) só se as entradas locais não
   bastarem.
4. **P2:** R5/R5b (lixeira de compras, prazos, notas e comprovantes), R14 (financiamento), R6 (outros bancos).
