@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Financeiro 404
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
  where python >nul 2>nul
  if not errorlevel 1 set "PY=python"
)
if not defined PY (
  echo.
  echo  O Python nao foi encontrado neste computador.
  echo  Instale o Python 3.10 ou mais novo e, na primeira tela do instalador,
  echo  marque a opcao "Add Python to PATH". Depois abra este arquivo de novo.
  echo.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)
%PY% -c "import cryptography, pymupdf" >nul 2>nul
if errorlevel 1 (
  echo Instalando componentes do Financeiro 404 ^(so na primeira vez, precisa de internet^)...
  %PY% -m pip install --user --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo Nao foi possivel instalar os componentes. O programa abre mesmo assim,
    echo mas sem backup cifrado e sem leitura de PDF.
    pause
  )
)
%PY% app.py
if errorlevel 1 pause
