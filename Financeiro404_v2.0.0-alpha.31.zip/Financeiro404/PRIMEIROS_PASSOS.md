# Primeiros passos — do zero ao primeiro mês em uma tarde

Tempo estimado: 30 a 60 minutos. Tenha em mãos a fatura do Ourocard em PDF e o saldo atual da conta corrente (o que aparece no app do banco).

**Como o sistema trabalha com o que vocês têm:** a fatura do cartão em PDF traz o detalhe dos gastos no cartão (e as parcelas que ainda vão vir). A conta corrente é acompanhada com previsões (salário, aluguel, contas fixas), lançamentos rápidos do dia a dia e uma conferência mensal com o saldo do app do banco. Nenhum extrato é necessário.

## 1. Instalar (uma vez)

1. Instale o Python 3.10 ou mais novo (python.org). **Marque "Add Python to PATH"** na primeira tela.
2. Extraia a pasta `Financeiro404` em `C:\Financeiro404` (não na Área de Trabalho nem em Documentos, que costumam estar no OneDrive).
3. Dê dois cliques em `criar_atalho_na_area_de_trabalho.bat`.
4. Abra pelo atalho "Financeiro 404". Na primeira vez, ele instala os componentes (precisa de internet) e abre o navegador.

O programa roda numa janela minimizada chamada "Financeiro 404". Para encerrar, feche essa janela. Abrir o atalho de novo com o programa aberto só abre o navegador.

## 2. Se vocês usavam a versão anterior

Copie o `data\financeiro.sqlite3` antigo para a pasta `data` desta versão **antes** de cadastrar qualquer coisa. A tela inicial oferece "Trazer esses dados para cá", com simulação e conferência de totais.

## 3. Cadastros (Contas e dívidas)

| Cadastre | Como |
|---|---|
| Conta corrente do BB | Tipo "Conta corrente". Saldo inicial = saldo do extrato num dia, e essa data. |
| Dinheiro, poupança, investimentos | Mesmo jeito, com o saldo de hoje. |
| Ourocard | Tipo "Cartão de crédito", fechamento 27, vencimento 6, regra "Entra na fatura que fecha". Deixe o saldo inicial em branco: a importação da fatura cuida disso. |

Em **Pessoas**, cadastre os dois pelo primeiro nome. A fatura reconhece o portador pelo nome.

**Saldo inicial da conta corrente:** use o saldo que aparece no app do banco hoje, com a data de hoje. Daqui para a frente o sistema acompanha.

## 4. Importar a fatura do Ourocard

1. **Importar fatura ou extrato** → escolha o Ourocard (ou **"+ Cartão novo"**, se ainda não cadastrou: ele é criado com as datas e o limite da fatura) → envie o PDF da fatura.
2. Na revisão, clique em **"Usar R$ … como saldo inicial do cartão"**. Isso só vale para a primeira fatura de cada cartão.
3. Confira as sugestões e escolha o que falta. Use "lembrar" nas que se repetem (Uber, farmácia, supermercado): na próxima fatura elas já vêm prontas.
4. Clique em **Gravar decisões**. Em "Cartões e faturas", a fatura deve aparecer com "Confere com o documento do banco".

As compras parceladas da fatura ("AMAZON PARC 08/10") geram sozinhas as parcelas que faltam, nas próximas faturas e com a mesma categoria. A tela confere a soma com o "saldo parcelado em faturas futuras" do banco. Assim, os compromissos dos próximos meses aparecem no Início e no fluxo de caixa. Na fatura seguinte, essas parcelas são reconhecidas e não duplicam.

O pagamento de fatura que aparece dentro dela (por exemplo, "PGTO. CASH AG.") é uma transferência da conta ou do dinheiro para o cartão, não uma despesa. Escolha de onde saiu o dinheiro.

A parcela de um parcelamento de fatura ("PAGTO. PARCEL ... PARC 02/02") vem sugerida em "Dívidas antigas e parcelamentos": é dinheiro indo para dívida de antes, não compra nova. O "saldo parcelado em faturas futuras" informado pelo banco **não** precisa ser cadastrado: as parcelas futuras chegam em cada fatura e são importadas na hora certa.

## 5. A conta corrente, sem extrato

1. **Previsões:** cadastre salários, aluguel, escola, contas fixas, com o dia do mês. Elas aparecem no fluxo de caixa.
2. **A pagar e receber:** quando o salário cai ou a conta é paga, abra "A pagar e receber", marque e corrija o valor se mudou (luz, água). O Início avisa quando há algo para confirmar.
3. **Lançamento rápido** (no Início): Pix, débito, saque. Descrição, valor, categoria, pronto.
4. **Uma vez por mês:** em Contas → Conta BB → "Conferir com o banco", digite o saldo que o app do banco mostra. Se não bater, clique em **"Lançar R$ … como gasto não identificado"**. O saldo fica certo e o relatório mostra quanto saiu sem detalhe. O objetivo, com o tempo, é esse valor diminuir.
5. **Pagamento da fatura:** em Cartões e faturas → a fatura → "Pagar esta fatura", saindo da conta corrente. Não é despesa: as despesas são as compras.

O **Fluxo de caixa** junta tudo (previsões, faturas a pagar, parcelas) e avisa se algum dia o saldo fica negativo.

## 6. Proteção

Em **Backup e segurança**:

1. **Backup automático:** informe uma pasta do OneDrive/Google Drive (ou um pendrive que fica conectado) e uma senha forte. Guarde a senha num
   gerenciador de senhas: sem ela, os backups não abrem. O programa não guarda a senha.
2. **Teste o backup** logo depois de ativar (botão "Testar o último backup", com a senha). O sistema lembra de testar de novo a cada 3 meses.
3. **PIN (opcional):** se mais alguém usa o notebook destrancado.

O programa também faz uma cópia local por dia (as últimas 14), mas ela fica no mesmo disco. Excluiu algo sem querer? Veja a **Lixeira** (90 dias).

## 7. Rotina

- **No dia a dia (1 min):** lançamento rápido do que não foi no cartão.
- **Quando a fatura fecha (10 min):** importar o PDF, revisar, gravar, registrar o pagamento.
- **Todo começo de mês (10 min):** marcar o que foi pago em "A pagar e receber", conferir o saldo da conta com o app do banco, "Fechamento do mês" do mês anterior.
- **No dia a dia:** anote os gastos no bloco de notas do celular (`18,50 padaria pix`) e, à noite, cole em **Lançar vários**.
- **No fim do mês:** abra o **Resumo do mês** e mostre para quem divide as contas com você.
- **Quando quiser analisar:** "Relatórios" (mês e ano), "Cobranças fixas" e "Baixar em planilha (CSV)" em Lançamentos.
- **Se a fatura não couber no mês:** abra o **Simulador de dívidas** antes de decidir entre pagar o mínimo, parcelar ou pegar empréstimo.
- **Uma vez:** em **Categorias**, confira o que é essencial e o que dá para cortar; em **Previsões**, cadastre as despesas anuais
  (IPVA, IPTU, seguro, material escolar) como "uma vez por ano"; crie as **Metas** (comece pela reserva de emergência) e liste em **Compras planejadas** o que vocês sabem que vão precisar comprar.
- **Depois do 3º mês:** abra o **Raio-X** (custo de vida mínimo e quanto tempo a reserva aguenta).
- **Antecipou parcelas ou cancelou uma compra parcelada?** Em **Cartões → Compras parceladas**, encerre o parcelamento.
- **Em março/abril:** **Relatórios → Imposto de Renda**. Mude para "Farmácia e remédios" o que estiver marcado como "parece farmácia".

## Notas fiscais (Nota Fiscal Paulista e fotos)

O app não entra na internet; quem abre o site é você, no navegador, e o app lê o que você salvou.

1. **Lista:** no site da Nota Fiscal Paulista, entre com o gov.br, vá em consultar documentos, escolha o período e, na
   página do resultado, aperte **Ctrl+S** e salve como "Página da Web, somente HTML". No app: **Notas fiscais → Trazer notas →
   Lista da Nota Fiscal Paulista**. Cada compra vira uma nota sem itens; a **Conferência** mostra as que não acharam
   lançamento (compras que ficaram fora do app). Mais de uma página de resultados? Salve e importe cada uma.
2. **Itens:** abra o detalhe de uma nota (o site pede um código enviado por e-mail; depois de confirmado, os detalhes ficam liberados por 24 horas) ou leia o QR code do
   cupom com o celular e abra no computador; **Ctrl+S**, "somente HTML". No app: **Trazer notas → Página da nota** (pode
   escolher várias). Se a nota já veio pela lista, os itens entram nela, sem duplicar.
3. **Fotos de cupons:** **Notas por foto → Enviar**; abra cada foto e digite os itens ao lado (uma linha por item, os números
   no fim). "Conferir soma" mostra quanto falta; ao salvar, vai para a próxima foto. iPhone: Ajustes > Câmera > Formatos >
   "Mais compatível" (o app não lê HEIC).

Na primeira vez, se o app não reconhecer a página, ele avisa e não grava nada: mande a página para ajustar o leitor (ela tem
seu nome e CPF; não compartilhe com mais ninguém).

## Outros cartões, sem fatura em PDF

Cadastre o cartão e lance as compras em **Novo lançamento** (com o número de parcelas, se houver). Quando chegar a fatura, use "Cartões e faturas" → a fatura → "Total segundo o banco" para conferir: o sistema mostra a diferença, se houver.
