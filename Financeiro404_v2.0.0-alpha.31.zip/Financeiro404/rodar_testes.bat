@echo off
cd /d "%~dp0"
set "VPY=%~dp0.venv\Scripts\python.exe"
if not exist "%VPY%" (
  echo Abra o Financeiro 404 uma vez pelo iniciar_windows.bat antes de rodar os testes.
  pause
  exit /b 1
)
"%VPY%" -m pip install --disable-pip-version-check -q -r requirements-dev.txt
"%VPY%" -m pytest -q tests
pause
