# Financeiro 404 — contexto completo para o Kiro

> Versão do código: **2.0.0-alpha.31** (13/11/2026). Este arquivo reúne o que existe, o que foi decidido e por quê, o que foi
> revisado por outras IAs e o que falta. Ele acompanha o código (abra a pasta do projeto no Kiro). Os arquivos em
> `.kiro/steering/` resumem produto, tecnologia e estrutura para o Kiro carregar sozinho.

## 0. O que pedimos ao Kiro

1. **Revisão crítica antes de escrever código.** Leia o código e este arquivo e aponte: erros de modelagem (sobretudo cartão e
   parcelas), riscos de segurança, riscos no Windows, testes que faltam, código frágil. Diga o que você mudaria e por quê.
2. **Specs para o backlog da seção 8**, no formato do Kiro (`requirements.md` com critérios de aceite, `design.md`, `tasks.md`),
   uma spec por item, **sem executar as tarefas** até a gente revisar.
3. **Respeite as regras da seção 9.** Elas não são preferência de estilo: cada uma evita um erro que já aconteceu ou um risco real.
4. Responda em português. Se discordar de uma decisão da seção 5, argumente; não reescreva por conta própria.

## 1. Produto

- **O que é:** aplicativo de finanças **familiar** (um casal), **100% local**: roda no notebook Windows e abre no navegador em
  `http://127.0.0.1:4040`. Nenhum dado sai do computador, exceto o backup cifrado que o usuário manda para a pasta que escolher.
- **Objetivo:** visão completa do dinheiro do casal no passado (o que aconteceu no ano), no presente (onde estamos) e no futuro
  (parcelas, contas fixas, metas), para decidir melhor. Um ponto de dor concreto: dívida de cartão de crédito (limite todo usado,
  uso de rotativo e parcelamento de fatura).
- **Quem usa:** na prática, uma pessoa opera (analista de segurança, técnico); a esposa quer só "ter controle", ou seja, ver um
  resumo. Não há uso simultâneo nem celular.
- **Restrição que moldou o projeto:** **não há extratos bancários recorrentes.** A fonte automática é a **fatura do cartão em PDF**
  (Ourocard, Banco do Brasil). A conta corrente é acompanhada por previsões, lançamentos manuais (inclusive em lote, colando texto)
  e conferência mensal com o saldo do app do banco. Descoberta tardia: o BB permite baixar o extrato da conta em OFX pelo
  internet banking (ainda não testado com arquivo real; o importador OFX já existe).

## 2. O que existe hoje (alpha.18)

| Área | Funcionalidades |
| --- | --- |
| Início | Disponível, dívida nos cartões (+ parcelas a vencer), patrimônio líquido, resultado do mês, reserva em meses, alertas dispensáveis, lançamento rápido com categoria adivinhada, gastos por categoria, faturas, compromissos dos próximos meses |
| Lançamentos | Lista com filtros (mês ou período, conta, categoria, situação, busca, tag, forma de pagamento, tipo), total por categoria do filtro, filtros salvos, exportação CSV; novo (despesa, receita, transferência, pagamento de fatura/dívida) com forma de pagamento, parcelas (cartão ou carnê/boleto), repetição (semanal a anual), tags; lançar vários colando texto livre com prévia editável; detalhe com editar, dividir em categorias, comprovantes (PDF/imagem), tornar recorrente, estornar, excluir (Lixeira 90 dias) |
| Cartões | Ciclos por dia de fechamento, substituídos pelas datas reais das faturas importadas; fatura = dívida no fim do ciclo; conferência com o total do documento do banco; pagamento; limite; parcelamentos com encerramento (antecipação/cancelamento) e aviso de parcela prevista que não veio na fatura |
| Importação | OFX/QFX, CSV genérico, PDF Ourocard (BB) com trava de soma; staging → sugestões (duplicado, casar com lançado/previsto, regras, aprendizado, palavras-chave, pagamento de cartão, estorno, parcelas) → revisão agrupada → aplicar atômico → desfazer lote inteiro; cartão novo criado a partir da fatura |
| Contas | Corrente, poupança, dinheiro, carteira/benefício, investimento, bem, cartão, empréstimo, outra dívida; saldo inicial; conferência com o saldo do banco com pistas (previsto não confirmado, lançamento em dobro, sentido trocado); "lançar a diferença" como gasto/entrada não identificada; atualizar valor de investimento/bem; excluir só sem histórico, senão desativar |
| Compras e projetos | Menu próprio: visão geral (quanto separar por mês, se cabe na sobra média, gráfico de 12 meses, atenção), projetos (casa, carro, viagem, trocas e reposições, reforma, filhos, festa, estudos) criados a partir de listas prontas por ambiente/grupo, com teto, prazo, gasto e progresso; lista de compras com filtros; item com tipo (compra, troca, manutenção, serviço, reserva), quantidade, valor ou "a cotar", já guardado, venda do usado, prioridade, mês-alvo, à vista ou parcelado, frequência de troca; cotações por loja (frete, parcelas, link) com "usar esta"; "Comprei" lança a despesa e planeja a próxima troca; histórico estimado × pago |
| Planejamento | Orçamento por categoria; previsões com frequência semanal, quinzenal, mensal, bimestral, trimestral, semestral, anual; provisão mensal das despesas não mensais; fechamento do mês (trava edições); metas (por conta ou valor informado, quanto guardar por mês); simulador de dívidas com o teto legal (Lei 14.690/2023) |
| Análises | Raio-X (custo de vida mínimo por natureza da categoria: essencial / comprometido / dá para cortar; reserva em meses; folga em dias; cenário de queda de renda); Evolução (gráficos SVG de 12 meses); fluxo de caixa projetado; relatórios do mês e do ano; resumo do mês para imprimir; custo do crédito; cobranças fixas com aviso de aumento; alertas de limite, cheque especial, categoria fora do padrão, tendência de alta; apoio ao IRPF (saúde, educação, farmácia não dedutível, receitas, saldos em 31/12) |
| Segurança | Só 127.0.0.1; CSRF; checagem de Host/Origin/Sec-Fetch-Site; CSP estrita sem JavaScript; PIN opcional; backup cifrado manual (AES-256-GCM + scrypt) e automático (X25519, sem senha guardada) com teste de restauração; cópia local diária; restauração com troca atômica e reversão |
| Interface | Tema claro/escuro/automático; layout para tela estreita; acessibilidade básica; impressão sem menu; menu em grupos recolhíveis: Visão, Dia a dia, Compras e projetos, Planejamento, Cadastros, Segurança |

## 3. Tecnologia e estrutura

- **Python ≥ 3.10**, servidor HTTP da biblioteca padrão (`ThreadingHTTPServer`), **sem framework e sem JavaScript**: HTML gerado no
  servidor, formulários comuns, confirmações em páginas; gráficos em SVG desenhado no servidor.
- **SQLite** em WAL, `BEGIN IMMEDIATE`, chaves estrangeiras ligadas, gatilhos de mês fechado, `AUTOINCREMENT`.
  Migrações numeradas `0001`–`0016` em `fin404/dados/migracoes/`, cópia automática antes de migrar.
- Dependências: `cryptography`, `pymupdf`. Testes: `pytest`, `hypothesis`, `playwright` (Chrome).
- Windows: `iniciar_windows.bat` (acha o Python, instala dependências, sobe o servidor e abre o navegador), atalho na área de trabalho.
- Cerca de 7.400 linhas de Python em `fin404/`:

```
fin404/
  dinheiro.py           centavos inteiros, datas, meses, formatação BR
  dados/                banco.py (conexões, migração, cópias), config.py, migracoes/*.sql
  dominio/              razao.py (livro-razão), cartoes.py, operacoes.py, relatorios.py, analises.py, categorias.py,
                        simulador.py, metas.py, tags.py, anexos.py, lote.py, compras.py, conferencias.py, receber.py,
                        reuniao.py, prazos.py, notas.py, catalogo.py
  importacao/           adaptadores/ (ofx, csv_generico, pdf_bb), pipeline.py
  seguranca/            backup.py (ENC2/ENC3, restauração), acesso.py (PIN)
  web/                  servidor.py, componentes.py, base.py, pg_*.py (uma área por módulo), static/app.css
ferramentas/            migrar_v09.py, remover_pin.py, recuperar_backup.py, importar_catalogo.py
tests/                  unidade, integracao, propriedades (hypothesis), e2e (navegador)
```

### Modelo de dados (o essencial)

- **Partidas dobradas.** Contas de cinco tipos (`ativo`, `passivo`, `receita`, `despesa`, `patrimonio`); categorias são contas.
  Cada transação tem lançamentos que **somam zero**. Status: `agendada` (previsto, fora de saldos e relatórios), `confirmada`, `conciliada`.
- **Cartão é passivo.** Compra: débito na categoria, crédito no cartão. Pagamento de fatura: débito no cartão, crédito na conta.
  Fatura = dívida do cartão no último dia do ciclo. Regra de fechamento `proxima`/`atual` (BB = `atual`).
- **Parcelas:** uma transação por parcela, cada uma no seu ciclo (cartão) ou mês (carnê/boleto, as futuras como previstas), ligadas
  por `planos_parcelas`. A fatura importada traz a parcela do ciclo; as futuras são projetadas e casadas na fatura seguinte.
- **Previsões** geram transações `agendada` com chave de idempotência; importação e "Confirmar previstos" as tornam reais.
- **Nada em dobro:** despesa conta no mês da compra/parcela; pagamento de fatura é transferência; estorno reduz a categoria.

## 4. Como chegamos aqui

1. **v0.9 (feita com o GPT):** revisão encontrou 17 defeitos; o principal era estrutural (saldos calculados por caminhos diferentes,
   contagem em dobro, float em dinheiro, ciclos errados, importação sem desfazer).
2. **v2 (Claude):** núcleo reescrito como livro-razão; migração da v0.9 com conferência de totais mês a mês.
3. **alpha.2–alpha.4:** leitor da fatura PDF validado com uma fatura real (total e parcelas futuras batem com o banco); rotina sem extrato.
4. **alpha.5–alpha.6:** segurança (PIN, backup automático, Lixeira), análises, interface; **revisão externa do DeepSeek** triada:
   procedia o encerramento de parcelas antecipadas/canceladas (era um erro real), o teste de backup, a separação Saúde/Farmácia no
   IRPF, alertas dispensáveis, custo de vida e reserva; não procedia conversão cambial (o app usa o valor em reais da fatura).
5. **alpha.7–alpha.10:** primeiro uso real (cartão a partir da fatura, botões de excluir), recorrência e formas de pagamento,
   **auditoria comparativa** com Mobills, Organizze, YNAB, Monarch, Actual Budget e Firefly III (lote por texto, gráficos, resumo,
   dividir, tags, anexos, filtros salvos), mais opções de frequência, parcelas fora do cartão e categorias.
6. **alpha.11:** **revisão do GPT** (arquivo `CRITICAS_E_MELHORIAS_FINANCEIRO404.md`, se enviado junto). Feito: backup recuperável
   sem o programa, aviso de casamento ambíguo, liquidez separada da reserva, `INDICADORES.md` com fórmulas e exemplo de
   parcelamento. Concordância: **congelar funcionalidades** até R1, R2 e um mês de uso real.
7. **alpha.12:** **Compras planejadas** (pedido do usuário; exceção ao congelamento): o que comprar, por prioridade, quanto
   separar por mês e se cabe na sobra média. Tabela nova, sem efeito nos saldos até o "Comprei" lançar a despesa.
8. **alpha.13:** **Compras e projetos** virou um módulo (projetos com listas prontas, cotações, reposição periódica, venda do
   usado) e foi feita a **auditoria final** (`AUDITORIA_FINAL.md`): 2 defeitos que impediam o programa de abrir no Python
   3.10/3.11, pasta de dados no OneDrive, CSV binário no 3.10, lentidão em Parcelamentos, migração da v0.9 sem teste.
9. **alpha.14:** **revisão do Kiro** (`RELATORIO-KIRO-PARA-CLAUDE.md`, 162/162 no Windows em 3.12 e 3.14). Feita a parte de código
   da R1: restauração endurecida e testada, CSV sem fórmula, `except` largos estreitados ou registrados, varredura de
   encerramento de parcelamento, iniciador com `.venv`. Falta da R1: validar o iniciador novo e a restauração no Windows real.
10. **alpha.15:** specs do Kiro executadas: **R11** (histórico de conferências, alerta de 35 dias, fechamento que exige conferir
   ou dispensar, gasto fora do cartão no Início), **R3** (A receber: conta com `papel`, transferências, quem deve, converter
   despesa), **R4** (pagar total/mínimo/outro com confirmação e aviso de rotativo), **R13** (Reunião do mês com decisões e
   lembrete), resto da R1 (mensagem clara no Windows, CSV de ida e volta, caminho com acento, OneDrive renomeado).
11. **alpha.16:** Novo lançamento volta pronto para o próximo (pedido do uso real).
12. **alpha.17:** **R12** (prazos e garantias) e **R10** camadas 1 e 2 (notas por CSV, catálogo por código de barras, agrupamento,
   histórico de preços). Sefaz fora: sem amostra real. Teste novo garante que nenhum módulo acessa a internet.
13. **alpha.18:** notas sem internet no app, a pedido do José: **página da NFC-e salva** (Nota Fiscal Paulista ou QR code),
   **lista de documentos da Nota Fiscal Paulista** com conferência contra os lançamentos, e **nota por foto** (digitar ao lado
   da imagem, com trava de soma). Página/foto completa a nota da lista sem duplicar. Substitui, por ora, a camada 3 (Sefaz).

## 5. Decisões e por quê

| Decisão | Por quê | Alternativa rejeitada |
| --- | --- | --- |
| Livro-razão de partidas dobradas | Elimina contagem em dobro por construção; um lugar calcula saldos | Remendar a v0.9 |
| Local, só 127.0.0.1 | Dados financeiros sensíveis; simplicidade | App na nuvem ou na rede de casa |
| Sem JavaScript | CSP máxima, menos superfície de ataque e manutenção | SPA |
| Biblioteca padrão, sem framework | Instalação trivial no Windows | Flask/FastAPI |
| Centavos inteiros em todo lugar | Dinheiro exato; um teste falha se aparecer `float(` ou `/100` | Decimal ou float |
| Fatura = dívida no fechamento | Fecha com o banco; a fatura real conferiu com diferença zero | Fatura como despesa do mês do pagamento |
| Parcelas como N transações | Relatório por mês correto e casamento com a fatura seguinte | Uma transação com parcelas virtuais |
| Diferença de saldo vira "não identificado" | Sem extrato, mantém saldos honestos | Ignorar a diferença |
| Backup automático com chave pública | Roda sozinho sem guardar a senha | Guardar a senha (DPAPI) |
| PIN não cifra o banco | SQLCipher é dependência nativa difícil no Windows; BitLocker cobre | SQLCipher |
| Anexos dentro do SQLite | Entram nos backups cifrados sem lógica extra | Pasta de arquivos ao lado |
| Investimento entra na reserva, mas a cobertura sem ele aparece ao lado | Nem todo investimento resgata no dia; um campo de liquidez por conta só se justifica com uso real | Tirar investimentos da reserva |
| Migrações só por acréscimo de coluna | SQLite não altera CHECK; reconstruir tabelas com chaves estrangeiras ligadas apagaria dados em cascata | Reconstruir tabelas |

## 6. Qualidade e evidências

A auditoria final, com medições, achados e riscos residuais, está em **`AUDITORIA_FINAL.md`**.

As fórmulas de todos os indicadores e um exemplo de parcelamento rodado no código estão em **`INDICADORES.md`**. Para auditar a
regra contábil, comece por lá.


- **202 testes** passando no Python 3.13 (Linux, Chrome headless); 186 sem navegador no 3.10 e no 3.14
  sequências aleatórias contra um modelo independente), navegador real (jornadas completas, CSP sem violação, nenhuma página com
  HTML escapado, tela de celular sem conteúdo cortado), migração da v0.9 e de bancos de versões anteriores.
- Teste de mutação feito numa rodada anterior (erros injetados foram pegos).
- `.github/workflows/testes.yml` roda a suíte em Ubuntu e Windows (ainda não executado: não há repositório).

## 7. Limitações e riscos conhecidos

1. **Nunca rodou no Windows**, que é o ambiente real: `.bat`, pip, `os.replace` na restauração, caminhos com acento, Edge.
2. **OFX real do BB não testado**; só fixtures sintéticas.
3. **Só o PDF do Ourocard** é lido; outros bancos dependem de amostra.
4. **Comprovantes não voltam com a Lixeira** (a tela avisa antes de excluir).
5. **Heurísticas** (cobranças fixas, palavras-chave de categoria, lote por texto) podem errar; só calibram com uso real.
6. **Uso do limite** difere do banco quando há parcelas futuras (o app explica na mensagem).
7. **Um computador só**; a esposa não lança. Abrir na rede de casa foi recusado por segurança.
8. **Escala:** pensado para um casal (milhares de lançamentos/ano); listas limitadas a 5.000 linhas por consulta.

## 8. Backlog (o que falta)

> **Estado em 08/11/2026 (alpha.18):** feitas pelo Claude seguindo as specs do Kiro em `.kiro/specs/` — **R3, R4, R10
> (camadas 1 e 2, e a alternativa local à camada 3: página salva, lista da Nota Fiscal Paulista e foto), R11, R12, R13** e a
> parte de código da **R1**. Cada `tasks.md` tem as caixas marcadas e uma seção "Execução (Claude)" com as decisões tomadas.
> Pendentes: R1 (validar no Windows), R2 (precisa do OFX real do BB), validar os leitores de página da R10 com uma página real
> (lista e detalhe), Sefaz automática (decisão de abrir a primeira saída para a internet; provavelmente desnecessária agora),
> R5/R5b/R6/R14 (P2) e R7/R8/R9 (decisão).

Prioridade: **P0** antes do uso a sério, **P1** primeiro mês, **P2** depois, **D** depende de decisão do usuário.

### R1 — Validar no Windows (P0)
- QUANDO o usuário rodar `iniciar_windows.bat` num Windows limpo com Python 3.10+, o sistema DEVE instalar dependências, subir o
  servidor e abrir o navegador sem erro.
- QUANDO a restauração de backup trocar o banco no Windows, o sistema DEVE concluir sem "arquivo em uso" e reverter se falhar.
- QUANDO a pasta do programa tiver acento ou espaço no caminho, tudo DEVE funcionar.

### R2 — Extrato OFX do Banco do Brasil (P0)
- QUANDO o usuário importar o OFX baixado do internet banking do BB, o sistema DEVE ler todas as linhas, casar com previstos e
  lançamentos manuais (±3 dias, mesmo valor) e não duplicar.
- Ajustar o adaptador ao arquivo real (charset, FITID, saldo) sem quebrar os testes existentes.

### R3 — Contas a receber (P1, sugestão nova)
- QUANDO o usuário pagar algo por outra pessoa (ou emprestar), o sistema DEVE registrar o valor como "a receber" (ativo), sem virar
  despesa, e mostrar quem deve quanto.
- QUANDO o valor for devolvido, DEVE baixar o "a receber" (transferência), sem virar receita.

### R4 — Atalhos no pagamento de fatura (P1)
- QUANDO o usuário abrir "Pagamento de fatura", o sistema DEVE oferecer "total da fatura em aberto", "mínimo" (da última fatura
  importada) ou "outro valor", e avisar quando o pago for menor que o total (rotativo).

### R5 — Lixeira para projetos e compras (P2)
- QUANDO o usuário excluir um projeto ou item de compra, o sistema DEVE permitir restaurá-lo pela Lixeira (hoje só fica na
  auditoria). QUANDO um lançamento ligado a uma compra for restaurado, a ligação DEVE voltar.

### R5b — Comprovantes na Lixeira (P2)
- QUANDO um lançamento com comprovante for excluído e depois restaurado, os comprovantes DEVEM voltar junto (guardar por 90 dias).

### R6 — Leitor de fatura de outros bancos (P2)
- Para cada banco com amostra anonimizada: ler itens, total e datas, com trava de soma, como o leitor do Ourocard.

### R7 — Open Finance via Meu Pluggy (D)
- Sincronização opcional, desligada por padrão, com consentimento explícito e aviso de que os dados passam por terceiro.
  Consentimento do Open Finance expira em 12 meses.

### R8 — Orçamento base zero / envelopes (D)
- Só se o casal quiser o método (YNAB/Actual).

### R9 — Acesso pelo celular (D)
- Só com projeto de segurança próprio (TLS local, PIN obrigatório, sessão por dispositivo). Até lá, captura pelo "Lançar vários".

### R10 — Notas fiscais e histórico de preços (P1, pedido do usuário em 07/11/2026)
Pendências registradas:
- **Envio das notas** — responsável: **José**. Fotografar as notas (o papel térmico desbota) e enviar em lotes; a transcrição sai
  num CSV fixo (data, loja, CNPJ, item, quantidade, unidade, preço unitário, total, chave da NFC-e).
- **Base de produtos de mercado** (marcas, tamanhos, unidades) — responsável: **Claude**. Escopo **amplo**, por decisão do usuário:
  catálogo local de produtos vendidos em mercado, independente das notas da família, importado de bases abertas por código de
  barras (GTIN): Open Food Facts (alimentos), Open Beauty Facts (higiene e beleza) e Open Products Facts (limpeza e outros),
  licença ODbL (exige atribuição). As notas da família completam o que faltar, e descrições diferentes entre lojas
  ("LEITE INT ITALAC 1L" = "LT ITALAC INTEGRAL") são agrupadas no mesmo produto. Fontes pagas (Cosmos/Bluesoft, GS1) só como
  opção; raspar sites de supermercado está fora (termos de uso).
Critérios (rascunho):
- QUANDO o usuário colar o link do QR code de uma NFC-e de SP, o sistema DEVE buscar a nota na Sefaz e importar os itens
  (a confirmar: captcha na consulta e notas antigas do tipo CF-e SAT). Isso abre a primeira saída para a internet: decisão do usuário.
- O sistema DEVE ligar cada nota ao lançamento correspondente (data, valor, cartão) e mostrar preço por produto ao longo do tempo,
  por loja, e gasto por tipo de item.

### R11 — Completude dos dados (P0, registrado em 07/11/2026)
Sem extrato, tudo o que não passa pelo Ourocard (Pix, boleto, débito automático, saque, outros cartões) depende de lançamento manual;
em um ou dois meses os números se descolam da realidade e o sistema perde a confiança. R2 (OFX do BB) e R7 (Open Finance) atacam
a causa; até lá:
- QUANDO uma conta corrente, poupança ou carteira não tiver conferência de saldo há mais de 35 dias, o sistema DEVE alertar.
- O Fechamento do mês DEVE exigir (ou registrar a dispensa de) a conferência de saldo de cada conta antes de fechar.
- O Início DEVE mostrar, no mês, quanto foi lançado fora do cartão, para tornar visível um mês "vazio" de Pix e boletos.

### R12 — Garantias e prazos (P1, registrado em 07/11/2026)
- QUANDO uma compra for registrada (Compras e projetos ou nota fiscal), o sistema DEVE permitir informar o prazo de garantia e
  anexar a nota, e DEVE avisar 30 dias antes de a garantia acabar.
- O sistema DEVE ter um painel único de prazos que não são compras: CNH, licenciamento, seguro do carro, fim de contrato
  (aluguel, internet, plano de celular), revisão, documentos, com aviso antecipado configurável.
- A busca DEVE achar a nota e a garantia de um item em poucos passos ("a geladeira ainda está na garantia?").

### R13 — Reunião financeira do mês (P1, registrado em 07/11/2026)
Objetivo: a esposa ter o controle que pediu sem operar o sistema. 15 minutos, uma vez por mês.
- O sistema DEVE ter uma página "Reunião do mês" (imprimível) com: sobrou ou faltou no mês, quanto a reserva cobre, compras grandes
  dos próximos 3 meses e se cabem, alertas importantes, e 2 ou 3 decisões a tomar.
- QUANDO o mês for fechado, o sistema DEVE oferecer a página da reunião e registrar a data em que ela aconteceu (e as decisões, em
  texto livre), para consultar depois.
- QUANDO passar o dia 10 sem a reunião do mês anterior registrada, o Início DEVE lembrar.

### R14 — Simulador de financiamento (P2, registrado em 07/11/2026; relevante se forem comprar imóvel ou carro)
- O sistema DEVE simular financiamento em SAC e Price: valor do bem, entrada, uso do FGTS, prazo, taxa anual e custo efetivo
  total (seguros e tarifas), mostrando primeira e última parcela, total pago e total de juros.
- O sistema DEVE comparar a parcela com a renda média (alerta acima de 30%) e com a sobra média do Raio-X, e mostrar o efeito
  na reserva de usar dinheiro guardado como entrada.
- O sistema DEVE permitir simular amortizações extras (reduzir prazo × reduzir parcela).

## 9. Regras do projeto (não negociáveis sem discussão)

1. Dinheiro só em **centavos inteiros**; nada de float. O teste `test_nenhum_float_no_codigo_de_dinheiro` falha se aparecer `float(` ou `/100`.
2. **Sem JavaScript** nas páginas e **sem estilo inline** (a CSP bloqueia). Interação = formulários e páginas de confirmação.
3. Toda alteração que mexe em dinheiro passa por `razao.registrar` (soma zero) e é **atômica** (`banco.transacao()`).
4. **Migrações só por acréscimo**, numeradas, nunca editar uma já publicada; nunca reconstruir tabela com chaves estrangeiras.
5. Todo texto vindo de dados passa por `e()` (escape) uma única vez; valores formatados com `dinheiro()` já são HTML.
6. Interface em **português do Brasil**, frases curtas, sem jargão contábil para o usuário.
7. **Nunca** incluir a pasta `data/`, faturas reais, nomes ou números de cartão em código, testes ou pacotes.
8. Toda mudança vem com teste; a suíte inteira (incluindo e2e) precisa passar.
9. Exclusões: só o que não tem histórico; o resto se desativa. Toda exclusão em dois passos e auditada.
