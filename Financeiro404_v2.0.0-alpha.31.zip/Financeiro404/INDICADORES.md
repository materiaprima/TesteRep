# Indicadores e regras contábeis do Financeiro 404

O que cada número da tela significa, de onde vem no código e o que fica de fora.
Valores em centavos inteiros; "hoje" é a data de referência da tela.

## 1. Regras gerais

- Todo lançamento é partida dobrada: cada transação tem 2+ linhas que somam zero (`razao.verificar_tudo` checa).
- **Entra nos números**: transações confirmadas com data ≤ hoje (`t.status <> 'agendada'`).
- **Não entra**: previstos (`agendada`), até serem confirmados ou casados com um extrato/fatura.
- Contas desativadas não entram nos saldos.

## 2. Grupos de contas (`razao.SUBTIPOS`)

| Grupo | Subtipos | Liquidez |
|---|---|---|
| Disponível | corrente, poupança, dinheiro, carteira digital/benefício | imediata |
| Investimentos | investimento | pode ter carência ou prazo de resgate |
| Bens | bem (imóvel, veículo) | ilíquido: nunca entra em reserva |
| Cartões | cartão | dívida de curto prazo |
| Outras dívidas | empréstimo/financiamento, outra dívida | longo prazo, paga em parcelas |

## 3. Indicadores (`relatorios.posicao`, `analises.raio_x`, `analises.folga_dias`)

| Indicador | Fórmula | Onde aparece |
|---|---|---|
| Disponível | soma dos saldos do grupo Disponível | Início |
| Livre depois dos cartões | Disponível − Cartões (dívida de hoje) | Início, Folga |
| Dívida nos cartões | saldo dos cartões com lançamentos até hoje | Início |
| Parcelas a vencer | parcelas de cartão com data > hoje | Início |
| Limite comprometido | tudo o que está no cartão, inclusive parcelas futuras | Cartões, alerta de limite |
| A receber | saldo da conta "Valores a receber" (papel `a_receber`) | Contas, A receber |
| Patrimônio líquido | Disponível + Investimentos + Bens + A receber − Cartões − Outras dívidas | Início, Evolução |
| Patrimônio após parcelas | Patrimônio líquido − Parcelas a vencer | Evolução |
| Reserva imediata | Disponível − Cartões | Raio-X ("sem investimentos") |
| Reserva | Reserva imediata + Investimentos | Raio-X, Início |
| Custo de vida mínimo | média mensal de essencial + comprometido + sem classificação + 1/12 das despesas anuais previstas | Raio-X |
| Reserva cobre | Reserva ÷ custo mínimo, em meses (uma casa decimal) | Início, Raio-X |
| Folga | (Disponível − Cartões) ÷ gasto médio diário dos últimos 90 dias | Raio-X |
| Resultado do mês | receitas − despesas confirmadas com data no mês | Início, Resumo |
| Gasto fora do cartão | despesas do mês cuja transação não passa por cartão (mesma base do total de despesas) | Início |

Decisões tomadas:

- **Outras dívidas na reserva:** empréstimos e financiamentos não são descontados da reserva, porque a parcela mensal já está no custo de vida (categoria "comprometido"). Descontar o saldo devedor inteiro contaria a dívida duas vezes.
- **Bens:** nunca entram em reserva nem em folga.
- **Investimentos:**
  - entram na Reserva;
  - não entram na Folga;
  - o Raio-X mostra também a cobertura sem eles.
- **Categoria sem classificação** conta como essencial, por prudência.

## 4. Parcelamentos: exemplo trabalhado

Dados do exemplo:

- Cartão: fecha dia 27, vence dia 6, limite R$ 5.000,00.
- Conta corrente: R$ 3.000,00.
- Compra: Geladeira R$ 1.000,00 em 3x, em 10/10.

**Lançamentos criados.** São 3 transações confirmadas ligadas por `planos_parcelas`. O resto da divisão vai para a primeira parcela (`dinheiro.dividir`).

| Parcela | Data contábil | Valor | Fatura (ciclo) |
|---|---|---|---|
| 1/3 | 10/10 | 333,34 | 27/09–27/10, vence 06/11 |
| 2/3 | 10/11 | 333,33 | 27/10–27/11, vence 06/12 |
| 3/3 | 10/12 | 333,33 | 27/11–27/12, vence 06/01 |

**A despesa conta no mês de cada parcela** (333,34 em outubro, e não 1.000 de uma vez). É o que a fatura cobra, e é como o orçamento mensal sente.

**Posição em três datas** (rodado no código):

| Data | Disponível | Dívida cartão | Parcelas a vencer | Patrimônio líquido | Após parcelas |
|---|---|---|---|---|---|
| 15/10 | 3.000,00 | 333,34 | 666,66 | 2.666,66 | 2.000,00 |
| 15/11 | 3.000,00 | 666,67 | 333,33 | 2.333,33 | 2.000,00 |
| 15/12 | 3.000,00 | 1.000,00 | 0,00 | 2.000,00 | 2.000,00 |

**Limite:** o limite comprometido é 1.000,00 desde o dia da compra (disponível 4.000,00), como no banco.

**Pagamento da fatura.** É uma transferência conta → cartão: o Disponível cai e a dívida do cartão cai. Não é despesa, porque a despesa já foi contada nas parcelas.

**Antecipação, cancelamento ou devolução** (`cartoes.encerrar_parcelamento`):

- As parcelas futuras ainda não cobradas vão para a lixeira (auditadas). O plano fica encerrado, com o motivo.
- Parcelas que vieram numa fatura importada nunca são tiradas.
- O valor cobrado na antecipação, ou o crédito do estorno, vem na fatura como linha própria e é lançado pela importação.
- No exemplo, antecipar em 10/11 retira só a 3/3. A 2/3 já está no ciclo atual.

**Parcela que não veio na fatura importada** (`cartoes.parcelas_ausentes`): gera o alerta "parcela prevista não apareceu". Isso pega cancelamentos que o usuário esqueceu de registrar.

**Parcelado fora do cartão** (carnê, crediário, boleto):

- A 1ª parcela é confirmada.
- As demais ficam previstas (`agendada`), uma por mês, e só contam quando confirmadas ou casadas com o extrato.

## 5. Casamento na importação (`importacao.pipeline`)

- **Candidato:** mesma conta, mesmo valor, data a até 3 dias (`TOLERANCIA_DIAS`). Ganha o de data mais próxima, e cada lançamento só pode casar uma vez por arquivo.
- **Mais de um candidato livre:** a sugestão vem com "CONFIRA: N lançamentos com o mesmo valor por perto". Nada é aplicado sem o usuário confirmar a prévia.
- **Linha já importada** (mesmo identificador, ou já ligada em outro arquivo): marcada como duplicada.
- **Arquivo idêntico** (mesmo sha256): recusado.
- **Aplicação e desfazer:** são atômicos, por lote.
- **Estorno:** crédito no cartão com a descrição de uma compra de até 120 dias antes, de valor maior ou igual, é sugerido na
  categoria daquela compra (cobre estorno parcial). No lançamento manual, transação dividida em várias categorias não
  oferece o botão de estorno.

## 6. Compras e projetos (`dominio/compras.py`)

- **Falta** = valor estimado − já guardado − venda do usado. Item sem valor fica "a cotar": aparece nas listas, mas fica fora do
  calendário, dos totais e do "cabe?".
- **À vista:** a falta é dividida pelos meses de hoje até o mês-alvo, contando o atual (o resto vai para os primeiros meses).
  Mês-alvo já passado: a falta inteira pesa no mês atual ("mês passou").
- **Parcelado:** a falta vira N parcelas a partir do mês-alvo; nada a guardar antes.
- **Sem mês-alvo:** fica na lista, fora do calendário e do "cabe?".
- **Sobra média** = renda média − gasto médio com despesas anuais (o mesmo `sobra` do Raio-X, meses completos recentes).
  Sem renda lançada no período, o app não diz o que cabe.
- **Cabe?** Itens de projetos em andamento (e avulsos), em ordem de prioridade (necessário → importante → desejo), depois data.
  Cada um soma o seu peso no calendário dos próximos 12 meses; cabe se, em todos os meses em que pesa, o acumulado ≤ sobra média.
  Projetos concluídos ou arquivados saem do calendário.
- **Projeto:** previsto = gasto (valor pago dos comprados) + planejado (valor dos abertos com preço); livre = teto − previsto;
  progresso = comprados ÷ (comprados + abertos).
- **Cotação:** total = preço + frete; "usar esta" passa o total e as parcelas para o item.
- **Frequência de troca:** ao comprar (ou marcar como comprado), cria o próximo item com o valor pago, no mês da compra + N meses.
- **Não afeta saldos.** Só "Comprei" cria lançamento (pela mesma rotina do Novo lançamento: cartão, conta ou parcelado).

Exemplo (testado em `tests/integracao/test_compras.py`), hoje em nov/2026, sobra média R$ 500:

| Item | Prioridade | Valor / guardado | Quando | Pesa | Cabe? |
|---|---|---|---|---|---|
| Geladeira | necessário | 1.200 / 300 | jan/2027 à vista | 300/mês nov–jan | sim (300 ≤ 500) |
| Notebook | importante | 2.000 | fev/2027, 10x | 200/mês fev–nov | sim |
| Praia | desejo | 600 | dez/2026 à vista | 300/mês nov–dez | não (nov: 600 > 500) |
| Sofá | desejo | 3.000 | sem data | — | — |

Troca de carro: valor 60.000, guardado 15.000, venda do usado 30.000, out/2027 → falta 15.000 → 1.250/mês por 12 meses.

## 7. Conferência de saldo e fechamento (`dominio/conferencias.py`)

- Cada conferência grava: data do saldo do banco, saldo informado, saldo calculado e diferença (informado − calculado).
- **Bateu** = diferença zero. "Lançar a diferença" e "Ajustar" gravam uma nova conferência, já zerada.
- **Alerta:** corrente, poupança ou carteira ativa sem conferência que bateu há mais de 35 dias (se nunca foi conferida, conta
  desde a criação da conta).
- **Fechamento de um mês:** exige toda conta disponível (corrente, poupança, dinheiro, carteira) com movimento até o fim do mês.
  Cada uma precisa ter a conferência **mais recente com data no mês** batendo, ou uma dispensa daquele mês (com motivo, na auditoria).

## 8. A receber (`dominio/receber.py`)

- Emprestar ou pagar por alguém = transferência origem → "Valores a receber" (com a pessoa). Devolução = transferência inversa.
  Nunca despesa nem receita; o patrimônio não muda (só a forma do dinheiro).
- Fica fora de Disponível, Reserva, Folga e Bens. Entra no Patrimônio líquido.
- Quem deve: por pessoa; as devoluções abatem as dívidas mais antigas primeiro ("desde" = a mais antiga ainda em aberto).

## 9. Prazos e garantias (`dominio/prazos.py`)

- Aviso quando faltam N dias (configurável, padrão 30) para `data_fim`.
- **Garantia:** conta da data da compra (num parcelamento, `planos_parcelas.data_compra`) + meses. Depois que acaba, sai dos
  alertas e vai para o histórico.
- **Outros prazos:** depois de vencidos, continuam como alerta urgente até serem concluídos. "Renovado" cria o próximo com
  `data_fim` + `repete_meses`.

## 10. Notas fiscais e preços (`dominio/notas.py`, `dominio/catalogo.py`)

- Quantidade em milésimos (0,512 kg = 512); dinheiro em centavos.
- **Travas do CSV:** |quantidade × preço unitário − total do item| ≤ 1 centavo; Σ itens − desconto = total da nota (exato).
  Qualquer falha recusa o arquivo inteiro.
- **Ligação com o lançamento:** despesa (ou primeira parcela de um parcelamento, pelo total do plano) com o mesmo valor e data a
  até 3 dias, ainda sem nota. Liga sozinho só se houver um único candidato na menor distância. A nota não cria despesa.
- **Variação de preço** = (último − primeiro) × 100 ÷ primeiro, em % inteiro, por unidade da nota (un, kg, l).
- **Gasto por tipo** = soma dos itens por tipo; o desconto da nota aparece à parte (não é rateado entre itens).
- **Semelhança para agrupar:** termos casados ÷ (termos de A + termos de B − casados), com abreviação de 3+ letras contando como
  o mesmo termo ("int" ~ "integral"). Sugere a partir de 34%.

## 11. Backup recuperável sem o programa

- Toda execução do backup automático deixa na pasta de destino `LEIA-ME_RECUPERACAO.txt` e `recuperar_backup.py`.
- O script depende só de Python e `cryptography` e decifra ENC3/ENC2/ENC1.
- Ele confere o SQLite (`integrity_check`) e não sobrescreve arquivo existente.
- Teste: `tests/unidade/test_seguranca.py::test_recuperar_backup_sem_o_programa` roda o script isolado (`python -I`), sem o pacote `fin404`.
