@echo off
chcp 65001 >nul
setlocal EnableExtensions
cd /d "%~dp0"
title Financeiro 404
rem Ambiente proprio em .venv: componentes isolados do resto do computador, sempre no mesmo lugar.
rem Se este arquivo der problema, use iniciar_sem_venv.bat (o iniciador anterior).
set "VENV=%~dp0.venv"
set "VPY=%VENV%\Scripts\python.exe"

if exist "%VPY%" (
  "%VPY%" -c "import sys" >nul 2>nul
  if errorlevel 1 (
    echo O ambiente .venv quebrou ^(o Python foi atualizado ou removido^). Recriando...
    rmdir /s /q "%VENV%"
  )
)
if exist "%VPY%" goto componentes

rem Escolhe o Python: prefere as versoes testadas (3.13, 3.12, 3.11, 3.10, 3.14).
set "BASE="
where py >nul 2>nul
if not errorlevel 1 (
  for %%v in (3.13 3.12 3.11 3.10 3.14) do (
    if not defined BASE (
      py -%%v -c "import sys" >nul 2>nul && set "BASE=py -%%v"
    )
  )
)
if not defined BASE (
  where python >nul 2>nul
  if not errorlevel 1 (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul && set "BASE=python"
  )
)
if not defined BASE (
  echo.
  echo  Nao achei o Python 3.10 ou mais novo neste computador.
  echo  Instale o Python 3.13 e, na primeira tela do instalador,
  echo  marque a opcao "Add Python to PATH". Depois abra este arquivo de novo.
  echo.
  start "" "https://www.python.org/downloads/"
  pause
  exit /b 1
)
echo Preparando o Financeiro 404 ^(so na primeira vez^)...
%BASE% -m venv "%VENV%"
if errorlevel 1 (
  echo Nao foi possivel criar o ambiente .venv. Use iniciar_sem_venv.bat.
  pause
  exit /b 1
)

:componentes
"%VPY%" -c "import cryptography, pymupdf" >nul 2>nul
if not errorlevel 1 goto abrir
echo Instalando componentes ^(precisa de internet^)...
"%VPY%" -m pip install --disable-pip-version-check -q -r requirements.txt
"%VPY%" -c "import cryptography, pymupdf" >nul 2>nul
if not errorlevel 1 goto abrir
echo.
echo  ATENCAO: os componentes nao foram instalados ^(sem internet ou versao do Python sem suporte^).
echo  Sem eles o programa abre, mas SEM backup cifrado e SEM leitura da fatura em PDF.
echo.
choice /c SN /m "Abrir mesmo assim"
if errorlevel 2 exit /b 1

:abrir
"%VPY%" app.py
if errorlevel 1 pause
