# Financeiro 404

Gestão financeira da família, 100% local: nada sai do seu computador. Versão **2.0.0-alpha.31**: núcleo novo, baseado em livro-razão.

> **Situação:** candidata para uso em paralelo, não fonte única ainda. Use junto com o seu controle atual por um ou dois meses e confira os totais com os extratos. Veja `ESTADO_DA_ENTREGA.md`.

## Instalação no Windows

1. Instale o Python em <https://www.python.org/downloads/> (testado do 3.10 ao 3.14; prefira o **3.13**, que já tem todos os
   componentes prontos para Windows). Na primeira tela do instalador, marque **"Add Python to PATH"**.
2. Extraia esta pasta em **`C:\Financeiro404`**. Evite Área de Trabalho e Documentos: no Windows 11 elas costumam ficar no
   OneDrive, e a sincronização pode corromper o banco enquanto ele está aberto (o programa avisa se detectar isso).
   O backup cifrado, esse sim, pode e deve ir para o OneDrive.
   **Ao atualizar, nunca apague nem substitua a pasta `data`**: é lá que ficam os seus dados.
3. Dê dois cliques em `criar_atalho_na_area_de_trabalho.bat` (uma vez) e depois abra pelo atalho "Financeiro 404"
   (ou dê dois cliques em `iniciar_windows.bat`). Na primeira vez, ele escolhe o Python testado (3.13, 3.12, 3.11, 3.10,
   3.14), cria um ambiente próprio na pasta `.venv` e instala os componentes (precisa de internet). Se a instalação falhar,
   ele avisa e pergunta antes de abrir sem backup cifrado e sem PDF. Se o iniciador der problema, use `iniciar_sem_venv.bat`.
   O navegador abre em <http://127.0.0.1:4040>. Para encerrar, feche a janela "Financeiro 404".

**Guia rápido para começar:** `PRIMEIROS_PASSOS.md`.

O programa só aceita conexões do próprio computador (127.0.0.1). Outros aparelhos da rede não conseguem acessar.

## Vindo da versão anterior (v0.9 / v1.0)

Copie o arquivo `data\financeiro.sqlite3` da versão antiga para a pasta `data` desta versão. Ao abrir, a tela inicial oferece **"Trazer esses dados para cá"**:

- primeiro é feita uma **simulação** num banco temporário, mostrando os totais por mês antes e depois;
- só se os totais conferirem o botão de migração fica disponível;
- o arquivo antigo nunca é alterado.

Depois da migração, configure os dias de fechamento e vencimento de cada cartão (em "Contas e dívidas") e revise os lançamentos que vieram de importação. A tela de migração lista o que revisar.

Também dá para migrar pela linha de comando: `py ferramentas\migrar_v09.py data\financeiro.sqlite3` (simula) e depois `... --executar`.

## Sem extrato do banco

O sistema funciona só com a fatura do cartão em PDF e o que vocês sabem: previsões (salário, contas fixas) confirmadas em "A pagar e receber",
lançamento rápido no Início e, uma vez por mês, conferência com o saldo do app do banco. A diferença pode virar "Gastos não identificados".
As parcelas futuras do cartão saem da própria fatura. Detalhes em `PRIMEIROS_PASSOS.md`.

## Começando do zero

1. **Contas e dívidas:** cadastre a conta corrente, a poupança, o dinheiro e cada cartão (com dia de fechamento, dia de vencimento e limite). Informe o **saldo inicial** de cada conta numa data de referência: o saldo que o extrato mostra naquele dia.
2. **Pessoas:** cadastre vocês dois, para ver gastos por pessoa.
3. **Importar extrato:** importe extratos e faturas (OFX ou CSV) a partir da data de referência. Na revisão, confirme a categoria de cada linha ou diga se é transferência ou pagamento de fatura. Marque "lembrar" para criar regras.
4. **Previsões:** salário, aluguel, escola, assinaturas. Elas alimentam o fluxo de caixa e são casadas com os lançamentos reais quando o extrato chega.
5. **Fechamento do mês:** no começo de cada mês, siga o checklist do mês anterior e feche-o. Mês fechado não aceita alterações (pode ser reaberto).

## Fatura do cartão em PDF (Ourocard / Banco do Brasil)

Em "Importar extrato", escolha o cartão e envie o PDF da fatura baixado do app ou site do BB.

- **Trava de segurança:** o saldo anterior mais a soma de todos os lançamentos lidos precisa dar exatamente o "Total da Fatura". Se não der (layout mudou, página faltando), nada é importado.
- As **datas reais** de fechamento e vencimento da fatura passam a valer para o cartão. O BB não fecha sempre no mesmo dia.
- No Ourocard, compra feita no dia do fechamento entra na fatura que fecha. O cartão é ajustado para essa regra automaticamente, se ainda não tiver movimento.
- Lançamentos com data anterior ao ciclo (compras parceladas antigas, lançamentos atrasados) entram na data do ciclo da fatura; a data original da compra aparece na revisão.
- As categorias do próprio banco (Transporte, Saúde, Restaurantes…) viram sugestões. IOF, juros, encargos e anuidade são sugeridos como "Juros, tarifas e IOF".
- Se é a **primeira fatura importada** desse cartão, a tela oferece usar o "saldo da fatura anterior" do banco como saldo inicial do cartão. Com isso, a fatura calculada fica igual à do banco.
- A pessoa é reconhecida pelo nome do portador do cartão, se ela estiver cadastrada em "Pessoas".
- PDF digitalizado (imagem) e faturas de outros bancos ainda não são lidos. Para eles, use OFX ou CSV.

## Como o sistema pensa (e por que não conta nada em dobro)

Todo lançamento é uma transação com dois lados que se anulam (partidas dobradas):

| Evento | O que acontece |
|---|---|
| Compra de R$ 100 no cartão | Despesa da categoria +100; dívida do cartão +100 |
| Pagamento da fatura de R$ 100 | Dívida do cartão −100; conta corrente −100. **Não é despesa.** |
| Pix para a sua poupança | Corrente −, poupança +. **Não é despesa nem receita.** |
| Estorno de R$ 100 | Dívida do cartão −100; despesa da categoria −100 |

**Fatura** = tudo o que se deve no cartão no último dia do ciclo (inclui saldo anterior não pago). A compra feita no dia do fechamento vai para a fatura seguinte ou entra na que fecha, conforme a regra do cartão (configurável). Datas reais de fechamento vindas das faturas importadas têm prioridade. Parcelas caem cada uma na sua fatura.

**Relatórios** contam a despesa no mês da compra (no parcelado, no mês de cada parcela). Lançamentos "previstos" não entram nos relatórios, só no fluxo de caixa.

## Backup e restauração

- **Backup cifrado** (menu Segurança): gera um arquivo `.fin404` cifrado com AES-256-GCM e chave derivada da senha (scrypt, N=2^17). Sem a senha, não há recuperação. Guarde o arquivo fora do notebook.
- **Restaurar:** primeiro verifica o arquivo e a senha, sem alterar nada. Depois, se você confirmar, troca o banco em uso com segurança: guarda uma cópia do banco atual em `data\copias`, espera as conexões terminarem, substitui e confere a integridade. Se algo falhar, devolve o banco anterior.
- Teste a restauração de vez em quando: a etapa de verificação não altera nada.
- **Testar o backup** (Backup e segurança): abre o último backup automático com a senha numa cópia temporária. Faça a cada poucos meses.
- **Backup automático** (Backup e segurança): escolha uma pasta fora do notebook ou sincronizada (OneDrive, Google Drive, pendrive) e uma senha.
  O programa grava ali um arquivo cifrado por dia (guarda os últimos 30) **sem guardar a senha no computador**: usa criptografia de chave
  pública (X25519 + AES-256-GCM); a chave privada vai dentro de cada arquivo, protegida pela sua senha. Para restaurar, use a mesma tela
  de restauração com essa senha.

Além disso, o programa faz **uma cópia local automática por dia** em `data\copias` (guarda as últimas 14). Ela protege contra erro de uso e arquivo corrompido, não contra perda do notebook.

O Início avisa quando uma fatura está para vencer (até 5 dias) e quando o último backup cifrado tem mais de 7 dias.

Arquivos em `data\`: `financeiro_v2.sqlite3` (o banco), `copias\` e `copias_pre_migracao\` (cópias de segurança **sem cifragem**; as automáticas se renovam sozinhas, as demais apague depois de ter um backup cifrado), `restauracoes\`, `logs\erros.log`.

## Segurança: o que o programa protege e o que não protege

Protege contra:
- acesso pela rede (só escuta em 127.0.0.1);
- sites maliciosos no navegador: token em todo formulário, checagem de origem e de Host (contra DNS rebinding), CSP sem nenhum JavaScript;
- perda de dados por erro: transações atômicas, auditoria de exclusões e edições, mês fechado, desfazer importação.

**PIN de acesso** (opcional, em Backup e segurança): pede o PIN ao abrir e depois de um tempo parado; 5 tentativas erradas bloqueiam por alguns minutos.
Ele evita que alguém abra o programa no seu notebook destrancado, mas **não cifra o banco**: quem copiar o arquivo `data\financeiro_v2.sqlite3`
consegue ler. Se esquecer o PIN: feche o programa e rode `py ferramentas\remover_pin.py`.

**Não** protege contra programa malicioso rodando na sua sessão do Windows: ele lê o que o Financeiro 404 lê. Use contas do Windows separadas se mais alguém usa o notebook, mantenha o BitLocker ligado e faça backups cifrados.

## Análises e planejamento

- **Simulador de dívidas:** compara pagar tudo, rotativo, parcelar a fatura e um empréstimo, com as taxas (CET) lidas da última fatura.
  Aplica o teto legal (Lei 14.690/2023: juros e encargos do rotativo e do parcelamento da fatura limitados a 100% da dívida original; IOF fora).
- **Custo do crédito:** "Juros, tarifas e IOF" aparece no relatório do mês e na retrospectiva do ano.
- **Cobranças fixas:** assinaturas e contas que se repetem em pelo menos 3 dos últimos 6 meses, com aviso quando o valor sobe.
- **Alertas no Início:** limite do cartão acima de 90% (contando parcelas futuras), categoria acima de 130% da média dos 3 meses anteriores, assinatura mais cara.
- **Raio-X:** custo de vida mínimo (categorias essenciais + dívidas), quantos meses a reserva cobre, onde cortar e "e se a renda cair X%".
  Classifique as categorias em Categorias (essencial / comprometido / dá para cortar).
- **Lançar vários de uma vez:** cole o que anotou no celular (`18,50 padaria pix`, uma linha por gasto), confira e grave.
- **Evolução:** gráficos de 12 meses (patrimônio, dívida, entradas e saídas, maiores categorias).
- **Resumo do mês:** uma página para mostrar ou imprimir (Ctrl+P → Salvar como PDF).
- **Dividir em categorias, tags e comprovantes** em cada lançamento; filtros avançados e salvos em Lançamentos.
- **Lançamento recorrente:** no Novo lançamento, "Repetir todo mês / todo ano" (aluguel, luz, assinaturas, salário, IPVA).
- **Forma de pagamento:** Pix, débito, crédito, boleto, débito automático, TED, dinheiro, vale; o relatório do mês separa por forma.
- **Despesas anuais:** em Previsões, "uma vez por ano" (IPVA, IPTU, seguro); o sistema mostra quanto separar por mês.
- **Parcelamentos:** compras parceladas em andamento; antecipou ou cancelou? Encerre o plano para tirar as parcelas que não vêm mais.
  O sistema avisa quando uma parcela prevista não aparece na fatura importada.
- **Conferência de saldo com pistas:** quando o saldo não bate, aponta previstos não confirmados, lançamentos em dobro ou no sentido errado.
- **Prazos e garantias:** CNH, seguro, licenciamento, contratos e garantias com aviso antes de vencer e busca.
- **Notas fiscais e preços:** quatro jeitos de trazer notas, sem internet no app: a **página da nota** salva do site da Nota
  Fiscal Paulista ou do QR code (todos os itens); a **lista de documentos da Nota Fiscal Paulista** (para achar compras que
  ficaram fora do app); a **foto do cupom** (você digita os itens ao lado da foto, com a soma conferida); e planilha CSV. A nota
  é ligada ao lançamento de mesmo valor; preço de cada produto no tempo e por loja; gasto por tipo (carnes, limpeza,
  hortifrúti…); catálogo por código de barras de bases abertas.
- **A receber:** dinheiro emprestado ou pago por alguém, por pessoa, sem contar como gasto; devoluções parciais.
- **Conferência de saldo:** histórico, alerta de 35 dias e fechamento do mês que exige conferir ou dispensar cada conta.
- **Reunião do mês:** página para olhar juntos (ou imprimir) com decisões registradas e lembrete.
- **Compras e projetos** (menu próprio): projetos como Casa, Carro, Viagem, Trocas e reposições, Reforma, Filhos, Festa e Estudos,
  criados a partir de listas prontas por ambiente ou grupo; cada item com prioridade, data, à vista ou parcelado, já guardado,
  venda do usado, cotações de lojas e frequência de troca. Mostra quanto separar por mês nos próximos 12 meses e o que cabe na
  sobra média. "Comprei" lança a despesa e, se for troca periódica, já planeja a próxima.
- **Metas:** valor, prazo e quanto guardar por mês; podem acompanhar o saldo de uma conta (por exemplo, a poupança da reserva).
- **Imposto de Renda:** saúde (potencialmente dedutível), educação (com limite), farmácia (em regra não dedutível), receitas e saldos em 31/12,
  para conferir com os informes. Não calcula imposto.
- **Alertas:** cada um pode ser dispensado por 30 dias (urgentes, 3 dias).
- **Aparência:** automática (segue o sistema), clara ou escura, no rodapé de qualquer página. Em janela estreita o layout se adapta,
  mas o programa só aceita conexões do próprio notebook (não abre no celular pela rede, de propósito).

## Testes

```
rodar_testes.bat                         (usa a .venv criada pelo iniciador)
.venv\Scripts\python -m playwright install chromium   (ou: set FIN404_NAVEGADOR=msedge para usar o Edge instalado)
```

- `tests/unidade`: dinheiro, datas, ciclo do cartão, parcelas, estornos, mês fechado, previsões, fluxo de caixa.
- `tests/integracao`: importação (staging, casamento, duplicatas entre OFX e CSV, desfazer, arquivos malformados) e fatura PDF do BB (com dados sintéticos).
- `tests/propriedades`: invariantes sob sequências aleatórias de operações. Para rodar mais: `set FIN404_EXEMPLOS=10000`.
- `tests/e2e`: jornada completa num navegador real, enviando formulários de verdade, inclusive em tela de celular e no tema claro.
- `.github/workflows/testes.yml`: se o projeto for para um repositório no GitHub, a suíte roda sozinha em Linux **e Windows** a cada envio.

## Licença e dados

Uso pessoal. Nenhum dado é enviado para a internet. Não há telemetria.
