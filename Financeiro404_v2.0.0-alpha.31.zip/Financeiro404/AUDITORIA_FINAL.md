# Financeiro 404 — Auditoria final (alpha.13)

Data: 06/11/2026.

**Escopo:** o sistema inteiro, depois da entrada do módulo Compras e projetos. É a última revisão antes da análise do Kiro.

**Método:** quase tudo foi medido ou testado em vez de opinado.

- **Testes em três versões do Python:**
  - 3.10 e 3.13: suíte completa, com navegador;
  - 3.14: suíte sem navegador.
- **Carga:** 5 anos de dados sintéticos, cronometrando as 32 páginas principais:
  - 11,5 mil transações;
  - 23 mil lançamentos;
  - 932 parcelamentos.
- **Medição de cobertura** dos testes.
- **Varredura de segurança:** SQL montado com texto, proteção contra requisições forjadas (CSRF), checagem de Host, links vindos do usuário.
- **Atualização a partir da versão anterior com dados**, com verificação de integridade.
- **Releitura da documentação** contra o código.

## 1. Resultado em uma frase

O núcleo contábil, a importação e a segurança estão sólidos e bem testados. A auditoria achou e corrigiu dois defeitos que **teriam
impedido o programa de abrir** num Windows com Python 3.10 ou 3.11, e uma instrução de instalação que punha os dados no
OneDrive. O que resta de risco não se resolve aqui: rodar no Windows de verdade, testar o extrato real do BB e usar por um mês.

## 2. Achados desta auditoria (todos corrigidos)

| # | Gravidade | Achado | Correção |
|---|---|---|---|
| A1 | **Crítica** | `pg_contas.py` e `componentes.py` usavam f-string aninhada com as mesmas aspas, que só existe a partir do Python 3.12. No 3.10 e no 3.11 (o README promete 3.10+), o programa **não abria**. Nunca apareceu porque os testes rodavam só no 3.13 e o CI do GitHub (que tem 3.10) nunca rodou. | Código reescrito; suíte completa passa no 3.10, 3.13 e 3.14. |
| A2 | **Alta** | O README mandava extrair em `Documentos\Financeiro404`. No Windows 11, Documentos e Área de Trabalho costumam estar no OneDrive; sincronizar um SQLite aberto (com `-wal`) pode corromper o banco. | README e Primeiros passos indicam `C:\Financeiro404`; alerta urgente na tela inicial se a pasta estiver em OneDrive, Google Drive, Dropbox ou iCloud (testado com caminhos Windows). |
| A3 | Média | No Python 3.10, um arquivo binário enviado como CSV (planilha renomeada) causava erro interno (`line contains NUL`) em vez de mensagem. | Recusa antecipada com mensagem clara. |
| A4 | Média | Parcelamentos levava **1,3 s** com 5 anos de dados (recalculava cada parcelamento já terminado). Faltava índice em `transacoes.plano_id`. | Filtro no banco + índice: **0,16 s**. |
| A5 | Média | A migração da v0.9 (porta de entrada dos dados antigos) não tinha nenhum teste automático. | Teste com banco no formato antigo: totais por mês conferem, simulação não grava, arquivo antigo intacto, 2ª execução recusada. |
| A6 | Baixa | Token CSRF comparado com `!=`. | `secrets.compare_digest`. |
| A7 | Baixa | Menu com 27 links não cabia em 1366×768. | Grupos recolhíveis sem JavaScript (`<details>`), abertos quando contêm a página atual. |
| A8 | Baixa | Mensagem da migração dizia "a v2 ainda não tem metas". | Texto corrigido. |

Também verificados, sem problema:

- A atualização da alpha.12 para a alpha.13 preserva as compras e faz cópia antes; isso agora tem teste.
- Restaurar um backup de versão anterior aplica as migrações.
- Link de cotação com `javascript:` é descartado.

## 3. Medições

**Desempenho com 5 anos de dados** (servidor local, primeira requisição):

| Página | Tempo |
|---|---|
| Evolução (12 meses de gráficos) | ~0,3 s |
| Início | ~0,2 s |
| Resumo do mês | ~0,2 s |
| Parcelamentos (932 planos) | ~0,16 s |
| Demais 28 páginas | mediana 14 ms, todas < 0,1 s |

**Testes:** 162 (unidade, integração, propriedades com hypothesis, navegador real). O navegador percorre 35 páginas procurando HTML
escapado, viola zero vezes a CSP e confere a tela de celular.

**Cobertura** das camadas de regra (domínio, importação, segurança, dados): **86%**.

| Módulo | Cobertura |
|---|---|
| `relatorios` | 92% |
| `compras` | 90% |
| `pipeline` de importação | 89% |
| `cartoes` | 87% |
| `razao` | 81% |
| `backup` | 69% (o resto são caminhos de erro de sistema de arquivos) |

As páginas web são cobertas pelos testes de navegador, que rodam em outro processo e por isso não entram na medição.

## 4. Avaliação por área

### 4.1 Integridade contábil (sólido)

- **Partidas dobradas** garantidas no código que grava e conferidas pela verificação geral.
- **Gatilhos no banco** travam meses fechados.
- **Centavos inteiros:** um teste falha se aparecer `float(` ou `/100`.
- **Testes de propriedade** comparam milhares de sequências aleatórias com um modelo independente.
- **Fatura real do Ourocard** conferida com diferença zero.

**Risco residual:**
- Heurísticas de categoria e de casamento acertam por padrão, não por garantia. Mitigado:
  - nada é gravado sem a prévia;
  - casamento ambíguo vem marcado "CONFIRA";
  - tudo é desfazível por lote.

### 4.2 Segurança (sólido para o modelo de ameaça: um computador da família)

- Escuta só 127.0.0.1.
- Proteção contra requisições forjadas e contra DNS rebinding:
  - CSRF em todo POST;
  - checagem de Host, Origin e Sec-Fetch-Site.
- CSP estrita e nenhum JavaScript.
- SQL só com parâmetros: as interpolações são constantes internas.
- Uploads com limite de tamanho e verificação de tipo.
- Backups cifrados (AES-256-GCM; automático com X25519, sem senha guardada) e recuperáveis sem o programa.

**Risco residual:**
- O PIN não cifra o banco. Para isso, contar com o BitLocker.
- Quem usa a conta do Windows tem acesso aos dados.

### 4.3 Compatibilidade com Windows (atenção)

- A1 e A2 eram exatamente esse tipo de risco e só foram achados com teste.
- **Ainda não verificado:**
  - `iniciar_windows.bat` num Windows limpo;
  - caminho com acento;
  - `os.replace` na restauração com o Edge aberto;
  - antivírus e SmartScreen bloqueando o `.bat`.
- **Python 3.15** (lançado em out/2026) pode ainda não ter `cryptography` ou `pymupdf` prontos para Windows. Por isso o README recomenda o 3.13. Se faltarem, o programa abre mesmo assim, sem backup cifrado e sem PDF.

### 4.4 Desempenho (sólido)

- Ver medições. Nada passa de 0,3 s com 5 anos de uso intenso.
- Listas limitadas a 5.000 linhas por consulta.

### 4.5 Usabilidade (bom, depende de uso real)

- Seis áreas no menu.
- Fluxo diário em três toques:
  1. Lançar vários ou importar fatura.
  2. Confirmar previstos.
  3. Ver o Início.
- Resumo de uma página para quem só quer acompanhar.
- **Compras e projetos** cobre o planejamento de médio prazo: casa, carro, viagem, trocas, reforma, festa, filhos, estudos.

**Risco residual:**
- Densidade de informação alta em Início e Raio-X.
- Ajustes só vão aparecer com um mês de uso.

### 4.6 Manutenibilidade (bom)

- Cerca de 8.600 linhas em módulos por área: domínio separado da web, uma área por `pg_*.py`.
- Migrações numeradas com cópia antes de aplicar.
- Documentação de decisões (`PARA_O_KIRO.md`) e de fórmulas (`INDICADORES.md`).

**Riscos:**
- HTML montado em f-strings longas é fácil de quebrar (A1 nasceu disso).
- Migrações não conseguem mudar CHECK.
- A 0011 precisou reconstruir uma tabela, o que só é seguro porque nenhuma outra aponta para ela.

### 4.7 Documentação (bom, conferida)

Conferida contra o código nesta rodada:

- README;
- Primeiros passos;
- Estado da entrega;
- Indicadores;
- Para o Kiro;
- `LEIA-ME` de recuperação na pasta do backup.

Corrigidos A2 e A8.

## 5. Mapa do sistema

| Menu | Páginas | Para quê |
|---|---|---|
| Visão | Início, Fluxo de caixa, Raio-X, Evolução, Relatórios, Cobranças fixas | Onde estamos, quanto dura a reserva, para onde vai o dinheiro |
| Dia a dia | Lançamentos, Novo, Lançar vários, Confirmar previstos, Importar, Cartões e faturas | Registrar e conferir |
| Compras e projetos | Visão geral, Projetos, Lista de compras, Comprados | O que comprar, quando, quanto separar, se cabe |
| Planejamento | Orçamento, Metas, Previsões, Simulador de dívidas, Fechamento do mês | Limites, objetivos de poupança, contas futuras, dívidas |
| Cadastros | Contas e dívidas, Categorias, Tags, Pessoas | Estrutura |
| Segurança | Backup e segurança, Lixeira | Proteger e desfazer |

## 6. O que fica para o Kiro e para o uso real

1. **R1 — Rodar no Windows** (P0): o `.bat`, um caminho com acento, a restauração de backup, o Python 3.13.
2. **R2 — OFX real do BB** (P0).
3. **Um mês de uso real** antes de qualquer funcionalidade nova. O congelamento vale de novo a partir daqui.
4. **R5 — Lixeira para projetos e compras** (P2): hoje a exclusão fica só na auditoria. Se um lançamento ligado a uma compra for restaurado da Lixeira, a ligação não volta.
5. **Ligar o CI no GitHub:** a matriz Linux + Windows × Python 3.10 + 3.13 já está pronta. Teria pegado A1 no primeiro envio.

**Pedidos ao Kiro:**
- Auditar antes de implementar.
- Não introduzir framework nem JavaScript sem discutir.
- Não reconstruir tabelas com chaves estrangeiras.
- Manter o teste de float e os testes de navegador.
- Rodar a suíte no Python 3.10.
