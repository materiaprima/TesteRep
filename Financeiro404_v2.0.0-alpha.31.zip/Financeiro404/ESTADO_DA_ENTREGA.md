# Financeiro 404 v2.0.0-alpha.29 — estado da entrega

Data: 06/11/2026. Referência: "Financeiro 404 — Revisão técnica, visão de produto e plano para desenvolvimento".

## Resumo

O núcleo foi **reescrito** em vez de remendado: o código da v0.9/v1.0 (`core.py`, `treasury.py`, `finance_plus.py`, `release_engine.py`, `advanced.py`, `ledger.py`) não é mais usado. Tudo agora passa por um livro-razão de partidas dobradas. Os dados antigos são trazidos por uma migração com conferência de totais.

Situação por fase do plano:

| Fase | Situação |
|---|---|
| 0 — Estabilizar | Superada pela reescrita. Todos os defeitos D1–D17 tratados (tabela abaixo). |
| 1 — Livro-razão e migração | **Concluída.** Esquema, invariantes no banco e no código, migração com relatório. |
| 2 — Primeira fatia (1 banco + 1 cartão) | **Pronta para validação com dados reais.** Falta o mês real anonimizado. |
| 3 — Demais bancos e pessoas | Pessoas: feito. Bancos: leitor genérico OFX/CSV pronto; adaptadores específicos dependem de amostras reais. |
| 4 — Presente e futuro | Previsões, parcelas, fluxo de caixa, orçamento, fechamento mensal, metas e simulador de dívidas: feitos. Cenários e provisões anuais: pendentes. |
| 5 — Visão completa | Patrimônio, investimentos e bens, retrospectiva anual, custo do crédito, cobranças fixas, alertas de padrão e apoio ao IRPF: feitos. |
| 6 — Endurecimento | Backup cifrado, restauração guiada, backup automático sem senha guardada, PIN, lixeira e CI (Linux + Windows): feitos. Execução real no Windows: pendente. |

## Novidades da alpha.31 (menos limitação + pente-fino, 13/11)

- **Categoria e conta em lote**: na lista de Lançamentos, toda despesa e receita tem caixinha; com os marcados dá para
  mudar a situação, a categoria e a conta/cartão de uma vez. O que não pode mudar fica como estava e a mensagem diz o motivo
  (cada item é alterado por inteiro ou não é: SAVEPOINT por item).
- **Mover compra parcelada para outro cartão**: na página da parcela, todas as parcelas vão juntas, com as datas pelo
  fechamento do cartão novo. Bloqueado se alguma parcela veio da fatura importada, foi conferida, ou cai em mês fechado.
- **Quanto gastei por período**: "De" e "Até" (até 24 meses), com tabela mês a mês e média.
- Falhas corrigidas no pente-fino:
  - `?mes=` vazio era descartado pelo servidor: "todos os meses" na lista de lançamentos não funcionava (só o mês guardado).
    Agora o parâmetro vazio fica na consulta; `req.q()` continua devolvendo o padrão.
  - Conta "a pagar" com data já passada sumia de Fluxo de caixa e Próximos meses; agora entra hoje, marcada como atrasada.
  - "Em aberto": o cartão de cima somava um horizonte e a lista outro (totais diferentes na mesma página). Agora o de cima é
    "Para pagar até…", igual ao total da lista.
  - Cartões: a linha da fatura aberta mostrava "falta pagar" cheio, somando de novo a fatura anterior; agora mostra só o novo.
  - Início: fatura aberta com R$ 0,00 não aparece mais em "O que vence".
  - "voltar ao mês atual" em páginas de detalhe (ex.: itens de Quanto gastei) dava erro 400; agora volta para a aba.
  - Página do lançamento usava "feito" para compra no cartão; agora "no cartão", como na lista.
  - Busca na lista avisa quando está procurando só num mês e oferece "Procurar em todos os meses".

## Novidades da alpha.30 (editar o passado e ver o que está em aberto, 13/11)

- **Editar qualquer lançamento**: além de valor, data, descrição, categoria e situação, agora dá para trocar
  **com qual conta ou cartão foi pago** ("Pago com"). Parcela de compra parcelada não troca de cartão sozinha
  (o plano inteiro está no cartão): cancele e lance de novo.
- **Compra parcelada**: caixa "aplicar a todas as parcelas" leva a nova descrição e categoria para as outras
  parcelas (meses fechados ficam como estão).
- **Mês fechado**: o lançamento mostra o motivo e um botão "Reabrir o mês" que volta direto para ele.
- **O que está em aberto**: a aba "Quanto devo" virou **"Em aberto"** e ganhou a seção "A receber".
  Em Lançamentos: atalhos "Em aberto (n)" e "Atrasados (n)", filtros novos e nomes de situação mais claros
  (em aberto / feito / conferido com o banco).
- Testes: troca de conta, bloqueio em parcela, propagação de parcelas, filtros, reabrir pelo lançamento
  (inclusive sem redirecionamento para fora do app).

## Novidades da alpha.29 (pontos de melhoria do usuário, 13/11)

- **Planejar → Próximos meses** (`relatorios.proximos_meses`): 3, 6 ou 12 meses com o que entra, faturas (no mês do
  vencimento), contas a pagar e previsões, compras planejadas, uma estimativa do dia a dia (média dos 3 meses anteriores sem
  parcelas nem contas fixas; dá para desligar) e o **saldo no fim de cada mês**, com aviso do primeiro mês negativo.
- **Fluxo de caixa:** fatura **vencida e não paga** agora entra como saída (antes sumia da projeção depois do vencimento).
- **Previsões editáveis:** "Editar…" em cada previsão (descrição, valor, dia, conta, categoria, fim). Os previstos de hoje em
  diante são refeitos; os pagos e os atrasados não mudam (`operacoes.atualizar_previsao`).
- **"Lanço um valor e aparece outro":** a causa era a repetição mensal — corrigir um mês não mudava a previsão, e os meses
  seguintes continuavam com o valor antigo. No Editar de um lançamento que se repete há "Aplicar também aos próximos meses"
  (marcado): a correção vale para a previsão e para os meses seguintes.
- **Ordenar:** toda tabela com 3 linhas ou mais ordena clicando no título da coluna (de novo inverte); entende datas, valores
  em reais, números e texto; linha de total fica no fim; cada tabela da página guarda a sua ordem na URL (o1, o2…).

## Novidades da alpha.28 (situação editável, pedido antigo do usuário)

- **Editar do lançamento:** campos **Situação** (Pago / A pagar / Pago em parte), **Quanto pagou** e **Pagou em (data)**.
  "Pago em parte" registra o pago na data e deixa o resto "a pagar" (`operacoes.mudar_situacao`). Compra no cartão e o que
  veio de extrato/fatura importada mostram a situação travada, com o motivo.
- **Lista de lançamentos:** caixinha em cada lançamento que pode mudar e "Marcar os selecionados como: Pago / A pagar", para
  corrigir vários de uma vez (a lista volta com o mesmo filtro).
- **Novo lançamento:** "Já foi pago?" não vem mais marcado como "Pago": a pessoa escolhe (obrigatório), e a escolha fica para o
  próximo lançamento. O "Pago" automático registrava como pago o que ainda não tinha sido.

## Novidades da alpha.27

- **Desfazer "pago":** no lançamento, "Ainda não foi pago: voltar para a pagar" (ou "a receber"). Só para despesa/receita
  lançada à mão fora do cartão; compra no cartão e o que veio de extrato/fatura importada não voltam (`operacoes.desmarcar_pago`).

## Novidades da alpha.26 (uso real)

- **Compra no cartão aparece como "no cartão"**, não "pago": quem é paga é a fatura. (Desde a alpha.21 a lista mostrava "pago"
  para toda despesa confirmada, inclusive as do cartão.)
- **Quanto devo → "O que pagar até…"**: as faturas dos cartões entram na lista junto com as contas a pagar, com data e total
  — a fatura vencida pelo que falta, a aberta só pelas compras novas (sem contar duas vezes) — e o aviso para não lançar a
  fatura como conta a pagar.

## Novidades da alpha.25 (pago, a pagar e pago em parte)

- **Pagamento parcial de conta "a pagar"** (`operacoes.pagar_parte`): o que foi pago vira pago na data informada; o resto
  continua "a pagar" num lançamento "(restante)" na data prevista. No lançamento: "Paguei só uma parte…"; em A pagar e
  receber: coluna "Pagou tudo?" com "Foi só uma parte: o resto continua". Pagar o resto todo depois só confirma.
- Fatura de cartão já aceitava pagamento parcial ("Outro valor"), com a situação "paga parcialmente".

## Novidades da alpha.24 (uso real: "devo uns 13 mil e o app mostra 7/8")

- **Quanto devo** (Início → aba Quanto devo): o total que vocês devem hoje num número só — cartões (inclusive a fatura vencida
  e a dívida de antes do app, com aviso se ela ainda não foi colocada), empréstimos e financiamentos, e contas lançadas como
  "a pagar" (atrasadas e próximos 31 dias). Explica que dívida não é o mesmo que gasto do mês.
- **Lançamentos:** os totais viraram quadros — despesas já feitas, **a pagar no período**, as duas somadas, e receitas (com o
  "a receber"). Antes os lançamentos "a pagar" ficavam fora de qualquer total.
- **Corrigido:** na lista de lançamentos, um estorno era somado como receita em vez de diminuir as despesas (os relatórios e
  Quanto gastei já estavam certos). Se houver pagamento de fatura lançado como estorno no filtro, a lista avisa e aponta a
  correção.

## Novidades da alpha.23 (revisão visual de todas as páginas)

51 páginas e abas fotografadas com dados fictícios em tela de notebook (tema claro e escuro) e de celular; nenhum erro e
nenhuma rolagem lateral da página.
- **Tabelas:** célula curta (data, valor, selo, link curto) não quebra mais em duas linhas ("fecha 27/10/2026", "vencida
  pagar"); valores nunca quebram no meio. No celular as células voltam a quebrar, para caber.
- **Quadros de números:** o texto pequeno ao lado do valor não vaza mais para fora do quadro.
- **Cartões e faturas:** a tabela cabe na tela (o "pago depois do fechamento" foi para baixo de "Falta pagar"; a diferença com
  o PDF para baixo do valor) e ganhou a coluna **Pagamentos e estornos**, para a conta fechar à vista:
  saldo anterior + compras − pagamentos e estornos = valor da fatura.
- **Quanto gastei → Conferir com a fatura:** separa pagamentos de estornos (antes um pagamento dentro do ciclo diminuía o
  "gasto deste ciclo").
- **Contas:** os movimentos mostram "pago" e "recebido" em vez de "confirmado".
- **Celular:** o menu de áreas vira uma fileira só, com rolagem para o lado (antes ocupava três linhas no topo).

## Novidades da alpha.22 (navegação refeita, a pedido do uso real)

Comparado com YNAB, Monarch, Actual, Organizze e Mobills. O menu de 33 itens em 6 grupos não cabia na tela e, sem
JavaScript, voltava ao topo a cada clique.
- **7 áreas** no menu (Início, Lançamentos, Cartões, Para onde foi, Planejar, Compras, Ajustes), que cabem em 1366×768 sem
  rolar; cada área tem **abas** no alto da página, **cor e ícone** próprios e o **caminho** (Compras › Projetos › Casa).
  Endereços antigos continuam iguais.
- **Mês guardado:** escolher um mês numa página vale para Lançamentos, Quanto gastei, Mês, Orçamento, Fechamento, Reunião e
  Resumo até "voltar ao mês atual" (aviso no topo) ou fechar o navegador.
- **Depois de salvar, a página volta ao painel mexido** (cada painel ganha um id; o formulário leva o id; o redirecionamento
  só desce se voltar à mesma página). O aviso de "salvo" fica preso no alto da tela.
- **Início** responde "o que fazer agora": avisos primeiro, 5 números (sai Patrimônio, que está em Evolução), e **O que vence
  nos próximos 15 dias** (fatura a pagar, fatura aberta só com as compras novas, contas a pagar e atrasadas) no lugar da
  tabela de faturas que induzia a somar a mesma dívida duas vezes.
- **Compras:** "Começar com a lista pronta" vem desmarcado; botão "Remover sugestões sem uso" (só itens da lista pronta sem
  preço, nada guardado, sem observação); "+ Adicionar item" e "+ Nova compra" no topo, recolhíveis.
- **Categorias** em uma linha por categoria (a página caiu de 3.500 px para 2.900 px e ficou legível); "+ Nova categoria" no topo.
- Situação "recebido" para receitas; Quanto gastei mostra as categorias antes da conferência; páginas e textos menores
  ajustados ("Quem nos deve", links repetidos removidos); no celular, menu em botões e "+ Novo lançamento" visível.

## Novidades da alpha.21 (uso real: "os números não condizem com a fatura")

Conferido com a fatura real do usuário num banco temporário (nada dela entrou no pacote): depois das duas correções abaixo,
a fatura do app ficou **igual à do banco, centavo por centavo**.
- **Pagamento lançado como estorno:** sem conta corrente cadastrada, a linha "PGTO..." da fatura ficava sem sugestão e, se
  ia para uma categoria, virava "estorno" e abatia o gasto do mês pelo valor pago. Agora: a importação sugere pagar a partir
  da conta corrente ou do dinheiro, e explica que não é gasto; o app acha os pagamentos já lançados assim e corrige com um
  clique ("É pagamento", escolhendo de onde saiu), em Cartões e faturas e no alerta do Início.
- **Dívida anterior ao app:** o saldo anterior da primeira fatura importada é a dívida que já existia; sem ele, todas as
  faturas do app ficam menores que as do banco. Cartões e faturas mostra a diferença e aplica o saldo inicial com um clique
  (não é gasto do mês).
- **Quanto gastei → Conferir com a fatura:** por cartão, saldo anterior + gasto do ciclo + pagamentos = fatura do app, ao
  lado do total do PDF e da diferença. Fatura ainda aberta aparece como "fecha em", não "fechou em".
- **Pago / a pagar:** no Novo lançamento, a situação agora é "Pago" ou "A pagar" (despesa) e "Recebido" ou "A receber"
  (receita). A lista mostra "a pagar", "a receber", "pago", e "atrasado" em vermelho. "Confirmar previstos" virou
  **A pagar e receber**: mostra tudo até o fim do mês seguinte e não marca nada sozinho. "Marcar como pago" no lançamento
  usa a data de hoje se pagou antes da data prevista. O menu de empréstimos a pessoas virou "Quem nos deve".
- Cartões e faturas: o aviso de "não some as duas linhas" só aparece quando nada da fatura anterior foi pago; crédito a
  favor aparece como crédito.

## Novidades da alpha.20 (uso real: "não sei quanto gastei em outubro")

- **Quanto gastei** (menu Visão): o total do mês por categoria em três jeitos de olhar, cada um explicado na tela —
  **pela fatura** (no cartão, a fatura que fechou no mês, que é o que bate com o papel do banco; fora do cartão, a data do
  gasto), **pela data da compra** e **pelo dinheiro que saiu** (gastos fora do cartão + pagamentos de fatura e dívidas).
  Abre no mês que acabou. Avisa quando o total está incompleto porque falta importar uma fatura (as compras do fim do mês
  só chegam na fatura seguinte). Clicar numa categoria lista cada lançamento que entrou na conta.
- **Lançamentos:** compra cuja data no app difere da do PDF (parcela de compra antiga, ou compra trazida para o ciclo da
  fatura) mostra também "no banco dd/mm".

## Novidades da alpha.19 (uso real)

- **Cartões e faturas:** cada cartão mostra **quanto se deve hoje**, a fatura a pagar (com link "pagar"), a fatura aberta
  (compras do ciclo) e o limite. A tabela ganhou "Saldo anterior", "Compras no ciclo" e "No PDF do banco". Quando a fatura
  anterior não foi paga, um aviso explica que a aberta já inclui esse valor e que as duas linhas não devem ser somadas.

## Novidades da alpha.18 (notas da Nota Fiscal Paulista e por foto)

- **Página da nota:** o detalhe da NFC-e salvo no navegador (Ctrl+S, "somente HTML"), aberto no site da Nota Fiscal Paulista
  ou pelo QR code do cupom, vira uma nota com todos os itens, código de barras, desconto e chave. Várias páginas de uma vez.
  O leitor segue o leiaute padrão da consulta de NFC-e (e uma tabela genérica de itens como reserva); com as mesmas travas do
  CSV, e o lote inteiro é recusado se uma página não for reconhecida ou não fechar. **Precisa ser conferido com a primeira
  página real** (as de teste são montadas no leiaute padrão, sem dado real).
- **Lista da Nota Fiscal Paulista:** a página do resultado de "Consultar documentos" salva vira notas sem itens (data, loja,
  CNPJ, valor), ligadas ao lançamento quando há um de mesmo valor (±3 dias). Na página Notas fiscais, a **Conferência** mostra
  quantas notas e quanto ficou sem lançamento: compras com CPF na nota que não estão no app. "Tentar ligar de novo" religa
  depois de importar a fatura.
- **Sem duplicar:** a página ou a foto de uma compra que veio pela lista **completa a mesma nota** (mesma chave, ou mesma data
  + CNPJ + total). Desfazer a página tira só os itens; desfazer a lista mantém a nota completada.
- **Nota por foto:** envie fotos (JPG, PNG, WEBP; HEIC do iPhone é recusado com instrução), abra cada uma e digite os itens ao
  lado da imagem (uma linha por item: só o total; quantidade e preço; ou quantidade, preço e total). "Conferir soma" mostra os
  itens lidos e quanto falta; se não fechar, a tela volta com tudo digitado. Ao salvar, vai para a próxima foto. A foto fica
  dentro do banco (entra no backup) e aparece na página da nota.
- Envio de vários arquivos no mesmo campo (antes só o último era lido) e nome de arquivo com caminho do Windows normalizado.
- Migração 0017: `fotos_nota` e `itens_nota.importacao_id` (de qual importação veio cada item). Só acréscimo.

## Novidades da alpha.17 (specs R12 e R10)

- **Prazos e garantias (R12, menu Planejamento):** CNH, licenciamento, seguro, contratos, revisões, documentos e garantias num
  painel só, com aviso configurável (7 a 90 dias antes), "Renovado" que cria o próximo e busca ("geladeira" acha a garantia,
  o lançamento e o comprovante). Garantia pelo lançamento (num parcelamento, conta da data da compra), pela compra planejada
  (meses de garantia, registrada ao comprar) ou pelo item da nota fiscal.
- **Notas fiscais (R10, menu Compras e projetos):** importar itens por CSV (modelo para baixar), com trava por item
  (quantidade × preço) e por nota (itens − desconto = total), atômico e desfazível; a nota é ligada ao lançamento de mesmo
  valor (±3 dias, inclusive compra parcelada) ou lançada a partir dela; tipo de cada item (carnes, hortifrúti, limpeza…).
- **Preços:** histórico por produto, no tempo e por loja (gráfico, menor, média, último, variação); gasto por tipo e por loja.
- **Catálogo de produtos:** por código de barras, importado de arquivo das bases abertas (Open Food/Beauty/Products Facts,
  ODbL com atribuição exibida), filtrado por país; o arquivo grande vai por `ferramentas/importar_catalogo.py` (lê .csv.gz em
  fluxo). "Agrupar produtos" junta o mesmo produto escrito de jeitos diferentes, com sugestão automática.
- **Consulta à Sefaz não foi feita:** precisa de uma página real de NFC-e de SP como amostra. O programa continua sem nenhum
  acesso à internet, agora garantido por teste.
- Defeitos achados e corrigidos nesta rodada: garantia de compra parcelada contava da parcela aberta, não da compra; a busca
  listava cada parcela como "sem garantia"; a semelhança de nomes contava abreviação duas vezes e escondia sugestões certas.
- Migrações 0015 (prazos, garantia na compra) e 0016 (notas, itens, produtos, apelidos, fontes do catálogo): só acréscimo.

## Novidades da alpha.16 (uso real)

- **Vários lançamentos seguidos:** depois de salvar, o Novo lançamento volta limpo para o próximo, com a mesma data, conta,
  forma de pagamento e pessoa; os últimos lançados à mão aparecem embaixo, com link para a lista do mês. Antes, cada salvar
  levava para a lista de lançamentos.
- `RETORNO_PARA_O_KIRO.md`: divergências das specs, pedido de validação no Windows e próximos passos.

## Novidades da alpha.15 (specs do Kiro: R11, R3, R4, R13 e resto da R1)

- **Conferência de saldo com histórico (R11):** cada conferência fica gravada com a diferença. Alerta quando conta corrente,
  poupança ou carteira passa 35 dias sem conferir. **Fechamento do mês exige** que cada conta com movimento esteja conferida no
  mês (a última conferência bateu) ou tenha a conferência dispensada com motivo (fica na auditoria). Link "conferir saldo de
  31/10" já leva a data certa. Início mostra o gasto **fora do cartão** e avisa se ele estiver zerado depois do dia 7.
- **A receber (R3):** emprestei ou paguei por alguém → transferência para "Valores a receber", com a pessoa; não conta como
  gasto; devolução não conta como receita; parcial abate o mais antigo. Despesa que veio na fatura pode virar a receber pelo
  detalhe do lançamento. Entra no patrimônio, não no disponível nem na reserva. Alerta acima de 90 dias.
- **Pagamento de fatura (R4):** botões Total em aberto / Mínimo (do PDF desta fatura) / Outro valor, com página de confirmação,
  aviso de rotativo quando paga menos e de digitação quando paga mais.
- **Reunião do mês (R13):** página com sobrou/faltou, reserva, compras dos próximos 3 meses, alertas e decisões sugeridas;
  registro da data e das decisões; lembrete a partir do dia 10.
- **R1, resto:** mensagem clara quando o Windows prende o arquivo na restauração; CSV exportado volta sem o apóstrofo ao
  reimportar; teste com acento e espaço no caminho; OneDrive detectado também pelas variáveis do Windows; `tema()` com except estreito.
- **Defeito achado e corrigido nesta rodada:** o fechamento considerava "conferida" uma conta cuja conferência mais recente do
  mês não tinha batido (valia uma anterior). Agora vale a mais recente.
- Migrações 0012 (conferências), 0013 (`contas.papel`), 0014 (reuniões): só acréscimo, com teste de atualização.
- Specs do Kiro incluídas em `.kiro/specs/`, com as tarefas feitas marcadas.

## Novidades da alpha.14 (achados do Kiro, parte de código da R1)

- **Restauração de backup endurecida** (achado 1): confere se o checkpoint esvaziou o WAL e para se outro programa segura o
  banco; tenta de novo o `os.replace` quando o Windows prende o arquivo; devolve `-wal/-shm` se a troca falhar; na reversão,
  descarta o WAL do banco restaurado antes de voltar ao anterior. Antes não havia nenhum teste; agora são 5.
- **CSV exportado sem injeção de fórmula** (achado 3): texto que começa com `= + - @` ganha apóstrofo; o valor continua número.
- **Erros não somem mais** (achado 4): decifragem só trata `InvalidTag` como "senha incorreta"; falha no kit de recuperação e
  no tema vai para o `erros.log`. (O backup automático já registrava e alertava.)
- **Teste de propriedade** com variável vazia no PowerShell (achado 5) e **encerramento de parcelamento** testado em todas as
  posições de corte, para 2, 3, 10 e 24 parcelas (achado 2: os testes dirigidos já existiam; faltava a varredura).
- **Iniciador do Windows** com ambiente próprio `.venv`, preferência por Python testado (3.13 → 3.12 → 3.11 → 3.10 → 3.14),
  nova checagem dos componentes depois de instalar e pergunta antes de abrir sem eles. O anterior ficou como
  `iniciar_sem_venv.bat`. **Não testado no Windows** (feito em Linux): validar na primeira abertura.
- CI com Python 3.14 na matriz. Suíte: 172 no 3.13 (com navegador); 161 no 3.10 e no 3.14 (sem navegador); todos com
  `ResourceWarning` como erro.

## Novidades da alpha.13 (compras e projetos + auditoria final)

- **Menu "Compras e projetos"**: Visão geral, Projetos, Lista de compras, Comprados. Os grupos do menu agora recolhem (Visão e
  Dia a dia sempre abertos; os outros abrem quando a página atual está neles), para caber em 1366×768.
- **Projetos** (casa, carro, viagem, trocas e reposições, reforma, filhos, festa, estudos) com **listas prontas** por ambiente ou
  grupo (cozinha, lavanderia, manutenção, documentação, hospedagem…), teto de orçamento, prazo, gasto, falta e progresso.
  Itens das listas entram "a cotar" e já com frequência de troca quando faz sentido (óleo 6 meses, pneus 4 anos, colchão 8 anos).
- **Itens**: tipo (compra nova, troca, manutenção, serviço, reserva), quantidade, valor ou "a cotar", já guardado, **venda do usado**
  (abate da falta), prioridade, mês-alvo, à vista ou parcelado, **frequência de troca** (ao comprar, a próxima entra no plano).
- **Cotações** por loja (preço, frete, parcelas, link só http/https), menor preço em destaque e "Usar esta".
- **Auditoria final** (ver `AUDITORIA_FINAL.md`): corrigidos 2 erros de sintaxe que impediam abrir no Python 3.10/3.11,
  CSV binário derrubando a importação no 3.10, Parcelamentos lento com anos de dados (1,3 s → 0,16 s, + índice), alerta de pasta
  no OneDrive (e o README que mandava extrair em Documentos), comparação de token CSRF em tempo constante, teste da migração v0.9.
- Migração 0011 refaz `compras_planejadas` para aceitar item sem preço (testado: dados da alpha.12 preservados).

## Novidades da alpha.12 (compras planejadas)

- **Planejamento → Compras planejadas:** lista do que a família precisa ou quer comprar, com valor estimado, já guardado,
  categoria, prioridade (necessário, importante, desejo), mês-alvo e forma (à vista ou parcelado).
- **Quanto separar:** à vista, o que falta é dividido pelos meses até a data; parcelado, as parcelas entram a partir do mês-alvo.
  Calendário dos próximos 12 meses com "sobra depois".
- **Cabe?** Na ordem de prioridade, comparando com a sobra média do Raio-X (renda − gasto médio). Sem renda lançada, não opina.
- **Ciclo:** "Comprei" lança a despesa (cartão, conta ou parcelado) e tira do plano; "Já está lançada" para o que veio na
  fatura; desistir, voltar ao plano, excluir. Histórico de comprados e desistências.
- **Resumo do mês** mostra as próximas compras e quanto separar no mês.
- Migração 0010 só cria tabela nova; não toca em saldos, cartões ou importação. Exceção consciente ao congelamento de
  funcionalidades, pedida pelo usuário.

## Novidades da alpha.11 (revisão do GPT: confiança nos números)

- **Backup recuperável sem o programa:** cada backup automático deixa na pasta `LEIA-ME_RECUPERACAO.txt` e
  `recuperar_backup.py` (só Python + `cryptography`). Testado isolado do pacote, com senha certa, errada e destino existente.
- **Casamento ambíguo avisa:** quando há mais de um lançamento igual por perto, a sugestão começa com "CONFIRA".
- **Liquidez separada:** o Raio-X mostra quanto a reserva cobre com e sem investimentos; a Folga e o Início descontam a dívida
  dos cartões do dinheiro disponível ("livre depois dos cartões").
- **`INDICADORES.md`:** fórmula de cada número da tela, o que entra e o que fica de fora, e um exemplo de parcelamento rodado no
  código (datas, faturas, patrimônio, limite, antecipação).
- **Congelamento de funcionalidades** até validar no Windows e usar um mês real (ver PARA_O_KIRO.md).

## Novidades da alpha.10 (mais opções para situações comuns)

- **Repetição:** toda semana, a cada 2 semanas, todo mês, a cada 2, 3 ou 6 meses, todo ano (no Novo lançamento, em "Tornar recorrente"
  e em Previsões). Semanais partem da data da 1ª vez (diarista, feira, mesada). Despesas a cada 2/3/6/12 meses entram como provisão
  mensal e saem das médias do Raio-X, para não contar duas vezes.
- **Parcelado fora do cartão** (carnê, boleto ou Pix parcelado, crediário): a 1ª parcela é lançada e as demais ficam previstas, uma
  por mês no mesmo dia; aparecem em Parcelamentos e podem ser encerradas como as do cartão.
- **Formas de pagamento novas:** carteira digital (PicPay, Mercado Pago, PayPal), crediário/carnê, desconto em folha, pontos/milhas/
  cashback. Também reconhecidas no "Lançar vários" (picpay, carnê, folha, cashback…).
- **Categorias novas** (só criadas se não existirem): Contas da casa, Pets, Filhos, Academia e esportes, Serviços domésticos;
  receitas: Trabalhos extras, Vendas de usados, Aluguel recebido, Vale-refeição e alimentação, Restituição do IR, Bônus e PLR,
  Presentes recebidos. Luz, água, gás, internet e celular passam a ser sugeridos em "Contas da casa".
- **Alerta de cheque especial:** conta corrente negativa vira alerta urgente.
- Migração 0009: como o SQLite não altera restrições de colunas existentes, a forma de pagamento passou para a coluna
  `meio_pagamento` e as previsões ganharam `frequencia` e `data_base` (dados copiados, nada perdido).

## Novidades da alpha.9 (auditoria comparativa: o que os outros apps têm)

Feito a partir da auditoria que comparou o Financeiro 404 com Mobills, Organizze, YNAB, Monarch, Actual Budget e Firefly III.

- **Lançar vários de uma vez** (DIA A DIA → Lançar vários): cola o texto anotado no celular, uma linha por gasto
  (`18,50 padaria pix`, `ontem uber 23,90 crédito`, `+500 freela pix`). Entende valor, data (dd/mm, ontem, anteontem),
  forma de pagamento e entrada (+). Mostra uma prévia editável (categoria adivinhada, conta, forma) e grava tudo de uma vez
  ou nada. "crédito" vai para o cartão escolhido.
- **Evolução** (VISÃO): gráficos de 12 meses, desenhados no servidor em SVG (sem JavaScript, compatíveis com a CSP):
  patrimônio líquido, disponível × dívida dos cartões, entrou × saiu e as 4 maiores categorias. Valor exato ao passar o mouse.
- **Resumo do mês** (`/resumo`, link no Início e em Relatórios): uma página para mostrar ou imprimir/salvar em PDF:
  entrou, saiu, sobrou, para onde foi, situação de hoje, faturas a pagar e alertas.
- **Folga em dias** (Raio-X): quantos dias de gasto o dinheiro disponível cobre, pela média dos últimos 90 dias.
- **Dividir em categorias**: um lançamento (ex.: nota do mercado com farmácia) pode ser repartido; as partes precisam somar o total.
  Com uma parte só, troca a categoria. Lançamento dividido não tem estorno automático (a tela não oferece).
- **Tags** (CADASTROS → Tags): etiquetas que cruzam categorias ("viagem", "Natal"), no Novo lançamento, na edição e no lote.
  A página mostra quanto custou cada tag; renomear para um nome existente junta as duas. Voltam junto na restauração da Lixeira.
- **Comprovantes**: PDF ou foto (até 8 MB) anexados ao lançamento, guardados dentro do banco (entram nos backups cifrados).
  O tipo é conferido pelo conteúdo; o download é sempre como arquivo (o navegador não abre dentro do app).
  Excluir o lançamento apaga os anexos (a tela avisa; eles não voltam com a Lixeira).
- **Filtros avançados e salvos** em Lançamentos: período livre (de/até), tag, forma de pagamento e tipo; com filtro ativo, aparece
  o total por categoria; "Salvar este filtro" cria atalhos no topo (até 20).
- Migração 0008 (tags e anexos).

## Novidades da alpha.8 (recorrência e forma de pagamento)

- **Repetir** no Novo lançamento (despesa e receita): "todo mês" ou "todo ano", com mês final opcional. Cria a previsão a partir da
  próxima ocorrência e gera os previstos dos próximos 12 meses; eles aparecem em "Confirmar previstos" e casam com a fatura importada.
  Um lançamento já feito também pode virar recorrente pela página dele ("Tornar recorrente"). Parcelado não repete.
- **Forma de pagamento**: Pix, débito, crédito, boleto, débito automático, TED, dinheiro, vale-refeição/alimentação, outro.
  No cartão de crédito e no dinheiro em espécie é preenchida sozinha; dá para mudar na edição do lançamento. As previsões levam a forma
  para os próximos. O relatório do mês mostra as despesas por forma de pagamento. Migração 0007 marca as compras de cartão já registradas como crédito.
- "Pago com" passou a se chamar "Saiu de (conta ou cartão)", porque é a conta de onde o dinheiro sai; o "como" é a forma de pagamento.

## Novidades da alpha.7 (primeiro uso real)

- **Importar sem cartão cadastrado:** no primeiro uso, a lista de contas da importação ficava vazia e não havia como seguir.
  Agora há a opção **"+ Cartão novo (criar a partir da fatura PDF)"**: o cartão é criado com os dias de fechamento e vencimento,
  a regra do BB e o limite lidos da própria fatura. Sem nenhuma conta, a página explica o que fazer.
- **Excluir cadastros.** Faltava botão de excluir em quase tudo. Revisão completa:
  - **Contas e cartões** (página da conta, no fim): excluir quando não há histórico; o saldo inicial vai para a Lixeira e as previsões
    que usam a conta saem junto. Com lançamentos, importações ou parcelamentos, explica que o caminho é desativar ("Conta ativa").
  - **Categorias** sem lançamentos (as usadas internamente, como "Gastos não identificados", são protegidas); com lançamentos, desativar.
  - **Pessoas** (os lançamentos dela ficam, sem pessoa), **metas** e **previsões** (apaga os previstos não confirmados; os confirmados ficam).
  - Já existiam: lançamentos (vão para a Lixeira), importações (desfazer), regras, parcelamentos (encerrar), orçamento (deixar vazio), PIN e backup automático.
  - Toda exclusão é em dois passos ("Excluir…" abre o aviso e só então aparece "Excluir de vez") e fica na auditoria.

## Novidades da alpha.6 (correções da revisão externa)

Uma revisão independente (DeepSeek, sobre o resumo do projeto) foi triada: o que procedia foi feito; o que já existia ou não se aplicava está no fim desta seção.

Correções de risco:
- **Parcelas antecipadas ou canceladas.** Antes, as parcelas projetadas a partir da fatura continuavam no planejamento para sempre, inflando
  dívida futura e fluxo de caixa. Agora: ao importar a fatura seguinte, parcelas previstas para aquele ciclo que não vieram são apontadas
  (na revisão e como alerta); a página **Parcelamentos** encerra o plano ("antecipado", "cancelado", "outro"), tirando só as parcelas que
  não vieram em faturas importadas. As retiradas vão para a Lixeira e o encerramento fica na auditoria. Testado com uma 2ª fatura sintética
  em que a parcela 03/05 é substituída por uma linha de antecipação.
- **Testar o backup.** Botão que abre o backup automático mais recente com a senha numa cópia temporária e confere a integridade.
  Alerta enquanto nunca foi testado e quando o último teste passa de 3 meses. Senha errada e arquivo adulterado são recusados.
- **PIN:** a tela agora diz o que ele protege e o que não protege (cópia do arquivo do banco).
- **IRPF:** "Saúde e farmácia" virou **Saúde** + **Farmácia e remédios** (migração 0006). Farmácia na seção do banco "Saúde" vai para Farmácia.
  O relatório separa "potencialmente dedutível", "com limite" e "em regra não dedutível", e marca lançamentos em Saúde que parecem farmácia.
- **Alertas dispensáveis:** "Dispensar" esconde por 30 dias (urgentes, 3 dias). O alerta é reconhecido mesmo quando os números mudam.
- **Limite do cartão:** acima de 100% (contando parcelas futuras), a mensagem explica que o banco mostra disponível R$ 0,00.
- **Lixeira em mês fechado:** testado; restaurar mostra a mensagem para reabrir o mês, sem erro.

Análises do primeiro mês:
- **Natureza das categorias:** essencial, comprometido (dívidas e juros) ou "dá para cortar", editável em Categorias, com padrão para as iniciais.
- **Raio-X:** renda média, gasto médio, **custo de vida mínimo**, **quantos meses a reserva cobre** (também no Início), onde cortar primeiro e
  o cenário **"e se a renda cair X%"** (mantendo os gastos × cortando o discricionário). Categoria sem classificação conta como essencial.
- **Despesas anuais (provisões):** previsões podem ser "uma vez por ano" (IPVA, IPTU, seguro); a página mostra quanto separar por mês;
  no Raio-X entram como 1/12 e saem da média, para não contar duas vezes.
- **Conciliação assistida:** quando o saldo não bate com o do banco, aparecem pistas no que já foi lançado: previsto não confirmado
  (inclusive dois somados), lançamento em dobro e lançamento no sentido errado, marcando os que batem exatamente com a diferença.
- **Alerta de tendência:** categoria que sobe três meses seguidos (≥ 30% e ≥ R$ 100).
- **Simulador:** avisa que o teto não torna o rotativo barato, que o teto é um só para a mesma dívida e que os parcelamentos são hipóteses, não oferta do banco.

Da revisão, não feito (e por quê): conversão cambial (o app usa o valor em reais cobrado pelo banco; a fatura real com compra no exterior fecha
com diferença zero), testes de "snapshot" de HTML (frágeis; o e2e cobre comportamento), código de recuperação do backup (equivale a uma segunda
senha; o teste periódico protege mais), taxa de referência do BCB (exigiria internet; a fatura já traz o CET real).

## Novidades da alpha.5 (segurança, análises e interface)

Segurança e proteção contra erro:
- **Backup automático diário** numa pasta escolhida (nuvem/pendrive), cifrado com chave pública (formato ENC3: X25519 + AES-256-GCM).
  A senha não fica no computador; a chave privada vai em cada arquivo, cifrada pela senha (scrypt). Retenção de 30 arquivos. Falha vira alerta urgente.
- **PIN de acesso** opcional: sessão por cookie HttpOnly/SameSite=Strict, bloqueio por inatividade, 5 erros → espera de 1 e depois 5 minutos.
  `ferramentas/remover_pin.py` para quem esquecer. Não cifra o banco (documentado).
- **Lixeira:** lançamentos excluídos podem ser restaurados por 90 dias (a partir da auditoria).

Menos trabalho na revisão da fatura:
- **Revisão agrupada:** linhas parecidas (ex.: várias "UBER *TRIP") viram uma decisão só, com opção de criar regra. Na fatura real: 101 linhas → 38 decisões.
- **Categoria adivinhada:** pelo que vocês já classificaram, por descrições parecidas e por palavras comuns (Uber, iFood, farmácia…), também no lançamento rápido.
- **Estorno sugerido:** crédito com a mesma descrição de uma compra vira estorno dela.
- Corrigido: regra criada a partir de uma linha com pontuação não casava com a própria linha.

Análises e planejamento:
- **Simulador de dívidas** com taxas lidas da fatura (rotativo, parcelamento, mínimo e encargos), com o teto da Lei 14.690/2023.
  Exemplo fictício (dívida de R$ 8.123,45, pagando R$ 1.500/mês): o rotativo bate no teto (juros iguais à dívida); parcelar em
  12x ou pegar empréstimo a 3,5% a.m. sai bem mais barato.
- **Custo do crédito** no mês e no ano; **cobranças fixas** com aviso de aumento; alertas de **limite ≥ 90%** e de **categoria acima do normal**.
- **Metas** (por conta ou valor informado, com quanto guardar por mês) e **apoio ao IRPF** (saúde, educação, receitas e saldos em 31/12).

Interface:
- **Tema claro, escuro ou automático** (segue o sistema), escolhido no rodapé.
- **Celular/janela estreita:** colunas secundárias escondidas, formulários em duas colunas, botão Bloquear visível; teste automático garante que nada fica cortado.
- Acessibilidade: link "Pular para o conteúdo", `aria-current` no menu, foco visível. Impressão sem menu.
- Código das páginas dividido por área (`fin404/web/pg_*.py`); `.github/workflows/testes.yml` roda a suíte em Linux e Windows.

## Novidades da alpha.4 (uso sem extrato bancário)

O casal não tem extratos recorrentes; a fonte disponível é a fatura do cartão em PDF. O fluxo foi ajustado para isso:

- **Parcelas futuras a partir da fatura:** cada linha "PARC k/n" gera as parcelas k+1..n nas faturas seguintes, com a mesma categoria e pessoa.
  A soma é conferida com o "saldo parcelado em faturas futuras" do banco. Na fatura real: R$ 1.873,37, igual ao banco. Anuidade parcelada
  (com desconto equivalente) e parcelamento de fatura não são projetados. Na fatura seguinte, as parcelas projetadas são casadas, não duplicadas.
- **Confirmar previstos:** tela para marcar, em lote, o que aconteceu (salário, aluguel, contas), ajustando valor e data.
- **Lançamento rápido** no Início, com a conta mais usada já escolhida.
- **Conferência mensal com o saldo do app do banco:** a diferença pode ser lançada como "Gastos não identificados" (ou "Entradas não identificadas"),
  para que saldo e relatórios fiquem completos sem extrato.
- Menu enxuto para caber numa tela de notebook (1366×768); restauração e integridade ficam na página de Backup.
- Migrações 0003 e 0004 (categorias novas).

## Novidades da alpha.3 (pronto para o dia a dia)

- **Layout no celular:** barra compacta com os 5 atalhos principais e "Mais opções"; o conteúdo aparece na primeira tela.
- **Página da conta:** movimentações até hoje primeiro; próximos lançamentos e previsões ficam recolhidos.
- **Detalhe do lançamento sem jargão contábil:** "entrou", "saiu", "dívida aumentou", "gasto", em vez de débito/crédito.
- **Alertas:** fatura vencendo em até 5 dias (urgente nos últimos 2), backup cifrado ausente ou com mais de 7 dias.
- **Cópia local automática diária** (últimas 14), ao abrir o programa e a cada 6 horas.
- **Exportar lançamentos em CSV** (com os filtros da tela), pronto para Excel em português.
- **Windows:** o iniciador procura o Python e, se faltar, abre a página de download; instala os componentes na primeira vez;
  `criar_atalho_na_area_de_trabalho.bat`; abrir de novo com o programa aberto só abre o navegador.
- **Guia `PRIMEIROS_PASSOS.md`.**

## Novidades da alpha.2 (fatura PDF do Ourocard BB)

- **Leitor de fatura PDF do Ourocard (BB)** com trava de soma: saldo anterior + lançamentos lidos = "Total da Fatura", ou o arquivo é recusado.
  Validado com uma fatura real (101 lançamentos): leitura exata e, depois da importação, fatura calculada igual à do banco (diferença R$ 0,00).
  A fatura real não faz parte do pacote: os testes usam uma fatura sintética no mesmo layout.
- **Datas reais de fechamento e vencimento:** guardadas a partir das faturas importadas, com prioridade sobre o dia fixo do cartão.
- **Regra de fechamento por cartão:** compra no dia do fechamento vai para a fatura seguinte ou entra na que fecha (Ourocard).
- **Revisão de fatura:** sugestões a partir das categorias do banco e de palavras como IOF, encargos e anuidade; data original da compra; parcela lançada no app é casada com a da fatura (pelo "PARC 02/05" e pelo ciclo); pessoa reconhecida pelo portador; oferta de saldo inicial do cartão a partir do "saldo da fatura anterior".
- **Primeira migração de esquema real (0001 → 0002)**, testada a partir de um banco na versão 1, com cópia de segurança antes de alterar.
- Testes de propriedade agora sorteiam também a regra de fechamento e datas reais deslocadas.

## Defeitos da revisão da v0.9

| ID | Defeito | Como ficou | Prova |
|---|---|---|---|
| D1 | Formulários não salvavam no Chrome/Edge | `Referrer-Policy: same-origin`; Origin e `Sec-Fetch-Site` conferidos | Jornada e2e no Chrome envia dezenas de formulários |
| D2 | Exclusão sem confirmação | Página de confirmação no servidor; nenhum JavaScript na aplicação | e2e: excluir → cancelar mantém o lançamento; zero violações de CSP |
| D3 | Importado não podia ser excluído | Exclusão devolve a linha para revisão; desfazer lote inteiro | e2e e `test_desfazer_lote_volta_ao_estado_anterior` |
| D4 | Extrato contava fatura e Pix como despesa | Revisão obrigatória com sugestões; pagamento de fatura e transferência viram movimentos entre contas | `test_mes_importado_sem_dupla_contagem` |
| D5 | Dois caminhos de pagamento | Um só: transferência para o passivo do cartão; a fatura sabe o que foi pago | `test_mes_tipico_sem_dupla_contagem` |
| D6 | Mesmo dado por 3 importadores = 3 cópias | Um importador; duplicata detectada por casamento (conta + valor + data ±3 dias) e por identificador | `test_mesmo_extrato_em_ofx_e_csv_nao_duplica` |
| D7 | Estorno não reduzia despesa | Estorno credita a categoria; orçamento desconta | `test_estorno_reduz_despesa_e_orcamento` |
| D8 | Telas fora do menu, link quebrado | Menu único; e2e verifica ausência de 404 | e2e |
| D9 | Entradas que derrubavam a conexão | Tratador global; erro sempre vira página em português e registro em `data/logs` | teste de fumaça com entradas inválidas |
| D10 | Mensagens técnicas em inglês | Validação própria em português | idem |
| D11 | Price com taxa nominal | Simulador removido desta versão (volta na fase 5 com taxa mensal e CET); `percentual()` já aceita vírgula | `test_percentual_aceita_virgula_e_rejeita_nan` |
| D12 | CSV/OFX dos bancos recusados | dd/mm/aaaa, Windows-1252, "Histórico", D/C, crédito/débito, linhas de saldo, títulos antes do cabeçalho; OFX confere a conta e trata FITID repetido como aviso | fixtures em `tests/fixtures` |
| D13 | Recorrências inflavam "vencidos" | Previsões só geram meses futuros e são casadas com o real | `test_previsoes_idempotentes_e_sem_passado` |
| D14 | `ResourceWarning` (conexões não fechadas) | Toda conexão passa por `banco.conexao()`/`transacao()`, que fecham explicitamente | Suíte roda com `-W error::ResourceWarning` |
| D15 | Testes dependentes de ordem | Banco novo por teste (fixture) | — |
| D16 | Padrões que induzem erro | Categoria e conta começam vazias ("Escolha…"); vencimento do cartão calculado pelo ciclo | e2e |
| D17 | Limites inconsistentes | Um limite de corpo (25 MB) e limites por formato | — |

## Encontrado e corrigido durante esta entrega

- **IDs reaproveitados:** os testes de propriedade (10 mil sequências) acharam que o SQLite reaproveitava o ID de uma transação excluída, o que faria links e auditoria apontarem para outro registro. Corrigido com `AUTOINCREMENT`; teste de regressão incluído.
- **OFX truncado:** era recusado com mensagem vaga; agora a mensagem diz que o arquivo está incompleto.
- **Simulador sem teto legal:** a primeira versão mostrava R$ 16,8 mil de juros no rotativo para R$ 8,4 mil de dívida, o que a lei não permite desde 2024. Corrigido e testado.
- **Simulador ignorava o formulário vazio:** campos em branco não chegam na URL; a página tratava a primeira abertura como envio. Achado pelo teste no navegador.

## Evidências

Comando: `FIN404_EXEMPLOS=10000 python -W error::ResourceWarning -m pytest -v tests`
Resultado (alpha.28): **231 aprovados** no 3.13; 206 (sem navegador) no 3.10 e no 3.14, 0 falhas, 0 avisos (ambiente Linux, Python 3.13, Chrome headless).
Os testes de propriedade (10.000 sequências) já sorteiam as duas regras de fechamento e datas reais deslocadas.

- Testes de propriedade: 10.000 sequências aleatórias de compras, parcelas, receitas, transferências, pagamentos, estornos e exclusões, conferidas contra um modelo independente (saldos, totais de relatório, limite de estorno, fatura = dívida na véspera do fechamento).
- Mutação: cinco erros injetados de propósito (transação desequilibrada, fechamento de cartão, previstos nos relatórios, importador sem casamento, e um controle neutro). Os quatro reais foram detectados; o controle passou.
- Migração: banco v0.9 real, montado com o código antigo e os cenários da revisão, migrado com totais idênticos em todos os meses.
- Fatura real (num banco temporário, fora do pacote): total e parcelas futuras conferem com o banco (diferença zero); simulador preenchido com as taxas e o mínimo da fatura; alerta de limite em 102% (o banco informa 100% utilizado).
- Ponta a ponta: jornada completa no Chrome (cadastro, compras, parcelamento, importação com revisão, estorno, relatórios, conferência de saldo, exclusão, fechamento de mês, previsões, fluxo de caixa, backup, restauração com senha errada e certa, integridade) sem violação de CSP, diálogo JS, erro 5xx ou recurso 404.

## Não verificado (depende de vocês ou de outro ambiente)

1. **Windows:** nada foi executado em Windows (o CI do GitHub resolve isso se o projeto for para um repositório). Pontos de atenção: `iniciar_windows.bat` e `criar_atalho_na_area_de_trabalho.bat`
   (escritos com cuidado, mas não executados), instalação via pip, troca do banco na restauração (`os.replace` com o arquivo fechado), Edge.
   Caminhos com espaço e acento foram testados no Linux.
2. **Documentos reais:** a fatura PDF do Ourocard foi validada com uma fatura real. Os leitores de OFX/CSV ficam disponíveis, mas não há extratos para validá-los; o uso previsto é sem extrato.
3. **PDF de fatura:** só Ourocard (BB). Santander e Inter dependem de amostras. OCR (PDF digitalizado) não existe.

## Próximos passos

- **Pendências registradas em 07/11/2026** (detalhes em PARA_O_KIRO.md, R10):
  - Envio das notas fiscais (fotos, em lotes) — **José**.
  - Base de dados de produtos de mercado (marcas, tamanhos, unidades) para o histórico de preços — **Claude**, depois do mês de teste.
  - Backlog novo no PARA_O_KIRO.md: R11 completude dos dados (alertas de conferência de saldo), R12 garantias e prazos,
    R13 reunião financeira do mês, R14 simulador de financiamento (SAC × Price, FGTS).

1. Rodar no notebook: instalar, migrar os dados da v0.9 e conferir a tela de migração.
2. Escolher o banco da fase 2 e importar um mês real; conferir saldo e fatura com os documentos.
3. Usar em paralelo por um mês. Relatar divergências.
4. Depois de um mês de uso: classificar as categorias novas, cadastrar as despesas anuais, conferir o Raio-X. PDF de outros bancos quando houver amostra.
