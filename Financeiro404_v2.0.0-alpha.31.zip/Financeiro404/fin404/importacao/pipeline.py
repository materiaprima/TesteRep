"""Importação em três etapas: staging -> casamento/sugestão -> revisão e confirmação.

Nada entra no livro-razão antes da confirmação. Um lote confirmado pode ser desfeito.
Convenção das linhas: valor negativo = saída da conta (ou compra, num cartão); positivo = entrada (ou crédito no cartão).
"""
import hashlib
import re
import unicodedata
from collections import Counter
from datetime import timedelta
from pathlib import Path

from fin404.dados.banco import auditar
from fin404.dinheiro import ErroValidacao, data as ler_data, somar_meses
from fin404.dominio import cartoes, razao
from fin404.importacao.adaptadores import csv_generico, ofx, pdf_bb

TOLERANCIA_DIAS = 3
RE_PAGAMENTO_CARTAO = re.compile(r'(pag(to|amento)?\.?\s*(de\s*)?(fatura|cart)|fatura\s*cart|pgto\s*cartao|pagamento\s*recebido|pag\s*fat)', re.I)
RE_PAGAMENTO_NA_FATURA = re.compile(r'^(pgto|pagto|pagamento)\b(?!.*parc)', re.I)
RE_TARIFA = re.compile(r'\b(iof|encargos?|juros|multa|anuidade|anud|tarifa|mora)\b', re.I)
RE_PARCELA = re.compile(r'\bPARC\.?\s*(\d{1,2})/(\d{1,2})\b', re.I)
RE_NAO_PROJETAR = re.compile(r'TIT-PARC|ANUID|ANUD|PAGTO\.?\s*PARCEL|PGTO\.?\s*PARCEL', re.I)
RE_PARCELAMENTO_FATURA = re.compile(r'(pagto|pgto)\.?\s*parcel', re.I)
CATEGORIA_DO_BANCO = {
    'educação': 'Educação', 'restaurantes': 'Restaurantes e delivery', 'saúde': 'Saúde',
    'transporte': 'Transporte', 'supermercados': 'Mercado', 'supermercado': 'Mercado', 'vestuário': 'Vestuário',
    'lazer': 'Lazer e viagens', 'viagens': 'Lazer e viagens', 'turismo': 'Lazer e viagens',
}


def _norm(s):
    s = unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode().lower()
    return re.sub(r'\s+', ' ', s).strip()


def _assinatura(descricao):
    """Descrição sem números e datas, para aprender categorias por semelhança."""
    s = _norm(descricao)
    s = re.sub(r'\d+/\d+', ' ', s)
    s = re.sub(r'[\d\-\*\.#:]+', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()[:60]


def ler_arquivo(nome, dados, inverter_sinal=False):
    ext = Path(nome or '').suffix.lower()
    if ext == '.pdf' or dados[:5] == b'%PDF-':
        texto = pdf_bb.extrair_texto(dados) if dados[:5] == b'%PDF-' else ''
        if pdf_bb.reconhece(texto):
            return pdf_bb.ler_texto(texto)
        raise ErroValidacao('Layout de PDF não reconhecido. Por enquanto, o Financeiro 404 lê a fatura Ourocard do Banco do Brasil. '
                            'Para outros bancos, use OFX ou CSV (ou mande uma fatura anonimizada para criarmos o leitor).')
    if ext in ('.ofx', '.qfx') or dados[:400].upper().find(b'<OFX') >= 0 or dados[:200].upper().startswith(b'OFXHEADER'):
        return ofx.ler(dados)
    if ext in ('.csv', '.txt', '') :
        return csv_generico.ler(dados, inverter_sinal=inverter_sinal)
    raise ErroValidacao('Formato não suportado. Envie OFX, QFX ou CSV.')


def criar_cartao_da_fatura(c, nome_arquivo, dados):
    """Cria o cartão a partir de uma fatura em PDF reconhecida (dias de fechamento e vencimento, regra e limite)."""
    if dados[:5] != b'%PDF-':
        raise ErroValidacao('"Novo cartão" só funciona com a fatura em PDF. Para extrato OFX ou CSV, cadastre a conta antes em Contas e dívidas.')
    lido = ler_arquivo(nome_arquivo, dados)
    fat = lido.get('fatura') or {}
    if not fat.get('fechamento') or not fat.get('vencimento'):
        raise ErroValidacao('Não achei as datas de fechamento e vencimento nesta fatura. Cadastre o cartão em Contas e dívidas.')
    base = 'Ourocard'
    nome, n = base, 2
    while c.execute("SELECT 1 FROM contas WHERE lower(nome)=lower(?) AND tipo IN ('ativo','passivo')", (nome,)).fetchone():
        nome, n = f'{base} {n}', n + 1
    return razao.criar_conta(c, nome, 'cartao', instituicao='Banco do Brasil', dia_fechamento=fat['fechamento'].day,
                             dia_vencimento=fat['vencimento'].day, limite_centavos=(fat.get('extras') or {}).get('limite'),
                             regra_fechamento=fat.get('regra_fechamento') or 'atual')


def preparar(c, conta_id, nome_arquivo, dados, inverter_sinal=None):
    """Etapa 1: lê o arquivo e grava as linhas em staging. Retorna (lote_id, avisos)."""
    conta = razao.conta(c, conta_id)
    if conta['tipo'] not in ('ativo', 'passivo'):
        raise ErroValidacao('Escolha a conta ou o cartão a que o arquivo pertence.')
    if inverter_sinal is None:
        inverter_sinal = conta['subtipo'] == 'cartao'   # CSV de fatura costuma trazer compras positivas
    lido = ler_arquivo(nome_arquivo, dados, inverter_sinal=inverter_sinal)
    sha = hashlib.sha256(dados).hexdigest()
    anterior = c.execute('SELECT id, criado_em FROM lotes_importacao WHERE conta_id=? AND sha256=? AND desfeito_em IS NULL',
                         (conta_id, sha)).fetchone()
    if anterior:
        raise ErroValidacao(f'Este mesmo arquivo já foi importado nesta conta (lote {anterior["id"]}, {anterior["criado_em"][:10]}).')
    externa = lido['conta_externa']
    if externa and conta['identificador_externo'] and _norm(externa) != _norm(conta['identificador_externo']):
        raise ErroValidacao(f'O arquivo é da conta "{externa}", mas "{conta["nome"]}" está cadastrada como '
                            f'"{conta["identificador_externo"]}". Escolha a conta certa.')
    if lido['cartao'] is True and conta['subtipo'] != 'cartao':
        raise ErroValidacao('O arquivo é de cartão de crédito. Escolha o cartão correspondente.')
    lote = c.execute('''INSERT INTO lotes_importacao(conta_id,formato,arquivo,sha256,identificador_conta)
                        VALUES(?,?,?,?,?)''', (conta_id, lido['formato'], Path(nome_arquivo or 'arquivo').name[:200], sha, externa)).lastrowid
    avisos = list(lido['avisos'])
    fat = lido.get('fatura')
    cartao = None
    if fat:
        if conta['subtipo'] != 'cartao':
            raise ErroValidacao('O arquivo é uma fatura de cartão. Escolha o cartão correspondente.')
        sem_movimento = not c.execute('SELECT 1 FROM lancamentos WHERE conta_id=?', (conta_id,)).fetchone()
        if not conta['dia_fechamento'] or (sem_movimento and conta['regra_fechamento'] != fat['regra_fechamento']):
            c.execute('UPDATE contas SET dia_fechamento=COALESCE(dia_fechamento,?), dia_vencimento=COALESCE(dia_vencimento,?), regra_fechamento=? WHERE id=?',
                      (fat['fechamento'].day, (fat['vencimento'] or fat['fechamento']).day, fat['regra_fechamento'], conta_id))
            avisos.append('Ciclo do cartão configurado a partir da fatura.')
        elif conta['regra_fechamento'] != fat['regra_fechamento']:
            avisos.append('Neste banco, compras no dia do fechamento entram na fatura que fecha. Ajuste a regra do cartão em "Contas e dívidas".')
        cartoes.registrar_fechamento(c, conta_id, fat['fechamento'], fat['vencimento'], f'lote:{lote}')
        if fat.get('proximo_fechamento'):
            cartoes.registrar_fechamento(c, conta_id, fat['proximo_fechamento'], None, f'lote:{lote}')
        cartoes.registrar_total_documento(c, conta_id, fat['fechamento'], fat['total'], f'lote:{lote}')
        limite_doc = (fat.get('extras') or {}).get('limite')
        if limite_doc and not conta['limite_centavos']:
            c.execute('UPDATE contas SET limite_centavos=? WHERE id=?', (limite_doc, conta_id))
            avisos.append('Limite do cartão preenchido a partir da fatura.')
        import json
        c.execute('''UPDATE lotes_importacao SET fatura_fechamento=?, fatura_total=?, fatura_saldo_anterior=?, fatura_parcelado_futuro=?,
                     fatura_info=? WHERE id=?''', (fat['fechamento'].isoformat(), fat['total'], fat['saldo_anterior'], fat.get('parcelado_futuro'),
                                                    json.dumps(fat.get('extras') or {}, ensure_ascii=False, default=str), lote))
        cartao = cartoes.completo(c, conta_id)
    ocorrencias = Counter()
    for ordem, l in enumerate(lido['linhas'], start=1):
        if l['id_externo']:
            chave = f'{conta_id}|id|{l["id_externo"]}'
        else:
            base = f'{conta_id}|{l["data"].isoformat()}|{l["valor"]}|{_norm(l["descricao"])}'
            ocorrencias[base] += 1
            chave = f'{base}|{ocorrencias[base]}'
        contabil = cartoes.ajustar_ao_ciclo(cartao, fat['fechamento'], l['data']) if fat else l['data']
        c.execute('''INSERT INTO linhas_importacao(lote_id,ordem,data,valor_centavos,descricao,id_externo,chave,situacao,
                                                     data_original,portador,categoria_banco) VALUES(?,?,?,?,?,?,?,'nova',?,?,?)''',
                  (lote, ordem, contabil.isoformat(), l['valor'], l['descricao'], l['id_externo'],
                   hashlib.sha256(chave.encode()).hexdigest(), l['data'].isoformat() if contabil != l['data'] else None,
                   l.get('portador', ''), l.get('categoria_banco', '')))
    sugerir(c, lote)
    auditar(c, 'preparar', 'lote', lote, f'{len(lido["linhas"])} linhas de {nome_arquivo}')
    return lote, avisos


def _ja_importada(c, linha, conta_id):
    return c.execute('''SELECT li.id FROM linhas_importacao li JOIN lotes_importacao lo ON lo.id=li.lote_id
                        WHERE li.chave=? AND lo.conta_id=? AND lo.desfeito_em IS NULL AND li.lote_id<>?
                        AND li.situacao IN ('casada','criada','ignorada')''', (linha['chave'], conta_id, linha['lote_id'])).fetchone()


def _candidatas(c, conta_id, linha, excluir):
    d = ler_data(linha['data'])
    rows = c.execute('''SELECT t.id, t.data, t.descricao, t.status,
                               (SELECT li.id FROM linhas_importacao li JOIN lotes_importacao lo ON lo.id=li.lote_id
                                WHERE li.transacao_id=t.id AND lo.desfeito_em IS NULL AND li.situacao IN ('casada','criada')
                                AND li.lote_id<>?) ja_ligada
                        FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                        WHERE l.conta_id=? AND l.valor_centavos=? AND t.data BETWEEN ? AND ?''',
                     (linha['lote_id'], conta_id, linha['valor_centavos'],
                      (d - timedelta(days=TOLERANCIA_DIAS)).isoformat(), (d + timedelta(days=TOLERANCIA_DIAS)).isoformat())).fetchall()
    parc = RE_PARCELA.search(linha['descricao'])
    conta = razao.conta(c, conta_id)
    if parc and conta['subtipo'] == 'cartao' and conta['dia_fechamento']:
        k = cartoes.completo(c, conta)
        inicio, fim = cartoes.ciclo(k, cartoes.fechamento_da_compra(k, d))
        extra = c.execute('''SELECT t.id, t.data, t.descricao, t.status, NULL ja_ligada FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                             WHERE l.conta_id=? AND l.valor_centavos=? AND t.plano_id IS NOT NULL AND t.parcela_n=?
                             AND t.data>=? AND t.data<?''', (conta_id, linha['valor_centavos'], int(parc.group(1)),
                                                             inicio.isoformat(), fim.isoformat())).fetchall()
        vistos = {r['id'] for r in rows}
        rows = list(rows) + [r for r in extra if r['id'] not in vistos]
    rows = [r for r in rows if r['id'] not in excluir]
    rows.sort(key=lambda r: (abs((ler_data(r['data']) - d).days), r['ja_ligada'] is not None, r['id']))
    return rows


def _categoria_aprendida(c, linha, eh_cartao):
    assinatura = _assinatura(linha['descricao'])
    if len(assinatura) < 3:
        return None
    tipo = 'despesa' if (eh_cartao or linha['valor_centavos'] < 0) else 'receita'
    for r in c.execute('''SELECT li.descricao, k.id, k.nome FROM linhas_importacao li
                           JOIN lancamentos l ON l.transacao_id=li.transacao_id JOIN contas k ON k.id=l.conta_id
                           WHERE li.situacao='criada' AND k.tipo=? ORDER BY li.id DESC LIMIT 2000''', (tipo,)):
        if _assinatura(r['descricao']) == assinatura:
            return r['id'], r['nome']
    return None


def _compra_do_estorno(c, conta_id, linha):
    """Procura a compra que o crédito estorna: mesma conta/cartão, descrição parecida, valor maior ou igual, até 120 dias antes.
    Olha o razão e também as linhas do mesmo arquivo. Devolve (categoria_id, descrição, data dd/mm) ou None."""
    from fin404.dominio import categorias as cats
    primeiro = (cats.chave_grupo(linha['descricao']).split(' ') or [''])[0]
    if len(primeiro) < 3:
        return None
    d = ler_data(linha['data'])
    for r in c.execute('''SELECT t.descricao, t.data, k.id FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                          JOIN lancamentos lc ON lc.transacao_id=t.id JOIN contas k ON k.id=lc.conta_id
                          WHERE l.conta_id=? AND l.valor_centavos<=? AND k.tipo='despesa' AND t.data BETWEEN ? AND ?
                          ORDER BY t.data DESC''', (conta_id, -linha['valor_centavos'], (d - timedelta(days=120)).isoformat(), d.isoformat())):
        if cats.chave_grupo(r['descricao']).split(' ')[0] == primeiro:
            return r['id'], r['descricao'], ler_data(r['data']).strftime('%d/%m')
    for r in c.execute('''SELECT * FROM linhas_importacao WHERE lote_id=? AND valor_centavos<=? AND sugestao LIKE 'cat:%' ''',
                       (linha['lote_id'], -linha['valor_centavos'])):
        if cats.chave_grupo(r['descricao']).split(' ')[0] == primeiro:
            return int(r['sugestao'][4:]), r['descricao'], ler_data(r['data_original'] or r['data']).strftime('%d/%m')
    return None


def grupos_pendentes(c, lote_id, minimo=3):
    """Junta linhas pendentes parecidas (mesma chave, mesmo sinal, sem casamento sugerido) para decidir de uma vez."""
    from fin404.dominio import categorias as cats
    grupos = {}
    for l in c.execute("SELECT * FROM linhas_importacao WHERE lote_id=? AND situacao='nova' ORDER BY ordem", (lote_id,)):
        if l['sugestao'].startswith('casar:'):
            continue
        chave = cats.chave_grupo(l['descricao'])
        if len(chave) < 3:
            continue
        grupos.setdefault((chave, l['valor_centavos'] < 0), []).append(l)
    return [(chave, linhas) for (chave, _), linhas in grupos.items() if len(linhas) >= minimo]


def criar_regra_de_grupo(c, chave, acao):
    tipo, _, alvo = acao.partition(':')
    nome = {'cat': 'categoria', 'transf': 'transferencia', 'fatura': 'pagamento_fatura', 'ignorar': 'ignorar'}.get(tipo)
    if not nome or len(chave) < 3 or c.execute('SELECT 1 FROM regras WHERE padrao=?', (chave,)).fetchone():
        return None
    return c.execute('INSERT INTO regras(padrao,acao,conta_id) VALUES(?,?,?)', (chave, nome, int(alvo) if alvo else None)).lastrowid


def _regra(c, descricao):
    d, sem_pontuacao = _norm(descricao), _assinatura(descricao)
    for r in c.execute('SELECT * FROM regras ORDER BY prioridade, id'):
        p = _norm(r['padrao'])
        if p in d or p in sem_pontuacao:
            return r
    return None


def sugerir(c, lote_id):
    """Etapa 2: marca duplicadas e sugere uma ação para cada linha nova."""
    lote = c.execute('SELECT * FROM lotes_importacao WHERE id=?', (lote_id,)).fetchone()
    conta = razao.conta(c, lote['conta_id'])
    reservadas = {r[0] for r in c.execute("SELECT transacao_id FROM linhas_importacao WHERE lote_id=? AND transacao_id IS NOT NULL", (lote_id,))}
    cartoes_ativos = cartoes.lista(c)
    correntes = razao.contas(c, subtipos=('corrente',))
    for linha in c.execute("SELECT * FROM linhas_importacao WHERE lote_id=? AND situacao='nova' ORDER BY ordem", (lote_id,)).fetchall():
        sug, motivo, situacao = '', '', 'nova'
        if _ja_importada(c, linha, conta['id']):
            situacao, sug, motivo = 'duplicada', 'ignorar', 'Já importada antes (mesmo identificador ou mesma linha).'
        else:
            cands = _candidatas(c, conta['id'], linha, reservadas)
            if cands:
                melhor = cands[0]
                if melhor['ja_ligada']:
                    situacao, sug = 'duplicada', 'ignorar'
                    motivo = f'Já importada em outro arquivo: "{melhor["descricao"]}" de {ler_data(melhor["data"]).strftime("%d/%m")}.'
                else:
                    sug = f'casar:{melhor["id"]}'
                    prev = ' (previsto)' if melhor['status'] == 'agendada' else ''
                    motivo = f'Corresponde a "{melhor["descricao"]}"{prev} de {ler_data(melhor["data"]).strftime("%d/%m")}.'
                    livres = [r for r in cands if not r['ja_ligada']]
                    if len(livres) > 1:
                        motivo = (f'CONFIRA: {len(livres)} lançamentos com o mesmo valor por perto; escolhi o de data mais próxima. '
                                  + motivo)
                reservadas.add(melhor['id'])
        if not sug:
            regra = _regra(c, linha['descricao'])
            if regra:
                prefixo = {'categoria': 'cat', 'transferencia': 'transf', 'pagamento_fatura': 'fatura', 'ignorar': 'ignorar'}[regra['acao']]
                sug = prefixo if prefixo == 'ignorar' else f'{prefixo}:{regra["conta_id"]}'
                motivo = f'Regra: contém "{regra["padrao"]}".'
        if not sug:
            aprendida = _categoria_aprendida(c, linha, conta['subtipo'] == 'cartao')
            if aprendida:
                sug, motivo = f'cat:{aprendida[0]}', f'Mesma descrição de lançamentos anteriores ({aprendida[1]}).'
        if not sug and conta['subtipo'] == 'cartao' and linha['valor_centavos'] > 0 and RE_PAGAMENTO_NA_FATURA.search(linha['descricao']):
            origem = cartoes.origem_sugerida(c, linha['descricao'])
            if origem:
                sug, motivo = f'fatura:{origem["id"]}', f'Pagamento da fatura (não é gasto); confirme de onde saiu o dinheiro ({origem["nome"]}?).'
            else:
                motivo = ('Pagamento da fatura: NÃO é gasto nem estorno. Cadastre a conta (ou "Dinheiro") de onde saiu o '
                          'dinheiro e escolha "Pagamento de fatura" aqui; se escolher uma categoria, o gasto do mês fica menor.')
        if not sug and conta['subtipo'] == 'cartao' and RE_PARCELAMENTO_FATURA.search(linha['descricao']):
            cid = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome='Dívidas antigas e parcelamentos' AND ativa=1").fetchone()
            if cid:
                sug = f'cat:{cid[0]}'
            motivo = 'Parcela de parcelamento de fatura: pagamento de dívida de antes, não compra nova.'
        if not sug and RE_TARIFA.search(linha['descricao']):
            cid = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome='Juros, tarifas e IOF' AND ativa=1").fetchone()
            if cid:
                sug, motivo = f'cat:{cid[0]}', 'Tarifa, juros, IOF ou anuidade.' + (' Crédito/estorno de tarifa.' if linha['valor_centavos'] > 0 else '')
        if not sug and linha['categoria_banco'] and linha['valor_centavos'] < 0:
            nome = CATEGORIA_DO_BANCO.get(linha['categoria_banco'].strip().lower())
            if nome == 'Saúde':  # o banco põe farmácia em "Saúde"; para o IRPF elas precisam ficar separadas
                from fin404.dominio.categorias import PALAVRAS, normalizar
                texto = ' ' + normalizar(linha['descricao']) + ' '
                if any(' ' + p in texto for p in PALAVRAS['Farmácia e remédios']):
                    nome = 'Farmácia e remédios'
            cid = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome=? AND ativa=1", (nome,)).fetchone() if nome else None
            if cid:
                sug, motivo = f'cat:{cid[0]}', f'Categoria do banco: {linha["categoria_banco"]}.'
        if not sug and conta['subtipo'] == 'cartao' and linha['valor_centavos'] > 0 and not RE_PAGAMENTO_NA_FATURA.search(linha['descricao']):
            achado = _compra_do_estorno(c, conta['id'], linha)
            if achado:
                sug, motivo = f'cat:{achado[0]}', f'Parece estorno de "{achado[1][:40]}" ({achado[2]}).'
        if not sug and linha['valor_centavos'] < 0:
            from fin404.dominio import categorias as cats
            inf = cats.inferir(c, linha['descricao'])
            if inf:
                sug, motivo = f'cat:{inf[0]}', inf[1]
        if not sug and RE_PAGAMENTO_CARTAO.search(linha['descricao']):
            v = abs(linha['valor_centavos'])
            if conta['tipo'] == 'ativo' and linha['valor_centavos'] < 0 and cartoes_ativos:
                alvo = None
                for k in cartoes_ativos:
                    if k['dia_fechamento']:
                        f = cartoes.fechamento_anterior(k, cartoes.fechamento_da_compra(k, linha['data']))
                        if cartoes.fatura(c, k['id'], f, linha['data'])['valor'] == v:
                            alvo = k; break
                alvo = alvo or (cartoes_ativos[0] if len(cartoes_ativos) == 1 else None)
                if alvo:
                    sug, motivo = f'fatura:{alvo["id"]}', f'Parece pagamento da fatura de {alvo["nome"]}.'
            elif conta['subtipo'] == 'cartao' and linha['valor_centavos'] > 0 and len(correntes) >= 1:
                sug, motivo = f'fatura:{correntes[0]["id"]}', f'Pagamento recebido; confirme a conta de origem ({correntes[0]["nome"]}).'
        if not motivo and linha['categoria_banco']:
            motivo = f'Categoria do banco: {linha["categoria_banco"]}.'
        if linha['data_original']:
            motivo = (motivo + ' ' if motivo else '') + f'Data da compra: {ler_data(linha["data_original"]).strftime("%d/%m/%Y")}.'
        c.execute('UPDATE linhas_importacao SET situacao=?, sugestao=?, motivo=? WHERE id=?', (situacao, sug, motivo, linha['id']))


def _acao(c, conta, linha, acao, pessoa_id=None):
    v = linha['valor_centavos']
    quando = linha['data']
    desc = linha['descricao']
    lote = linha['lote_id']
    if acao == 'ignorar':
        return 'ignorada', None, None
    tipo_acao, _, alvo = acao.partition(':')
    if not alvo.isdigit():
        raise ErroValidacao(f'Ação inválida na linha {linha["ordem"]}.')
    alvo = int(alvo)
    if tipo_acao == 'casar':
        t = razao.transacao(c, alvo)
        if not c.execute('SELECT 1 FROM lancamentos WHERE transacao_id=? AND conta_id=? AND valor_centavos=?', (alvo, conta['id'], v)).fetchone():
            raise ErroValidacao(f'A linha {linha["ordem"]} não corresponde ao lançamento escolhido.')
        anterior = t['status']
        if anterior == 'agendada' and t['data'] != quando:
            c.execute('UPDATE transacoes SET data=? WHERE id=?', (quando, alvo))
        razao.confirmar(c, alvo, 'conciliada')
        return 'casada', alvo, anterior
    k = razao.conta(c, alvo)
    if tipo_acao == 'cat':
        if k['subtipo'] != 'categoria':
            raise ErroValidacao(f'Linha {linha["ordem"]}: escolha uma categoria.')
        if k['tipo'] == 'despesa':
            tipo = 'despesa' if v < 0 else 'estorno'
            linhas = [(k['id'], -v, pessoa_id), (conta['id'], v)]
        else:
            if v < 0:
                raise ErroValidacao(f'Linha {linha["ordem"]}: saída não pode ir para categoria de receita.')
            tipo = 'receita'
            linhas = [(conta['id'], v), (k['id'], -v, pessoa_id)]
        tid = razao.registrar(c, quando, desc, tipo, linhas, status='conciliada', lote_id=lote)
        return 'criada', tid, None
    if tipo_acao in ('transf', 'fatura'):
        if k['tipo'] not in ('ativo', 'passivo') or k['id'] == conta['id']:
            raise ErroValidacao(f'Linha {linha["ordem"]}: escolha outra conta sua.')
        if tipo_acao == 'fatura' and not ({k['tipo'], conta['tipo']} == {'ativo', 'passivo'}):
            raise ErroValidacao(f'Linha {linha["ordem"]}: pagamento de fatura liga uma conta a um cartão ou dívida.')
        linhas = [(k['id'], -v), (conta['id'], v)]
        recebe_passivo = (v < 0 and k['tipo'] == 'passivo') or (v > 0 and conta['tipo'] == 'passivo')
        tipo = 'pagamento_fatura' if recebe_passivo and (k['tipo'] == 'ativo' or conta['tipo'] == 'ativo') else 'transferencia'
        tid = razao.registrar(c, quando, desc, tipo, linhas, status='conciliada', lote_id=lote)
        return 'criada', tid, None
    raise ErroValidacao(f'Ação inválida na linha {linha["ordem"]}.')


def parcelas_restantes(linha):
    """(k, n) se a linha é parcela k de n de uma compra (e não anuidade nem parcelamento de fatura)."""
    m = RE_PARCELA.search(linha['descricao'])
    if not m or linha['valor_centavos'] >= 0 or RE_NAO_PROJETAR.search(linha['descricao']):
        return None
    k, n = int(m.group(1)), int(m.group(2))
    return (k, n) if 1 <= k <= n <= 72 and n >= 2 else None


def projecao_parcelas(c, lote_id):
    """Soma das parcelas que ainda vão vir, segundo as linhas 'PARC k/n' da fatura."""
    total = 0
    for l in c.execute('SELECT * FROM linhas_importacao WHERE lote_id=?', (lote_id,)):
        kn = parcelas_restantes(l)
        if kn:
            total += (kn[1] - kn[0]) * -l['valor_centavos']
    return total


def _gerar_parcelas_futuras(c, conta, linha, tid, lote):
    """A partir da parcela k/n lida na fatura, cria as parcelas k+1..n nas faturas seguintes (mesma categoria e pessoa)."""
    kn = parcelas_restantes(linha)
    if not kn or not lote['fatura_fechamento']:
        return 0
    k, n = kn
    valor = -linha['valor_centavos']
    cat = c.execute('''SELECT l.conta_id, l.pessoa_id FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                       WHERE l.transacao_id=? AND k.tipo='despesa' ''', (tid,)).fetchone()
    if cat is None:
        return 0
    descricao = re.sub(r'\s+', ' ', RE_PARCELA.sub('', linha['descricao'])).strip() or linha['descricao']
    plano = c.execute('''INSERT INTO planos_parcelas(descricao,total_centavos,n_parcelas,conta_cartao_id,data_compra)
                         VALUES(?,?,?,?,?)''', (descricao, valor * n, n, conta['id'], linha['data_original'] or linha['data'])).lastrowid
    c.execute('UPDATE transacoes SET plano_id=?, parcela_n=? WHERE id=?', (plano, k, tid))
    cartao = cartoes.completo(c, conta['id'])
    fech = ler_data(lote['fatura_fechamento'])
    base = ler_data(linha['data'])
    for j in range(k + 1, n + 1):
        fech = cartoes.fechamento_seguinte(cartao, fech)
        quando = cartoes.ajustar_ao_ciclo(cartao, fech, somar_meses(base, j - k))
        razao.registrar(c, quando, f'{descricao} ({j}/{n})', 'despesa', [(cat['conta_id'], valor, cat['pessoa_id']), (conta['id'], -valor)],
                        plano_id=plano, parcela_n=j, lote_id=lote['id'],
                        observacao=f'Parcela futura informada na fatura que fechou em {fech.strftime("%d/%m/%Y")}'[:500])
    return n - k


def _pessoa_do_portador(c, portador):
    if not portador:
        return None
    nome = _norm(portador)
    achadas = [p['id'] for p in c.execute('SELECT * FROM pessoas') if _norm(p['nome']).split(' ')[0] in nome.split(' ')]
    return achadas[0] if len(achadas) == 1 else None


def aplicar(c, lote_id, escolhas, regras_novas=()):
    """Etapa 3: grava no razão as linhas com ação escolhida. Linhas sem ação continuam pendentes.
    escolhas: {linha_id: 'ignorar' | 'casar:<transacao>' | 'cat:<conta>' | 'transf:<conta>' | 'fatura:<conta>'}"""
    lote = c.execute('SELECT * FROM lotes_importacao WHERE id=?', (lote_id,)).fetchone()
    if lote is None or lote['desfeito_em']:
        raise ErroValidacao('Lote de importação inexistente ou desfeito.')
    conta = razao.conta(c, lote['conta_id'])
    feitas = 0
    for linha in c.execute("SELECT * FROM linhas_importacao WHERE lote_id=? AND situacao IN ('nova','duplicada') ORDER BY ordem", (lote_id,)).fetchall():
        acao = (escolhas.get(linha['id']) or '').strip()
        if not acao:
            continue
        situacao, tid, anterior = _acao(c, conta, linha, acao, _pessoa_do_portador(c, linha['portador']))
        c.execute('UPDATE linhas_importacao SET situacao=?, transacao_id=?, status_anterior=? WHERE id=?',
                  (situacao, tid, anterior, linha['id']))
        if situacao == 'criada' and conta['subtipo'] == 'cartao':
            _gerar_parcelas_futuras(c, conta, linha, tid, lote)
        feitas += 1
        if linha['id'] in regras_novas and acao.split(':')[0] in ('cat', 'transf', 'fatura', 'ignorar'):
            criar_regra_da_linha(c, linha, acao)
    if lote['identificador_conta'] and not conta['identificador_externo']:
        c.execute('UPDATE contas SET identificador_externo=? WHERE id=?', (lote['identificador_conta'], conta['id']))
    auditar(c, 'confirmar', 'lote', lote_id, f'{feitas} linhas')
    return feitas


def criar_regra_da_linha(c, linha, acao):
    padrao = _assinatura(linha['descricao'])
    if len(padrao) < 3:
        return None
    tipo, _, alvo = acao.partition(':')
    nome = {'cat': 'categoria', 'transf': 'transferencia', 'fatura': 'pagamento_fatura', 'ignorar': 'ignorar'}[tipo]
    if c.execute('SELECT 1 FROM regras WHERE padrao=?', (padrao,)).fetchone():
        return None
    return c.execute('INSERT INTO regras(padrao,acao,conta_id) VALUES(?,?,?)',
                     (padrao, nome, int(alvo) if alvo else None)).lastrowid


def desfazer(c, lote_id):
    lote = c.execute('SELECT * FROM lotes_importacao WHERE id=?', (lote_id,)).fetchone()
    if lote is None or lote['desfeito_em']:
        raise ErroValidacao('Lote inexistente ou já desfeito.')
    for li in c.execute("SELECT * FROM linhas_importacao WHERE lote_id=? AND situacao='casada'", (lote_id,)).fetchall():
        if li['transacao_id'] and li['status_anterior']:
            razao.confirmar(c, li['transacao_id'], li['status_anterior'])
    for (tid,) in c.execute('SELECT id FROM transacoes WHERE lote_id=?', (lote_id,)).fetchall():
        razao.excluir(c, tid)
    c.execute('DELETE FROM planos_parcelas WHERE id NOT IN (SELECT plano_id FROM transacoes WHERE plano_id IS NOT NULL)')
    c.execute("DELETE FROM fechamentos_conhecidos WHERE origem=?", (f'lote:{lote_id}',))
    c.execute("DELETE FROM faturas_documento WHERE origem=?", (f'lote:{lote_id}',))
    c.execute("UPDATE lotes_importacao SET desfeito_em=CURRENT_TIMESTAMP WHERE id=?", (lote_id,))
    c.execute("UPDATE linhas_importacao SET situacao='nova', transacao_id=NULL WHERE lote_id=?", (lote_id,))
    auditar(c, 'desfazer', 'lote', lote_id, '')


def resumo_lote(c, lote_id):
    return {r['situacao']: r['n'] for r in c.execute('SELECT situacao, COUNT(*) n FROM linhas_importacao WHERE lote_id=? GROUP BY situacao', (lote_id,))}
