"""Fatura Ourocard (Banco do Brasil) em PDF com texto.

Trava de segurança: saldo anterior + soma dos lançamentos lidos precisa ser igual ao "Total da Fatura".
Se não for (layout mudou, página faltando, PDF diferente), o arquivo é recusado inteiro.

Sinal: na fatura, compra é positiva e pagamento/crédito é negativo. Aqui, seguindo a convenção das
linhas de importação, compra vira negativo (aumenta a dívida do cartão) e crédito vira positivo.
"""
import re
from datetime import date

from fin404.dinheiro import ErroValidacao, centavos, data as ler_data, formatar

RE_DATA = re.compile(r'^(\d{2})/(\d{2})(?:\s+(.*))?$')
RE_VALOR = re.compile(r'^(?:([A-Z]{2})\s+)?R\$\s*(-?[\d.]+,\d{2})$')
RE_PAIS = re.compile(r'^[A-Z]{2}$')
RE_PORTADOR = re.compile(r'^(.+?)\s*\(Cart[aã]o\s+(\d{4})\)$')
RE_RODAPE = re.compile(r'^P[aá]gina\s+\d+/\d+$')


def reconhece(texto):
    t = texto.upper()
    return 'OUROCARD' in t and 'LANÇAMENTOS NESTA FATURA' in t and 'TOTAL DA FATURA' in t


def _campo_data(texto, rotulo):
    m = re.search(rotulo + r'\s*\n\s*(\d{2}/\d{2}/\d{4})', texto)
    return ler_data(m.group(1)) if m else None


def _campo_valor(texto, rotulo):
    m = re.search(rotulo + r'\s*\n\s*R\$\s*(-?[\d.]+,\d{2})', texto)
    return centavos(m.group(1), permitir_negativo=True, permitir_zero=True) if m else None


def _ano(dia, mes, fechamento):
    d = date(fechamento.year, mes, dia)
    if d > fechamento and (d - fechamento).days > 31:
        d = date(fechamento.year - 1, mes, dia)
    return d


def _taxa(texto, rotulo_bloco, rotulo):
    """Lê '14,16% (CET 16,53% a.m. / 526,98% a.a.)' dentro de um bloco da fatura."""
    i = texto.find(rotulo_bloco)
    if i < 0:
        return None
    m = re.search(re.escape(rotulo) + r'\*?\s*\n\s*(\d{1,2},\d{2})%\s*\(CET\s*(\d{1,3},\d{2})%\s*a\.m\.', texto[i:i + 600])
    return {'taxa_am': m.group(1), 'cet_am': m.group(2)} if m else None


def informacoes_extras(texto):
    """Taxas, mínimo e limite (opcionais: se o banco mudar o texto, simplesmente não aparecem)."""
    info = {
        'minimo': _campo_valor(texto, r'Pagamento mínimo'),
        'encargos_se_minimo': None,
        'rotativo_proxima': _taxa(texto, 'Encargos financeiros próxima fatura', 'Crédito rotativo'),
        'parcelado_proxima': _taxa(texto, 'Encargos financeiros próxima fatura', 'Crédito parcelado'),
        'limite': _campo_valor(texto, r'Limite único'),
        'limite_utilizado': _campo_valor(texto, r'Limite único utilizado'),
        'limite_disponivel': _campo_valor(texto, r'Limite único disponível'),
    }
    m = re.search(r'encargos cobrados no próximo\s*\n?\s*vencimento será de\s*([\d.]+,\d{2})', texto)
    if m:
        info['encargos_se_minimo'] = centavos(m.group(1), permitir_zero=True)
    return info


def ler_texto(texto):
    if not reconhece(texto):
        raise ErroValidacao('Este PDF não parece uma fatura Ourocard do Banco do Brasil.')
    fechamento = _campo_data(texto, r'Fatura fechada em')
    vencimento = _campo_data(texto, r'Vencimento')
    proximo = _campo_data(texto, r'Fechamento da próxima fatura')
    total = _campo_valor(texto, r'Total da Fatura')
    if not fechamento or total is None:
        raise ErroValidacao('Não encontrei a data de fechamento ou o total da fatura no PDF.')
    final = re.search(r'Final\s+(\d{4})', texto)
    parcelado = re.search(r'Saldo parcelado em faturas\s*\n?\s*futuras\s*\n\s*R\$\s*([\d.]+,\d{2})', texto)
    inicio = texto.find('Lançamentos nesta fatura')
    fim = texto.rfind('Total da Fatura')
    linhas = [l.strip() for l in texto[inicio:fim].splitlines()]
    linhas = [l for l in linhas if l and not RE_RODAPE.match(l)]
    itens, secao, portador, saldo_anterior = [], '', '', None
    i = 1  # pula o título
    while i < len(linhas):
        l = linhas[i]
        m = RE_DATA.match(l)
        if m:
            dia, mes, resto = int(m.group(1)), int(m.group(2)), m.group(3)
            j = i + 1
            if resto:
                descricao = resto
            else:
                if j >= len(linhas):
                    raise ErroValidacao(f'Lançamento de {l} sem descrição (PDF incompleto?).')
                descricao = linhas[j]; j += 1
            if j < len(linhas) and RE_PAIS.match(linhas[j]):
                j += 1
            if j >= len(linhas) or not RE_VALOR.match(linhas[j]):
                raise ErroValidacao(f'Não consegui ler o valor do lançamento "{descricao}" de {l}. O layout da fatura pode ter mudado.')
            valor = centavos(RE_VALOR.match(linhas[j]).group(2), permitir_negativo=True, permitir_zero=True)
            try:
                original = _ano(dia, mes, fechamento)
            except ValueError:
                raise ErroValidacao(f'Data inválida na fatura: {l}.')
            itens.append({'data': original, 'valor': -valor, 'descricao': re.sub(r'\s+', ' ', descricao)[:200],
                          'id_externo': None, 'categoria_banco': secao, 'portador': portador})
            i = j + 1
            continue
        if l.upper() == 'SALDO FATURA ANTERIOR':
            j = i + 1
            if j < len(linhas) and RE_PAIS.match(linhas[j]):
                j += 1
            if j >= len(linhas) or not RE_VALOR.match(linhas[j]):
                raise ErroValidacao('Não consegui ler o saldo da fatura anterior.')
            saldo_anterior = centavos(RE_VALOR.match(linhas[j]).group(2), permitir_negativo=True, permitir_zero=True)
            i = j + 1
            continue
        p = RE_PORTADOR.match(l)
        if p:
            portador = f'{p.group(1).strip()} (cartão {p.group(2)})'
        elif l not in ('Data', 'Descrição', 'País', 'Valor') and not l.startswith(('Confira aqui', 'se:', 'Para identificar')):
            secao = l
        i += 1
    saldo_anterior = saldo_anterior or 0
    soma = -sum(x['valor'] for x in itens)
    if saldo_anterior + soma != total:
        raise ErroValidacao(f'Saldo anterior + lançamentos lidos somam {formatar(saldo_anterior + soma)}, mas o total da fatura é '
                            f'{formatar(total)}. O layout pode ter mudado; nada foi importado.')
    if not itens:
        raise ErroValidacao('Nenhum lançamento encontrado na fatura.')
    return {
        'formato': 'pdf-bb', 'conta_externa': f'final {final.group(1)}' if final else '', 'cartao': True,
        'linhas': itens, 'avisos': [],
        'fatura': {'fechamento': fechamento, 'vencimento': vencimento, 'proximo_fechamento': proximo, 'total': total,
                   'saldo_anterior': saldo_anterior,
                   'parcelado_futuro': centavos(parcelado.group(1), permitir_zero=True) if parcelado else None,
                   'regra_fechamento': 'atual', 'extras': informacoes_extras(texto)},
    }


def extrair_texto(dados):
    try:
        import pymupdf
    except ImportError:
        try:
            import fitz as pymupdf
        except ImportError:
            raise ErroValidacao('Para ler PDF, instale o PyMuPDF: py -m pip install pymupdf')
    try:
        with pymupdf.open(stream=dados, filetype='pdf') as doc:
            if doc.needs_pass:
                raise ErroValidacao('PDF protegido por senha. Abra no leitor de PDF e salve uma cópia sem senha.')
            if len(doc) > 60:
                raise ErroValidacao('PDF com mais de 60 páginas.')
            texto = '\n'.join(p.get_text() for p in doc)
    except ErroValidacao:
        raise
    except Exception:
        raise ErroValidacao('Não foi possível abrir o PDF (arquivo corrompido ou incompleto).')
    if len(texto.strip()) < 50:
        raise ErroValidacao('O PDF não tem texto (parece digitalizado). Leitura de imagem (OCR) ainda não existe.')
    return texto


def ler(dados):
    if len(dados) > 15_000_000 or not dados.startswith(b'%PDF-'):
        raise ErroValidacao('Arquivo PDF inválido ou maior que 15 MB.')
    return ler_texto(extrair_texto(dados))
