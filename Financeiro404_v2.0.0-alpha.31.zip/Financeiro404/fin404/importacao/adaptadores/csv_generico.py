"""Leitor de CSV de extratos e faturas com os formatos comuns dos bancos brasileiros.

Aceita: UTF-8 ou Windows-1252; separador ; , ou tabulação; datas DD/MM/AAAA ou AAAA-MM-DD;
valores 1.234,56 / -12,30 / 12,30 D; coluna única de valor ou colunas de crédito e débito.
Linhas de saldo ("Saldo anterior", "S A L D O") são descartadas e informadas.
Qualquer linha com data ou valor ilegível recusa o arquivo inteiro, indicando a linha.
"""
import csv
import io
import re
import unicodedata

from fin404.dinheiro import ErroValidacao, centavos, data as ler_data

LIMITE_BYTES = 8_000_000
LIMITE_LINHAS = 20_000

ALIASES = {
    'data': ('data', 'data lancamento', 'data do lancamento', 'data movimento', 'data da compra', 'dt', 'date', 'data transacao'),
    'descricao': ('descricao', 'historico', 'lancamento', 'estabelecimento', 'memo', 'descricao do lancamento',
                  'title', 'description', 'detalhes', 'nome'),
    'valor': ('valor', 'valor r$', 'valor (r$)', 'valor em r$', 'amount', 'quantia', 'valor brl'),
    'credito': ('credito', 'entrada', 'credito r$', 'credito (r$)'),
    'debito': ('debito', 'saida', 'debito r$', 'debito (r$)'),
    'id': ('id', 'identificador', 'fitid', 'id transacao', 'codigo da transacao'),
}


def _norm(s):
    s = unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode().lower().strip()
    return re.sub(r'\s+', ' ', s)


def _decodificar(dados):
    for enc in ('utf-8-sig', 'cp1252'):
        try:
            return dados.decode(enc)
        except UnicodeDecodeError:
            continue
    return dados.decode('latin-1')


def _separador(primeira):
    contagem = {s: primeira.count(s) for s in (';', ',', '\t')}
    return max(contagem, key=contagem.get) if max(contagem.values()) else ';'


def ler(dados, inverter_sinal=False):
    if len(dados) > LIMITE_BYTES:
        raise ErroValidacao('CSV acima de 8 MB.')
    if b'\x00' in dados[:65536]:
        # Arquivo binário (planilha .xlsx renomeada, PDF…). O Python 3.10 nem consegue ler NUL no CSV.
        raise ErroValidacao('Este arquivo não é um CSV de texto. Exporte do banco em CSV ou OFX (planilha .xlsx não serve).')
    texto = _decodificar(dados).replace('\r\n', '\n').replace('\r', '\n')
    linhas_texto = [l for l in texto.split('\n')]
    # Alguns bancos colocam linhas de título antes do cabeçalho: procura a primeira linha com coluna de data.
    inicio = None
    for i, l in enumerate(linhas_texto[:30]):
        if not l.strip():
            continue
        sep = _separador(l)
        campos = [_norm(x) for x in next(csv.reader([l], delimiter=sep))]
        if any(x in ALIASES['data'] for x in campos):
            inicio = i
            break
    if inicio is None:
        raise ErroValidacao('Não encontrei o cabeçalho do CSV. Ele precisa de colunas de data, descrição e valor.')
    sep = _separador(linhas_texto[inicio])
    leitor = csv.reader(io.StringIO('\n'.join(linhas_texto[inicio:])), delimiter=sep)
    cabecalho = [_norm(x) for x in next(leitor)]
    col = {}
    for chave, nomes in ALIASES.items():
        for i, nome in enumerate(cabecalho):
            if nome in nomes and chave not in col:
                col[chave] = i
    if 'data' not in col or 'descricao' not in col or not ('valor' in col or 'credito' in col or 'debito' in col):
        raise ErroValidacao('O CSV precisa de colunas de data, descrição e valor (ou crédito e débito). '
                            f'Colunas encontradas: {", ".join(cabecalho)}.')
    resultado, avisos, saldos = [], [], 0
    for n, campos in enumerate(leitor, start=inicio + 2):
        if not any(x.strip() for x in campos):
            continue
        if n - inicio > LIMITE_LINHAS:
            raise ErroValidacao('CSV com mais de 20 mil linhas.')

        def pegar(chave):
            i = col.get(chave)
            return campos[i].strip() if i is not None and i < len(campos) else ''
        descricao = re.sub(r'\s+', ' ', pegar('descricao'))
        if descricao[:1] == "'" and descricao[1:2] in ('=', '+', '-', '@'):
            descricao = descricao[1:]          # apóstrofo que o próprio Financeiro 404 põe ao exportar (anti-fórmula)
        nd = _norm(descricao).replace(' ', '')
        if nd.startswith('saldo') or nd in ('total', 'totaldafatura'):
            saldos += 1
            continue
        try:
            quando = ler_data(pegar('data'))
            if 'valor' in col and pegar('valor'):
                valor = centavos(pegar('valor'), permitir_negativo=True, permitir_zero=True)
            else:
                cred = pegar('credito'); deb = pegar('debito')
                valor = (centavos(cred, permitir_zero=True, permitir_negativo=True) if cred else 0) - \
                        (abs(centavos(deb, permitir_zero=True, permitir_negativo=True)) if deb else 0)
        except ErroValidacao as exc:
            raise ErroValidacao(f'Linha {n} do CSV: {exc}')
        if not descricao:
            raise ErroValidacao(f'Linha {n} do CSV sem descrição.')
        if valor == 0:
            avisos.append(f'Linha {n} com valor zero foi ignorada.')
            continue
        resultado.append({'data': quando, 'valor': -valor if inverter_sinal else valor,
                          'descricao': descricao[:200], 'id_externo': pegar('id') or None})
    if saldos:
        avisos.append(f'{saldos} linha(s) de saldo ou total descartadas.')
    if not resultado:
        raise ErroValidacao('Nenhuma movimentação encontrada no CSV.')
    return {'formato': 'csv', 'conta_externa': '', 'cartao': None, 'linhas': resultado, 'avisos': avisos}
