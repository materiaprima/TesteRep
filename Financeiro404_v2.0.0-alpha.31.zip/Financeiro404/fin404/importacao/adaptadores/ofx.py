"""Leitor de OFX/QFX (SGML 1.x e XML 2.x) tolerante aos arquivos de bancos brasileiros."""
import re
from datetime import date
from decimal import Decimal, InvalidOperation

from fin404.dinheiro import ErroValidacao

LIMITE_BYTES = 10_000_000
LIMITE_TRANSACOES = 20_000


def _decodificar(dados):
    cabecalho = dados[:600].decode('ascii', 'replace').upper()
    m = re.search(r'CHARSET:\s*(\d+|[A-Z0-9-]+)', cabecalho)
    xml = re.search(r'ENCODING="([^"]+)"', cabecalho)
    candidatos = []
    if xml:
        candidatos.append(xml.group(1).lower())
    if m and m.group(1) in ('1252', 'WINDOWS-1252'):
        candidatos.append('cp1252')
    elif m and m.group(1) in ('8859-1', 'ISO-8859-1', 'LATIN1'):
        candidatos.append('latin-1')
    candidatos += ['utf-8-sig', 'cp1252']
    for enc in candidatos:
        try:
            return dados.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return dados.decode('latin-1')


def _campo(bloco, nome):
    m = re.search(r'<' + nome + r'>\s*([^<\r\n]*)', bloco, re.I)
    return m.group(1).strip() if m else ''


def ler(dados):
    if len(dados) > LIMITE_BYTES:
        raise ErroValidacao('Arquivo OFX acima de 10 MB.')
    texto = _decodificar(dados)
    if '<OFX' not in texto.upper():
        raise ErroValidacao('O arquivo não parece ser um OFX válido.')
    cartao = bool(re.search(r'<CREDITCARDMSGSRSV1|<CCSTMTRS', texto, re.I))
    conta_externa = _campo(texto, 'ACCTID')
    blocos = re.findall(r'<STMTTRN>(.*?)(?=</STMTTRN>|<STMTTRN>|</BANKTRANLIST>)', texto, re.I | re.S)
    abertos = len(re.findall(r'<STMTTRN>', texto, re.I))
    if abertos != len(blocos) or (abertos and '</OFX>' not in texto.upper()):
        raise ErroValidacao('O OFX parece incompleto (arquivo truncado). Baixe o extrato novamente.')
    if len(blocos) > LIMITE_TRANSACOES:
        raise ErroValidacao('OFX com mais de 20 mil transações.')
    linhas, avisos, vistos = [], [], {}
    for n, b in enumerate(blocos, start=1):
        dt = _campo(b, 'DTPOSTED')[:8]
        if not re.fullmatch(r'\d{8}', dt):
            raise ErroValidacao(f'Transação {n} do OFX sem data válida.')
        try:
            quando = date(int(dt[:4]), int(dt[4:6]), int(dt[6:8]))
        except ValueError:
            raise ErroValidacao(f'Transação {n} do OFX com data inexistente ({dt}).')
        bruto = _campo(b, 'TRNAMT').replace(' ', '')
        if ',' in bruto and '.' in bruto:
            bruto = bruto.replace('.', '').replace(',', '.')
        else:
            bruto = bruto.replace(',', '.')
        try:
            valor = Decimal(bruto)
            if not valor.is_finite():
                raise InvalidOperation
            cent = int((valor * 100).to_integral_value())
        except InvalidOperation:
            raise ErroValidacao(f'Transação {n} do OFX com valor inválido ("{_campo(b, "TRNAMT")}").')
        if cent == 0:
            avisos.append(f'Transação {n} com valor zero foi ignorada.')
            continue
        memo, nome = _campo(b, 'MEMO'), _campo(b, 'NAME')
        descricao = (memo if len(memo) >= len(nome) else nome) or 'Movimentação sem descrição'
        fitid = _campo(b, 'FITID') or None
        if fitid:
            if fitid in vistos:
                avisos.append(f'Identificador {fitid} repete nas transações {vistos[fitid]} e {n}; '
                              'a repetida será conferida por data e valor.')
                fitid = None
            else:
                vistos[fitid] = n
        linhas.append({'data': quando, 'valor': cent, 'descricao': re.sub(r'\s+', ' ', descricao)[:200], 'id_externo': fitid})
    if not linhas:
        raise ErroValidacao('Nenhuma transação encontrada no OFX.')
    return {'formato': 'ofx', 'conta_externa': conta_externa, 'cartao': cartao, 'linhas': linhas, 'avisos': avisos}
