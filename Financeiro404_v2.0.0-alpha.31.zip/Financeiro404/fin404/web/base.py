"""Utilidades comuns às páginas: redirecionar, ler parâmetros e montar listas para formulários."""
from datetime import date

from fin404.dinheiro import ErroValidacao, mes as ler_mes
from fin404.dominio import razao
from fin404.web.componentes import com_msg
from fin404.web.servidor import Redirecionar

ROTULO_TIPO = razao.TIPOS_TRANSACAO
COR_STATUS = {'agendada': ('em aberto', 'amarelo'), 'confirmada': ('feito', ''), 'conciliada': ('conferido com o banco', 'verde')}


def ir(caminho, msg=''):
    raise Redirecionar(com_msg(caminho, msg) if msg else caminho)


def hoje():
    return date.today()


def mes_atual():
    return hoje().strftime('%Y-%m')


def mes_param(req, nome='mes', padrao=None):
    """Mês pedido na página; sem pedido, o último escolhido em outra página (fica guardado até fechar o navegador)."""
    v = req.q(nome)
    if v:
        v = ler_mes(v)
        req.mes_novo = v
        return v
    return req.mes_guardado() or padrao or mes_atual()


def inteiro(texto, nome='número'):
    try:
        return int(str(texto).strip())
    except (TypeError, ValueError):
        raise ErroValidacao(f'Informe um {nome} válido.')


def opcional_int(texto):
    texto = (texto or '').strip()
    return int(texto) if texto.isdigit() else None


# ------------------------------------------------------------------ listas para formulários

def grupos_contas(c, disponiveis=True, cartoes_=True, investimentos=False, dividas=False):
    grupos = []
    if disponiveis:
        grupos.append(('Contas e dinheiro', [(k['id'], k['nome']) for k in razao.contas(c, subtipos=razao.DISPONIVEIS)]))
    if cartoes_:
        grupos.append(('Cartões de crédito', [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('cartao',))]))
    if investimentos:
        grupos.append(('Investimentos e bens', [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('investimento', 'bem'))]))
    if dividas:
        grupos.append(('Empréstimos e dívidas', [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('emprestimo', 'outro_passivo'))]))
    return grupos


def categorias(c, tipo):
    return [(k['id'], k['nome']) for k in razao.contas(c, tipo=tipo) if k['subtipo'] == 'categoria']


def pessoas(c):
    return [(p['id'], p['nome']) for p in c.execute('SELECT * FROM pessoas ORDER BY nome')]


def tem_contas(c):
    return c.execute("SELECT 1 FROM contas WHERE tipo IN ('ativo','passivo') AND ativa=1").fetchone() is not None
