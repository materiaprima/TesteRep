"""Páginas de análise e planejamento: simulador de dívidas, cobranças fixas, metas e apoio ao IRPF."""
import json
from datetime import date

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao, centavos, formatar, percentual
from fin404.dominio import analises, cartoes, metas, razao, simulador
from fin404.web.componentes import botao_excluir, aviso, barra, campo_valor, data_br, dinheiro, e, mes_br, opcoes, selo, tabela
from fin404.web.base import hoje, inteiro, ir, opcional_int
from fin404.web.servidor import rota, token_html as tk


# ------------------------------------------------------------------ simulador

def _padroes_simulador(c):
    """Valores iniciais a partir da última fatura importada (taxas, mínimo e saldo a pagar)."""
    p = {'divida': None, 'pagamento': None, 'rotativo': '', 'parcelado': '', 'origem': None, 'minimo': None,
         'encargos_se_minimo': None}
    lote = c.execute('''SELECT lo.*, k.nome cartao FROM lotes_importacao lo JOIN contas k ON k.id=lo.conta_id
                        WHERE lo.desfeito_em IS NULL AND lo.fatura_info IS NOT NULL AND lo.fatura_fechamento IS NOT NULL
                        ORDER BY lo.fatura_fechamento DESC, lo.id DESC LIMIT 1''').fetchone()
    if not lote:
        return p
    try:
        info = json.loads(lote['fatura_info'] or '{}')
    except ValueError:
        info = {}
    p['rotativo'] = ((info.get('rotativo_proxima') or {}).get('cet_am') or '')
    p['parcelado'] = ((info.get('parcelado_proxima') or {}).get('cet_am') or '')
    p['minimo'] = info.get('minimo')
    p['encargos_se_minimo'] = info.get('encargos_se_minimo')
    p['pagamento'] = info.get('minimo')
    try:
        fat = cartoes.fatura(c, lote['conta_id'], lote['fatura_fechamento'])
        p['divida'] = fat['restante'] if fat['restante'] > 0 else None
    except ErroValidacao:
        pass
    if p['divida'] is None and lote['fatura_total']:
        p['divida'] = lote['fatura_total']
    p['origem'] = f'fatura de {lote["cartao"]} que fechou em {date.fromisoformat(lote["fatura_fechamento"]).strftime("%d/%m/%Y")}'
    return p


@rota('GET', '/simulador')
def simulador_pagina(req):
    with banco.conexao() as c:
        p = _padroes_simulador(c)
    calcular = req.q('calcular') == '1'  # campos vazios não chegam na consulta: o marcador diz que o formulário foi enviado
    v = {
        'divida': req.q('divida') if calcular else campo_valor(p['divida']),
        'pagamento': req.q('pagamento') if calcular else campo_valor(p['pagamento']),
        'rotativo': req.q('rotativo') if calcular else p['rotativo'].replace('.', ','),
        'parcelado': req.q('parcelado') if calcular else p['parcelado'].replace('.', ','),
        'parcelas': req.q('parcelas') or '12',
        'emprestimo': req.q('emprestimo') if calcular else '',
        'parcelas_emprestimo': req.q('parcelas_emprestimo') or '12',
    }
    resultado = ''
    if calcular:
        try:
            divida = centavos(v['divida'])
            pagamento = centavos(v['pagamento']) if (v['pagamento'] or '').strip() else 0
            n = inteiro(v['parcelas'], 'número de parcelas')
            if not 2 <= n <= 48:
                raise ErroValidacao('Parcelas da fatura: de 2 a 48.')
            emp = percentual(v['emprestimo']) if (v['emprestimo'] or '').strip() else None
            ne = inteiro(v['parcelas_emprestimo'], 'número de parcelas do empréstimo') if emp is not None else None
            if ne is not None and not 1 <= ne <= 120:
                raise ErroValidacao('Parcelas do empréstimo: de 1 a 120.')
            ops = simulador.comparar(divida, pagamento, percentual(v['rotativo']), percentual(v['parcelado']), n, emp, ne)
            validas = [o for o in ops[1:] if o['juros'] is not None]
            melhor = min(validas, key=lambda o: o['juros']) if validas else None
            linhas = [[('<b>' + e(o['nome']) + '</b>') if o is melhor else e(o['nome']), dinheiro(o['parcela']),
                       e(o['meses']) if o['meses'] else '—', dinheiro(o['total']), dinheiro(o['juros']), f'<span class="fraco">{e(o["nota"])}</span>']
                      for o in ops]
            dica = (f'<p>Entre as opções com juros, a mais barata é <b>{e(melhor["nome"])}</b>: {e(formatar(melhor["juros"]))} de juros no total.</p>'
                    if melhor else '')
            resultado = f'''<section class="painel"><h2>Comparação</h2>{tabela(['Opção', 'Por mês', 'Meses', 'Total pago', 'Juros', 'Observação'], linhas, (1, 2, 3, 4), ocultar_movel=(2, 5))}
{dica}<p class="fraco">Taxas mensais compostas. Anual equivalente: rotativo {simulador.anual(percentual(v['rotativo'])):.0f}% a.a.,
parcelamento {simulador.anual(percentual(v['parcelado'])):.0f}% a.a.{f", empréstimo {simulador.anual(emp):.0f}% a.a." if emp is not None else ""}</p></section>'''
        except ErroValidacao as exc:
            resultado = aviso(str(exc), 'erro')
    origem = (f'<p class="fraco">Valores iniciais tirados da {e(p["origem"])}. Ajuste à vontade.</p>' if p['origem'] else
              '<p class="fraco">Importe uma fatura em PDF para preencher as taxas automaticamente.</p>')
    minimo = ''
    if p['minimo'] and p['encargos_se_minimo']:
        minimo = aviso(f'Na última fatura, pagar só o mínimo ({formatar(p["minimo"])}) geraria cerca de '
                       f'{formatar(p["encargos_se_minimo"])} de encargos no mês seguinte, segundo o próprio banco.', 'info')
    corpo = f'''{minimo}<section class="painel"><form method="get" action="/simulador" class="campos"><input type="hidden" name="calcular" value="1">
<label>Dívida a quitar<input name="divida" value="{e(v['divida'])}" inputmode="decimal" required></label>
<label>Quanto conseguem pagar por mês<input name="pagamento" value="{e(v['pagamento'])}" inputmode="decimal" placeholder="para o rotativo"></label>
<label>Rotativo (CET % a.m.)<input name="rotativo" value="{e(v['rotativo'])}" inputmode="decimal" required></label>
<label>Parcelamento da fatura (CET % a.m.)<input name="parcelado" value="{e(v['parcelado'])}" inputmode="decimal" required></label>
<label>Parcelas da fatura<input type="number" name="parcelas" min="2" max="48" value="{e(v['parcelas'])}"></label>
<label>Empréstimo: taxa % a.m. (opcional)<input name="emprestimo" value="{e(v['emprestimo'])}" inputmode="decimal" placeholder="ex.: 3,5"></label>
<label>Empréstimo: parcelas<input type="number" name="parcelas_emprestimo" min="1" max="120" value="{e(v['parcelas_emprestimo'])}"></label>
<button>Comparar</button></form>{origem}</section>{resultado}
<section class="painel"><h2>Como ler</h2><ul class="fraco">
<li>Use o <b>CET</b> (custo efetivo total), que inclui IOF e encargos: ele está na fatura e no app do banco.</li>
<li>Desde 03/01/2024 (Lei 14.690/2023), juros e encargos do rotativo e do parcelamento da fatura, somados, não podem passar
de 100% do valor original da dívida. O IOF fica fora desse teto. O simulador já aplica o teto.</li>
<li><b>O teto não torna o rotativo barato:</b> a dívida ainda pode chegar ao dobro do valor original. E o teto é um só para a mesma
dívida: passar do rotativo para o parcelamento não abre um teto novo.</li>
<li>As opções de parcelamento aqui são <b>hipóteses para comparar</b>, não uma oferta do banco: a proposta real (prazo, taxa e CET)
aparece no app ou na central do banco.</li>
<li>Na prática, o banco só deixa a dívida no rotativo até o vencimento seguinte; depois disso oferece o parcelamento.
A linha do rotativo serve para mostrar quanto custa “ir pagando o que der”.</li>
<li>Empréstimo pessoal ou consignado com taxa menor pode quitar a fatura mais barato, mas não tem o teto legal do cartão:
confira o CET da proposta antes de aceitar.</li>
<li>É uma estimativa: o banco arredonda e calcula IOF diário, então os centavos podem diferir.</li></ul></section>'''
    return req.html('Simulador de dívidas', corpo, 'Compare pagar agora, rotativo, parcelar a fatura e um empréstimo.')


# ------------------------------------------------------------------ cobranças fixas

@rota('GET', '/recorrentes')
def recorrentes_pagina(req):
    with banco.conexao() as c:
        itens = analises.recorrentes(c, hoje())
    linhas = [[f'<a href="/lancamentos/{x["transacao_id"]}">{e(x["descricao"])}</a>', e(x['categoria']), f'{x["meses"]} de 6',
               data_br(x['ultima_data']), dinheiro(x['ultimo']),
               (selo(f'+{formatar(x["aumento"])}', 'amarelo') if x['aumento'] else ''), dinheiro(x['por_ano'])] for x in itens]
    total = sum(x['ultimo'] for x in itens)
    corpo = f'''<div class="cartoes"><div class="cartao"><small>Cobranças fixas encontradas</small><strong>{len(itens)}</strong></div>
<div class="cartao"><small>Somando por mês</small><strong>{dinheiro(total)}</strong><em>{e(formatar(total * 12))} por ano</em></div></div>
<section class="painel">{tabela(['Descrição', 'Categoria', 'Meses', 'Última', 'Valor', 'Aumento', 'Por ano'], linhas, (4, 6), ocultar_movel=(1, 2, 3, 6), vazio=
        'Nada recorrente ainda. Aparece quando a mesma cobrança surge em 3 meses diferentes.')}</section>
<p class="fraco">Olha os últimos 6 meses e junta lançamentos com a mesma descrição (sem números) que aparecem em pelo menos 3 meses,
no máximo duas vezes por mês. Parcelas não entram. Bom lugar para achar assinatura esquecida.</p>'''
    return req.html('Cobranças fixas', corpo, 'Assinaturas e contas que se repetem todo mês.')


# ------------------------------------------------------------------ metas

def _contas_meta(c):
    return [(k['id'], k['nome']) for k in razao.contas(c) if k['tipo'] == 'ativo' and k['subtipo'] not in ('bem',)]


@rota('GET', '/metas')
def metas_pagina(req):
    with banco.conexao() as c:
        lista = metas.listar(c, hoje(), todas=True)
        contas = _contas_meta(c)
    blocos = []
    for m in lista:
        if m['concluida']:
            situ = selo('concluída', 'verde')
        elif m['atrasada']:
            situ = selo('prazo passou', 'vermelho')
        elif m['por_mes']:
            situ = f'guardar {dinheiro(m["por_mes"])} por mês até {mes_br(m["prazo"])}'
        else:
            situ = '<span class="fraco">sem prazo</span>'
        editar = f'''<details><summary>Editar</summary><form method="post" action="/metas/{m['id']}" class="campos">{tk()}
<label>Nome<input name="nome" value="{e(m['nome'])}" maxlength="80" required></label>
<label>Valor da meta<input name="alvo" value="{campo_valor(m['alvo_centavos'])}" inputmode="decimal" required></label>
<label>Acompanhar a conta<select name="conta">{opcoes(contas, m['conta_id'], 'Nenhuma: informo à mão')}</select></label>
<label>Guardado (se não acompanhar conta)<input name="guardado" value="{campo_valor(m['guardado_centavos'])}" inputmode="decimal"></label>
<label>Prazo<input type="month" name="prazo" value="{e(m['prazo'] or '')}"></label><button>Salvar</button></form>
{f'<form method="post" action="/metas/{m["id"]}/encerrar">{tk()}<button class="secundario">Arquivar meta</button></form>' if m['ativa'] else ''}
{botao_excluir(f'/metas/{m["id"]}/excluir', 'A meta será apagada. O dinheiro e as contas não mudam; só some o acompanhamento.', 'Excluir meta')}</details>'''
        origem = f'saldo de {e(m["conta"])}' if m['conta_id'] else 'valor informado'
        blocos.append(f'''<section class="painel meta{'' if m['ativa'] else ' arquivada'}"><h2>{e(m['nome'])}{'' if m['ativa'] else ' ' + selo('arquivada')}</h2>
<p><b>{dinheiro(m['atual'])}</b> de {dinheiro(m['alvo_centavos'])} ({m['pct']}%) · <span class="fraco">{origem}</span></p>{barra(m['atual'], m['alvo_centavos'])}
<p>Falta {dinheiro(m['falta'])} · {situ}</p>{editar}</section>''')
    corpo = f'''{''.join(blocos) or '<div class="vazio">Nenhuma meta ainda. Uma boa primeira: reserva de emergência (3 a 6 meses de despesas).</div>'}
<section class="painel"><h2>Nova meta</h2><form method="post" action="/metas" class="campos">{tk()}
<label>Nome<input name="nome" maxlength="80" required placeholder="Reserva de emergência, viagem, quitar o cartão…"></label>
<label>Valor da meta<input name="alvo" inputmode="decimal" required></label>
<label>Acompanhar a conta<select name="conta">{opcoes(contas, None, 'Nenhuma: informo à mão')}</select></label>
<label>Já guardado (se não acompanhar conta)<input name="guardado" inputmode="decimal" placeholder="0,00"></label>
<label>Prazo<input type="month" name="prazo"></label><button>Criar meta</button></form>
<p class="fraco">Se a meta acompanha uma conta (por exemplo, a poupança da reserva), o progresso é o saldo dela. Sem conta,
atualize o valor guardado quando quiser.</p></section>'''
    return req.html('Metas', corpo, 'Quanto falta e quanto guardar por mês para chegar lá.')


def _dados_meta(req):
    guardado = centavos(req.f('guardado'), permitir_zero=True) if (req.f('guardado') or '').strip() else 0
    return req.f('nome'), centavos(req.f('alvo')), opcional_int(req.f('conta')), guardado, (req.f('prazo') or '').strip() or None


@rota('POST', '/metas')
def metas_criar(req):
    nome, alvo, conta, guardado, prazo = _dados_meta(req)
    with banco.transacao() as c:
        metas.criar(c, nome, alvo, conta, guardado, prazo)
    ir('/metas', 'Meta criada.')


@rota('POST', r'/metas/(\d+)')
def metas_editar(req):
    nome, alvo, conta, guardado, prazo = _dados_meta(req)
    with banco.transacao() as c:
        metas.atualizar(c, int(req.parametros[0]), nome, alvo, conta, guardado, prazo)
    ir('/metas', 'Meta atualizada.')


@rota('POST', r'/metas/(\d+)/encerrar')
def metas_encerrar(req):
    with banco.transacao() as c:
        metas.encerrar(c, int(req.parametros[0]))
    ir('/metas', 'Meta arquivada.')


# ------------------------------------------------------------------ IRPF

@rota('GET', '/relatorios/irpf')
def irpf_pagina(req):
    ano = inteiro(req.q('ano') or str(hoje().year - 1), 'ano')
    with banco.conexao() as c:
        r = analises.irpf(c, ano)
    rotulos = {
        analises.SAUDE: ('Saúde', 'Potencialmente dedutível', 'verde',
                         'Consultas, exames, dentista, psicólogo, hospital e plano de saúde costumam ser dedutíveis, sem limite, com recibo ou nota '
                         'que tenha o CPF/CNPJ de quem prestou o serviço. Confira cada um.'),
        analises.EDUCACAO: ('Educação', 'Potencialmente dedutível, com limite', 'amarelo',
                            'Só ensino regular (escola, faculdade, pós, técnico), com limite anual por pessoa. Cursos livres e idiomas não entram.'),
        analises.FARMACIA: ('Farmácia e remédios', 'Em regra, não dedutível', 'vermelho',
                            'Remédio comprado em farmácia não é dedutível, mesmo com receita (só entra se fizer parte da conta do hospital). '
                            'Não some na declaração sem orientação específica.'),
    }
    secoes = []
    for nome, itens in r['despesas'].items():
        titulo, situ, cor, nota = rotulos[nome]
        linhas = [[data_br(x['data']), f'<a href="/lancamentos/{x["id"]}">{e(x["descricao"])}</a>'
                   + (' ' + selo('parece farmácia', 'amarelo') if x.get('parece_farmacia') else ''),
                   e(x['pessoa'] or ''), dinheiro(x['v'])] for x in itens]
        secoes.append(f'<section class="painel"><h2>{e(titulo)} · {dinheiro(sum(x["v"] for x in itens))} {selo(situ, cor)}</h2>'
                      f'<p class="fraco">{e(nota)}</p>{tabela(["Data", "Descrição", "Pessoa", "Valor"], linhas, (3,), "Nada nesta categoria no ano.")}</section>')
    if any(x.get('parece_farmacia') for x in r['despesas'][analises.SAUDE]):
        secoes.insert(0, aviso('Há lançamentos em "Saúde" que parecem compras de farmácia. Mude a categoria deles para "Farmácia e remédios" '
                               'para não somá-los nas deduções.', 'atencao'))
    bens = [[e(k['nome']), e(k['subtipo']), dinheiro(k['saldo_anterior']), dinheiro(k['saldo_natural'])] for k in r['bens']]
    dividas = [[e(k['nome']), e(k['subtipo']), dinheiro(k['saldo_anterior']), dinheiro(k['saldo_natural'])] for k in r['dividas']]
    receitas = [[e(n), dinheiro(v)] for n, v in r['receitas']]
    corpo = f'''<div class="abas"><a href="/relatorios/irpf?ano={ano - 1}">← {ano - 1}</a><a class="atual" href="#">{ano}</a><a href="/relatorios/irpf?ano={ano + 1}">{ano + 1} →</a></div>
{aviso('Material de apoio para organizar documentos. Não substitui o informe de rendimentos, os recibos nem um contador.', 'info')}
<div class="grade"><section class="painel"><h2>Bens e contas em 31/12</h2>{tabela(['Conta', 'Tipo', f'31/12/{ano - 1}', f'31/12/{ano}'], bens, (2, 3), 'Sem saldos.')}</section>
<section class="painel"><h2>Dívidas em 31/12</h2>{tabela(['Dívida', 'Tipo', f'31/12/{ano - 1}', f'31/12/{ano}'], dividas, (2, 3), 'Sem dívidas.')}</section></div>
<section class="painel"><h2>Receitas registradas no ano</h2>{tabela(['Categoria', 'Valor'], receitas, (1,), 'Nenhuma receita registrada.')}</section>
{''.join(secoes)}
<section class="painel"><h2>Atenção</h2><ul class="fraco">
<li>O que vale para a declaração são os informes do banco e do empregador; aqui é para conferir e não esquecer nada.</li></ul></section>'''
    return req.html(f'Apoio ao Imposto de Renda · ano-base {ano}', corpo, 'Saúde, educação, bens e dívidas do ano em um lugar só.')


# ------------------------------------------------------------------ raio-x

def meses_txt(decimos):
    if decimos is None:
        return '—'
    return f'{decimos // 10},{decimos % 10} meses'


@rota('GET', '/raio-x')
def raio_x_pagina(req):
    q = req.q('queda') or '20'
    queda = int(q) if q.isdigit() and 0 <= int(q) <= 100 else 20
    with banco.conexao() as c:
        r = analises.raio_x(c, hoje(), queda_pct=queda)
        folga = analises.folga_dias(c, hoje())
    cartao_folga = ''
    if folga:
        cls = 'neg' if folga['dias'] < 30 else 'pos' if folga['dias'] >= 60 else ''
        cartao_folga = (f'<div class="cartao"><small>Folga</small><strong class="{cls}">{folga["dias"]} dias</strong>'
                        f'<em>o dinheiro das contas, já tirando a dívida dos cartões, cobre {folga["dias"]} dias de gasto ({e(formatar(folga["gasto_dia"]))}/dia). Meta: 30+</em></div>')
    periodo = f'{mes_br(r["janela"][0])} a {mes_br(r["janela"][-1])}'
    avisos = ''
    if r['meses_com_dados'] < len(r['janela']):
        avisos += aviso(f'Só {r["meses_com_dados"]} dos últimos {len(r["janela"])} meses têm gastos lançados: as médias ficam baixas até '
                        'completar 3 meses de uso.', 'atencao')
    if r['sem_classificacao']:
        avisos += aviso('Categorias sem classificação contam como essenciais (por segurança): ' +
                        ', '.join(x['nome'] for x in r['sem_classificacao'][:6]) + '. Classifique em Categorias.', 'info')
    total = r['custo_total'] or 1
    nomes = {'essencial': 'Essencial', 'comprometido': 'Comprometido (dívidas e juros)', 'discricionario': 'Dá para cortar',
             None: 'Sem classificação'}
    linhas = [[e(nomes[n]), dinheiro(v), f'{v * 100 // total}%', barra(v, total)] for n, v in r['media'].items() if v]
    if r['provisao_mes']:
        linhas.append(['Despesas anuais (1/12 por mês)', dinheiro(r['provisao_mes']), f'{r["provisao_mes"] * 100 // total}%',
                       barra(r['provisao_mes'], total)])
    cobre = r['cobertura_minimo']
    cor = 'neg' if cobre is not None and cobre < 30 else 'pos' if cobre is not None and cobre >= 60 else ''

    def cen(x):
        if x['deficit'] == 0:
            return [dinheiro(x['custo']), f'<span class="pos">sobra {e(formatar(x["sobra"]))}</span>', 'sustentável']
        return [dinheiro(x['custo']), f'<span class="neg">falta {e(formatar(x["deficit"]))}</span>', meses_txt(x['meses'])]
    quedas = ''.join(f'<option value="{v}"{" selected" if v == queda else ""}>{v}%</option>' for v in (10, 20, 30, 50, 100))
    cortes = [[f'<a href="/lancamentos?categoria={x["id"]}">{e(x["nome"])}</a>', dinheiro(x['media'])] for x in r['cortes']]
    imediata = ''
    if r['posicao']['investimentos'] and r['cobertura_imediata'] is not None:
        imediata = f' · sem investimentos: {meses_txt(r["cobertura_imediata"])}'
    corpo = f'''{avisos}<div class="cartoes">
<div class="cartao"><small>Renda média</small><strong>{dinheiro(r['renda'])}</strong><em>por mês, {e(periodo)}</em></div>
<div class="cartao"><small>Gasto médio</small><strong>{dinheiro(r['custo_total'])}</strong><em>por mês, com as despesas anuais</em></div>
<div class="cartao"><small>Custo de vida mínimo</small><strong>{dinheiro(r['custo_minimo'])}</strong><em>essencial + dívidas</em></div>
<div class="cartao"><small>Reserva cobre</small><strong class="{cor}">{meses_txt(cobre)}</strong><em>do custo mínimo · reserva {e(formatar(r['reserva']))}{imediata}</em></div>
{cartao_folga}</div>
<div class="grade"><section class="painel"><h2>Para onde vai, em média</h2>{tabela(['Tipo de gasto', 'Por mês', '%', ''], linhas, (1, 2), 'Sem gastos no período.', ocultar_movel=(3,))}
<p>Sobra média por mês: <b>{dinheiro(r['sobra'], cor=True)}</b></p></section>
<section class="painel"><h2>Onde cortar primeiro</h2>{tabela(['Categoria', 'Média/mês'], cortes, (1,), 'Nenhum gasto classificado como "dá para cortar".')}</section></div>
<section class="painel"><h2>E se a renda cair?</h2><form method="get" action="/raio-x" class="acoes"><label>Queda da renda<select name="queda">{quedas}</select></label><button class="secundario">Ver</button></form>
<p>Renda passaria de {dinheiro(r['renda'])} para <b>{dinheiro(r['nova_renda'])}</b> por mês.</p>
{tabela(['Cenário', 'Gasto por mês', 'Resultado', 'A reserva dura'], [['Mantendo os gastos', *cen(r['mantendo'])], ['Cortando o que dá para cortar', *cen(r['cortando'])]], (1,))}
</section>
<p class="fraco">Médias dos meses completos de {e(periodo)}. Reserva = dinheiro disponível + investimentos − o que vocês devem hoje nos cartões
(bens como carro e imóvel não entram). Investimento pode demorar para resgatar ou ter carência; por isso aparece também quanto
o dinheiro das contas cobre sozinho. Empréstimos e financiamentos não são descontados: eles já entram no custo mensal como parcela. Despesas anuais cadastradas em Previsões entram como 1/12 por mês e saem da média, para não contar duas vezes.
A classificação das categorias é feita em <a href="/categorias">Categorias</a>.</p>'''
    return req.html('Raio-X da família', corpo, 'Quanto custa a vida de vocês, quanto tempo a reserva aguenta e onde dá para cortar.')


@rota('POST', r'/metas/(\d+)/excluir')
def metas_excluir(req):
    with banco.transacao() as c:
        nome = metas.excluir(c, int(req.parametros[0]))
    ir('/metas', f'Meta "{nome}" excluída.')


# ------------------------------------------------------------------ evolução

@rota('GET', '/evolucao')
def evolucao_pagina(req):
    from fin404.web.componentes import grafico_linhas, mes_curto
    with banco.conexao() as c:
        ev = analises.evolucao(c, hoje())
        tem_dados = c.execute("SELECT COUNT(DISTINCT substr(data,1,7)) FROM transacoes WHERE status<>'agendada'").fetchone()[0]
    rot = [mes_curto(m) for m in ev['meses']]
    aviso_poucos = aviso('Ainda há poucos meses lançados: os gráficos ganham forma com o uso. O mês atual vai até hoje.', 'info') \
        if tem_dados < 3 else '<p class="fraco">Cada ponto é o fim do mês; o mês atual vai até hoje. Passe o mouse num ponto para ver o valor.</p>'
    delta = ev['patrimonio'][-1] - ev['patrimonio'][0]
    corpo = f'''{aviso_poucos}
<section class="painel"><h2>Patrimônio líquido</h2>
<p>{"Cresceu" if delta >= 0 else "Caiu"} {dinheiro(abs(delta))} em 12 meses: tudo o que vocês têm menos tudo o que devem.</p>
{grafico_linhas(rot, [('Patrimônio líquido', ev['patrimonio'])])}</section>
<section class="painel"><h2>Dinheiro disponível × dívida dos cartões</h2>
<p class="fraco">Quando a linha da dívida fica acima da do dinheiro, o cartão está financiando o mês.</p>
{grafico_linhas(rot, [('Disponível', ev['disponivel']), ('Dívida nos cartões', ev['cartoes'])])}</section>
<section class="painel"><h2>Entrou × saiu</h2>
{grafico_linhas(rot, [('Entradas', ev['entradas']), ('Saídas', ev['saidas'])])}</section>
<section class="painel"><h2>Onde mais se gastou</h2>
<p class="fraco">As {len(ev['categorias'])} categorias com mais gasto nos 12 meses, mês a mês.</p>
{grafico_linhas(rot, ev['categorias']) if ev['categorias'] else '<div class="vazio">Sem despesas no período.</div>'}</section>'''
    return req.html('Evolução', corpo, 'Como o dinheiro de vocês se moveu nos últimos 12 meses.')


# ------------------------------------------------------------------ resumo do mês (para mostrar ou imprimir)

@rota('GET', '/resumo')
def resumo_pagina(req):
    from fin404.dominio import relatorios
    from fin404.dinheiro import somar_meses
    from fin404.web.base import mes_param
    ym = mes_param(req)
    anterior = somar_meses(date.fromisoformat(ym + '-01'), -1).strftime('%Y-%m')
    with banco.conexao() as c:
        m = relatorios.resumo_mes(c, ym)
        ma = relatorios.resumo_mes(c, anterior)
        p = relatorios.posicao(c, hoje())
        rx = analises.raio_x(c, hoje())
        alertas, _ = relatorios.alertas_visiveis(c)
        faturas = []
        for k in cartoes.lista(c):
            if k['dia_fechamento']:
                atual = cartoes.fechamento_da_compra(k, hoje())
                fat = cartoes.fatura(c, k['id'], cartoes.fechamento_anterior(k, atual))
                if fat['restante'] > 0:
                    faturas.append(fat)
        from fin404.dominio import compras
        plano = compras.plano(c, hoje())
    proximas = sorted((it for it in plano['itens'] if it['mes_alvo'] and it['valor_centavos']), key=lambda it: (it['mes_alvo'], it['id']))[:5]
    compras_txt = ''
    if proximas:
        compras_txt = ('<section class="painel"><h2>Próximas compras planejadas</h2><ul>'
                       + ''.join(f'<li>{e(it["descricao"])}: {dinheiro(it["valor_centavos"])} em {mes_br(it["mes_alvo"])}'
                                 f' ({e(compras.PRIORIDADES.get(it["prioridade"], ""))}'
                                 + ('' if it['cabe'] is None else ', cabe' if it['cabe'] else ', não cabe na sobra') + ')</li>'
                                 for it in proximas)
                       + f'</ul><p>Separar este mês para as compras: <b>{dinheiro(plano["este_mes"])}</b></p></section>')
    sobra = m['resultado']
    dif = m['total_despesas'] - ma['total_despesas']
    comp = (f'Gastaram {formatar(abs(dif))} {"a mais" if dif > 0 else "a menos"} que em {mes_br(anterior)}.' if ma['total_despesas'] and dif else '')
    seguinte = somar_meses(date.fromisoformat(ym + '-01'), 1).strftime('%Y-%m')
    link_seguinte = f'<a href="/resumo?mes={seguinte}">{mes_br(seguinte)} →</a>' if seguinte <= hoje().strftime('%Y-%m') else ''
    tot = m['total_despesas'] or 1
    top = [[e(n), dinheiro(v), f'{v * 100 // tot}%', barra(v, tot)] for _, n, v in m['despesas'][:6]]
    fat_txt = ''.join(f'<li>Fatura {e(f["cartao"]["nome"])}: {dinheiro(f["restante"])} a pagar, vence {data_br(f["vencimento"])}</li>'
                      for f in faturas)
    cob = rx['cobertura_minimo']
    frase = ('Sobrou dinheiro no mês.' if sobra > 0 else 'Saiu mais do que entrou.' if sobra < 0 else 'Entrou e saiu o mesmo.')
    corpo = f'''<div class="resumo-impressao"><div class="abas"><a href="/resumo?mes={anterior}">← {mes_br(anterior)}</a><a class="atual" href="#">{mes_br(ym)}</a>{link_seguinte}</div>
<p><b>{frase}</b> {e(comp)}</p>
<div class="cartoes"><div class="cartao"><small>Entrou</small><strong>{dinheiro(m['total_receitas'])}</strong></div>
<div class="cartao"><small>Saiu</small><strong>{dinheiro(m['total_despesas'])}</strong></div>
<div class="cartao"><small>{"Sobrou" if sobra >= 0 else "Faltou"}</small><strong>{dinheiro(sobra, cor=True)}</strong></div>
<div class="cartao"><small>Juros e tarifas</small><strong>{dinheiro(m['custo_credito'])}</strong></div></div>
<section class="painel"><h2>Para onde foi</h2>{tabela(['Categoria', 'Valor', '%', ''], top, (1, 2), 'Nenhuma despesa no mês.', ocultar_movel=(3,))}</section>
<section class="painel"><h2>Situação hoje</h2><ul>
<li>Dinheiro disponível: <b>{dinheiro(p['disponivel'])}</b></li>
<li>Dívida nos cartões: <b>{dinheiro(p['cartoes'])}</b>, mais {dinheiro(p['parcelas_futuras'])} em parcelas a vencer</li>
{f"<li>Reserva cobre <b>{cob // 10},{cob % 10} meses</b> do custo de vida mínimo</li>" if cob is not None else ""}
{fat_txt}</ul></section>
{compras_txt}
{f'<section class="painel"><h2>Atenção</h2><ul>' + "".join(f"<li>{e(t)}</li>" for _, t, _, _ in alertas[:4]) + '</ul></section>' if alertas else ''}
<p class="fraco">Para imprimir ou salvar em PDF: Ctrl+P no navegador (o menu não sai na impressão). Gerado em {data_br(hoje())}.</p></div>'''
    return req.html(f'Resumo de {mes_br(ym)}', corpo, 'Uma página para mostrar como foi o mês.')
