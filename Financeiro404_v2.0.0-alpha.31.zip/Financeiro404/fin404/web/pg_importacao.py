"""Importação de faturas e extratos: envio, revisão e desfazer."""
import datetime

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao, data as ler_data
from fin404.dominio import cartoes, razao
from fin404.importacao import pipeline
from fin404.web.base import (categorias, grupos_contas, inteiro, ir)
from fin404.web.componentes import aviso, campo_valor, data_br, dinheiro, e, opcoes_agrupadas, selo, tabela
from fin404.web.servidor import rota, token_html as tk


# ------------------------------------------------------------------ importação

@rota('GET', '/importar')
def importar(req):
    with banco.conexao() as c:
        grupos = grupos_contas(c, investimentos=True, dividas=True)
    tem_conta = any(itens for _, itens in grupos)
    novo = '<option value="novo_cartao">+ Cartão novo (criar a partir da fatura PDF)</option>'
    seletor = opcoes_agrupadas(grupos, None, 'Escolha…').replace('</option>', '</option>' + novo, 1)
    dica = '' if tem_conta else ('<div class="aviso info">Nenhuma conta ou cartão cadastrado ainda. Para a fatura do Ourocard em PDF, escolha '
                                 '<b>"Cartão novo"</b>: o cartão é criado com as datas e o limite da própria fatura. Para extrato '
                                 '(OFX ou CSV), cadastre a conta antes em <a href="/contas">Contas e dívidas</a>.</div>')
    corpo = f'''{dica}<section class="painel"><form method="post" action="/importar" enctype="multipart/form-data" class="campos">{tk()}
<label>Conta ou cartão do arquivo<select name="conta" required>{seletor}</select></label>
<label>Arquivo (OFX, QFX, CSV ou fatura PDF)<input type="file" name="arquivo" accept=".ofx,.qfx,.csv,.txt,.pdf" required></label>
<label>Sinal dos valores no CSV<select name="sinal"><option value="auto">Automático (cartão: compras positivas)</option>
<option value="normal">Saídas negativas, entradas positivas</option><option value="invertido">Compras/saídas positivas</option></select></label>
<button>Ler arquivo</button></form></section>
<section class="painel"><h2>Como funciona</h2><ol><li><b>Leitura:</b> o arquivo é lido e conferido. Se alguma linha estiver ilegível, nada é aproveitado e a linha é indicada.</li>
<li><b>Casamento:</b> cada linha é comparada com o que já existe (mesmo valor, data até 3 dias de diferença, mesmo identificador do banco).
O que já foi importado aparece como duplicado; o que você lançou à mão é casado, não duplicado.</li>
<li><b>Revisão:</b> você confirma a categoria ou indica se é transferência ou pagamento de fatura. Só então entra nos relatórios.
Um lote pode ser desfeito inteiro depois.</li></ol>
<p class="fraco">Formatos testados: OFX (SGML e XML, inclusive Windows-1252) e CSV com data DD/MM/AAAA ou AAAA-MM-DD, valores 1.234,56, sufixo D/C,
coluna única de valor ou colunas de crédito e débito. PDF: fatura Ourocard do Banco do Brasil (com conferência do total); outros PDFs ainda não. PDF digitalizado (imagem) não é lido.</p></section>
<div class="acoes"><a href="/importacoes">Ver importações anteriores →</a><a href="/regras">Regras de sugestão →</a></div>'''
    return req.html('Importar extrato ou fatura', corpo)


@rota('POST', '/importar')
def importar_enviar(req):
    if 'arquivo' not in req.arquivos or not req.arquivos['arquivo'][1]:
        raise ErroValidacao('Escolha um arquivo.')
    nome, dados = req.arquivos['arquivo']
    sinal = {'normal': False, 'invertido': True}.get(req.f('sinal'))
    with banco.transacao() as c:
        if req.f('conta') == 'novo_cartao':
            conta = pipeline.criar_cartao_da_fatura(c, nome, dados)
            avisos_extra = [f'Cartão "{razao.conta(c, conta)["nome"]}" criado com as datas e o limite da fatura (dá para renomear em Contas e dívidas).']
        else:
            conta, avisos_extra = inteiro(req.f('conta'), 'conta'), []
        lote, avisos = pipeline.preparar(c, conta, nome, dados, inverter_sinal=sinal)
        avisos = avisos_extra + list(avisos)
    ir(f'/importacoes/{lote}', ' '.join(avisos) if avisos else 'Arquivo lido. Revise as linhas abaixo.')


@rota('GET', '/importacoes')
def importacoes(req):
    with banco.conexao() as c:
        lotes = c.execute('''SELECT lo.*, k.nome conta,
            (SELECT COUNT(*) FROM linhas_importacao WHERE lote_id=lo.id) total,
            (SELECT COUNT(*) FROM linhas_importacao WHERE lote_id=lo.id AND situacao IN ('nova')) pendentes,
            (SELECT COUNT(*) FROM linhas_importacao WHERE lote_id=lo.id AND situacao='duplicada') duplicadas
            FROM lotes_importacao lo JOIN contas k ON k.id=lo.conta_id ORDER BY lo.id DESC LIMIT 200''').fetchall()
    linhas = [[f'<a href="/importacoes/{l["id"]}">{e(l["arquivo"])}</a>', e(l['conta']), data_br(l['criado_em'][:10]), str(l['total']),
               selo('desfeito', '') if l['desfeito_em'] else (selo(f'{l["pendentes"]} pendente(s)', 'amarelo') if l['pendentes'] or l['duplicadas']
                                                                 else selo('concluído', 'verde'))] for l in lotes]
    return req.html('Importações', f'<section class="painel">{tabela(["Arquivo", "Conta", "Importado em", "Linhas", "Situação"], linhas, (3,), "Nenhuma importação ainda.")}</section>'
                    '<p><a href="/importar">Importar novo arquivo →</a></p>')


def _opcoes_linha(conta, linha, cats_d, cats_r, contas_proprias, cand):
    v = linha['valor_centavos']
    itens = [('', '— decidir depois —'), ('ignorar', 'Ignorar esta linha')]
    if cand:
        itens.append((f'casar:{cand["id"]}', f'Já lançado: {cand["descricao"]} ({ler_data(cand["data"]).strftime("%d/%m")})'))
    grupos = [('Ações', itens)]
    if v < 0 or conta['subtipo'] == 'cartao':
        grupos.append(('Despesa (categoria)' if v < 0 else 'Estorno / crédito na categoria', [(f'cat:{i}', n) for i, n in cats_d]))
    if v > 0:
        grupos.append(('Receita (categoria)', [(f'cat:{i}', n) for i, n in cats_r]))
    outros = [k for k in contas_proprias if k['id'] != conta['id']]
    transf, fat = [], []
    for k in outros:
        if v < 0 and k['tipo'] == 'passivo' and conta['tipo'] == 'ativo':
            fat.append((f'fatura:{k["id"]}', f'Pagamento de {k["nome"]}'))
        elif v > 0 and conta['tipo'] == 'passivo' and k['tipo'] == 'ativo':
            fat.append((f'fatura:{k["id"]}', f'Pagamento vindo de {k["nome"]}'))
        elif k['tipo'] == 'ativo' or (k['subtipo'] == 'emprestimo' and v > 0):
            transf.append((f'transf:{k["id"]}', ('Para ' if v < 0 else 'Vindo de ') + k['nome']))
        elif conta['tipo'] == 'passivo' and k['tipo'] == 'passivo' and v < 0 and k['subtipo'] != 'cartao':
            transf.append((f'transf:{k["id"]}', f'Dívida transferida de {k["nome"]}'))
    grupos.append(('Pagamento de fatura ou dívida', fat))
    grupos.append(('Transferência entre contas suas', transf))
    return opcoes_agrupadas(grupos, linha['sugestao'] or '')


@rota('GET', r'/importacoes/(\d+)')
def importacao_revisar(req):
    lote_id = int(req.parametros[0])
    with banco.conexao() as c:
        lote = c.execute('SELECT * FROM lotes_importacao WHERE id=?', (lote_id,)).fetchone()
        if lote is None:
            raise ErroValidacao('Importação não encontrada.')
        conta = razao.conta(c, lote['conta_id'])
        linhas = c.execute('SELECT * FROM linhas_importacao WHERE lote_id=? ORDER BY ordem', (lote_id,)).fetchall()
        cats_d, cats_r = categorias(c, 'despesa'), categorias(c, 'receita')
        proprias = razao.contas(c, tipo='ativo') + razao.contas(c, tipo='passivo')
        cands = {}
        for l in linhas:
            if l['sugestao'].startswith('casar:'):
                tid = int(l['sugestao'][6:])
                t = c.execute('SELECT * FROM transacoes WHERE id=?', (tid,)).fetchone()
                if t:
                    cands[l['id']] = t
        resumo = pipeline.resumo_lote(c, lote_id)
        grupos = [] if req.q('individual') else pipeline.grupos_pendentes(c, lote_id)
        quadro_fatura = ''
        if lote['fatura_fechamento']:
            k = cartoes.completo(c, conta['id'])
            fech = ler_data(lote['fatura_fechamento'])
            inicio, _ = cartoes.ciclo(k, fech)
            vespera = inicio - datetime.timedelta(days=1)
            no_sistema = -razao.saldo(c, conta['id'], vespera)
            venc = k['fech_doc'].get(fech)
            partes = [f'Fatura que fechou em <b>{data_br(fech)}</b>' + (f', vence em <b>{data_br(venc)}</b>' if venc else '') +
                      f'. Total do banco: <b>{dinheiro(lote["fatura_total"])}</b>, conferido com a soma dos lançamentos lidos.']
            projetado = pipeline.projecao_parcelas(c, lote_id)
            if lote['fatura_parcelado_futuro'] is not None or projetado:
                banco_fut = lote['fatura_parcelado_futuro']
                confere = (' Confere com o banco.' if banco_fut == projetado else
                           f' O banco informa {dinheiro(banco_fut)}: confira as linhas de compras parceladas.' if banco_fut is not None else '')
                partes.append(f'Parcelas que ainda vão vir, pelas linhas "PARC": <b>{dinheiro(projetado)}</b>.{confere} '
                              'Ao gravar, elas são lançadas nas próximas faturas, com a mesma categoria.')
            partes.append(f'Saldo da fatura anterior segundo o banco: <b>{dinheiro(lote["fatura_saldo_anterior"])}</b>; no Financeiro 404, '
                          f'a dívida deste cartão em {data_br(vespera)} é {dinheiro(no_sistema)}.')
            botao = ''
            if no_sistema != lote['fatura_saldo_anterior']:
                botao = (f'<form method="post" action="/contas/{conta["id"]}/saldo-inicial" class="acoes">{tk()}'
                         f'<input type="hidden" name="data" value="{vespera.isoformat()}"><input type="hidden" name="valor" value="{campo_valor(lote["fatura_saldo_anterior"])}">'
                         f'<input type="hidden" name="volta" value="/importacoes/{lote_id}">'
                         f'<button class="secundario">Usar {dinheiro(lote["fatura_saldo_anterior"])} como saldo inicial do cartão em {data_br(vespera)}</button></form>'
                         '<p class="fraco">Faça isso se esta é a primeira fatura que você importa deste cartão. Assim a fatura calculada fica igual à do banco.</p>')
            quadro_fatura = f'<section class="painel"><h2>Fatura do cartão</h2><p>{"<br>".join(partes)}</p>{botao}</section>'
    agrupadas = {l['id'] for _, ls in grupos for l in ls}
    pendentes = [l for l in linhas if l['situacao'] in ('nova', 'duplicada') and l['id'] not in agrupadas]
    feitas = [l for l in linhas if l['situacao'] not in ('nova', 'duplicada')]
    cab = (f'<p>{e(conta["nome"])} · arquivo <b>{e(lote["arquivo"])}</b> · {len(linhas)} linha(s): '
           + ', '.join(f'{n} {s}' for s, n in resumo.items()) + '</p>')
    if lote['desfeito_em']:
        return req.html('Importação desfeita', aviso(f'Esta importação foi desfeita em {lote["desfeito_em"][:10]}.', 'info') + cab)
    tabela_pend = ''
    trs_grupos = []
    from collections import Counter
    for n, (chave, ls) in enumerate(grupos):
        modelo = dict(ls[0])
        sugestoes = Counter(l['sugestao'] for l in ls if l['sugestao'])
        modelo['sugestao'] = sugestoes.most_common(1)[0][0] if sugestoes else ''
        total = sum(l['valor_centavos'] for l in ls)
        detalhe = ''.join(f'<li>{data_br(l["data_original"] or l["data"])} · {e(l["descricao"])} · {dinheiro(l["valor_centavos"])}</li>' for l in ls)
        trs_grupos.append(f'''<tr><td>{data_br(min(l['data'] for l in ls))}<br><span class="fraco">a {data_br(max(l['data'] for l in ls))}</span></td>
<td><b>{e(chave.upper())}…</b> {selo(f'{len(ls)} linhas parecidas', 'verde')}<details><summary>ver as linhas</summary><ul>{detalhe}</ul></details></td>
<td class="n">{dinheiro(total, cor=True)}</td><td>{selo('sugestão', 'verde') if modelo['sugestao'] else selo('nova', '')}</td>
<td><input type="hidden" name="grupo_ids_{n}" value="{','.join(str(l['id']) for l in ls)}"><input type="hidden" name="grupo_chave_{n}" value="{e(chave)}">
<select name="grupo_{n}">{_opcoes_linha(conta, modelo, cats_d, cats_r, proprias, None)}</select></td>
<td><label class="check"><input type="checkbox" name="regra_grupo_{n}" value="1" checked> lembrar</label></td></tr>''')
    if pendentes or trs_grupos:
        trs = list(trs_grupos)
        for l in pendentes:
            situ = selo('já importada', 'amarelo') if l['situacao'] == 'duplicada' else (selo('sugestão', 'verde') if l['sugestao'] else selo('nova', ''))
            trs.append(f'''<tr><td>{data_br(l['data'])}</td><td>{e(l['descricao'])}<br><span class="fraco">{e(l['motivo'])}</span></td>
<td class="n">{dinheiro(l['valor_centavos'], cor=True)}</td><td>{situ}</td>
<td><select name="acao_{l['id']}">{_opcoes_linha(conta, l, cats_d, cats_r, proprias, cands.get(l['id']))}</select></td>
<td><label class="check"><input type="checkbox" name="regra_{l['id']}" value="1"> lembrar</label></td></tr>''')
        n_pend = len(pendentes) + sum(len(ls) for _, ls in grupos)
        alternar = (f'<a href="/importacoes/{lote_id}?individual=1">Ver todas as linhas uma a uma</a>' if grupos else
                    (f'<a href="/importacoes/{lote_id}">Agrupar linhas parecidas</a>' if req.q('individual') else ''))
        tabela_pend = f'''<section class="painel"><h2>Para revisar ({n_pend})</h2><p>{alternar}</p><form method="post" action="/importacoes/{lote_id}">{tk()}
<table><thead><tr><th>Data</th><th>Descrição</th><th class="n">Valor</th><th>Situação</th><th>O que é</th><th>Regra</th></tr></thead><tbody>{''.join(trs)}</tbody></table>
<p class="fraco">Linhas em "decidir depois" ficam pendentes. "Lembrar" cria uma regra para descrições parecidas nas próximas importações.</p>
<div class="acoes"><button>Gravar decisões</button></div></form></section>'''
    lin_feitas = [[data_br(l['data']), e(l['descricao']), dinheiro(l['valor_centavos'], cor=True),
                   e({'casada': 'casada com lançamento existente', 'criada': 'lançada', 'ignorada': 'ignorada'}[l['situacao']]),
                   f'<a href="/lancamentos/{l["transacao_id"]}">ver</a>' if l['transacao_id'] else ''] for l in feitas]
    ausentes = []
    if lote['fatura_fechamento']:
        with banco.conexao() as c2:
            ausentes = cartoes.parcelas_ausentes(c2, lote_id)
    quadro_ausentes = ''
    if ausentes:
        itens = ''.join(f'<li>{e(x["descricao"])} · {dinheiro(x["valor"])}</li>' for x in ausentes)
        quadro_ausentes = (f'<section class="painel">{aviso("Parcelas previstas para esta fatura que não apareceram nela:", "atencao")}<ul>{itens}</ul>'
                           '<p>Se foram <b>antecipadas</b> ou a compra foi <b>cancelada</b>, o banco mostra isso numa linha própria desta fatura '
                           '(lance essa linha normalmente). Depois de gravar, encerre o parcelamento em '
                           '<a href="/parcelamentos">Parcelamentos</a> para tirar as parcelas que não vão mais vir.</p></section>')
    corpo = cab + quadro_fatura + quadro_ausentes + tabela_pend + (f'<section class="painel"><h2>Já processadas ({len(feitas)})</h2>{tabela(["Data", "Descrição", "Valor", "Resultado", ""], lin_feitas, (2,))}</section>' if feitas else '') \
        + f'<p><a href="/importacoes/{lote_id}/desfazer">Desfazer esta importação inteira…</a></p>'
    return req.html('Revisar importação', corpo)


@rota('POST', r'/importacoes/(\d+)')
def importacao_aplicar(req):
    lote_id = int(req.parametros[0])
    escolhas = {int(k[5:]): v[0] for k, v in req.form.items() if k.startswith('acao_') and k[5:].isdigit() and v and v[0]}
    regras = {int(k[6:]) for k, v in req.form.items() if k.startswith('regra_') and k[6:].isdigit() and v and v[0] == '1'}
    regras_grupo = []
    for k, v in req.form.items():
        if k.startswith('grupo_') and k[6:].isdigit() and v and v[0]:
            n_g = k[6:]
            ids = [int(x) for x in req.f(f'grupo_ids_{n_g}').split(',') if x.strip().isdigit()]
            for i in ids:
                escolhas.setdefault(i, v[0])
            if req.f(f'regra_grupo_{n_g}') == '1':
                regras_grupo.append((req.f(f'grupo_chave_{n_g}'), v[0]))
    with banco.transacao() as c:
        n = pipeline.aplicar(c, lote_id, escolhas, regras)
        for chave, acao in regras_grupo:
            pipeline.criar_regra_de_grupo(c, chave, acao)
        pend = c.execute("SELECT COUNT(*) FROM linhas_importacao WHERE lote_id=? AND situacao IN ('nova','duplicada')", (lote_id,)).fetchone()[0]
    ir(f'/importacoes/{lote_id}', f'{n} linha(s) gravada(s). ' + (f'{pend} continuam pendentes.' if pend else 'Importação concluída.'))


@rota('GET', r'/importacoes/(\d+)/desfazer')
def importacao_desfazer_confirmar(req):
    lote_id = int(req.parametros[0])
    corpo = f'''<section class="painel"><p>Desfazer apaga os lançamentos criados por esta importação e devolve à situação anterior os que foram casados.
O arquivo poderá ser importado de novo.</p><form method="post" action="/importacoes/{lote_id}/desfazer" class="acoes">{tk()}
<label class="check"><input type="checkbox" name="confirmo" value="1" required> Confirmo</label><button class="perigo">Desfazer importação</button>
<a href="/importacoes/{lote_id}">Cancelar</a></form></section>'''
    return req.html('Desfazer importação', corpo)


@rota('POST', r'/importacoes/(\d+)/desfazer')
def importacao_desfazer(req):
    if req.f('confirmo') != '1':
        raise ErroValidacao('Marque a confirmação.')
    with banco.transacao() as c:
        pipeline.desfazer(c, int(req.parametros[0]))
    ir('/importacoes', 'Importação desfeita.')
