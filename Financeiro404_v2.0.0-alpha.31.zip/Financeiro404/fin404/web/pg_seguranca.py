"""Páginas de acesso (PIN), backup e segurança, e lixeira."""
import urllib.parse

from fin404.dados import banco, config
from fin404.dinheiro import ErroValidacao
from fin404.dominio import razao
from fin404.seguranca import acesso, backup
from fin404.web.componentes import aviso, data_br, dinheiro, e, pagina_simples, selo, tabela
from fin404.web.base import ir
from fin404.web.servidor import Redirecionar, rota, token_html as tk


def _volta_segura(v):
    v = urllib.parse.unquote(v or '/')
    return v if v.startswith('/') and not v.startswith('//') and '\\' not in v else '/'


@rota('GET', '/entrar')
def entrar(req):
    if not acesso.pin_ativo():
        raise Redirecionar('/')
    erro = aviso(req.q('erro'), 'erro') if req.q('erro') else ''
    corpo = f'''<h1>Bloqueado</h1><p class="sub">Digite o PIN para abrir.</p>{erro}
<form method="post" action="/entrar">{tk()}<input type="hidden" name="volta" value="{e(_volta_segura(req.q('volta')))}">
<label>PIN<input type="password" name="pin" inputmode="numeric" autocomplete="current-password" autofocus required></label><button>Entrar</button></form>'''
    return 200, 'text/html; charset=utf-8', pagina_simples('Entrar', corpo).encode('utf-8'), {}


@rota('POST', '/entrar')
def entrar_post(req):
    volta = _volta_segura(req.f('volta'))
    try:
        token = acesso.verificar_pin(req.f('pin'))
    except ErroValidacao as exc:
        raise Redirecionar('/entrar?' + urllib.parse.urlencode({'volta': volta, 'erro': str(exc)}))
    raise Redirecionar(volta, {'Set-Cookie': acesso.cabecalho_cookie(token)})


@rota('POST', '/sair')
def sair(req):
    acesso.encerrar(req.sessao)
    raise Redirecionar('/entrar', {'Set-Cookie': f'{acesso.COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})


@rota('GET', '/backup')
def seguranca(req):
    with banco.conexao() as c:
        pin = acesso.pin_ativo(c)
        inat = acesso.inatividade_minutos(c)
        auto = config.obter('backup_auto', None, c)
        status = config.obter('backup_auto_status', None, c) or {}
        verificado = config.obter('backup_verificado', None, c)
        ultimo_manual = c.execute("SELECT MAX(em) FROM auditoria WHERE acao='backup'").fetchone()[0]
    # PIN
    if pin:
        bloco_pin = f'''<p>{selo('ativo', 'verde')} O programa pede o PIN ao abrir e bloqueia após {inat} minutos sem uso.</p>
<form method="post" action="/seguranca/pin" class="campos">{tk()}<label>PIN atual<input type="password" name="atual" required></label>
<label>Novo PIN (deixe vazio para remover)<input type="password" name="pin" minlength="4" autocomplete="new-password"></label>
<label>Bloquear após (minutos)<input type="number" name="inatividade" min="5" max="480" value="{inat}"></label><button class="secundario">Salvar</button></form>'''
    else:
        bloco_pin = f'''<p>{selo('desativado', 'amarelo')} Qualquer pessoa usando este Windows consegue abrir o programa.</p>
<form method="post" action="/seguranca/pin" class="campos">{tk()}<label>Novo PIN (4+ caracteres; recomendado 6+)<input type="password" name="pin" minlength="4" required autocomplete="new-password"></label>
<label>Repita<input type="password" name="pin2" minlength="4" required autocomplete="new-password"></label>
<label>Bloquear após (minutos)<input type="number" name="inatividade" min="5" max="480" value="30"></label><button>Ativar PIN</button></form>
<p class="fraco">Esqueceu o PIN? Feche o programa e rode <code>ferramentas\\remover_pin.py</code>.</p>'''
    # Backup automático
    if auto:
        ok = status.get('ultimo_sucesso')
        situacao = (aviso(status['erro'], 'erro') if status.get('erro') else '') + \
            f'<p>{selo("ativo", "verde")} Pasta: <code>{e(auto["pasta"])}</code> · guarda os últimos {auto.get("manter", 30)} dias.<br>' + \
            (f'Último backup: {e(ok.replace("T", " "))} ({e(status.get("arquivo", ""))}).' if ok else 'Nenhum backup gerado ainda.') + '</p>'
        teste = (f'<p>{selo("testado", "verde")} Último teste: {e(verificado["em"].replace("T", " ")[:16])} · {e(verificado["arquivo"])} abriu com a senha '
                 f'e tem {e(verificado["transacoes"])} lançamento(s).</p>' if verificado else
                 aviso('Este backup ainda não foi testado. Backup que nunca foi aberto não é garantia: teste agora com a senha.', 'atencao'))
        bloco_auto = f'''{situacao}{teste}<form method="post" action="/seguranca/backup-auto/testar" class="campos">{tk()}
<label>Senha do backup<input type="password" name="senha" required autocomplete="current-password"></label><button>Testar o último backup</button></form>
<p class="fraco">O teste abre o arquivo mais recente da pasta numa cópia temporária e confere se está íntegro. Não altera nada.
Faça de novo a cada poucos meses, para não esquecer a senha.</p>
<div class="acoes"><form method="post" action="/seguranca/backup-auto/agora">{tk()}<button class="secundario">Fazer backup agora</button></form>
<form method="post" action="/seguranca/backup-auto/desativar">{tk()}<button class="secundario">Desativar</button></form></div>'''
    else:
        bloco_auto = f'''<p>Um backup cifrado por dia, sozinho, numa pasta fora do notebook (pendrive, OneDrive, Google Drive).
<b>A senha não fica guardada no computador:</b> o programa só consegue cifrar; para abrir o backup, só com a senha.</p>
<form method="post" action="/seguranca/backup-auto" class="campos">{tk()}
<label>Pasta de destino (caminho completo)<input name="pasta" required placeholder="C:\\Users\\voce\\OneDrive\\Financeiro404"></label>
<label>Senha do backup (12+ caracteres)<input type="password" name="senha" minlength="12" required autocomplete="new-password"></label>
<label>Repita a senha<input type="password" name="senha2" minlength="12" required autocomplete="new-password"></label><button>Ativar backup automático</button></form>'''
    bloco_pin += ('<p class="fraco"><b>O que o PIN protege:</b> impede que alguém abra o programa no seu notebook destrancado. '
                  '<b>O que não protege:</b> quem copiar o arquivo do banco (<code>data\\financeiro_v2.sqlite3</code>) consegue lê-lo sem o PIN. '
                  'Para isso, mantenha o BitLocker ligado e a sua conta do Windows com senha.</p>')
    corpo = f'''<section class="painel"><h2>PIN de acesso</h2>{bloco_pin}</section>
<section class="painel"><h2>Backup automático cifrado</h2>{bloco_auto}</section>
<section class="painel"><h2>Backup manual (baixar agora)</h2><form method="post" action="/backup" class="campos">{tk()}
<label>Senha do backup (12+ caracteres)<input type="password" name="senha" minlength="12" required autocomplete="new-password"></label>
<label>Repita a senha<input type="password" name="senha2" minlength="12" required autocomplete="new-password"></label><button class="secundario">Gerar e baixar</button></form>
<p class="fraco">{"Último backup manual: " + e(ultimo_manual[:16]) + ". " if ultimo_manual else ""}AES-256-GCM, chave derivada da senha (scrypt). Sem a senha, não há como recuperar.</p></section>
<section class="painel"><div class="acoes"><a href="/restaurar">Restaurar ou testar um backup →</a><a href="/lixeira">Lixeira →</a><a href="/integridade">Verificar integridade →</a></div>
<p class="fraco">Além disso, o programa guarda sozinho uma cópia por dia em data\\copias (as últimas 14), no mesmo disco e sem cifragem.</p></section>'''
    return req.html('Backup e segurança', corpo)


@rota('POST', '/seguranca/pin')
def seguranca_pin(req):
    with banco.transacao() as c:
        ativo = acesso.pin_ativo(c)
    if ativo:
        acesso.verificar_pin(req.f('atual'))
        if not req.f('pin'):
            acesso.remover_pin()
            ir('/backup', 'PIN removido.')
        acesso.definir_pin(req.f('pin'), req.f('inatividade') or 30)
        token = acesso.nova_sessao()
        raise Redirecionar('/backup?msg=' + urllib.parse.quote('PIN alterado.'), {'Set-Cookie': acesso.cabecalho_cookie(token)})
    if req.f('pin') != req.f('pin2'):
        raise ErroValidacao('Os PINs não são iguais.')
    acesso.definir_pin(req.f('pin'), req.f('inatividade') or 30)
    token = acesso.nova_sessao()
    raise Redirecionar('/backup?msg=' + urllib.parse.quote('PIN ativado. Ele será pedido ao abrir o programa.'),
                       {'Set-Cookie': acesso.cabecalho_cookie(token)})


@rota('POST', '/seguranca/backup-auto')
def backup_auto_ativar(req):
    if req.f('senha') != req.f('senha2'):
        raise ErroValidacao('As senhas não são iguais.')
    st = backup.configurar_automatico(req.f('senha'), req.f('pasta'))
    if st and st.get('erro'):
        raise ErroValidacao(st['erro'])
    ir('/backup', 'Backup automático ativado. O primeiro já foi gravado na pasta.')


@rota('POST', '/seguranca/backup-auto/testar')
def backup_auto_testar(req):
    r = backup.testar_automatico(req.f('senha'))
    ir('/backup', f'Backup testado: {r["arquivo"]} abriu com a senha e está íntegro ({r["transacoes"]} lançamento(s)).')


@rota('POST', '/seguranca/backup-auto/agora')
def backup_auto_agora(req):
    st = backup.executar_automatico(forcar=True)
    if st and st.get('erro'):
        raise ErroValidacao(st['erro'])
    ir('/backup', 'Backup gravado na pasta.')


@rota('POST', '/seguranca/backup-auto/desativar')
def backup_auto_desativar(req):
    backup.desativar_automatico()
    ir('/backup', 'Backup automático desativado. Os arquivos já gravados continuam na pasta.')


@rota('GET', '/lixeira')
def lixeira(req):
    with banco.conexao() as c:
        itens = razao.lixeira(c)
    linhas = []
    for i in itens:
        t = i['transacao']
        total = sum(x['valor_centavos'] for x in i['lancamentos'] if x['valor_centavos'] > 0)
        linhas.append([data_br(t['data']), e(t['descricao']), dinheiro(total), e(i['em'][:16]),
                       f'<form method="post" action="/lixeira/{i["auditoria_id"]}">{tk()}<button class="secundario">Restaurar</button></form>'])
    return req.html('Lixeira', f'<section class="painel">{tabela(["Data", "Descrição", "Valor", "Excluído em", ""], linhas, (2,), "A lixeira está vazia.")}</section>',
                    'Lançamentos excluídos nos últimos 90 dias. Restaurar recria o lançamento como era.')


@rota('POST', r'/lixeira/(\d+)')
def lixeira_restaurar(req):
    with banco.transacao() as c:
        novo = razao.restaurar(c, int(req.parametros[0]))
    ir(f'/lancamentos/{novo}', 'Lançamento restaurado.')


@rota('POST', '/preferencias/tema')
def preferencias_tema(req):
    from fin404.web.componentes import TEMAS
    t = req.f('tema')
    if t not in dict(TEMAS):
        raise ErroValidacao('Tema inválido.')
    config.definir('tema', t)
    raise Redirecionar(_volta_do_referer(req.referer or '/'))


def _volta_do_referer(ref):
    """Volta para a página de onde veio (mesma origem), sem a mensagem anterior."""
    p = urllib.parse.urlsplit(ref)
    consulta = urllib.parse.urlencode([(k, v) for k, v in urllib.parse.parse_qsl(p.query) if k != 'msg'])
    return _volta_segura((p.path or '/') + ('?' + consulta if consulta else ''))
