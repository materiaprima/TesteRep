"""Servidor HTTP local (biblioteca padrão). Escuta só em 127.0.0.1.

Segurança: token CSRF em todo POST; checagem de Host (contra DNS rebinding) e de Origin;
CSP sem nenhum script; Referrer-Policy same-origin (com no-referrer, o navegador manda Origin: null
e os formulários falham — defeito D1 da v0.9).
"""
import email
import email.policy
import logging
import mimetypes
import re
import secrets
import sqlite3
import traceback
import urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from fin404.dados import banco
from fin404.dados.banco import ErroBanco
from fin404.dinheiro import ErroValidacao
from fin404.seguranca import acesso
from fin404.web.componentes import e, pagina

HOST, PORTA = '127.0.0.1', 4040
TOKEN = secrets.token_urlsafe(32)
LIMITE_CORPO = 25_000_000
ESTATICOS = Path(__file__).resolve().parent / 'static'
ROTAS = []
log = logging.getLogger('fin404')


def rota(metodo, padrao):
    def registrar(func):
        ROTAS.append((metodo, re.compile('^' + padrao + '$'), func))
        return func
    return registrar


class Redirecionar(Exception):
    def __init__(self, destino, cabecalhos=None):
        self.destino = destino
        self.cabecalhos = cabecalhos or {}


class Requisicao:
    def __init__(self, metodo, caminho, consulta, form, arquivos, parametros, referer, sessao=None, cookies=None):
        self.metodo, self.caminho, self.consulta = metodo, caminho, consulta
        self.form, self.arquivos, self.parametros, self.referer = form, arquivos, parametros, referer
        self.sessao = sessao
        self.cookies = cookies or {}
        self.mes_novo = None          # mês escolhido nesta requisição: fica guardado para as próximas páginas

    def mes_guardado(self):
        """Mês escolhido antes em outra página (cookie da sessão do navegador), se válido."""
        v = self.cookies.get('fin404_mes', '')
        return v if re.fullmatch(r'20\d\d-(0[1-9]|1[0-2])', v) else ''

    def q(self, nome, padrao=''):
        # parâmetro vazio (?mes=) existe na consulta (quer dizer "todos"), mas para q() vale o padrão, como antes
        return self.consulta.get(nome, [''])[0] or padrao

    def f(self, nome, padrao=''):
        v = self.form.get(nome)
        return (v[0] if v else padrao).strip() if isinstance(padrao, str) else (v[0] if v else padrao)

    def lista(self, nome):
        return self.form.get(nome, [])

    def html(self, titulo, corpo, subtitulo='', status=200):
        sair = acesso.pin_ativo()
        from datetime import date
        atual = date.today().strftime('%Y-%m')
        fixado = self.mes_novo if self.mes_novo is not None else self.mes_guardado()
        extras = {}
        if self.mes_novo is not None:
            extras['Set-Cookie'] = (f'fin404_mes={self.mes_novo}; Path=/; HttpOnly; SameSite=Strict' if self.mes_novo and self.mes_novo != atual
                                    else 'fin404_mes=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0')
        mostrar = fixado if fixado and fixado != atual else None
        return status, 'text/html; charset=utf-8', pagina(titulo, corpo, self.caminho, self.q('msg'), subtitulo, sair, mostrar).encode('utf-8'), extras


def _cookies(cabecalho):
    saida = {}
    for parte in (cabecalho or '').split(';'):
        nome, _, valor = parte.strip().partition('=')
        if nome:
            saida[nome] = valor
    return saida


def _voltar_ao_bloco(destino, req):
    """Depois de salvar, se a página de volta é a mesma de onde veio o formulário, desce até o painel que foi mexido."""
    bloco = (req.form.get('_bloco') or [''])[0] if req.metodo == 'POST' else ''
    if not bloco or '#' in destino or not re.fullmatch(r'[a-z][a-z0-9_-]{0,39}', bloco):
        return destino
    origem = urllib.parse.urlsplit(req.referer).path if req.referer else ''
    if urllib.parse.urlsplit(destino).path != origem:
        return destino
    return destino + '#' + bloco


def token_html():
    return f'<input type="hidden" name="csrf" value="{TOKEN}">'


def _ler_multipart(tipo, corpo):
    msg = email.message_from_bytes(b'Content-Type: ' + tipo.encode('latin-1') + b'\r\nMIME-Version: 1.0\r\n\r\n' + corpo,
                                   policy=email.policy.HTTP)
    form, arquivos = {}, {}
    for parte in msg.iter_parts():
        nome = parte.get_param('name', header='content-disposition')
        if not nome:
            continue
        conteudo = parte.get_payload(decode=True) or b''
        if parte.get_filename() is not None:
            arquivo = Path(parte.get_filename().replace('\\', '/')).name   # navegador antigo manda C:\...\nome
            arquivos[nome] = (arquivo, conteudo)
            if conteudo:   # vários arquivos no mesmo campo (input multiple): todos ficam em 'nome[]'
                arquivos.setdefault(nome + '[]', []).append((arquivo, conteudo))
        else:
            form.setdefault(nome, []).append(conteudo.decode('utf-8', 'replace'))
    return form, arquivos


class Manipulador(BaseHTTPRequestHandler):
    server_version = 'Financeiro404'
    sys_version = ''

    def _enviar(self, status, tipo, corpo, extras=None):
        self.send_response(status)
        self.send_header('Content-Type', tipo)
        self.send_header('Content-Length', str(len(corpo)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Content-Security-Policy', "default-src 'none'; style-src 'self'; img-src 'self' data:; "
                                                    "form-action 'self'; base-uri 'none'; frame-ancestors 'none'")
        self.send_header('Referrer-Policy', 'same-origin')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Cross-Origin-Opener-Policy', 'same-origin')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        for k, v in (extras or {}).items():
            self.send_header(k, v)
        self.end_headers()
        if self.command != 'HEAD':
            self.wfile.write(corpo)

    def _erro(self, status, titulo, mensagem):
        voltar = ''
        ref = self.headers.get('Referer', '')
        if ref.startswith(f'http://{HOST}:{PORTA}/') or ref.startswith(f'http://localhost:{PORTA}/'):
            voltar = f'<p><a href="{e(urllib.parse.urlsplit(ref).path or "/")}">← Voltar</a></p>'
        corpo = pagina(titulo, f'<div class="aviso erro">{e(mensagem)}</div>{voltar}', '').encode('utf-8')
        self._enviar(status, 'text/html; charset=utf-8', corpo)

    def _origem_ok(self):
        hosts = (f'{HOST}:{PORTA}', f'localhost:{PORTA}')
        if self.headers.get('Host') not in hosts:
            return False
        origem = self.headers.get('Origin')
        if self.command == 'POST':
            if origem is not None and origem not in (f'http://{h}' for h in hosts):
                return False
            site = self.headers.get('Sec-Fetch-Site')
            if site is not None and site not in ('same-origin', 'none'):
                return False
        return True

    def _tratar(self):
        partes = urllib.parse.urlsplit(self.path)
        caminho = partes.path
        if not self._origem_ok():
            return self._erro(403, 'Acesso recusado', 'Origem não autorizada. Abra o Financeiro 404 pelo endereço http://127.0.0.1:4040.')
        if self.command in ('GET', 'HEAD') and caminho.startswith('/static/'):
            arq = (ESTATICOS / caminho[len('/static/'):]).resolve()
            if arq.parent != ESTATICOS or not arq.is_file():
                return self._erro(404, 'Não encontrado', 'Arquivo não encontrado.')
            tipo = mimetypes.guess_type(arq.name)[0] or 'application/octet-stream'
            return self._enviar(200, tipo + ('; charset=utf-8' if tipo.startswith('text/') else ''), arq.read_bytes(),
                                {'Cache-Control': 'max-age=300'})
        form, arquivos = {}, {}
        if self.command == 'POST':
            try:
                tamanho = int(self.headers.get('Content-Length', '0'))
            except ValueError:
                tamanho = -1
            if tamanho < 0 or tamanho > LIMITE_CORPO:
                return self._erro(413, 'Envio muito grande', 'O arquivo ou formulário passa do limite de 25 MB.')
            corpo = self.rfile.read(tamanho)
            tipo = self.headers.get('Content-Type', '')
            if tipo.startswith('multipart/form-data'):
                form, arquivos = _ler_multipart(tipo, corpo)
            elif tipo.startswith('application/x-www-form-urlencoded'):
                form = urllib.parse.parse_qs(corpo.decode('utf-8', 'replace'), keep_blank_values=True)
            else:
                return self._erro(400, 'Envio inválido', 'Formato de formulário não reconhecido.')
            if not secrets.compare_digest((form.get('csrf') or [''])[0], TOKEN):
                return self._erro(400, 'Página expirada', 'O formulário expirou (o programa foi reiniciado). Recarregue a página e tente de novo.')
        metodo = 'GET' if self.command == 'HEAD' else self.command
        sessao = acesso.ler_cookie(self.headers.get('Cookie'))
        if caminho not in ('/entrar',) and acesso.pin_ativo() and not acesso.sessao_valida(sessao):
            destino = '/entrar' + ('?volta=' + urllib.parse.quote(caminho) if metodo == 'GET' and caminho != '/' else '')
            self.send_response(303)
            self.send_header('Location', destino)
            self.send_header('Content-Length', '0')
            self.send_header('Cache-Control', 'no-store')
            self.end_headers()
            return
        for m, padrao, func in ROTAS:
            achou = padrao.match(caminho)
            if m == metodo and achou:
                req = Requisicao(metodo, caminho, urllib.parse.parse_qs(partes.query, keep_blank_values=True), form, arquivos, achou.groups(),
                                 self.headers.get('Referer', ''), sessao, _cookies(self.headers.get('Cookie')))
                from fin404.web.componentes import REQ_ATUAL, _N_TABELA
                REQ_ATUAL.set(req)
                _N_TABELA.set(0)
                try:
                    resultado = func(req)
                except Redirecionar as r:
                    self.send_response(303)
                    self.send_header('Location', _voltar_ao_bloco(r.destino, req))
                    for k, v in r.cabecalhos.items():
                        self.send_header(k, v)
                    self.send_header('Content-Length', '0')
                    self.end_headers()
                    return
                except ErroValidacao as exc:
                    return self._erro(400, 'Confira os dados', str(exc))
                except ErroBanco as exc:
                    return self._erro(503, 'Aguarde', str(exc))
                except sqlite3.OperationalError as exc:
                    log.error('Erro de banco em %s: %s', caminho, exc)
                    if 'locked' in str(exc):
                        return self._erro(503, 'Banco ocupado', 'O banco está ocupado. Tente de novo em alguns segundos.')
                    return self._erro(500, 'Erro no banco de dados', 'Não foi possível concluir. Os detalhes foram gravados no registro de erros.')
                status, tipo, corpo, extras = resultado
                return self._enviar(status, tipo, corpo, extras)
        if any(p.match(caminho) for _, p, _ in ROTAS):
            return self._erro(405, 'Método não permitido', 'Esta página não aceita esse tipo de envio.')
        return self._erro(404, 'Página não encontrada', 'O endereço não existe.')

    def _seguro(self):
        try:
            self._tratar()
        except Exception:
            log.error('Erro inesperado em %s %s\n%s', self.command, self.path, traceback.format_exc())
            try:
                self._erro(500, 'Algo deu errado', 'Ocorreu um erro inesperado. Nada foi gravado pela metade. '
                                                   'Os detalhes ficaram no registro de erros (data/logs).')
            except Exception:
                pass

    do_GET = do_HEAD = do_POST = _seguro

    def log_message(self, *args):
        pass


def configurar_log():
    pasta = banco.pasta_dados() / 'logs'
    pasta.mkdir(parents=True, exist_ok=True)
    h = logging.FileHandler(pasta / 'erros.log', encoding='utf-8')
    h.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
    log.addHandler(h)
    log.setLevel(logging.INFO)


def criar_servidor(porta=PORTA):
    global PORTA
    PORTA = porta
    from fin404.web import paginas  # noqa: F401  (registra as rotas)
    configurar_log()
    banco.migrar()
    _agendar_copias()
    return ThreadingHTTPServer((HOST, porta), Manipulador)


def _agendar_copias():
    import threading

    def ciclo():
        try:
            banco.copia_diaria()
        except Exception:
            log.error('Falha na cópia automática\n%s', traceback.format_exc())
        try:
            from fin404.seguranca import backup
            backup.executar_automatico()
        except Exception:
            log.error('Falha no backup automático\n%s', traceback.format_exc())
        t = threading.Timer(6 * 3600, ciclo)
        t.daemon = True
        t.start()
    ciclo()


def main():
    import os
    import sys
    try:
        servidor = criar_servidor(int(os.environ.get('FIN404_PORTA', PORTA)))
    except OSError:
        print(f'O Financeiro 404 já está aberto. Abrindo o navegador em http://{HOST}:{PORTA} ...')
        if not os.environ.get('FIN404_NAO_ABRIR'):
            import webbrowser
            webbrowser.open(f'http://{HOST}:{PORTA}/')
        sys.exit(0)
    except ErroBanco as exc:
        print(f'Não foi possível abrir o banco: {exc}')
        sys.exit(1)
    print(f'Financeiro 404 rodando em http://{HOST}:{PORTA}  (feche esta janela ou Ctrl+C para encerrar)', flush=True)
    import os
    if not os.environ.get('FIN404_NAO_ABRIR'):
        import threading, webbrowser
        threading.Timer(0.5, lambda: webbrowser.open(f'http://{HOST}:{PORTA}/')).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        servidor.server_close()
