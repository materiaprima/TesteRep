"""Compras e projetos: visão geral, projetos (por ambiente/grupo), lista com filtros, item com cotações e histórico."""
from fin404.dados import banco
from fin404.dinheiro import centavos
from fin404.dominio import compras
from fin404.web.base import categorias, grupos_contas, hoje, inteiro, ir, opcional_int
from fin404.web.componentes import (aviso, barra, botao_excluir, campo_valor, data_br, dinheiro, e, grafico_linhas, mes_br,
                                    mes_curto, opcoes, opcoes_agrupadas, selo, tabela)
from fin404.web.servidor import rota, token_html as tk

COR_PRIORIDADE = {'necessario': 'vermelho', 'importante': 'amarelo', 'desejo': ''}
OPCOES_PARCELAS = [(1, 'À vista (guardar antes)')] + [(n, f'{n}x') for n in (2, 3, 4, 5, 6, 8, 10, 12, 15, 18, 24, 36, 48, 60)]
OPCOES_VIDA = [(6, 'a cada 6 meses'), (12, 'todo ano'), (24, 'a cada 2 anos'), (36, 'a cada 3 anos'), (48, 'a cada 4 anos'),
               (60, 'a cada 5 anos'), (96, 'a cada 8 anos'), (120, 'a cada 10 anos')]
ESTADOS_FILTRO = [('a cotar', 'Sem preço (a cotar)'), ('sem data', 'Sem data'), ('atrasada', 'Mês já passou'),
                  ('nao_cabe', 'Não cabe na sobra'), ('guardando', 'Guardando (à vista)'), ('parcelado', 'Parcelado'),
                  ('dinheiro separado', 'Dinheiro já separado')]
ABAS = [('/compras', 'Visão geral'), ('/compras/projetos', 'Projetos'), ('/compras/lista', 'Lista de compras'),
        ('/compras/historico', 'Comprados e histórico')]


def _abas(atual):
    return ''   # as abas da área Compras (no alto da página) já levam a cada parte


def _prio(p):
    return selo(compras.PRIORIDADES.get(p, p), COR_PRIORIDADE.get(p, ''))


def _como(it):
    return 'à vista' if it['parcelas'] == 1 else f'{it["parcelas"]}x'


def _cabe(it):
    if it.get('cabe') is None:
        return '<span class="fraco">—</span>'
    return selo('cabe', 'verde') if it['cabe'] else selo('não cabe', 'vermelho')


def _estado(it):
    est = it.get('estado')
    if est == 'a cotar':
        return selo('a cotar', 'amarelo')
    if est == 'atrasada':
        return selo('mês passou', 'vermelho')
    if est == 'dinheiro separado':
        return selo('dinheiro separado', 'verde')
    if it.get('por_mes') is None:
        return '<span class="fraco">sem mês definido</span>'
    return f'{"parcela" if est == "parcelado" else "guardar"} {dinheiro(it["por_mes"])}/mês'


def _nome(it, link=True):
    qtd = f'{it["quantidade"]}× ' if it.get('quantidade', 1) > 1 else ''
    nome = f'{e(qtd)}{e(it["descricao"])}'
    return f'<a href="/compras/{it["id"]}">{nome}</a>' if link else nome


def _onde(it):
    partes = [x for x in (it.get('plano'), it.get('grupo')) if x]
    return e(' · '.join(partes)) if partes else '<span class="fraco">avulsa</span>'


def _datalist_grupos(c):
    usados = {r[0] for r in c.execute("SELECT DISTINCT grupo FROM compras_planejadas WHERE grupo<>''")}
    todos = sorted(usados | {g for gs in compras.GRUPOS_SUGERIDOS.values() for g in gs})
    return '<datalist id="grupos-compra">' + ''.join(f'<option value="{e(g)}">' for g in todos) + '</datalist>'


def _lista_planos(c, so_ativos=True):
    return [(p['id'], p['nome']) for p in c.execute(
        "SELECT id, nome FROM planos_compra" + (" WHERE situacao='ativo'" if so_ativos else '') + ' ORDER BY nome')]


def _campos_item(cats, planos_, it=None, plano_fixo=None):
    it = dict(it or {})
    prio = it.get('prioridade', 'importante')
    plano_sel = plano_fixo or it.get('plano_id')
    projeto = (f'<input type="hidden" name="plano" value="{plano_fixo}">' if plano_fixo else
               f'<label>Projeto<select name="plano">{opcoes(planos_, plano_sel, "Avulsa (sem projeto)")}</select></label>')
    return f'''<label>O que comprar<input name="descricao" value="{e(it.get('descricao', ''))}" maxlength="120" required
placeholder="Geladeira, pneus, passagens, material escolar…"></label>
{projeto}
<label>Ambiente ou grupo<input name="grupo" list="grupos-compra" value="{e(it.get('grupo', ''))}" maxlength="40" placeholder="Cozinha, Manutenção, Hospedagem…"></label>
<label>Tipo<select name="tipo_item">{opcoes(compras.TIPOS_ITEM.items(), it.get('tipo_item', 'compra'))}</select></label>
<label>Quantidade<input name="quantidade" value="{it.get('quantidade', 1)}" inputmode="numeric"></label>
<label>Valor total estimado<input name="valor" value="{campo_valor(it.get('valor_centavos'))}" inputmode="decimal" placeholder="em branco = a cotar"></label>
<label>Já guardado para isso<input name="guardado" value="{campo_valor(it.get('guardado_centavos') or None)}" inputmode="decimal" placeholder="0,00"></label>
<label>Venda do usado (abate)<input name="revenda" value="{campo_valor(it.get('revenda_centavos') or None)}" inputmode="decimal" placeholder="0,00"></label>
<label>Categoria<select name="categoria">{opcoes(cats, it.get('categoria_id'), 'Escolher depois')}</select></label>
<label>Prioridade<select name="prioridade">{opcoes(compras.PRIORIDADES.items(), prio)}</select></label>
<label>Para quando<input type="month" name="mes_alvo" value="{e(it.get('mes_alvo') or '')}"></label>
<label>Como pagar<select name="parcelas">{opcoes(OPCOES_PARCELAS, it.get('parcelas', 1))}</select></label>
<label>Trocar de novo<select name="vida_util">{opcoes(OPCOES_VIDA, it.get('vida_util_meses'), 'Não se repete')}</select></label>
<label>Garantia (meses)<input name="garantia" value="{it.get('garantia_meses') or ''}" inputmode="numeric" placeholder="ao comprar, entra em Prazos"></label>
<label>Observação<input name="observacao" value="{e(it.get('observacao', ''))}" maxlength="300" placeholder="Modelo, medida, loja…"></label>'''


def _valor_opcional(req, nome):
    return centavos(req.f(nome), permitir_zero=True) if req.f(nome) else 0


def _dados_item(req):
    valor = centavos(req.f('valor')) if req.f('valor') else None
    return dict(descricao=req.f('descricao'), valor=valor, categoria_id=opcional_int(req.f('categoria')),
                prioridade=req.f('prioridade'), mes_alvo=req.f('mes_alvo') or None,
                parcelas=inteiro(req.f('parcelas') or '1', 'parcelas'), guardado=_valor_opcional(req, 'guardado'),
                observacao=req.f('observacao'), plano_id=opcional_int(req.f('plano')), grupo=req.f('grupo'),
                tipo_item=req.f('tipo_item') or 'compra', quantidade=inteiro(req.f('quantidade') or '1', 'quantidade'),
                revenda=_valor_opcional(req, 'revenda'), vida_util_meses=opcional_int(req.f('vida_util')),
                garantia_meses=opcional_int(req.f('garantia')))


def _voltar(req, padrao='/compras/lista'):
    destino = req.f('voltar')
    return destino if destino.startswith('/compras') and '//' not in destino else padrao


def _tabela_itens(itens, com_onde=True, vazio='Nada por aqui.'):
    cab = ['Prioridade', 'Compra'] + (['Projeto · grupo'] if com_onde else []) + ['Valor', 'Falta', 'Quando', 'Como', 'Por mês', 'Cabe?']
    linhas = []
    for it in itens:
        if it['situacao'] != 'planejada':
            situ = selo(compras.SITUACOES.get(it['situacao'], it['situacao']), 'verde' if it['situacao'] == 'comprada' else '')
            linhas.append([_prio(it['prioridade']), _nome(it)] + ([_onde(it)] if com_onde else []) +
                          [dinheiro(it['valor_pago_centavos'] or it['valor_centavos']), '—',
                           data_br(it['concluida_em']) if it['concluida_em'] else '—', e(_como(it)), situ, ''])
            continue
        quando = mes_br(it['mes_alvo']) if it['mes_alvo'] else '<span class="fraco">sem data</span>'
        linhas.append([_prio(it['prioridade']), _nome(it)] + ([_onde(it)] if com_onde else []) +
                      [dinheiro(it['valor_centavos']), dinheiro(it.get('falta')), quando, e(_como(it)), _estado(it), _cabe(it)])
    n = 1 if com_onde else 0
    return tabela(cab, linhas, (2 + n, 3 + n), vazio, ocultar_movel=((2,) if com_onde else ()) + (2 + n, 5 + n))


def _cartoes_resumo(p):
    n = len(p['itens'])
    if p['sobra'] is None:
        situ = '<strong>—</strong><em>sem renda lançada para comparar</em>'
    elif p['nao_cabem']:
        situ = f'<strong class="neg">{p["nao_cabem"]} não cabe{"m" if p["nao_cabem"] > 1 else ""}</strong><em>na ordem de prioridade</em>'
    else:
        situ = '<strong class="pos">Tudo cabe</strong><em>na sobra média, na ordem de prioridade</em>'
    sem = len(p['sem_preco'])
    return f'''<div class="cartoes">
<div class="cartao"><small>Falta para tudo</small><strong>{dinheiro(p['total_falta'])}</strong><em>{n} item(ns) em aberto · {dinheiro(p['total_guardado'])} já guardado{f" · {sem} sem preço" if sem else ""}</em></div>
<div class="cartao"><small>Separar este mês</small><strong>{dinheiro(p['este_mes'])}</strong><em>guardar + parcelas do mês</em></div>
<div class="cartao"><small><a href="/raio-x">Sobra média</a></small><strong>{dinheiro(p['sobra'], cor=True)}</strong><em>renda − gasto médio por mês</em></div>
<div class="cartao"><small>Cabe no orçamento?</small>{situ}</div></div>'''


def _avisos(p):
    if p['sobra'] is None:
        return aviso('Ainda não dá para dizer o que cabe: o cálculo usa a sobra média (renda − gastos) dos últimos 3 meses '
                     'completos, e ainda não há renda lançada nesse período. Projetos, listas e calendário já funcionam.')
    if p['sobra'] <= 0:
        return aviso('Pela média dos últimos meses, os gastos já consomem toda a renda: nenhuma compra nova cabe sem cortar '
                     'algo antes. Veja onde cortar no Raio-X.', 'erro')
    return ''


def _cartao_projeto(r):
    prazo = f' · até {mes_br(r["mes_alvo"])}' if r['mes_alvo'] else ''
    orc = (f'{dinheiro(r["previsto"])} de {dinheiro(r["orcamento_centavos"])}' if r['orcamento_centavos']
           else f'{dinheiro(r["previsto"])} previstos')
    livre = ''
    if r['livre'] is not None:
        livre = (f' · <span class="neg">estoura {e(_fmt(-r["livre"]))}</span>' if r['livre'] < 0
                 else f' · sobra {dinheiro(r["livre"])}')
    situ = '' if r['situacao'] == 'ativo' else ' ' + selo(compras.SITUACOES_PLANO.get(r['situacao'], r['situacao']))
    return f'''<section class="painel"><h2><a href="/compras/projetos/{r['id']}">{e(r['nome'])}</a>{situ}</h2>
<p class="fraco">{e(compras.TIPOS_PLANO.get(r['tipo'], r['tipo']))}{prazo}</p>
<p>{r['n_comprados']} de {r['n_comprados'] + r['n_abertos']} itens comprados ({r['pct']}%)</p>{barra(r['n_comprados'], r['n_comprados'] + r['n_abertos'])}
<p>{orc}{livre}</p><p>Falta: <b>{dinheiro(r['falta'])}</b>{f" · {r['n_sem_preco']} sem preço" if r['n_sem_preco'] else ""}</p></section>'''


def _link_projeto(it):
    return f'<a href="/compras/projetos/{it["plano_id"]}">{e(it["plano"])}</a>'


def _fmt(cent):
    from fin404.dinheiro import formatar
    return formatar(cent)


# ------------------------------------------------------------------ visão geral

@rota('GET', '/compras')
def compras_pagina(req):
    with banco.conexao() as c:
        p = compras.plano(c, hoje())
        projetos = [r for r in compras.planos(c) if r['situacao'] == 'ativo']
    cal = p['calendario']
    serie = [('Compras do mês', [m['total'] for m in cal])]
    if p['sobra'] is not None:
        serie.append(('Sobra média', [p['sobra']] * len(cal)))
    atencao = []
    for it in p['atrasadas']:
        atencao.append(f'<li>{_nome(it)}: o mês planejado ({mes_br(it["mes_alvo"])}) passou. Compre, mude a data ou desista.</li>')
    for it in [x for x in p['itens'] if x['cabe'] is False][:5]:
        atencao.append(f'<li>{_nome(it)} não cabe na sobra: adie, parcele ou corte outro gasto.</li>')
    for it in p['proximas_trocas'][:5]:
        atencao.append(f'<li>{_nome(it)} ({e(compras.TIPOS_ITEM.get(it["tipo_item"], ""))}) em {mes_br(it["mes_alvo"])}.</li>')
    if p['sem_preco']:
        atencao.append(f'<li><a href="/compras/lista?estado=a+cotar">{len(p["sem_preco"])} item(ns) sem preço</a>: '
                       'cote para entrarem no plano.</li>')
    cards = ''.join(_cartao_projeto(r) for r in projetos)
    prios = [[_prio(k), str(v['n']), dinheiro(v['falta'])] for k, v in p['por_prioridade'].items() if v['n']]
    por_cat = [[e(nome), str(v['n']), dinheiro(v['falta'])] for nome, v in p['por_categoria']]
    linhas_cal = [[mes_br(m['ym']), dinheiro(m['guardar']), dinheiro(m['parcelas']), f'<b>{dinheiro(m["total"])}</b>',
                   dinheiro(m['folga'], cor=True)] for m in cal]
    corpo = f'''{_abas('/compras')}{_avisos(p)}{_cartoes_resumo(p)}
{f'<section class="painel"><h2>Atenção</h2><ul>{"".join(atencao)}</ul></section>' if atencao else ''}
<h2>Projetos em andamento</h2>
{f'<div class="grade">{cards}</div>' if cards else '<div class="vazio">Nenhum projeto ainda. <a href="/compras/projetos">Crie um</a>: casa, carro, viagem, trocas, reforma, festa…</div>'}
<section class="painel"><h2>Próximos 12 meses</h2>{grafico_linhas([mes_curto(m['ym']) for m in cal], serie)}
{tabela(['Mês', 'Guardar', 'Parcelas', 'Total', 'Sobra depois'], linhas_cal, (1, 2, 3, 4))}
<p class="fraco">"Guardar" é o que separar para compras à vista; "Parcelas", o que as compras parceladas pedem. "Sobra depois" =
sobra média − total do mês. Negativo: o plano não fecha naquele mês.</p></section>
<div class="grade"><section class="painel"><h2>Por prioridade</h2>{tabela(['Prioridade', 'Itens', 'Falta'], prios, (1, 2), 'Nada em aberto.')}</section>
<section class="painel"><h2>Por categoria</h2>{tabela(['Categoria', 'Itens', 'Falta'], por_cat, (1, 2), 'Nada em aberto.')}</section></div>
<p class="fraco">O plano não mexe em saldo nenhum: só "Comprei" lança a despesa. <b>Necessário</b>: não dá para ficar sem.
<b>Importante</b>: melhora a vida e tem prazo. <b>Desejo</b>: pode esperar. O que cabe é decidido nessa ordem.</p>'''
    return req.html('Compras e projetos', corpo, 'O que a família precisa ou quer comprar, quanto separar por mês e se cabe na sobra.')


# ------------------------------------------------------------------ projetos

def _campos_plano(r=None):
    r = dict(r or {})
    return f'''<label>Nome<input name="nome" value="{e(r.get('nome', ''))}" maxlength="80" required placeholder="Casa 404, Carro, Viagem de férias…"></label>
<label>Tipo<select name="tipo">{opcoes(compras.TIPOS_PLANO.items(), r.get('tipo', 'casa'))}</select></label>
<label>Teto do orçamento<input name="orcamento" value="{campo_valor(r.get('orcamento_centavos'))}" inputmode="decimal" placeholder="opcional"></label>
<label>Prazo<input type="month" name="mes_alvo" value="{e(r.get('mes_alvo') or '')}"></label>
<label>Observação<input name="observacao" value="{e(r.get('observacao', ''))}" maxlength="300"></label>'''


def _dados_plano(req):
    return dict(nome=req.f('nome'), tipo=req.f('tipo') or 'outro',
                orcamento=centavos(req.f('orcamento')) if req.f('orcamento') else None,
                mes_alvo=req.f('mes_alvo') or None, observacao=req.f('observacao'))


@rota('GET', '/compras/projetos')
def projetos_pagina(req):
    with banco.conexao() as c:
        todos = compras.planos(c)
    ativos = ''.join(_cartao_projeto(r) for r in todos if r['situacao'] == 'ativo')
    outros = [[f'<a href="/compras/projetos/{r["id"]}">{e(r["nome"])}</a>', e(compras.TIPOS_PLANO.get(r['tipo'], r['tipo'])),
               selo(compras.SITUACOES_PLANO.get(r['situacao'], r['situacao'])), dinheiro(r['gasto'])]
              for r in todos if r['situacao'] != 'ativo']
    modelos = ''.join(f'<li><b>{e(compras.TIPOS_PLANO[t])}</b>: {e(", ".join(compras.GRUPOS_SUGERIDOS[t]))}</li>'
                      for t in compras.TIPOS_PLANO if compras.MODELOS.get(t))
    corpo = f'''{_abas('/compras/projetos')}
{f'<div class="grade">{ativos}</div>' if ativos else '<div class="vazio">Nenhum projeto em andamento.</div>'}
<section class="painel"><h2>Novo projeto</h2><form method="post" action="/compras/projetos" class="campos">{tk()}
{_campos_plano()}<label class="marcar"><input type="checkbox" name="modelo" value="1"> Começar com a lista pronta do tipo (sugestões sem preço; dá para remover depois)</label>
<button>Criar projeto</button></form>
<details><summary>O que vem em cada lista pronta</summary><ul>{modelos}</ul>
<p class="fraco">Os itens entram sem preço ("a cotar"). Apague o que não serve, cote o resto e ajuste prioridade e data.
Manutenções e trocas já vêm com a frequência (óleo a cada 6 meses, pneus a cada 4 anos…): ao comprar, a próxima é planejada.</p></details></section>
{f'<details class="painel"><summary>Concluídos e arquivados ({len(outros)})</summary>{tabela(["Projeto", "Tipo", "Situação", "Gasto"], outros, (3,))}</details>' if outros else ''}'''
    return req.html('Projetos de compra', corpo, 'Casa, carro, viagem, trocas, reforma, festa: cada objetivo com a sua lista, prazo e teto.')


@rota('POST', '/compras/projetos')
def projetos_criar(req):
    with banco.transacao() as c:
        pid = compras.criar_plano(c, **_dados_plano(req), usar_modelo=req.f('modelo') == '1')
        n = c.execute('SELECT COUNT(*) FROM compras_planejadas WHERE plano_id=?', (pid,)).fetchone()[0]
    ir(f'/compras/projetos/{pid}', f'Projeto criado{f" com {n} itens para cotar" if n else ""}.')


@rota('GET', r'/compras/projetos/(\d+)')
def projeto_pagina(req):
    pid = int(req.parametros[0])
    with banco.conexao() as c:
        d = compras.detalhe_plano(c, pid, hoje())
        cats = categorias(c, 'despesa')
        planos_ = _lista_planos(c)
        dl = _datalist_grupos(c)
    r = d['plano']
    orc = dinheiro(r['orcamento_centavos']) if r['orcamento_centavos'] else '<span class="fraco">sem teto</span>'
    livre = ('<strong>—</strong><em>defina um teto para acompanhar</em>' if r['livre'] is None else
             f'<strong>{dinheiro(r["livre"], cor=True)}</strong><em>teto − gasto − planejado</em>')
    secoes = []
    for nome, g in d['grupos'].items():
        secoes.append(f'''<section class="painel"><h2>{e(nome)} <small class="fraco">{g['feitos']} de {g['n']} · falta {e(_fmt(g['falta']))}</small></h2>
{_tabela_itens(g['itens'], com_onde=False)}</section>''')
    acoes = []
    if r['situacao'] == 'ativo':
        acoes.append(('concluido', 'Marcar como concluído'))
        acoes.append(('arquivado', 'Arquivar (pausar)'))
    else:
        acoes.append(('ativo', 'Voltar a andamento'))
    botoes = ''.join(f'<form method="post" action="/compras/projetos/{pid}/situacao" class="acoes">{tk()}<input type="hidden" name="situacao" value="{s}">'
                     f'<button class="secundario">{e(n)}</button></form>' for s, n in acoes)
    modelo = (f'<form method="post" action="/compras/projetos/{pid}/modelo" class="acoes">{tk()}<button class="secundario">'
              f'Acrescentar itens da lista pronta ({e(compras.TIPOS_PLANO[r["tipo"]])})</button></form>'
              f'<form method="post" action="/compras/projetos/{pid}/sem-sugestoes" class="acoes">{tk()}<button class="secundario">'
              f'Remover sugestões da lista pronta que vocês não usaram</button></form>'
              '<p class="fraco">Remove só os itens da lista pronta sem preço, sem nada guardado e sem observação.</p>'
              if compras.MODELOS.get(r['tipo']) else '')
    pausado = '' if r['situacao'] == 'ativo' else aviso('Projeto fora de andamento: os itens dele não entram no calendário nem no "cabe?".')
    corpo = f'''{_abas('/compras/projetos')}{pausado}<p class="fraco">{e(compras.TIPOS_PLANO.get(r['tipo'], r['tipo']))}{f" · prazo {mes_br(r['mes_alvo'])}" if r['mes_alvo'] else ""}{f" · {e(r['observacao'])}" if r['observacao'] else ""}</p>
<div class="cartoes">
<div class="cartao"><small>Teto</small><strong>{orc}</strong><em>previsto {dinheiro(r['previsto'])}</em></div>
<div class="cartao"><small>Já gasto</small><strong>{dinheiro(r['gasto'])}</strong><em>{r['n_comprados']} item(ns) comprado(s)</em></div>
<div class="cartao"><small>Falta comprar</small><strong>{dinheiro(r['falta'])}</strong><em>{r['n_abertos']} item(ns){f", {r['n_sem_preco']} sem preço" if r['n_sem_preco'] else ""}</em></div>
<div class="cartao"><small>Livre no teto</small>{livre}</div>
<div class="cartao"><small>Progresso</small><strong>{r['pct']}%</strong>{barra(r['n_comprados'], r['n_comprados'] + r['n_abertos'])}</div></div>
{(f'<div class="aviso info">{r["n_sem_preco"]} item(ns) sem preço. Os que vieram da lista pronta e vocês não vão comprar podem sair de uma vez: '
   f'<form method="post" action="/compras/projetos/{pid}/sem-sugestoes" class="inline">{tk()}<button class="secundario">Remover sugestões sem uso</button></form></div>')
  if r['n_sem_preco'] >= 5 and compras.MODELOS.get(r['tipo']) else ''}
<details class="painel" id="adicionar"{" open" if not secoes else ""}><summary><strong>+ Adicionar item</strong></summary><form method="post" action="/compras" class="campos">{tk()}
<input type="hidden" name="voltar" value="/compras/projetos/{pid}">{_campos_item(cats, planos_, {'prioridade': 'importante', 'mes_alvo': r['mes_alvo']}, plano_fixo=pid)}
<button>Adicionar</button></form>{dl}</details>
{''.join(secoes) or '<div class="vazio">Nenhum item ainda. Adicione acima ou use a lista pronta (em Ações).</div>'}
<div class="grade"><section class="painel"><h2>Editar projeto</h2><form method="post" action="/compras/projetos/{pid}" class="campos">{tk()}
{_campos_plano(r)}<button>Salvar</button></form></section>
<section class="painel"><h2>Ações</h2>{botoes}{modelo}
{botao_excluir(f"/compras/projetos/{pid}/excluir", "Apaga o projeto e os itens ainda planejados. O que já foi comprado continua no histórico e nos lançamentos.", "Excluir projeto")}</section></div>'''
    return req.html(r['nome'], corpo, 'Itens por ambiente ou grupo, teto, gasto e o que falta.')


@rota('POST', r'/compras/projetos/(\d+)')
def projeto_editar(req):
    with banco.transacao() as c:
        compras.atualizar_plano(c, int(req.parametros[0]), **_dados_plano(req))
    ir(f'/compras/projetos/{req.parametros[0]}', 'Projeto atualizado.')


@rota('POST', r'/compras/projetos/(\d+)/situacao')
def projeto_situacao(req):
    with banco.transacao() as c:
        compras.mudar_situacao_plano(c, int(req.parametros[0]), req.f('situacao'))
    ir(f'/compras/projetos/{req.parametros[0]}', 'Situação do projeto atualizada.')


@rota('POST', r'/compras/projetos/(\d+)/modelo')
def projeto_modelo(req):
    with banco.transacao() as c:
        n = compras.aplicar_modelo(c, int(req.parametros[0]))
    ir(f'/compras/projetos/{req.parametros[0]}', f'{n} item(ns) acrescentado(s).' if n else 'Todos os itens da lista pronta já estão no projeto.')


@rota('POST', r'/compras/projetos/(\d+)/sem-sugestoes')
def projeto_sem_sugestoes(req):
    with banco.transacao() as c:
        n = compras.remover_sugestoes(c, int(req.parametros[0]))
    ir(f'/compras/projetos/{req.parametros[0]}', f'{n} sugestão(ões) sem uso removida(s).' if n else 'Nenhuma sugestão sem uso para remover.')


@rota('POST', r'/compras/projetos/(\d+)/excluir')
def projeto_excluir(req):
    with banco.transacao() as c:
        nome, n = compras.excluir_plano(c, int(req.parametros[0]))
    ir('/compras/projetos', f'Projeto "{nome}" excluído ({n} item(ns) planejado(s) apagado(s)).')


# ------------------------------------------------------------------ lista e histórico

@rota('GET', '/compras/lista')
def lista_pagina(req):
    plano_q = req.q('plano')
    plano_id = 0 if plano_q == 'avulsa' else opcional_int(plano_q)
    prio, tipo, estado = req.q('prioridade'), req.q('tipo'), req.q('estado')
    with banco.conexao() as c:
        p = compras.plano(c, hoje())
        planos_ativos = _lista_planos(c)
        cats = categorias(c, 'despesa')
        dl = _datalist_grupos(c)
    itens = compras.filtrar(p['itens'], plano_id, prio, tipo, estado)
    filtro_planos = [('avulsa', 'Avulsas (sem projeto)')] + planos_ativos
    filtros = f'''<form method="get" action="/compras/lista" class="acoes filtros">
<label>Projeto<select name="plano">{opcoes(filtro_planos, plano_q, 'Todos')}</select></label>
<label>Prioridade<select name="prioridade">{opcoes(compras.PRIORIDADES.items(), prio, 'Todas')}</select></label>
<label>Tipo<select name="tipo">{opcoes(compras.TIPOS_ITEM.items(), tipo, 'Todos')}</select></label>
<label>Situação<select name="estado">{opcoes(ESTADOS_FILTRO, estado, 'Todas')}</select></label>
<button class="secundario">Filtrar</button></form>'''
    soma = sum(it['falta'] or 0 for it in itens)
    corpo = f'''{_abas('/compras/lista')}{_avisos(p)}<details class="painel" id="nova"><summary><strong>+ Nova compra</strong></summary><form method="post" action="/compras" class="campos">{tk()}
<input type="hidden" name="voltar" value="/compras/lista">{_campos_item(cats, planos_ativos)}<button>Adicionar ao plano</button></form>{dl}
<p class="fraco">Sem valor, o item fica "a cotar" e não entra nas contas. À vista, o app divide o que falta pelos meses até a data;
parcelado, mostra as parcelas a partir do mês escolhido. "Venda do usado" abate da falta (carro, celular). "Trocar de novo"
planeja a próxima troca quando esta for comprada.</p></details>
<section class="painel">{filtros}
<p>{len(itens)} item(ns) · falta {dinheiro(soma)}</p>
{_tabela_itens(itens, vazio='Nenhuma compra com esses filtros.')}</section>'''
    return req.html('Lista de compras', corpo, 'Tudo o que está planejado, com filtros.')


@rota('GET', '/compras/historico')
def historico_pagina(req):
    with banco.conexao() as c:
        h = compras.historico(c, 200)
    gasto = sum(x['valor_pago_centavos'] or 0 for x in h if x['situacao'] == 'comprada')
    linhas = [[_nome(x), _onde(x), selo(compras.SITUACOES.get(x['situacao'], x['situacao']), 'verde' if x['situacao'] == 'comprada' else ''),
               data_br(x['concluida_em']) if x['concluida_em'] else '—', dinheiro(x['valor_centavos']), dinheiro(x['valor_pago_centavos']),
               f'<a href="/lancamentos/{x["transacao_id"]}">lançamento</a>' if x['transacao_id'] else '<span class="fraco">—</span>']
              for x in h]
    corpo = f'''{_abas('/compras/historico')}<p>Comprado nos registros: <b>{dinheiro(gasto)}</b></p>
<section class="painel">{tabela(['Compra', 'Projeto · grupo', 'Situação', 'Quando', 'Estimado', 'Pago', ''], linhas, (4, 5), 'Nada concluído ainda.', ocultar_movel=(1, 4))}
<p class="fraco">Compare o estimado com o pago para calibrar as próximas estimativas.</p></section>'''
    return req.html('Comprados e histórico', corpo, 'O que já foi comprado ou deixado de lado.')


# ------------------------------------------------------------------ item

@rota('POST', '/compras')
def compras_criar(req):
    with banco.transacao() as c:
        compras.criar(c, **_dados_item(req))
    ir(_voltar(req), 'Compra adicionada ao plano.')


@rota('GET', r'/compras/(\d+)')
def compra_pagina(req):
    cid = int(req.parametros[0])
    with banco.conexao() as c:
        it = dict(compras.uma(c, cid))
        calc = next((x for x in compras.plano(c, hoje())['itens'] if x['id'] == cid), None)
        cots = compras.cotacoes(c, cid)
        cats = categorias(c, 'despesa')
        planos_ = _lista_planos(c, so_ativos=False)
        g_pag = grupos_contas(c)
        dl = _datalist_grupos(c)
        origem = compras.uma(c, it['origem_id']) if it['origem_id'] and c.execute(
            'SELECT 1 FROM compras_planejadas WHERE id=?', (it['origem_id'],)).fetchone() else None
    if calc is None and it['situacao'] == 'planejada':
        mapa, por_mes, estado, falta = compras._impacto(it, hoje())
        calc = {**it, 'falta': falta, 'por_mes': por_mes, 'estado': estado, 'cabe': None}
    voltar = f'/compras/projetos/{it["plano_id"]}' if it['plano_id'] else '/compras/lista'
    info = [f'{_prio(it["prioridade"])} {e(compras.TIPOS_ITEM.get(it["tipo_item"], it["tipo_item"]))}'
            + (f' · {it["quantidade"]} unidades' if it['quantidade'] > 1 else ''),
            'Projeto: ' + (_link_projeto(it) if it['plano_id'] else 'avulsa') + (f' · {e(it["grupo"])}' if it['grupo'] else ''),
            f'Valor: <b>{dinheiro(it["valor_centavos"]) if it["valor_centavos"] else "a cotar"}</b> · categoria {e(it["categoria"] or "a escolher")}',
            f'Quando: {mes_br(it["mes_alvo"]) if it["mes_alvo"] else "sem data"} · {e(_como(it))}']
    extras = []
    if it['guardado_centavos']:
        extras.append(f'já guardado {dinheiro(it["guardado_centavos"])}')
    if it['revenda_centavos']:
        extras.append(f'venda do usado {dinheiro(it["revenda_centavos"])}')
    if it['vida_util_meses']:
        extras.append(dict(OPCOES_VIDA).get(it['vida_util_meses'], f'a cada {it["vida_util_meses"]} meses').replace('todo ano', 'troca todo ano')
                      .replace('a cada', 'troca a cada', 1))
    if extras:
        info.append(' · '.join(extras))
    if calc:
        cabe = '' if calc.get('cabe') is None else f' · {_cabe(calc)}'
        info.append(f'Falta {dinheiro(calc["falta"])} · {_estado(calc)}{cabe}')
    if origem:
        info.append(f'Reposição de <a href="/compras/{origem["id"]}">{e(origem["descricao"])}</a> comprada em {data_br(origem["concluida_em"])}')
    if it['observacao']:
        info.append(e(it['observacao']))
    if it['situacao'] != 'planejada':
        info.append(f'{selo(compras.SITUACOES.get(it["situacao"], it["situacao"]), "verde" if it["situacao"] == "comprada" else "")} '
                    f'em {data_br(it["concluida_em"]) if it["concluida_em"] else "—"}'
                    + (f' · pago {dinheiro(it["valor_pago_centavos"])}' if it['valor_pago_centavos'] else ''))
        if it['transacao_id']:
            info.append(f'<a href="/lancamentos/{it["transacao_id"]}">Ver o lançamento</a>')
    blocos = [f'<p><a href="{voltar}">← Voltar</a></p><section class="painel">' + ''.join(f'<p>{x}</p>' for x in info) + '</section>']
    aberta = it['situacao'] == 'planejada'
    linhas_cot = []
    for q in cots:
        link = f' <a href="{e(q["link"])}" rel="noopener noreferrer" target="_blank">abrir</a>' if q['link'] else ''
        usar = (f'<form method="post" action="/compras/cotacoes/{q["id"]}/usar" class="acoes">{tk()}<button class="secundario">Usar esta</button></form>'
                if aberta else '')
        apagar = (f'<form method="post" action="/compras/cotacoes/{q["id"]}/excluir" class="acoes">{tk()}<button class="secundario">Remover</button></form>'
                  if aberta else '')
        linhas_cot.append([e(q['loja']) + link, dinheiro(q['valor_centavos']), dinheiro(q['frete_centavos']), f'<b>{dinheiro(q["total"])}</b>',
                           'à vista' if q['parcelas'] == 1 else f'{q["parcelas"]}x', data_br(q['data']), e(q['observacao']), usar + apagar])
    melhor = f'<p>Menor preço: <b>{dinheiro(cots[0]["total"])}</b> em {e(cots[0]["loja"])}.</p>' if cots else ''
    form_cot = f'''<form method="post" action="/compras/{cid}/cotacoes" class="campos">{tk()}
<label>Loja ou vendedor<input name="loja" maxlength="80" required></label><label>Preço<input name="valor" inputmode="decimal" required></label>
<label>Frete<input name="frete" inputmode="decimal" placeholder="0,00"></label><label>Parcelas sem juros<input name="parcelas" value="1" inputmode="numeric"></label>
<label>Link<input name="link" maxlength="500" placeholder="https://…"></label><label>Observação<input name="observacao" maxlength="200" placeholder="cor, garantia, prazo…"></label>
<button>Guardar cotação</button></form>''' if aberta else ''
    blocos.append(f'''<section class="painel"><h2>Cotações</h2>{melhor}
{tabela(['Loja', 'Preço', 'Frete', 'Total', 'Pagamento', 'Data', 'Obs.', ''], linhas_cot, (1, 2, 3), 'Nenhuma cotação ainda.', ocultar_movel=(2, 5, 6))}
{form_cot}</section>''')
    if aberta:
        cat_comprar = '' if it['categoria_id'] else f'<label>Categoria<select name="categoria" required>{opcoes(cats, None, "Escolha")}</select></label>'
        blocos.append(f'''<div class="grade"><section class="painel"><h2>Comprei</h2>
<form method="post" action="/compras/{cid}/comprar" class="campos">{tk()}
<label>Data<input type="date" name="data" value="{hoje().isoformat()}" required></label>
<label>Pago com<select name="conta" required>{opcoes_agrupadas(g_pag, None, "Escolha")}</select></label>
<label>Valor pago<input name="valor" value="{campo_valor(it['valor_centavos'])}" inputmode="decimal" required></label>
<label>Parcelas<input name="parcelas" value="{it['parcelas']}" inputmode="numeric"></label>{cat_comprar}
<button>Lançar a compra</button></form>
<p class="fraco">Lança a despesa (no cartão, as parcelas caem nas faturas certas) e tira o item do plano.{" Como o item tem frequência de troca, a próxima já entra no plano." if it['vida_util_meses'] else ""}</p>
<form method="post" action="/compras/{cid}/marcar" class="acoes">{tk()}<button class="secundario">Já está lançada (veio na fatura ou extrato)</button></form>
<form method="post" action="/compras/{cid}/desistir" class="acoes">{tk()}<button class="secundario">Desistimos desta compra</button></form>
</section>
<section class="painel"><h2>Editar</h2><form method="post" action="/compras/{cid}" class="campos">{tk()}
{_campos_item(cats, planos_, it)}<button>Salvar</button></form>{dl}</section></div>''')
    else:
        blocos.append(f'''<section class="painel"><form method="post" action="/compras/{cid}/reabrir" class="acoes">{tk()}
<button class="secundario">Voltar para o plano</button></form>
<p class="fraco">Se a compra tem lançamento, exclua o lançamento antes; o plano não apaga dinheiro lançado.</p></section>''')
    blocos.append(f'<section class="painel">{botao_excluir(f"/compras/{cid}/excluir", "Apaga só o item do plano (e as cotações). Lançamentos feitos a partir dele continuam.", "Excluir do plano")}</section>')
    return req.html(it['descricao'], ''.join(blocos), 'Compra planejada')


@rota('POST', r'/compras/(\d+)')
def compra_editar(req):
    with banco.transacao() as c:
        compras.atualizar(c, int(req.parametros[0]), **_dados_item(req))
    ir(f'/compras/{req.parametros[0]}', 'Compra atualizada.')


@rota('POST', r'/compras/(\d+)/comprar')
def compra_comprar(req):
    with banco.transacao() as c:
        item = compras.uma(c, int(req.parametros[0]))
        _, proxima = compras.comprar(c, item['id'], req.f('data'), inteiro(req.f('conta'), 'conta'),
                                     valor=centavos(req.f('valor')), parcelas=inteiro(req.f('parcelas') or '1', 'parcelas'),
                                     categoria_id=opcional_int(req.f('categoria')))
        prox = compras.uma(c, proxima) if proxima else None
    destino = f'/compras/projetos/{item["plano_id"]}' if item['plano_id'] else '/compras'
    ir(destino, 'Compra lançada e retirada do plano.' + (f' Próxima troca planejada para {prox["mes_alvo"][5:]}/{prox["mes_alvo"][:4]}.' if prox else ''))


@rota('POST', r'/compras/(\d+)/marcar')
def compra_marcar(req):
    with banco.transacao() as c:
        item = compras.uma(c, int(req.parametros[0]))
        proxima = compras.marcar_comprada(c, item['id'], hoje=hoje())
    destino = f'/compras/projetos/{item["plano_id"]}' if item['plano_id'] else '/compras'
    ir(destino, 'Marcada como comprada.' + (' Próxima troca planejada.' if proxima else ''))


@rota('POST', r'/compras/(\d+)/desistir')
def compra_desistir(req):
    with banco.transacao() as c:
        compras.desistir(c, int(req.parametros[0]), hoje=hoje())
    ir(f'/compras/{req.parametros[0]}', 'Compra retirada do plano.')


@rota('POST', r'/compras/(\d+)/reabrir')
def compra_reabrir(req):
    with banco.transacao() as c:
        compras.reabrir(c, int(req.parametros[0]))
    ir(f'/compras/{req.parametros[0]}', 'De volta ao plano.')


@rota('POST', r'/compras/(\d+)/excluir')
def compra_excluir(req):
    with banco.transacao() as c:
        item = compras.uma(c, int(req.parametros[0]))
        nome = compras.excluir(c, item['id'])
    ir(f'/compras/projetos/{item["plano_id"]}' if item['plano_id'] else '/compras/lista', f'"{nome}" excluída do plano.')


@rota('POST', r'/compras/(\d+)/cotacoes')
def cotacao_criar(req):
    with banco.transacao() as c:
        compras.adicionar_cotacao(c, int(req.parametros[0]), req.f('loja'), centavos(req.f('valor')),
                                  inteiro(req.f('parcelas') or '1', 'parcelas'), _valor_opcional(req, 'frete'),
                                  req.f('link'), req.f('observacao'), hoje())
    ir(f'/compras/{req.parametros[0]}', 'Cotação guardada.')


@rota('POST', r'/compras/cotacoes/(\d+)/usar')
def cotacao_usar(req):
    with banco.transacao() as c:
        cid = compras.usar_cotacao(c, int(req.parametros[0]))
    ir(f'/compras/{cid}', 'Valor e parcelas da cotação passados para a compra.')


@rota('POST', r'/compras/cotacoes/(\d+)/excluir')
def cotacao_excluir(req):
    with banco.transacao() as c:
        cid = compras.excluir_cotacao(c, int(req.parametros[0]))
    ir(f'/compras/{cid}', 'Cotação removida.')
