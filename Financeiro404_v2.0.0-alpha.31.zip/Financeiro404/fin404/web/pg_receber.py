"""A receber (R3): quem deve quanto, emprestar ou pagar por alguém, registrar devolução."""
from fin404.dados import banco
from fin404.dinheiro import centavos
from fin404.dominio import receber
from fin404.web.base import grupos_contas, hoje, inteiro, ir, opcional_int, pessoas
from fin404.web.componentes import data_br, dinheiro, e, opcoes, opcoes_agrupadas, selo, tabela
from fin404.web.servidor import rota, token_html as tk


@rota('GET', '/receber')
def receber_pagina(req):
    with banco.conexao() as c:
        devem = receber.quem_deve(c, hoje())
        movs = receber.movimentos(c, 50)
        ps = pessoas(c)
        g_origem = grupos_contas(c)
        g_destino = [g for g in grupos_contas(c) if g[0] == 'Contas e dinheiro']
    total = sum(x['aberto'] for x in devem)
    linhas = []
    for x in devem:
        idade = selo(f'{x["dias"]} dias', 'amarelo') if x['dias'] > receber.DIAS_ALERTA else f'{x["dias"]} dias'
        detalhe = '<br>'.join(f'<span class="fraco">{data_br(i["data"])} · {e(i["descricao"])} · '
                              f'{dinheiro(i["restante"])}{" de " + dinheiro(i["valor"]) if i["restante"] != i["valor"] else ""}</span>'
                              for i in x['itens'][:5])
        linhas.append([f'<b>{e(x["nome"])}</b><br>{detalhe}', dinheiro(x['aberto']), data_br(x['desde']), idade,
                       dinheiro(x['devolvido'])])
    hist = [[data_br(m['data']), f'<a href="/lancamentos/{m["id"]}">{e(m["descricao"])}</a>', e(m['nome']),
             selo('emprestado', '') if m['v'] > 0 else selo('devolvido', 'verde'), dinheiro(abs(m['v']))] for m in movs]
    pessoas_abertas = [(x['pessoa_id'], f'{x["nome"]} (deve {dinheiro(x["aberto"])})') for x in devem if x['pessoa_id']]
    corpo = f'''<div class="cartoes"><div class="cartao"><small>Total a receber</small><strong>{dinheiro(total)}</strong>
<em>{len(devem)} pessoa(s) · entra no patrimônio, não no disponível nem na reserva</em></div></div>
<section class="painel"><h2>Quem deve</h2>{tabela(['Pessoa', 'Em aberto', 'Desde', 'Há', 'Já devolveu'], linhas, (1, 4), 'Ninguém deve nada a vocês.', ocultar_movel=(4,))}
<p class="fraco">Devoluções abatem primeiro o que é mais antigo.</p></section>
<div class="grade"><section class="painel"><h2>Emprestei ou paguei por alguém</h2>
<form method="post" action="/receber/emprestar" class="campos">{tk()}
<label>Data<input type="date" name="data" value="{hoje().isoformat()}" required></label>
<label>Quem vai devolver<select name="pessoa">{opcoes(ps, None, "Escolha ou escreva ao lado")}</select></label>
<label>Ou nome<input name="nome" maxlength="60" placeholder="ex.: Mãe, Carlos"></label>
<label>Valor<input name="valor" inputmode="decimal" required></label>
<label>Saiu de<select name="conta" required>{opcoes_agrupadas(g_origem, None, "Escolha")}</select></label>
<label>Descrição<input name="descricao" maxlength="200" placeholder="ex.: ingresso do show, empréstimo"></label>
<button>Registrar</button></form>
<p class="fraco">Não conta como gasto: o dinheiro só mudou de lugar. Se já foi lançado como despesa (por exemplo, veio na fatura),
abra o lançamento e use "Foi para outra pessoa?".</p></section>
<section class="painel"><h2>Recebi de volta</h2>
<form method="post" action="/receber/devolver" class="campos">{tk()}
<label>Data<input type="date" name="data" value="{hoje().isoformat()}" required></label>
<label>Quem devolveu<select name="pessoa" required>{opcoes(pessoas_abertas, None, "Escolha")}</select></label>
<label>Valor<input name="valor" inputmode="decimal" required></label>
<label>Entrou em<select name="conta" required>{opcoes_agrupadas(g_destino, None, "Escolha")}</select></label>
<button>Registrar devolução</button></form>
<p class="fraco">Não conta como receita. Devolução parcial abate só o valor recebido.</p></section></div>
<section class="painel"><h2>Movimentos</h2>{tabela(['Data', 'Descrição', 'Pessoa', '', 'Valor'], hist, (4,), 'Nada registrado ainda.', ocultar_movel=(2,))}</section>'''
    return req.html('Quem nos deve', corpo, 'Dinheiro emprestado ou gasto pago por outras pessoas, que vai voltar.')


@rota('POST', '/receber/emprestar')
def receber_emprestar(req):
    with banco.transacao() as c:
        pid = receber.pessoa(c, opcional_int(req.f('pessoa')), req.f('nome'))
        receber.emprestar(c, req.f('data'), pid, centavos(req.f('valor')), inteiro(req.f('conta'), 'conta'), req.f('descricao'))
    ir('/receber', 'Registrado como valor a receber.')


@rota('POST', '/receber/devolver')
def receber_devolver(req):
    with banco.transacao() as c:
        receber.receber(c, req.f('data'), inteiro(req.f('pessoa'), 'pessoa'), centavos(req.f('valor')),
                        inteiro(req.f('conta'), 'conta'))
    ir('/receber', 'Devolução registrada.')


@rota('POST', r'/lancamentos/(\d+)/a-receber')
def lancamento_a_receber(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        pid = receber.pessoa(c, opcional_int(req.f('pessoa')), req.f('nome'))
        receber.converter_despesa(c, tid, pid)
    ir(f'/lancamentos/{tid}', 'Passou para valores a receber: saiu dos gastos do mês.')
