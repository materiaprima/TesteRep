"""Relatórios do mês e do ano e fluxo de caixa."""
import datetime

from fin404.dados import banco
from fin404.dinheiro import fmt_mes, mes as ler_mes, mes_seguinte, somar_meses
from fin404.dominio import relatorios
from fin404.web.base import (hoje, inteiro, mes_param)
from fin404.web.componentes import aviso, barra, data_br, dinheiro, e, mes_br, selo, tabela
from fin404.web.servidor import rota


# ------------------------------------------------------------------ relatórios e fluxo

@rota('GET', '/relatorios')
def relatorio_mes(req):
    ym = mes_param(req)
    with banco.conexao() as c:
        r = relatorios.resumo_mes(c, ym)
    ant, prox = somar_meses(datetime.date.fromisoformat(ym + '-01'), -1).strftime('%Y-%m'), mes_seguinte(ym)
    nav = (f'<div class="abas"><a href="/relatorios?mes={ant}">← {mes_br(ant)}</a><a class="atual" href="/relatorios?mes={ym}">{mes_br(ym)}</a>'
           f'<a href="/relatorios?mes={prox}">{mes_br(prox)} →</a><a href="/gastos?mes={ym}">Quanto gastei</a><a href="/relatorios/ano?ano={ym[:4]}">Ano {ym[:4]}</a><a href="/relatorios/irpf?ano={ym[:4]}">Imposto de Renda</a><a href="/resumo?mes={ym}">Resumo para imprimir</a></div>')
    td = r['total_despesas'] or 1
    desp = [[f'<a href="/lancamentos?mes={ym}&amp;categoria={i}">{e(n)}</a>', dinheiro(v), f'{v * 100 // td}%', barra(v, td)] for i, n, v in r['despesas']]
    rec = [[f'<a href="/lancamentos?mes={ym}&amp;categoria={i}">{e(n)}</a>', dinheiro(v)] for i, n, v in r['receitas']]
    pes = [[e(n), dinheiro(v)] for n, v in r['por_pessoa']]
    from fin404.dominio.operacoes import FORMAS_PAGAMENTO
    nomes_forma = dict(FORMAS_PAGAMENTO)
    formas = [[e(nomes_forma.get(f, 'Não informada')), dinheiro(v)] for f, v in r['por_forma']]
    corpo = f'''{nav}<div class="cartoes"><div class="cartao"><small>Receitas</small><strong>{dinheiro(r['total_receitas'])}</strong></div>
<div class="cartao"><small>Despesas</small><strong>{dinheiro(r['total_despesas'])}</strong></div>
<div class="cartao"><small>Resultado</small><strong>{dinheiro(r['resultado'], cor=True)}</strong></div>
<div class="cartao"><small>Juros, tarifas e IOF</small><strong>{dinheiro(r['custo_credito'])}</strong><em>{'custo de usar crédito' if r['custo_credito'] else 'nenhum neste mês'}</em></div></div>
<div class="grade"><section class="painel"><h2>Despesas por categoria</h2>{tabela(['Categoria', 'Valor', '%', ''], desp, (1, 2), ocultar_movel=(3,))}</section>
<div><section class="painel"><h2>Receitas</h2>{tabela(['Categoria', 'Valor'], rec, (1,))}</section>
<section class="painel"><h2>Despesas por pessoa</h2>{tabela(['Pessoa', 'Valor'], pes, (1,), 'Cadastre pessoas para ver esta divisão.')}</section>
<section class="painel"><h2>Despesas por forma de pagamento</h2>{tabela(['Forma', 'Valor'], formas, (1,), 'Sem despesas no mês.')}</section></div></div>
<p class="fraco">Despesas entram no mês da compra (no cartão parcelado, no mês de cada parcela). Para ver pela fatura ou pelo
dinheiro que saiu, use <a href="/gastos?mes={ym}">Quanto gastei</a>. Estornos reduzem a categoria.
Transferências e pagamentos de fatura não entram. Previstos não entram.</p>'''
    return req.html(f'Relatório de {fmt_mes(ym)}', corpo)


@rota('GET', '/relatorios/ano')
def relatorio_ano(req):
    ano = inteiro(req.q('ano') or str(hoje().year), 'ano')
    with banco.conexao() as c:
        r = relatorios.resumo_ano(c, ano)
        pos = relatorios.posicao(c)
    linhas = [[f'<a href="/relatorios?mes={m}">{mes_br(m)}</a>', dinheiro(v['receitas']), dinheiro(v['despesas']), dinheiro(v['resultado'], cor=True)]
              for m, v in r['meses'].items()]
    linhas.append(['<b>Total</b>', f'<b>{dinheiro(r["total_receitas"])}</b>', f'<b>{dinheiro(r["total_despesas"])}</b>', f'<b>{dinheiro(r["resultado"], cor=True)}</b>'])
    cats = [[e(n), dinheiro(v), dinheiro(v // 12)] for n, v in r['categorias']]
    taxa = f'{r["taxa_poupanca"]}%' if r['taxa_poupanca'] is not None else '—'
    corpo = f'''<div class="abas"><a href="/relatorios/ano?ano={ano - 1}">← {ano - 1}</a><a class="atual" href="#">{ano}</a><a href="/relatorios/ano?ano={ano + 1}">{ano + 1} →</a><a href="/relatorios/irpf?ano={ano}">Imposto de Renda {ano}</a></div>
<div class="cartoes"><div class="cartao"><small>Resultado do ano</small><strong>{dinheiro(r['resultado'], cor=True)}</strong><em>taxa de poupança {taxa}</em></div>
<div class="cartao"><small>Juros, tarifas e IOF</small><strong>{dinheiro(r['juros_tarifas'])}</strong><em>custo financeiro no ano{' · <a href="/simulador">simular saída</a>' if r['juros_tarifas'] else ''}</em></div>
<div class="cartao"><small>Patrimônio líquido hoje</small><strong>{dinheiro(pos['patrimonio_liquido'], cor=True)}</strong></div></div>
<div class="grade"><section class="painel"><h2>Mês a mês</h2>{tabela(['Mês', 'Receitas', 'Despesas', 'Resultado'], linhas, (1, 2, 3))}</section>
<section class="painel"><h2>Para onde foi o dinheiro</h2>{tabela(['Categoria', 'No ano', 'Média/mês'], cats, (1, 2))}</section></div>'''
    return req.html(f'Retrospectiva {ano}', corpo)


@rota('GET', '/fluxo')
def fluxo(req):
    dias = inteiro(req.q('dias') or '90', 'número de dias')
    dias = max(7, min(dias, 730))
    with banco.conexao() as c:
        f = relatorios.fluxo_caixa(c, dias)
    linhas = [[data_br(l['data']), e(l['descricao']), selo(l['tipo'], {'previsto': 'amarelo', 'fatura': ''}.get(l['tipo'], 'verde')),
               dinheiro(l['valor'], cor=True), dinheiro(l['saldo'], cor=l['saldo'] < 0)] for l in f['linhas']]
    abas = '<div class="abas">' + ''.join(f'<a href="/fluxo?dias={d}"{" class=atual" if d == dias else ""}>{d} dias</a>' for d in (30, 90, 180, 365)) + '</div>'
    alerta = aviso(f'O saldo projetado fica negativo em {f["menor_data"].strftime("%d/%m/%Y")}.', 'erro') if f['menor_saldo'] < 0 else ''
    corpo = f'''{abas}{alerta}<div class="cartoes"><div class="cartao"><small>Disponível hoje</small><strong>{dinheiro(f['inicial'])}</strong></div>
<div class="cartao"><small>Menor saldo no período</small><strong>{dinheiro(f['menor_saldo'], cor=f['menor_saldo'] < 0)}</strong><em>em {data_br(f['menor_data'])}</em></div>
<div class="cartao"><small>Saldo em {data_br(f['ate'])}</small><strong>{dinheiro(f['final'], cor=True)}</strong></div></div>
<section class="painel">{tabela(['Data', 'Descrição', 'Origem', 'Valor', 'Saldo projetado'], linhas, (3, 4), 'Nada previsto no período. Cadastre previsões.', ocultar_movel=(2,))}</section>
<p class="fraco">Considera as contas disponíveis (corrente, poupança, dinheiro, carteira), as previsões cadastradas, lançamentos com data futura
e o pagamento integral de cada fatura no vencimento (faturas futuras: só as compras e parcelas já lançadas).</p>'''
    return req.html('Fluxo de caixa', corpo)


# ------------------------------------------------------------------ quanto gastei no mês (três jeitos de olhar)

EXPLICA_VISAO = {
    'fatura': 'No cartão, conta a fatura que <strong>fechou</strong> no mês: é o que o banco cobrou. Fora do cartão (Pix, débito, '
              'dinheiro), conta a data do gasto. É o jeito que bate com o papel da fatura.',
    'compra': 'Tudo pela data da compra; no parcelado, cada parcela no mês dela. As compras dos últimos dias do mês só chegam na '
              'fatura seguinte, então o mês só fica completo depois que ela for importada.',
    'caixa': 'O dinheiro que saiu das contas no mês: gastos fora do cartão e pagamentos de fatura e de dívidas. Compras no cartão '
             'só aparecem aqui quando a fatura é paga.',
}


def _mes_padrao(req):
    return mes_param(req, padrao=somar_meses(hoje().replace(day=1), -1).strftime('%Y-%m'))   # sem escolha: o mês que acabou


@rota('GET', '/gastos')
def gastos_mes(req):
    ym = _mes_padrao(req)
    ver = req.q('ver') if req.q('ver') in relatorios.VISOES else 'fatura'
    ate = ler_mes(req.q('ate')) if req.q('ate') else ym
    if ate < ym:
        ym, ate = ate, ym
    periodo = ate != ym
    with banco.conexao() as c:
        r = relatorios.gastos_periodo(c, ym, ate, ver)
    ate = r['ate']
    q_ate = f'&amp;ate={ate}' if periodo else ''
    ant, prox = somar_meses(datetime.date.fromisoformat(ym + '-01'), -1).strftime('%Y-%m'), mes_seguinte(ym)
    nav = '' if periodo else (
        f'<div class="abas"><a href="/gastos?mes={ant}&amp;ver={ver}">← {mes_br(ant)}</a><a class="atual" href="#">{mes_br(ym)}</a>'
        f'<a href="/gastos?mes={prox}&amp;ver={ver}">{mes_br(prox)} →</a></div>')
    nome_periodo = f'de {mes_br(ym)} a {mes_br(ate)}' if periodo else f'em {mes_br(ym)}'
    form_periodo = (f'<form method="get" class="campos painel periodo"><input type="hidden" name="ver" value="{e(ver)}">'
                    f'<label>De<input type="month" name="mes" value="{e(ym)}" required></label>'
                    f'<label>Até<input type="month" name="ate" value="{e(ate)}"></label><button class="secundario">Ver período</button>'
                    + (f' <a href="/gastos?mes={ate}&amp;ver={ver}">Só um mês</a>' if periodo else '') + '</form>')
    lentes = '<div class="abas">' + ''.join(f'<a href="/gastos?mes={ym}{q_ate}&amp;ver={k}"{" class=atual" if k == ver else ""}>{e(v)}</a>'
                                            for k, v in relatorios.VISOES.items()) + '</div>'
    tot = r['total'] or 1
    cats = [[f'<a href="/gastos/itens?mes={ym}{q_ate}&amp;ver={ver}&amp;categoria={x["id"]}">{e(x["nome"])}</a>', str(x['n']), dinheiro(x['v']),
             f'{x["v"] * 100 // tot}%', barra(x['v'], tot)] for x in r['categorias']]
    cats += [[f'Pagamento: {e(n)}', str(q), dinheiro(v), f'{v * 100 // tot}%', barra(v, tot)] for n, v, q in r['pagamentos']]
    subt = ''.join(f'<div class="cartao"><small>{e(n)}</small><strong>{dinheiro(v)}</strong></div>' for n, v in r['subtotais']) \
        if len(r['subtotais']) > 1 or r['pagamentos'] else ''
    if r['pagamentos']:
        subt += f'<div class="cartao"><small>Pagamentos de fatura e dívidas</small><strong>{dinheiro(sum(v for _, v, _ in r["pagamentos"]))}</strong></div>'
    faltando = ''
    if r['faltando']:
        faltando = ('<div class="aviso atencao"><strong>Este total ainda está incompleto.</strong><ul>'
                    + ''.join(f'<li>{e(f)}</li>' for f in r['faltando']) + '</ul></div>')
    explica = ''
    if r['explica']:
        explica = '<ul class="fraco">' + ''.join(f'<li>{e(x)}</li>' for x in r['explica']) + '</ul>'
    conf = ''
    for f in r.get('faturas', []):
        k = f['cartao']
        partes = [('Gasto deste ciclo: compras menos estornos (entra em Quanto gastei)', f['compras'] - f['estornos'])]
        if f['saldo_anterior']:
            partes.insert(0, ('Saldo anterior (o que vinha da fatura anterior)', f['saldo_anterior']))
        if f['pagos_no_ciclo']:
            partes.append(('Pagamentos feitos dentro do ciclo', -f['pagos_no_ciclo']))
        linhas_c = [[e(n), dinheiro(v, cor=v < 0)] for n, v in partes] + [['<strong>Fatura no app</strong>', f'<strong>{dinheiro(f["valor"])}</strong>']]
        if f['documento'] is not None:
            linhas_c.append(['No PDF / papel do banco', dinheiro(f['documento'])])
            if f['diferenca']:
                linhas_c.append(['<span class="neg">Diferença</span>', dinheiro(f['diferenca'], cor=True)])
        link = f'/cartoes/{k["id"]}/fatura/{f["fechamento"].isoformat()}'
        dica = ('' if f['documento'] is not None else
                f'<p class="fraco">Para conferir com o banco, informe o total do papel em <a href="{link}#documento">Total segundo o banco</a>.</p>')
        conf += (f'<section class="painel"><h2>Conferir com a fatura: {e(k["nome"])} (fecha {data_br(f["fechamento"])})</h2>'
                 f'{tabela(["", "Valor"], linhas_c, (1,))}{dica}<p class="fraco">Quanto gastei mostra só o gasto do ciclo. '
                 f'O valor cobrado pelo banco soma também o que ficou da fatura anterior e os encargos; por isso os dois podem ser diferentes. '
                 f'<a href="{link}">Ver a fatura linha a linha →</a></p></section>')
    mes_a_mes = ''
    if periodo:
        n_meses = len(r['meses'])
        mes_a_mes = (f'<section class="painel"><h2>Mês a mês</h2>' + tabela(['Mês', 'Gasto', ''], [
            [f'<a href="/gastos?mes={m}&amp;ver={ver}">{mes_br(m)}</a>', dinheiro(v), barra(v, max(x for _, x in r['meses']) or 1)]
            for m, v in r['meses']] + [['<strong>Média por mês</strong>', f'<strong>{dinheiro(r["total"] // n_meses)}</strong>', '']],
            (1,), ordenar=False) + '</section>')
    corpo = f'''{form_periodo}{nav}{lentes}<p>{EXPLICA_VISAO[ver]}</p>{explica}
<div class="cartoes"><div class="cartao"><small>Gasto {nome_periodo}</small><strong>{dinheiro(r['total'])}</strong>
<em>{e(relatorios.VISOES[ver].lower())}</em></div>{subt}</div>
{faltando}
<section class="painel"><h2>Por categoria</h2>{tabela(['Categoria', 'Lançamentos', 'Valor', '%', ''], cats, (1, 2, 3), 'Nenhum gasto neste período, neste jeito de olhar.', ocultar_movel=(1, 4))}
<p class="fraco">Clique numa categoria para ver cada lançamento e a data em que ele entrou na conta. Transferências entre contas,
previstos ainda não confirmados e o dinheiro guardado não são gasto.</p></section>{mes_a_mes}{conf}'''
    return req.html('Quanto gastei', corpo, 'O mesmo mês pode ter três totais diferentes, e todos estão certos: depende da pergunta.')


@rota('GET', '/gastos/itens')
def gastos_itens(req):
    ym = mes_param(req)
    ver = req.q('ver') if req.q('ver') in relatorios.VISOES else 'fatura'
    ate = ler_mes(req.q('ate')) if req.q('ate') else None
    cat = inteiro(req.q('categoria'), 'categoria')
    from fin404.dominio import razao
    with banco.conexao() as c:
        nome = razao.conta(c, cat)['nome']
        itens = relatorios.gastos_itens(c, ym, ver, cat, ate)
    linhas = []
    for t in itens:
        dif = t['data_banco'] and t['data_banco'] != t['data']
        nota = (f'<br><small class="fraco">no banco: {data_br(t["data_banco"])}'
                f'{" (parcela)" if t["parcela_n"] else " (entrou no ciclo da fatura)"}</small>') if dif else ''
        linhas.append([data_br(t['data']) + nota, f'<a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a>', e(t['conta'] or ''), dinheiro(t['v'])])
    q_ate = f'&amp;ate={ate}' if ate and ate != ym else ''
    periodo_txt = f'de {mes_br(ym)} a {mes_br(ate)}' if q_ate else f'em {mes_br(ym)}'
    corpo = (f'<p><a href="/gastos?mes={ym}{q_ate}&amp;ver={ver}">← Quanto gastei {periodo_txt} ({e(relatorios.VISOES[ver].lower())})</a></p>'
             f'<section class="painel">{tabela(["Data no app", "Descrição", "Conta ou cartão", "Valor"], linhas, (3,), "Nada aqui.")}'
             f'<p class="fraco">Total: {dinheiro(sum(t["v"] for t in itens))}. Se uma data estiver errada, abra o lançamento e corrija; '
             f'o total do mês muda junto.</p></section>')
    return req.html(f'{nome} — {fmt_mes(ym)}' + (f' a {fmt_mes(ate)}' if q_ate else ''), corpo)


@rota('GET', '/mes/atual')
def mes_atual_rota(req):
    """Esquece o mês escolhido: todas as páginas voltam ao mês de hoje."""
    from fin404.web.servidor import Redirecionar
    volta = req.q('volta') or '/'
    if not volta.startswith('/') or volta.startswith('//'):
        volta = '/'
    raise Redirecionar(volta, {'Set-Cookie': 'fin404_mes=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0'})
