"""Peças de HTML. Todo texto vindo de dados passa por `e()` (escape)."""
import contextvars
import decimal
import html
import re
import logging
import urllib.parse

from fin404 import VERSAO
from fin404.dinheiro import fmt_data, fmt_mes, formatar, para_campo

# Sete áreas, cada uma com as suas abas (o menu cabe na tela sem rolar; sem JavaScript, rolar o menu se perde a cada clique).
# (chave, nome no menu, ícone, abas[(endereço, nome)])
AREAS = [
    ('inicio', 'Início', 'casa', [('/', 'Início'), ('/devo', 'Em aberto')]),
    ('lancamentos', 'Lançamentos', 'lista', [('/lancamentos', 'Lista'), ('/novo', 'Novo'), ('/lote', 'Vários de uma vez'),
                                             ('/confirmar', 'A pagar e receber'), ('/importar', 'Importar fatura ou extrato')]),
    ('cartoes', 'Cartões', 'cartao', [('/cartoes', 'Faturas'), ('/parcelamentos', 'Parcelamentos'), ('/simulador', 'Simulador de dívidas')]),
    ('analises', 'Para onde foi', 'grafico', [('/gastos', 'Quanto gastei'), ('/relatorios', 'Mês'), ('/relatorios/ano', 'Ano'),
                                              ('/fluxo', 'Fluxo de caixa'), ('/evolucao', 'Evolução'), ('/raio-x', 'Raio-X'),
                                              ('/recorrentes', 'Cobranças fixas')]),
    ('planejar', 'Planejar', 'calendario', [('/proximos', 'Próximos meses'), ('/orcamento', 'Orçamento'), ('/metas', 'Metas'), ('/previsoes', 'Previsões'),
                                            ('/prazos', 'Prazos e garantias'), ('/fechamento', 'Fechamento do mês'),
                                            ('/reuniao', 'Reunião do mês')]),
    ('compras', 'Compras', 'carrinho', [('/compras', 'Visão geral'), ('/compras/projetos', 'Projetos'), ('/compras/lista', 'Lista de compras'),
                                        ('/compras/historico', 'Comprados'), ('/notas', 'Notas fiscais'), ('/precos', 'Preços')]),
    ('ajustes', 'Ajustes', 'ajustes', [('/contas', 'Contas e dívidas'), ('/categorias', 'Categorias'), ('/pessoas', 'Pessoas'),
                                       ('/receber', 'Quem nos deve'), ('/tags', 'Tags'), ('/backup', 'Backup e segurança'),
                                       ('/lixeira', 'Lixeira')]),
]
# Páginas que não são abas, mas pertencem a uma (o caminho mostra de onde vieram).
DENTRO_DE = {'/importacoes': '/importar', '/regras': '/importar', '/resumo': '/relatorios', '/relatorios/irpf': '/relatorios/ano',
             '/integridade': '/backup', '/restaurar': '/backup', '/migrar': '/backup', '/gastos/itens': '/gastos'}
ICONES = {   # traço simples, desenhado aqui (sem fonte de ícones de fora)
    'casa': '<path d="M3 11l9-7 9 7"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    'lista': '<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6h1M4 12h1M4 18h1"/>',
    'cartao': '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/>',
    'grafico': '<path d="M12 3v9h9"/><path d="M20.5 15A9 9 0 1 1 9 3.5"/>',
    'calendario': '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
    'carrinho': '<path d="M3 4h2l2.5 11h11l2-8H6.3"/><circle cx="9" cy="20" r="1"/><circle cx="18" cy="20" r="1"/>',
    'ajustes': '<path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h11M19 18h1"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="17" cy="18" r="2"/>',
}


def icone(nome):
    return (f'<svg class="icone" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" '
            f'stroke-linecap="round" stroke-linejoin="round">{ICONES[nome]}</svg>')


def onde_estou(caminho):
    """(área, aba) do caminho: a aba de endereço exato ou o prefixo mais longo; páginas soltas pela tabela DENTRO_DE."""
    melhor, tam = None, -1
    alvo = caminho
    for prefixo, aba in DENTRO_DE.items():
        if caminho == prefixo or caminho.startswith(prefixo + '/'):
            alvo = aba
            break
    for area in AREAS:
        for href, nome in area[3]:
            if alvo == href or (href != '/' and alvo.startswith(href + '/')):
                if len(href) > tam:
                    melhor, tam = (area, (href, nome)), len(href)
    return melhor or (AREAS[0], AREAS[0][3][0])


def campo_csrf():
    from fin404.web.servidor import token_html
    return token_html()


def e(x):
    return html.escape('' if x is None else str(x), quote=True)


def dinheiro(cent, cor=False):
    if cent is None:
        return '<span class="fraco">—</span>'
    classe = ('v pos' if cent > 0 else 'v neg' if cent < 0 else 'v') if cor else 'v'
    return f'<span class="{classe}">{e(formatar(cent))}</span>'


def campo_valor(cent):
    return '' if cent is None else para_campo(cent)


def data_br(d):
    return e(fmt_data(d)) if d else ''


def mes_br(ym):
    return e(fmt_mes(ym))


def opcoes(itens, selecionado=None, vazio=None):
    partes = [f'<option value="">{e(vazio)}</option>'] if vazio is not None else []
    for valor, rotulo in itens:
        sel = ' selected' if str(valor) == str(selecionado) else ''
        partes.append(f'<option value="{e(valor)}"{sel}>{e(rotulo)}</option>')
    return ''.join(partes)


def opcoes_agrupadas(grupos, selecionado=None, vazio=None):
    partes = [f'<option value="">{e(vazio)}</option>'] if vazio is not None else []
    for nome, itens in grupos:
        if itens:
            partes.append(f'<optgroup label="{e(nome)}">{opcoes(itens, selecionado)}</optgroup>')
    return ''.join(partes)


def aviso(texto, tipo='info'):
    return f'<div class="aviso {tipo}">{e(texto)}</div>' if texto else ''


def botao_excluir(acao, aviso_texto, rotulo='Excluir'):
    """Exclusão em dois passos, sem JavaScript: abre o aviso e só então mostra o botão definitivo."""
    return (f'<details class="excluir"><summary>{e(rotulo)}…</summary><p>{e(aviso_texto)}</p>'
            f'<form method="post" action="{e(acao)}">{campo_csrf()}<button class="perigo">Excluir de vez</button></form></details>')


def selo(texto, cor=''):
    return f'<span class="selo {cor}">{e(texto)}</span>'


_RE_TAG = re.compile(r'<[^>]+>')


_RE_DATA_BR = re.compile(r'\b(\d{2})/(\d{2})/(\d{4})\b')
_RE_VALOR_BR = re.compile(r'(−|-)?\s*R\$\s*(\d{1,3}(?:\.\d{3})*,\d{2})')


def _chave_ordem(celula):
    """Chave para ordenar uma célula pelo que ela mostra: data, valor em reais, número ou texto."""
    texto = html.unescape(_RE_TAG.sub(' ', str(celula))).strip()
    m = _RE_VALOR_BR.search(texto)
    if m:
        v = int(m.group(2).replace('.', '').replace(',', ''))
        return (0, -v if m.group(1) else v, '')
    m = _RE_DATA_BR.search(texto)
    if m:
        return (1, 0, f'{m.group(3)}-{m.group(2)}-{m.group(1)}')
    num = texto.replace('.', '').replace(',', '.')
    try:
        return (0, decimal.Decimal(num), '')
    except (decimal.InvalidOperation, ValueError):
        return (2, 0, texto.lower())


REQ_ATUAL = contextvars.ContextVar('req_atual', default=None)   # o servidor põe a requisição aqui (para ordenar tabelas)
_N_TABELA = contextvars.ContextVar('n_tabela', default=0)


def tabela(cabecalho, linhas, numericas=(), vazio='Nada por aqui ainda.', ocultar_movel=(), ordenar=True):
    """Tabela simples. `ocultar_movel`: índices de colunas escondidas em telas estreitas.
    Com 3 linhas ou mais, os títulos viram links que ordenam pela coluna (clicar de novo inverte); cada tabela da página
    tem o seu parâmetro (o1, o2…). Linha de total (primeira célula em <strong>) fica sempre no fim. `ordenar=False` desliga."""
    if not linhas:
        return f'<div class="vazio">{e(vazio)}</div>'
    req = REQ_ATUAL.get()
    if ordenar is True:
        ordenar = req if req is not None and len(linhas) >= 3 else None
    elif ordenar is False:
        ordenar = None

    def cls(i):
        nomes = (['n'] if i in numericas else []) + (['m-oculta'] if i in ocultar_movel else [])
        return f' class="{" ".join(nomes)}"' if nomes else ''
    th = ''.join(f'<th scope="col"{cls(i)}>{e(h)}</th>' for i, h in enumerate(cabecalho))
    if ordenar is not None:
        n = _N_TABELA.get() + 1
        _N_TABELA.set(n)
        nome = f'o{n}'
        pedido = re.fullmatch(r'(\d{1,2})([ad])', ordenar.q(nome))
        col = int(pedido.group(1)) if pedido and int(pedido.group(1)) < len(cabecalho) else None
        desc = bool(pedido) and pedido.group(2) == 'd'
        if col is not None:
            fixas = [l for l in linhas if str(l[0]).startswith('<strong>')]
            soltas = [l for l in linhas if not str(l[0]).startswith('<strong>')]
            linhas = sorted(soltas, key=lambda l: _chave_ordem(l[col]), reverse=desc) + fixas
        base = {k: v[0] for k, v in ordenar.consulta.items() if k not in (nome, 'msg') and v}

        def titulo(i, h):
            if not h:
                return f'<th scope="col"{cls(i)}></th>'
            atual = col == i
            prox = 'a' if atual and desc else 'd' if atual else 'a'
            seta = (' ↓' if desc else ' ↑') if atual else ''
            href = '?' + urllib.parse.urlencode({**base, nome: f'{i}{prox}'})
            rotulo = f'Ordenar por {h}' + (', ordem inversa' if atual else '')
            return (f'<th scope="col"{cls(i)}{" aria-sort=" + chr(34) + ("descending" if desc else "ascending") + chr(34) if atual else ""}>'
                    f'<a class="ordenar" href="{e(href)}" title="{e(rotulo)}">{e(h)}{seta}</a></th>')
        th = ''.join(titulo(i, h) for i, h in enumerate(cabecalho))

    def td(i, c):
        # célula curta (data, valor, selo, link curto) não quebra linha: "fecha 27/10/2026" fica numa linha só
        texto = _RE_TAG.sub('', str(c))
        curta = len(texto.strip()) <= 26 and '<form' not in str(c) and '<br' not in str(c)
        nomes = (['n'] if i in numericas else []) + (['m-oculta'] if i in ocultar_movel else []) + (['nw'] if curta else [])
        return f'<td class="{" ".join(nomes)}">{c}</td>' if nomes else f'<td>{c}</td>'
    corpo = ''.join('<tr>' + ''.join(td(i, c) for i, c in enumerate(l)) + '</tr>' for l in linhas)
    return f'<table><thead><tr>{th}</tr></thead><tbody>{corpo}</tbody></table>'


def barra(parte, total):
    """Barra de progresso sem CSS inline (compatível com a CSP restrita)."""
    if not total:
        return ''
    classe = 'barra estouro' if parte > total else 'barra'
    return f'<progress class="{classe}" max="{total}" value="{max(0, min(parte, total))}"></progress>'


def com_msg(caminho, msg):
    sep = '&' if '?' in caminho else '?'
    return caminho + sep + 'msg=' + urllib.parse.quote(msg)


TEMAS = (('auto', 'Automático'), ('claro', 'Claro'), ('escuro', 'Escuro'))


def tema():
    import sqlite3
    from fin404.dados import banco, config
    try:
        t = config.obter('tema', 'auto')
    except (banco.ErroBanco, sqlite3.Error):  # banco pausado (restauração em andamento): usa o padrão
        t = 'auto'
    except Exception:  # qualquer outra coisa é defeito: registra, mas não derruba a página por causa do tema
        logging.getLogger('fin404').exception('Falha ao ler o tema')
        t = 'auto'
    return t if t in dict(TEMAS) else 'auto'


def _seletor_tema(atual):
    botoes = ''.join(f'<button name="tema" value="{v}" aria-pressed="{"true" if v == atual else "false"}">{e(n)}</button>' for v, n in TEMAS)
    return f'<form method="post" action="/preferencias/tema" class="tema">{campo_csrf()}<span>Aparência:</span>{botoes}</form>'


def pagina_simples(titulo, corpo):
    return f'''<!doctype html><html lang="pt-BR" class="{tema()}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(titulo)} · Financeiro 404</title><link rel="stylesheet" href="/static/app.css"><link rel="icon" href="/static/icone.svg"></head>
<body class="simples"><main class="cartao-entrada"><div class="marca"><b>404</b><span>Financeiro 404<small>gestão familiar</small></span></div>{corpo}</main></body></html>'''


def pagina(titulo, corpo, caminho_atual='/', msg='', subtitulo='', sair=False, mes_fixado=None):
    area, (aba_href, aba_nome) = onde_estou(caminho_atual)
    chave, nome_area, ic, abas = area
    itens = []
    for a in AREAS:
        atual = a[0] == chave
        marca = ' class="atual" aria-current="page"' if atual else ''
        itens.append(f'<a href="{a[3][0][0]}"{marca}>{icone(a[2])}<span>{e(a[1])}</span></a>')
    nav = ''.join(itens)
    barra_abas = ''
    if len(abas) > 1:
        barra_abas = ('<nav class="abas-area" aria-label="' + e(nome_area) + '">'
                      + ''.join(f'<a href="{h}"{" class=atual aria-current=page" if h == aba_href else ""}>{e(n)}</a>' for h, n in abas)
                      + '</nav>')
    caminho_txt = f'<a href="{abas[0][0]}">{e(nome_area)}</a>'
    if len(abas) > 1 and (aba_href != abas[0][0] or caminho_atual != aba_href):
        caminho_txt += f' <span aria-hidden="true">›</span> <a href="{aba_href}">{e(aba_nome)}</a>'
    if caminho_atual != aba_href and titulo != aba_nome:
        caminho_txt += f' <span aria-hidden="true">›</span> <span>{e(titulo)}</span>'
    fixado = ''
    if mes_fixado:
        fixado = (f'<span class="mes-fixado">Vendo <b>{e(mes_br(mes_fixado))}</b> · '
                  f'<a href="/mes/atual?volta={urllib.parse.quote(aba_href or caminho_atual)}">voltar ao mês atual</a></span>')
    sub = f'<p class="sub">{e(subtitulo)}</p>' if subtitulo else ''
    t = tema()
    return f'''<!doctype html><html lang="pt-BR" class="{t}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{e(titulo)} · Financeiro 404</title><link rel="stylesheet" href="/static/app.css"><link rel="icon" href="/static/icone.svg"></head><body class="area-{chave}"><a class="pular" href="#conteudo">Pular para o conteúdo</a><div class="app">
<aside class="lateral" aria-label="Menu"><div class="marca"><b>404</b><span>Financeiro 404<small>gestão familiar</small></span></div><nav class="nav-areas">{nav}</nav><a class="lancar-movel" href="/novo">+ Novo lançamento</a></aside>
<div><div class="topo"><span class="local">● Somente neste computador (127.0.0.1)</span>{fixado}<span class="acoes">{'<form method="post" action="/sair" class="form-sair">' + campo_csrf() + '<button class="secundario">Bloquear</button></form>' if sair else ''}<a class="botao-link" href="/novo">+ Novo lançamento</a></span></div>
<main id="conteudo" tabindex="-1">{'' if chave == 'inicio' and caminho_atual == '/' else f'<p class="caminho">{icone(ic)} {caminho_txt}</p>'}{barra_abas}<h1>{e(titulo)}</h1>{sub}{aviso(msg, 'ok flash')}{_blocos(corpo)}</main><div class="rodape">Financeiro 404 v{e(VERSAO)} · dados locais · faça backups cifrados {_seletor_tema(t)}</div></div></div></body></html>'''


_RE_BLOCO = re.compile(r'<(section|details)\b([^>]*\bclass="[^"]*\bpainel\b[^"]*"[^>]*)>|<form\b([^>]*\bmethod="post"[^>]*)>')


def _blocos(corpo):
    """Dá um id a cada painel e põe nos formulários de envio o painel de onde vieram, para a página voltar a ele depois de salvar."""
    n, atual = 0, ''

    def troca(m):
        nonlocal n, atual
        if m.group(1):
            attrs = m.group(2)
            achado = re.search(r'\bid="([^"]+)"', attrs)
            if achado:
                atual = achado.group(1)
                return m.group(0)
            n += 1
            atual = f'b{n}'
            return f'<{m.group(1)} id="{atual}"{attrs}>'
        if not atual:
            return m.group(0)
        return m.group(0) + f'<input type="hidden" name="_bloco" value="{atual}">'
    return _RE_BLOCO.sub(troca, corpo)


# ---------------------------------------------------------------- gráficos (SVG desenhado no servidor, sem JavaScript)

CENTAVOS_POR_REAL = 100
MESES_CURTOS = ('jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez')


def mes_curto(ym):
    return f'{MESES_CURTOS[int(ym[5:7]) - 1]}/{ym[2:4]}'


def _compacto(centavos_):
    reais, _ = divmod(abs(centavos_), CENTAVOS_POR_REAL)
    sinal = '−' if centavos_ < 0 else ''
    if reais >= 1_000_000:
        return f'{sinal}{reais // 1_000_000} mi'
    if reais >= 1000:
        mil, resto = divmod(reais, 1000)
        return f'{sinal}{mil},{resto // CENTAVOS_POR_REAL} mil' if mil < 10 and resto >= CENTAVOS_POR_REAL else f'{sinal}{mil} mil'
    return f'{sinal}{reais}'


def _passo(intervalo):
    """Passo 'redondo' (1, 2, 2,5 ou 5 × 10^n) para dividir o eixo em cerca de 4 partes."""
    bruto = max(intervalo // 4, 1)
    mag = 10 ** (len(str(bruto)) - 1)
    for m in (1, 2, 5, 10):
        if bruto <= m * mag:
            return m * mag
    return 10 * mag


def grafico_linhas(rotulos, series, altura=230):
    """Gráfico de linhas em SVG. `series` = [(nome, [valores em centavos])]. Passe o mouse num ponto para ver o valor."""
    todos = [v for _, vals in series for v in vals]
    if not todos or not rotulos:
        return '<div class="vazio">Sem dados para o gráfico ainda.</div>'
    largura, esq, dir_, topo, base = 720, 64, 30, 12, 26
    vmin, vmax = min(min(todos), 0), max(max(todos), 0)
    if vmin == vmax:
        vmax = vmin + 10000
    passo = _passo(vmax - vmin)
    vmin = (vmin // passo) * passo
    vmax = -((-vmax) // passo) * passo
    alt_util, larg_util = altura - topo - base, largura - esq - dir_

    def y(v):
        return topo + alt_util - (v - vmin) * alt_util / (vmax - vmin)

    def x(i):
        return esq + (larg_util * i / (len(rotulos) - 1) if len(rotulos) > 1 else larg_util / 2)
    partes = []
    v = vmin
    while v <= vmax:
        partes.append(f'<line class="{"g-zero" if v == 0 else "g-grade"}" x1="{esq}" x2="{largura - dir_}" y1="{y(v):.1f}" y2="{y(v):.1f}"/>'
                      f'<text class="g-txt" x="{esq - 6}" y="{y(v) + 4:.1f}" text-anchor="end">{_compacto(v)}</text>')
        v += passo
    pulo = max(1, -(-len(rotulos) // 12))
    for i, r in enumerate(rotulos):
        if i % pulo == 0 or i == len(rotulos) - 1:
            partes.append(f'<text class="g-txt" x="{x(i):.1f}" y="{altura - 8}" text-anchor="middle">{e(r)}</text>')
    for k, (nome, vals) in enumerate(series):
        pontos = ' '.join(f'{x(i):.1f},{y(v):.1f}' for i, v in enumerate(vals))
        partes.append(f'<polyline class="g-linha serie-{k}" points="{pontos}"/>')
        for i, v in enumerate(vals):
            partes.append(f'<circle class="g-ponto serie-{k}" cx="{x(i):.1f}" cy="{y(v):.1f}" r="3.5">'
                          f'<title>{e(nome)} · {e(rotulos[i])}: {e(formatar(v))}</title></circle>')
    legenda = ''.join(f'<span class="leg serie-{k}">{e(nome)}</span>' for k, (nome, _) in enumerate(series)) if len(series) > 1 else ''
    resumo = '; '.join(f'{nome}: de {formatar(vals[0])} a {formatar(vals[-1])}' for nome, vals in series)
    return (f'<figure class="grafico"><svg viewBox="0 0 {largura} {altura}" role="img" aria-label="{e(resumo)}">{"".join(partes)}</svg>'
            f'{f"<figcaption>{legenda}</figcaption>" if legenda else ""}</figure>')
