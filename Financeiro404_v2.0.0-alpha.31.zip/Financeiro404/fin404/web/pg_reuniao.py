"""Reunião do mês (R13): uma página para imprimir ou olhar juntos, com o registro das decisões."""
from fin404.dados import banco
from fin404.dinheiro import mes as ler_mes, somar_meses
from fin404.dominio import reuniao
from fin404.web.base import hoje, ir
from fin404.web.componentes import data_br, dinheiro, e, mes_br, selo
from fin404.web.servidor import rota, token_html as tk


@rota('GET', '/reuniao')
def reuniao_pagina(req):
    from fin404.web.base import mes_param
    ym = mes_param(req, padrao=somar_meses(hoje().replace(day=1), -1).strftime('%Y-%m'))
    with banco.conexao() as c:
        p = reuniao.pauta(c, ym, hoje())
        hist = reuniao.historico(c)
    r, rx = p['resumo'], p['raio_x']
    meses = [somar_meses(hoje().replace(day=1), -i).strftime('%Y-%m') for i in range(5, -1, -1)]
    feitas = {h['mes'] for h in hist}
    abas = '<div class="abas">' + ''.join(f'<a href="/reuniao?mes={m}"{" class=atual" if m == ym else ""}>{mes_br(m)}{" ✓" if m in feitas else ""}</a>'
                                         for m in meses) + '</div>'
    cob = rx['cobertura_minimo']
    reserva = (f'{cob // 10},{cob % 10} meses' if cob is not None and rx['custo_minimo'] > 0 else 'sem dados de gasto ainda')
    compras_li = ''.join(
        f'<li>{e(it["descricao"])}: {dinheiro(it["valor_centavos"])} em {mes_br(it["mes_alvo"])} · '
        + (selo('cabe', 'verde') if it['cabe'] else selo('não cabe', 'vermelho') if it['cabe'] is False else selo('sem renda para comparar'))
        + '</li>' for it in p['proximas']) or '<li class="fraco">Nada planejado para os próximos 3 meses.</li>'
    alertas_li = ''.join(f'<li>{e(txt)}</li>' for _, txt in p['alertas']) or '<li class="fraco">Nada urgente.</li>'
    reg = p['registro']
    sugestoes = '\n'.join('- ' + x for x in p['sugestoes'])
    texto = reg['decisoes'] if reg else sugestoes
    registro_html = (f'<p>{selo("reunião feita", "verde")} em {data_br(reg["feita_em"])}</p>'
                     f'<div class="decisoes">{"<br>".join(e(l) for l in reg["decisoes"].splitlines()) or "<span class=fraco>sem decisões anotadas</span>"}</div>'
                     if reg else '<p class="fraco">Ainda não registrada.</p>')
    corpo = f'''{abas}<div class="cartoes">
<div class="cartao"><small>{mes_br(ym)}: sobrou ou faltou</small><strong>{dinheiro(r['resultado'], cor=True)}</strong>
<em>{dinheiro(r['total_receitas'])} entrou · {dinheiro(r['total_despesas'])} saiu ({dinheiro(r['despesas_no_cartao'])} no cartão)</em></div>
<div class="cartao"><small>A reserva cobre</small><strong>{e(reserva)}</strong><em>do custo de vida mínimo</em></div>
<div class="cartao"><small>Maior gasto</small><strong>{e(r['despesas'][0][1]) if r['despesas'] else '—'}</strong>
<em>{dinheiro(r['despesas'][0][2]) if r['despesas'] else ''}</em></div></div>
<div class="grade"><section class="painel"><h2>Compras dos próximos 3 meses</h2><ul>{compras_li}</ul></section>
<section class="painel"><h2>Atenção</h2><ul>{alertas_li}</ul></section></div>
<section class="painel"><h2>Decisões</h2>{registro_html}
<form method="post" action="/reuniao" class="campos">{tk()}<input type="hidden" name="mes" value="{ym}">
<label>Data da reunião<input type="date" name="feita_em" value="{e(reg['feita_em'] if reg else hoje().isoformat())}" required></label>
<label class="largo">O que vocês decidiram (uma por linha)<textarea name="decisoes" rows="6" maxlength="2000">{e(texto)}</textarea></label>
<button>{"Atualizar" if reg else "Registrar reunião"}</button></form>
<p class="fraco">As sugestões vêm dos números do mês; apague, troque ou acrescente. Para imprimir, use Ctrl+P: o menu e os
formulários somem.</p></section>'''
    return req.html(f'Reunião de {mes_br(ym)}', corpo, '15 minutos, uma vez por mês: como foi, como está a reserva e o que vem pela frente.')


@rota('POST', '/reuniao')
def reuniao_registrar(req):
    ym = ler_mes(req.f('mes'))
    with banco.transacao() as c:
        reuniao.registrar(c, ym, req.f('feita_em'), req.f('decisoes'))
    ir(f'/reuniao?mes={ym}', 'Reunião registrada.')
