"""Categorias, pessoas e regras de importação."""

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao
from fin404.dominio import razao
from fin404.web.base import (hoje, ir)
from fin404.web.componentes import botao_excluir, dinheiro, e, opcoes, tabela
from fin404.web.servidor import rota, token_html as tk


# ------------------------------------------------------------------ cadastros

NATUREZAS = (('essencial', 'Essencial'), ('comprometido', 'Comprometido (dívidas)'), ('discricionario', 'Dá para cortar'))

@rota('GET', '/categorias')
def categorias_pagina(req):
    ano = str(hoje().year)
    with banco.conexao() as c:
        rows = c.execute('''SELECT k.*, COALESCE((SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                            WHERE l.conta_id=k.id AND t.status<>'agendada' AND substr(t.data,1,4)=?),0) total,
                            (SELECT COUNT(*) FROM lancamentos l WHERE l.conta_id=k.id) usos
                            FROM contas k WHERE k.subtipo='categoria' ORDER BY k.tipo, k.ativa DESC, k.nome''', (ano,)).fetchall()
    def linha(k):
        total = k['total'] if k['tipo'] == 'despesa' else -k['total']
        return [f'''<form method="post" action="/categorias/{k['id']}" class="acoes">{tk()}<input name="nome" value="{e(k['nome'])}" maxlength="80">
{f'<select name="natureza" aria-label="Natureza">{opcoes(NATUREZAS, k["natureza"], "Sem classificação")}</select>' if k['tipo'] == 'despesa' else ''}
<label class="check"><input type="checkbox" name="ativa" value="1"{" checked" if k['ativa'] else ""}> ativa</label><button class="secundario">Salvar</button></form>'''
                + ('' if k['usos'] or k['nome'] in razao.PROTEGIDAS else
                   botao_excluir(f'/categorias/{k["id"]}/excluir', f'A categoria "{k["nome"]}" não tem lançamentos e será apagada '
                                 '(junto com orçamentos, regras e previsões que a usam).')),
                f'<a href="/lancamentos?mes=&amp;categoria={k["id"]}">{dinheiro(total)}</a>']
    desp = [linha(k) for k in rows if k['tipo'] == 'despesa']
    rec = [linha(k) for k in rows if k['tipo'] == 'receita']
    corpo = f'''<details class="painel"><summary><strong>+ Nova categoria</strong></summary><form method="post" action="/categorias" class="campos">{tk()}
<label>Nome<input name="nome" required maxlength="80"></label><label>Tipo<select name="tipo"><option value="despesa">Despesa</option><option value="receita">Receita</option></select></label>
<button>Criar</button></form></details>
<section class="painel lista-categorias"><h2>Despesas</h2>{tabela(['Categoria', f'Em {ano}'], desp, (1,))}</section>
<section class="painel lista-categorias"><h2>Receitas</h2>{tabela(['Categoria', f'Em {ano}'], rec, (1,))}</section>'''
    corpo += '''<p class="fraco"><b>Essencial</b>: o que continua mesmo se a renda cair (moradia, mercado, saúde, transporte, escola).
<b>Comprometido</b>: parcelas de dívidas e juros, que não dá para parar de pagar. <b>Dá para cortar</b>: lazer, restaurantes, compras.
Essa classificação alimenta o <a href="/raio-x">Raio-X</a> (custo de vida mínimo e quanto tempo a reserva dura).</p>'''
    return req.html('Categorias', corpo, 'Categoria sem lançamentos pode ser excluída. Com lançamentos, desative: some dos formulários e o histórico fica.')


@rota('POST', '/categorias')
def categorias_criar(req):
    with banco.transacao() as c:
        razao.criar_conta(c, req.f('nome'), 'categoria', tipo_categoria=req.f('tipo'))
    ir('/categorias', 'Categoria criada.')


@rota('POST', r'/categorias/(\d+)')
def categorias_editar(req):
    cid = int(req.parametros[0])
    nome = req.f('nome').strip()
    if not 1 <= len(nome) <= 80:
        raise ErroValidacao('Informe um nome.')
    with banco.transacao() as c:
        k = razao.conta(c, cid)
        if k['subtipo'] != 'categoria':
            raise ErroValidacao('Não é uma categoria.')
        if c.execute('SELECT 1 FROM contas WHERE tipo=? AND lower(nome)=lower(?) AND id<>?', (k['tipo'], nome, cid)).fetchone():
            raise ErroValidacao(f'Já existe a categoria "{nome}".')
        natureza = req.f('natureza') or None
        if natureza not in (None, *dict(NATUREZAS)) or (natureza and k['tipo'] != 'despesa'):
            raise ErroValidacao('Classificação inválida.')
        c.execute('UPDATE contas SET nome=?, ativa=?, natureza=? WHERE id=?', (nome, 1 if req.f('ativa') == '1' else 0, natureza, cid))
    ir('/categorias', 'Categoria atualizada.')


@rota('GET', '/pessoas')
def pessoas_pagina(req):
    with banco.conexao() as c:
        ps = c.execute('SELECT * FROM pessoas ORDER BY nome').fetchall()
    linhas = [[f'''<form method="post" action="/pessoas/{p['id']}" class="acoes">{tk()}<input name="nome" value="{e(p['nome'])}" maxlength="60" required>
<button class="secundario">Renomear</button></form>''' + botao_excluir(f'/pessoas/{p["id"]}/excluir',
               f'"{p["nome"]}" será apagada. Os lançamentos marcados com ela continuam, só que sem pessoa (contam como do casal).')] for p in ps]
    corpo = f'''<section class="painel">{tabela(['Pessoa'], linhas, (), 'Ninguém cadastrado ainda.')}</section>
<section class="painel"><h2>Nova pessoa</h2><form method="post" action="/pessoas" class="campos">{tk()}<label>Nome<input name="nome" required maxlength="60"></label><button>Adicionar</button></form>
<p class="fraco">Em cada despesa ou receita dá para indicar de quem é. Sem indicação, conta como do casal.</p></section>'''
    return req.html('Pessoas', corpo)


@rota('POST', '/pessoas')
def pessoas_criar(req):
    nome = req.f('nome')
    if not 1 <= len(nome) <= 60:
        raise ErroValidacao('Informe um nome.')
    with banco.transacao() as c:
        if c.execute('SELECT 1 FROM pessoas WHERE lower(nome)=lower(?)', (nome,)).fetchone():
            raise ErroValidacao('Essa pessoa já está cadastrada.')
        c.execute('INSERT INTO pessoas(nome) VALUES(?)', (nome,))
    ir('/pessoas', 'Pessoa adicionada.')


@rota('POST', r'/pessoas/(\d+)')
def pessoas_renomear(req):
    nome = req.f('nome')
    if not 1 <= len(nome) <= 60:
        raise ErroValidacao('Informe um nome.')
    with banco.transacao() as c:
        c.execute('UPDATE pessoas SET nome=? WHERE id=?', (nome, int(req.parametros[0])))
    ir('/pessoas', 'Nome atualizado.')


@rota('GET', '/regras')
def regras(req):
    with banco.conexao() as c:
        rs = c.execute('SELECT r.*, k.nome conta FROM regras r LEFT JOIN contas k ON k.id=r.conta_id ORDER BY r.prioridade, r.id').fetchall()
    rot = {'categoria': 'Categoria', 'transferencia': 'Transferência', 'pagamento_fatura': 'Pagamento de fatura', 'ignorar': 'Ignorar'}
    linhas = [[f'<code>{e(r["padrao"])}</code>', e(rot[r['acao']]), e(r['conta'] or ''),
               f'<form method="post" action="/regras/{r["id"]}/excluir">{tk()}<button class="secundario">Excluir</button></form>'] for r in rs]
    return req.html('Regras de importação', f'<section class="painel">{tabela(["Descrição contém", "Ação", "Conta / categoria", ""], linhas, (), "Nenhuma regra. Marque “lembrar” ao revisar uma importação.")}</section>',
                    'Sugestões automáticas na revisão de importações. Você sempre confirma antes de gravar.')


@rota('POST', r'/regras/(\d+)/excluir')
def regras_excluir(req):
    with banco.transacao() as c:
        c.execute('DELETE FROM regras WHERE id=?', (int(req.parametros[0]),))
    ir('/regras', 'Regra excluída.')


@rota('POST', r'/categorias/(\d+)/excluir')
def categorias_excluir(req):
    with banco.transacao() as c:
        k = razao.conta(c, int(req.parametros[0]))
        if k['tipo'] not in ('receita', 'despesa'):
            raise ErroValidacao('Isto não é uma categoria.')
        nome = razao.excluir_conta(c, k['id'])
    ir('/categorias', f'Categoria "{nome}" excluída.')


@rota('POST', r'/pessoas/(\d+)/excluir')
def pessoas_excluir(req):
    with banco.transacao() as c:
        nome, n = razao.excluir_pessoa(c, int(req.parametros[0]))
    ir('/pessoas', f'"{nome}" excluída' + (f'; {n} lançamento(s) ficaram sem pessoa.' if n else '.'))


# ------------------------------------------------------------------ tags

@rota('GET', '/tags')
def tags_pagina(req):
    import urllib.parse
    from fin404.dominio import tags
    from fin404.web.componentes import data_br
    with banco.conexao() as c:
        lista = tags.listar(c)
    linhas = [[f'<a href="/lancamentos?mes=&amp;tag={e(urllib.parse.quote(t["nome"]))}">{e(t["nome"])}</a>', str(t['n']),
               f'{data_br(t["primeira"])} a {data_br(t["ultima"])}', dinheiro(t['despesas']), dinheiro(t['receitas']),
               f'''<form method="post" action="/tags/{t['id']}" class="acoes">{tk()}<input name="nome" value="{e(t['nome'])}" maxlength="40" aria-label="Novo nome">
<button class="secundario">Renomear</button></form>''' + botao_excluir(f'/tags/{t["id"]}/excluir', f'A tag "{t["nome"]}" sai dos lançamentos (eles continuam).')]
              for t in lista]
    corpo = f'''<section class="painel">{tabela(['Tag', 'Lançamentos', 'Período', 'Gastos', 'Entradas', ''], linhas, (1, 3, 4),
        'Nenhuma tag ainda. Adicione tags no Novo lançamento ou na página de um lançamento.', ocultar_movel=(1, 2, 4))}</section>
<p class="fraco">Tags cruzam categorias: "viagem" junta hotel, restaurante e combustível da mesma viagem. Renomear para um nome que já existe junta as duas.</p>'''
    return req.html('Tags', corpo, 'Quanto custou cada viagem, festa ou projeto.')


@rota('POST', r'/tags/(\d+)')
def tags_renomear(req):
    from fin404.dominio import tags
    with banco.transacao() as c:
        tags.renomear(c, int(req.parametros[0]), req.f('nome'))
    ir('/tags', 'Tag atualizada.')


@rota('POST', r'/tags/(\d+)/excluir')
def tags_excluir(req):
    from fin404.dominio import tags
    with banco.transacao() as c:
        tags.excluir(c, int(req.parametros[0]))
    ir('/tags', 'Tag excluída.')
