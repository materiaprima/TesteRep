"""Lançamentos: lista, filtros, exportação, novo, detalhe, edição, estorno e exclusão."""

from fin404.dados import banco, config
from fin404.dinheiro import ErroValidacao, centavos, data as ler_data, fim_do_mes, fmt_mes, mes as ler_mes
from fin404.dominio import anexos, cartoes, operacoes, razao, tags
from fin404.web.base import (COR_STATUS, ROTULO_TIPO, categorias, grupos_contas, hoje, inteiro, ir, mes_atual, opcional_int,
                             pessoas, tem_contas)
from fin404.web.componentes import aviso, barra, botao_excluir, campo_valor, data_br, dinheiro, e, mes_br, opcoes, opcoes_agrupadas, selo, tabela
from fin404.web.servidor import Redirecionar, rota, token_html as tk


# ------------------------------------------------------------------ lançamentos

def _q(x):
    import urllib.parse
    return urllib.parse.quote(x)


def _status_selo(s, efeito=None, quando=None, no_cartao=False):
    """Previsto vira "a pagar" (saída) ou "a receber" (entrada); atrasado se a data já passou."""
    if s == 'agendada':
        nome = 'a pagar' if efeito is not None and efeito < 0 else 'a receber' if efeito else 'previsto'
        atrasado = quando is not None and str(quando) < hoje().isoformat()
        return selo(nome + (' · atrasado' if atrasado else ''), 'vermelho' if atrasado else 'amarelo')
    nome, cor = COR_STATUS[s]
    if s == 'confirmada' and efeito:
        # compra no cartão não está paga: está na fatura (a fatura é que é paga)
        nome = ('no cartão' if no_cartao else 'pago') if efeito < 0 else 'recebido'
    return selo(nome, cor)


def _filtrar_lancamentos(req):
    filtros, args = [], []
    if 'mes' in req.consulta:
        ym = req.q('mes')
        if ym:
            ym = ler_mes(ym)
            req.mes_novo = ym
    elif req.q('status') in ('aberto', 'atrasado'):
        ym = ''                       # em aberto e atrasados: de qualquer mês, a não ser que peça um
    else:
        ym = req.mes_guardado() or mes_atual()
    if ym:
        filtros.append('t.data BETWEEN ? AND ?'); args += [ym + '-01', fim_do_mes(ym).isoformat()]
    conta_id = opcional_int(req.q('conta'))
    if conta_id:
        filtros.append('EXISTS(SELECT 1 FROM lancamentos x WHERE x.transacao_id=t.id AND x.conta_id=?)'); args.append(conta_id)
    cat_id = opcional_int(req.q('categoria'))
    if cat_id:
        filtros.append('EXISTS(SELECT 1 FROM lancamentos x WHERE x.transacao_id=t.id AND x.conta_id=?)'); args.append(cat_id)
    status = req.q('status')
    if status in ('aberto', 'agendada'):
        filtros.append("t.status='agendada'")
    elif status == 'atrasado':
        filtros.append("t.status='agendada' AND t.data<?"); args.append(hoje().isoformat())
    elif status in COR_STATUS:
        filtros.append('t.status=?'); args.append(status)
    busca = req.q('busca').strip()
    if busca:
        filtros.append('t.descricao LIKE ?'); args.append(f'%{busca}%')
    de, ate = req.q('de').strip(), req.q('ate').strip()
    if de or ate:
        if ym:  # período livre substitui o mês
            filtros.pop(0); del args[0:2]
            ym = ''
        if de:
            filtros.append('t.data>=?'); args.append(ler_data(de).isoformat())
        if ate:
            filtros.append('t.data<=?'); args.append(ler_data(ate).isoformat())
    tag = req.q('tag').strip()
    if tag:
        filtros.append('''EXISTS(SELECT 1 FROM transacao_tags x JOIN tags g ON g.id=x.tag_id
                          WHERE x.transacao_id=t.id AND g.nome=? COLLATE NOCASE)'''); args.append(tag)
    forma = req.q('forma')
    if forma in dict(operacoes.FORMAS_PAGAMENTO):
        filtros.append('t.meio_pagamento=?'); args.append(forma)
    elif forma == 'nenhuma':
        filtros.append('t.meio_pagamento IS NULL')
    tipo = req.q('tipo')
    if tipo in ROTULO_TIPO:
        filtros.append('t.tipo=?'); args.append(tipo)
    where = ('WHERE ' + ' AND '.join(filtros)) if filtros else ''
    req.filtro_sql = (where, list(args))
    with banco.conexao() as c:
        rows = c.execute(f'''SELECT t.*,
            (SELECT SUM(valor_centavos) FROM lancamentos WHERE transacao_id=t.id AND valor_centavos>0) total,
            (SELECT group_concat(k.nome, ' → ') FROM (SELECT k.nome FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                 WHERE l.transacao_id=t.id AND k.tipo IN ('ativo','passivo') ORDER BY l.valor_centavos) k) contas,
            (SELECT group_concat(k.nome, ', ') FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                 WHERE l.transacao_id=t.id AND k.tipo IN ('receita','despesa')) cats,
            (SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                 WHERE l.transacao_id=t.id AND k.tipo IN ('receita','despesa')) efeito,
            EXISTS(SELECT 1 FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                   WHERE l.transacao_id=t.id AND k.subtipo='cartao') no_cartao,
            (SELECT p.nome FROM lancamentos l JOIN pessoas p ON p.id=l.pessoa_id WHERE l.transacao_id=t.id LIMIT 1) pessoa
            FROM transacoes t {where} ORDER BY t.data DESC, t.id DESC LIMIT 5000''', args).fetchall()
    return rows, ym, conta_id, cat_id, status, busca


def texto_planilha(v):
    """Texto livre no CSV: Excel e LibreOffice executam célula que começa com = + - @ (ou tab/CR) como fórmula.
    Descrição vem de fatura e extrato importados, ou seja, de terceiros: neutraliza com apóstrofo. Só nas colunas de texto;
    o valor (que pode ser negativo) fica como número."""
    v = '' if v is None else str(v)
    return "'" + v if v[:1] in ('=', '+', '-', '@', '\t', '\r') else v


@rota('GET', '/lancamentos.csv')
def lancamentos_csv(req):
    import csv, io
    from fin404.dinheiro import para_campo
    rows = _filtrar_lancamentos(req)[0]
    saida = io.StringIO()
    w = csv.writer(saida, delimiter=';')
    w.writerow(['data', 'descricao', 'tipo', 'categoria', 'conta', 'pessoa', 'valor', 'situacao', 'observacao'])
    for t in rows:
        valor = -(t['efeito']) if t['efeito'] else (t['total'] or 0)
        w.writerow([t['data'][8:10] + '/' + t['data'][5:7] + '/' + t['data'][:4], texto_planilha(t['descricao']), ROTULO_TIPO[t['tipo']],
                    texto_planilha(t['cats']), texto_planilha(t['contas']), texto_planilha(t['pessoa']), para_campo(valor),
                    COR_STATUS[t['status']][0], texto_planilha(t['observacao'])])
    nome = 'lancamentos_' + (req.q('mes') or 'todos') + '.csv'
    return 200, 'text/csv; charset=utf-8', ('\ufeff' + saida.getvalue()).encode('utf-8'), {'Content-Disposition': f'attachment; filename="{nome}"'}


@rota('GET', '/lancamentos')
def lancamentos(req):
    import urllib.parse as _u3
    rows, ym, conta_id, cat_id, status, busca = _filtrar_lancamentos(req)
    where, args = req.filtro_sql
    avancado = any(req.q(k) for k in ('de', 'ate', 'tag', 'forma', 'tipo'))
    with banco.conexao() as c:
        g_contas = grupos_contas(c, investimentos=True, dividas=True)
        grupos_contas_pg = grupos_contas(c, dividas=True)
        g_cats = [('Despesas', categorias(c, 'despesa')), ('Receitas', categorias(c, 'receita'))]
        nomes_tags = [x['nome'] for x in tags.listar(c)]
        salvos = config.obter('filtros_salvos', [], c) or []
        filtro_ativo = where and (len(args) > 2 or avancado or conta_id or cat_id or busca or status)
        por_cat = c.execute(f'''SELECT k.id, k.nome, k.tipo, SUM(l.valor_centavos) v FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                                JOIN contas k ON k.id=l.conta_id {where}{" AND" if where else " WHERE"} t.status<>'agendada'
                                AND k.tipo IN ('receita','despesa') GROUP BY k.id ORDER BY ABS(SUM(l.valor_centavos)) DESC''', args).fetchall() \
            if filtro_ativo else []
        from fin404.dominio import cartoes as _cartoes
        ids_lista = {t['id'] for t in rows}
        pagamentos_errados = [x for x in _cartoes.pagamentos_como_gasto(c) if x['id'] in ids_lista]
        data_banco = {}
        ids = [t['id'] for t in rows][:5000]
        for i in range(0, len(ids), 900):        # data em que a compra aparece no PDF, quando o app a trouxe para o ciclo da fatura
            parte = ids[i:i + 900]
            data_banco.update(c.execute(f'''SELECT transacao_id, data_original FROM linhas_importacao
                                            WHERE data_original IS NOT NULL AND transacao_id IN ({",".join("?" * len(parte))})''', parte).fetchall())
    linhas = []
    tot_r = tot_d = prev_r = prev_d = 0
    for t in rows:
        efeito = -(t['efeito'] or 0)   # positivo = receita, negativo = despesa
        # estorno devolve uma despesa: diminui as despesas, não é receita
        eh_saida = efeito < 0 or t['tipo'] == 'estorno'
        if t['status'] != 'agendada':
            if eh_saida:
                tot_d -= efeito
            else:
                tot_r += efeito
        elif eh_saida:
            prev_d -= efeito
        else:
            prev_r += efeito
        valor = dinheiro(efeito, cor=True) if t['efeito'] else f'<span class="fraco">{dinheiro(t["total"])}</span>'
        quando = data_br(t['data']) + (f'<br><small class="fraco">no banco {data_br(data_banco[t["id"]])}</small>' if t['id'] in data_banco else '')
        pode_mudar = t['tipo'] in ('despesa', 'receita')
        marcar = (f'<label class="check"><input type="checkbox" name="ids" value="{t["id"]}" form="mudar-situacao" '
                  f'aria-label="Selecionar {e(t["descricao"])}"></label>') if pode_mudar else ''
        linhas.append([marcar, quando, f'<a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a>',
                       e(t['cats'] or ROTULO_TIPO[t['tipo']]), e(t['contas'] or ''), valor,
                       _status_selo(t['status'], efeito if t['efeito'] else None, t['data'], t['no_cartao'])])
    with banco.conexao() as c_ab:
        ab = c_ab.execute('''SELECT COUNT(*) n, COALESCE(SUM(t.data<?),0) atras FROM transacoes t WHERE t.status='agendada'
                             AND t.tipo IN ('despesa','receita')''', (hoje().isoformat(),)).fetchone()
    status_q = req.q('status')
    atalhos = (f'<div class="abas sub"><a href="/lancamentos?status=aberto"{" class=atual" if status_q == "aberto" else ""}>Em aberto ({ab["n"]})</a>'
               f'<a href="/lancamentos?status=atrasado"{" class=atual" if status_q == "atrasado" else ""}>Atrasados ({ab["atras"]})</a>'
               f'<a href="/lancamentos">Este mês</a><a href="/devo">Tudo o que está em aberto, com cartões →</a></div>')
    filtros_html = atalhos + f'''<form method="get" class="campos painel"><label>Mês <small class="fraco">(vazio = todos)</small><input type="month" name="mes" value="{e(ym)}"></label>
<label>Conta ou cartão<select name="conta">{opcoes_agrupadas(g_contas, conta_id, 'Todas')}</select></label>
<label>Categoria<select name="categoria">{opcoes_agrupadas(g_cats, cat_id, 'Todas')}</select></label>
<label>Situação<select name="status">{opcoes([('aberto', 'Em aberto (a pagar / a receber)'), ('atrasado', 'Atrasados'), ('confirmada', 'Pagos / recebidos / no cartão'), ('conciliada', 'Conferidos com o banco')], status, 'Todas')}</select></label>
<label>Busca<input name="busca" value="{e(busca)}" placeholder="parte da descrição"></label>
<details class="mais-filtros"{" open" if avancado else ""}><summary>Mais filtros</summary><div class="campos">
<label>De<input type="date" name="de" value="{e(req.q('de'))}"></label><label>Até<input type="date" name="ate" value="{e(req.q('ate'))}"></label>
<label>Tag<select name="tag">{opcoes([(n, n) for n in nomes_tags], req.q('tag') or None, 'Todas')}</select></label>
<label>Forma de pagamento<select name="forma">{opcoes(list(operacoes.FORMAS_PAGAMENTO) + [('nenhuma', 'Não informada')], req.q('forma') or None, 'Todas')}</select></label>
<label>Tipo<select name="tipo">{opcoes(list(ROTULO_TIPO.items()), req.q('tipo') or None, 'Todos')}</select></label></div>
<p class="fraco">Com "De" ou "Até" preenchidos, o filtro de mês é ignorado.</p></details><button>Filtrar</button></form>'''
    resumo = f'''<div class="cartoes">
<div class="cartao"><small>Despesas já feitas</small><strong>{dinheiro(tot_d)}</strong><em>pagas ou no cartão</em></div>
<div class="cartao"><small>A pagar no período</small><strong>{dinheiro(prev_d)}</strong><em>lançadas como "a pagar"</em></div>
<div class="cartao"><small>Despesas com o que falta pagar</small><strong>{dinheiro(tot_d + prev_d)}</strong><em>as duas somadas</em></div>
<div class="cartao"><small>Receitas</small><strong>{dinheiro(tot_r)}</strong><em>{("+ " + dinheiro(prev_r) + " a receber") if prev_r else "recebidas"}</em></div></div>
<p class="fraco">{len(rows)} lançamento(s). Transferências e pagamentos de fatura não são despesa: a compra no cartão já entrou quando foi feita.
Dívida de antes do app (saldo inicial de cartão ou empréstimo) também não; veja <a href="/devo">Em aberto</a>.</p>'''
    if busca and ym:
        resumo = (f'<p class="aviso info">Procurando "{e(busca)}" só em {mes_br(ym)}. '
                  f'<a href="/lancamentos?{e(_u3.urlencode({"busca": busca, "mes": ""}))}">Procurar em todos os meses →</a></p>') + resumo
    if pagamentos_errados:
        soma_err = sum(x['valor'] for x in pagamentos_errados)
        resumo = (f'<div class="aviso atencao"><strong>{len(pagamentos_errados)} pagamento(s) de fatura lançado(s) como estorno</strong> '
                  f'estão diminuindo as despesas deste filtro em {dinheiro(soma_err)}. '
                  f'<a href="/cartoes">Corrigir em Cartões e faturas</a> ("É pagamento").</div>') + resumo
    import urllib.parse as _u
    exportar = f'<p><a href="/lancamentos.csv?{e(_u.urlencode({k: v[0] for k, v in req.consulta.items() if k != "msg"}))}">Baixar estes lançamentos em planilha (CSV)</a></p>'
    import urllib.parse as _u2
    consulta_atual = _u2.urlencode({k: v[0] for k, v in req.consulta.items() if k != 'msg' and v and v[0]})
    barra_salvos = ''
    if salvos:
        barra_salvos = ('<div class="abas">' + ''.join(f'<a href="/lancamentos?{e(f["consulta"])}"{" class=atual" if f["consulta"] == consulta_atual else ""}>{e(f["nome"])}</a>'
                                                       for f in salvos) + '<a href="/lancamentos/filtros">Gerenciar…</a></div>')
    salvar = (f'''<form method="post" action="/lancamentos/filtros" class="acoes">{tk()}<input type="hidden" name="consulta" value="{e(consulta_atual)}">
<label>Salvar este filtro como<input name="nome" maxlength="40" required placeholder="ex.: Viagem 2026"></label><button class="secundario">Salvar</button></form>''') \
        if consulta_atual else ''
    quadro_cat = ''
    if por_cat:
        tot = sum(abs(r['v']) for r in por_cat if r['tipo'] == 'despesa') or 1
        lc = [[f'<a href="/lancamentos?{e(_u2.urlencode({**{k: v[0] for k, v in req.consulta.items() if k != "msg"}, "categoria": r["id"]}))}">{e(r["nome"])}</a>',
               e('Despesa' if r['tipo'] == 'despesa' else 'Receita'), dinheiro(abs(r['v'])),
               (barra(abs(r['v']), tot) if r['tipo'] == 'despesa' else '')] for r in por_cat]
        quadro_cat = f'<section class="painel"><h2>Por categoria, neste filtro</h2>{tabela(["Categoria", "Tipo", "Total", ""], lc, (2,), ocultar_movel=(1, 3))}</section>'
    volta_lista = '/lancamentos?' + _u2.urlencode({k: v[0] for k, v in req.consulta.items() if k != 'msg'})
    mudar_lote = (f'<form method="post" action="/lancamentos/situacao" id="mudar-situacao" class="painel-interno lote">{tk()}'
                  f'<input type="hidden" name="volta" value="{e(volta_lista)}"><h3>Com os marcados na primeira coluna</h3>'
                  '<div class="acoes"><span>Situação:</span>'
                  '<button name="situacao" value="pago" class="secundario">Pago / recebido</button>'
                  '<button name="situacao" value="a_pagar" class="secundario">A pagar / a receber</button></div>'
                  f'<div class="campos"><label>Categoria nova<select name="categoria_lote">{opcoes_agrupadas(g_cats, None, "Não mudar")}</select></label>'
                  f'<label>Conta ou cartão novo<select name="conta_lote">{opcoes_agrupadas(grupos_contas_pg, None, "Não mudar")}</select></label>'
                  '<button name="situacao" value="editar">Trocar categoria / conta</button></div>'
                  '<p class="fraco">Compra no cartão e o que veio de extrato importado não mudam de situação (no cartão, quem se paga é a fatura; '
                  'o importado aconteceu no banco), mas mudam de categoria. Parcela muda de cartão pela página dela ("Mover a compra"). '
                  'Para pagar só uma parte, abra o lançamento.</p></form>') if linhas else ''
    corpo = barra_salvos + filtros_html + quadro_cat + '<section class="painel">' + resumo + exportar + salvar + tabela(['', 'Data', 'Descrição', 'Categoria', 'Conta', 'Valor', 'Situação'], linhas, (5,), 'Nenhum lançamento com esses filtros.', ocultar_movel=(3, 4)) + mudar_lote + '</section>'
    return req.html('Lançamentos', corpo)


ABAS_NOVO = [('despesa', 'Despesa'), ('receita', 'Receita'), ('transferencia', 'Transferência'), ('pagamento', 'Pagamento de fatura ou dívida')]


@rota('GET', '/novo')
def novo(req):
    tipo = req.q('tipo', 'despesa')
    if tipo not in dict(ABAS_NOVO):
        tipo = 'despesa'
    # Lançando várias notas seguidas: data, conta, forma e pessoa do último lançamento vêm preenchidas
    data_sel = req.q('data') or hoje().isoformat()
    try:
        ler_data(data_sel)
    except ErroValidacao:
        data_sel = hoje().isoformat()
    conta_sel, origem_sel, destino_sel, pessoa_sel = (opcional_int(req.q(k)) for k in ('conta', 'origem', 'destino', 'pessoa'))
    forma_sel = req.q('forma') if req.q('forma') in dict(operacoes.FORMAS_PAGAMENTO) else ''
    hoje_iso = data_sel
    with banco.conexao() as c:
        if not tem_contas(c):
            ir('/contas', 'Cadastre ao menos uma conta antes de lançar.')
        recentes = c.execute('''SELECT t.id, t.data, t.descricao, t.tipo,
                                       (SELECT SUM(ABS(l.valor_centavos)) FROM lancamentos l WHERE l.transacao_id=t.id) / 2 valor
                                FROM transacoes t WHERE t.lote_id IS NULL AND t.chave_origem IS NULL AND t.status<>'agendada'
                                AND (t.parcela_n IS NULL OR t.parcela_n=1) ORDER BY t.id DESC LIMIT 5''').fetchall()
        g_pag = grupos_contas(c)
        g_ativos = grupos_contas(c, cartoes_=False, investimentos=True)
        g_passivos = [('Cartões', [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('cartao',))]),
                      ('Empréstimos e dívidas', [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('emprestimo', 'outro_passivo'))])]
        ps = pessoas(c)
        dicas = []
        for k in cartoes.lista(c):
            if k['dia_fechamento']:
                f = cartoes.fechamento_anterior(k, cartoes.fechamento_da_compra(k, hoje()))
                fat = cartoes.fatura(c, k['id'], f)
                if fat['restante']:
                    dicas.append(f'{e(k["nome"])}: falta pagar {dinheiro(fat["restante"])} (vence {data_br(fat["vencimento"])})')
        cats_d, cats_r = categorias(c, 'despesa'), categorias(c, 'receita')
    abas = '<div class="abas">' + ''.join(f'<a href="/novo?tipo={t}"{" class=atual" if t == tipo else ""}>{n}</a>' for t, n in ABAS_NOVO) + '</div>'
    pessoa = f'<label>De quem<select name="pessoa">{opcoes(ps, pessoa_sel, "Do casal / não informar")}</select></label>' if ps else ''
    rot_sit = {'despesa': ('Pago', 'A pagar (ainda não paguei)'), 'receita': ('Recebido', 'A receber (ainda não caiu)')}.get(
        tipo, ('Já aconteceu', 'Ainda vai acontecer'))
    st = req.q('status') if req.q('status') in ('confirmada', 'agendada') else ''
    # sem padrão escondido: a pessoa escolhe se já pagou (o "Pago" automático registrava como pago o que não foi)
    situacao = (f'<label>Já foi {"recebido" if tipo == "receita" else "pago"}?<select name="status" required>'
                f'<option value=""{" selected" if not st else ""} disabled>Escolha…</option>'
                f'<option value="confirmada"{" selected" if st == "confirmada" else ""}>{rot_sit[0]}</option>'
                f'<option value="agendada"{" selected" if st == "agendada" else ""}>{rot_sit[1]}</option></select>'
                '<small class="fraco">No cartão, escolha "Pago": quem fica a pagar é a fatura.</small></label>')
    formas = ''.join(f'<option value="{v}"{" selected" if v == forma_sel else ""}>{e(n)}</option>' for v, n in operacoes.FORMAS_PAGAMENTO)

    def forma(rotulo):
        return f'<label>{rotulo}<select name="forma"><option value="">Automático / não informar</option>{formas}</select></label>'
    freqs = ''.join(f'<option value="{v}">{e(n)}</option>' for v, n in operacoes.FREQUENCIAS)
    repetir = (f'<label>Repetir<select name="repetir"><option value="">Não repete</option>{freqs}</select></label>'
               '<label>Repetir até (opcional)<input type="month" name="repetir_ate"></label>')
    campo_tags = '<label>Tags (opcional)<input name="tags" maxlength="200" placeholder="ex.: viagem, Natal"></label>'
    comuns = f'''<label>Descrição<input name="descricao" required maxlength="200" autofocus></label>
<label>Valor (R$)<input name="valor" required inputmode="decimal" placeholder="0,00"></label>
<label>Data<input type="date" name="data" value="{hoje_iso}" required></label>'''
    if tipo == 'despesa':
        campos = f'''{comuns}<label>Categoria<select name="categoria">{opcoes(cats_d, None, "Adivinhar pela descrição")}</select></label>
<label>Saiu de (conta ou cartão)<select name="conta" required>{opcoes_agrupadas(g_pag, conta_sel, "Escolha…")}</select></label>
{forma('Como pagou')}
<label>Parcelas<input type="number" name="parcelas" min="1" max="72" value="1"></label>{repetir}{pessoa}{situacao}
<label>Observação<input name="observacao" maxlength="500"></label>{campo_tags}'''
        ajuda = ('No cartão, cada parcela cai automaticamente na fatura certa, pelo dia de fechamento do cartão. '
                 'Em conta (carnê, boleto ou Pix parcelado), a 1ª parcela é lançada e as outras ficam previstas, uma por mês. '
                 '<b>Repetir</b> serve para contas fixas e assinaturas (aluguel, luz, Netflix, IPVA): os próximos ficam como previstos, '
                 'aparecem em "A pagar e receber" e casam com a fatura quando ela for importada. Para mudar ou parar, use Previsões.')
    elif tipo == 'receita':
        campos = f'''{comuns}<label>Categoria<select name="categoria" required>{opcoes(cats_r, None, "Escolha…")}</select></label>
<label>Entrou em<select name="conta" required>{opcoes_agrupadas(g_ativos, conta_sel, "Escolha…")}</select></label>
{forma('Como recebeu')}{repetir}{pessoa}{situacao}
<label>Observação<input name="observacao" maxlength="500"></label>{campo_tags}'''
        ajuda = ('Receita é dinheiro novo (salário, reembolso, rendimento). Dinheiro vindo de outra conta sua é transferência. '
                 'Salário: marque <b>Repetir todo mês</b>.')
    elif tipo == 'transferencia':
        campos = f'''<label>Valor (R$)<input name="valor" required inputmode="decimal" placeholder="0,00" autofocus></label>
<label>Data<input type="date" name="data" value="{hoje_iso}" required></label>
<label>Sai de<select name="origem" required>{opcoes_agrupadas(g_ativos + [g_passivos[1]], origem_sel, "Escolha…")}</select></label>
<label>Vai para<select name="destino" required>{opcoes_agrupadas(g_ativos, destino_sel, "Escolha…")}</select></label>
{forma('Como')}<label>Descrição<input name="descricao" maxlength="200" placeholder="opcional"></label>'''
        ajuda = 'Transferência entre contas suas não é receita nem despesa: o patrimônio não muda.'
    else:
        campos = f'''<label>Valor (R$)<input name="valor" required inputmode="decimal" placeholder="0,00" autofocus></label>
<label>Data<input type="date" name="data" value="{hoje_iso}" required></label>
<label>Sai de<select name="origem" required>{opcoes_agrupadas(g_ativos, origem_sel, "Escolha…")}</select></label>
<label>Cartão ou dívida<select name="destino" required>{opcoes_agrupadas(g_passivos, destino_sel, "Escolha…")}</select></label>
{forma('Como pagou')}<label>Descrição<input name="descricao" maxlength="200" placeholder="opcional"></label>'''
        ajuda = 'Pagar a fatura não é despesa: as despesas são as compras feitas no cartão. O pagamento só abate a dívida.'
        if dicas:
            ajuda += '<br>' + '<br>'.join(dicas)
    ultimos = ''
    if recentes:
        ultimos = ('<section class="painel"><h2>Últimos lançados à mão</h2>'
                   + tabela(['Data', 'Descrição', 'Tipo', 'Valor'],
                            [[data_br(r['data']), f'<a href="/lancamentos/{r["id"]}">{e(r["descricao"])}</a>', e(ROTULO_TIPO[r['tipo']]),
                              dinheiro(r['valor'])] for r in recentes], (3,))
                   + f'<p><a href="/lancamentos?mes={data_sel[:7]}">Ver todos os lançamentos de {mes_br(data_sel[:7])}</a></p></section>')
    corpo = f'''{abas}<section class="painel"><form method="post" action="/novo" class="campos">{tk()}<input type="hidden" name="tipo" value="{tipo}">
{campos}<button>Salvar</button></form><p class="fraco">{ajuda} Depois de salvar, o formulário volta pronto para o próximo,
com a mesma data, conta e forma de pagamento.</p></section>{ultimos}'''
    return req.html('Novo lançamento', corpo)


@rota('POST', '/novo')
def novo_salvar(req):
    tipo = req.f('tipo')
    valor = centavos(req.f('valor'))
    quando = ler_data(req.f('data'))
    forma, repetir, repetir_ate = req.f('forma') or None, req.f('repetir') or None, req.f('repetir_ate') or None
    with banco.transacao() as c:
        if tipo == 'despesa':
            categoria = req.f('categoria')
            if not categoria:
                from fin404.dominio import categorias as cats
                inferida = cats.inferir(c, req.f('descricao'))
                if not inferida:
                    raise ErroValidacao(f'Não consegui adivinhar a categoria de "{req.f("descricao")}". Escolha uma na lista.')
                categoria = str(inferida[0])
            ids = operacoes.despesa(c, quando, req.f('descricao'), valor, inteiro(categoria, 'categoria'),
                                    inteiro(req.f('conta'), 'conta'), inteiro(req.f('parcelas') or '1', 'número de parcelas'),
                                    opcional_int(req.f('pessoa')), req.f('status') or 'confirmada', req.f('observacao'))
            nome_cat = razao.conta(c, int(categoria))['nome']
            msg = (f'Despesa registrada em {len(ids)} parcela(s)' if len(ids) > 1 else 'Despesa registrada') + f' em {nome_cat}.'
            if repetir and len(ids) > 1:
                raise ErroValidacao('Compra parcelada não pode ser recorrente: escolha "Não repete" ou 1 parcela.')
            operacoes.definir_forma(c, ids, forma or operacoes.forma_padrao(c, inteiro(req.f('conta'), 'conta')))
        elif tipo == 'receita':
            tid = operacoes.receita(c, quando, req.f('descricao'), valor, inteiro(req.f('categoria'), 'categoria'),
                                    inteiro(req.f('conta'), 'conta'), opcional_int(req.f('pessoa')), req.f('status') or 'confirmada',
                                    req.f('observacao'))
            ids = [tid]
            operacoes.definir_forma(c, ids, forma)
            msg = 'Receita registrada.'
        elif tipo == 'transferencia':
            ids = [operacoes.transferencia(c, quando, req.f('descricao'), valor, inteiro(req.f('origem'), 'conta de origem'),
                                           inteiro(req.f('destino'), 'conta de destino'))]
            operacoes.definir_forma(c, ids, forma)
            msg = 'Transferência registrada.'
        elif tipo == 'pagamento':
            ids = [cartoes.pagar(c, inteiro(req.f('origem'), 'conta de origem'), inteiro(req.f('destino'), 'cartão'), valor, quando,
                                 req.f('descricao') or None)]
            operacoes.definir_forma(c, ids, forma)
            msg = 'Pagamento registrado.'
        else:
            raise ErroValidacao('Tipo de lançamento inválido.')
        if req.f('tags'):
            tags.adicionar(c, ids, req.f('tags'))
        if repetir:
            if tipo not in ('despesa', 'receita'):
                raise ErroValidacao('Só despesas e receitas podem repetir. Para transferência fixa, use Previsões.')
            operacoes.repetir(c, ids[0], repetir, repetir_ate, hoje=hoje())
            msg += f' Repete: {dict(operacoes.FREQUENCIAS)[repetir].lower()}; os próximos já estão nas Previsões.'
    if req.f('volta') == '/':
        ir('/', msg)
    from urllib.parse import urlencode
    fica = {'tipo': tipo, 'data': quando.isoformat()}
    for campo in ('conta', 'origem', 'destino', 'pessoa', 'forma', 'status'):
        if req.f(campo):
            fica[campo] = req.f(campo)
    ir('/novo?' + urlencode(fica), msg)


@rota('GET', r'/lancamentos/(\d+)')
def lancamento(req):
    tid = int(req.parametros[0])
    with banco.conexao() as c:
        t = razao.transacao(c, tid)
        ls = razao.lancamentos_de(c, tid)
        origem = c.execute('''SELECT li.*, lo.arquivo FROM linhas_importacao li JOIN lotes_importacao lo ON lo.id=li.lote_id
                              WHERE li.transacao_id=? ORDER BY li.id DESC LIMIT 1''', (tid,)).fetchone()
        estornos = c.execute('SELECT * FROM transacoes WHERE estorno_de=? ORDER BY data', (tid,)).fetchall()
        original = razao.transacao(c, t['estorno_de']) if t['estorno_de'] else None
        estornado = razao.total_estornado(c, tid)
        ps = pessoas(c)
        g_contas_edit = grupos_contas(c, dividas=True, investimentos=True)
        outros_cartoes = [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('cartao',))
                          if t['plano_id'] and k['id'] != c.execute('SELECT conta_cartao_id FROM planos_parcelas WHERE id=?',
                                                                    (t['plano_id'],)).fetchone()[0]]
        from fin404.dominio import receber
        tem_a_receber = any(receber.eh_a_receber(c, x['conta_id']) for x in ls)
        simples = len(ls) == 2 and t['tipo'] in ('receita', 'despesa', 'transferencia', 'pagamento_fatura') and not tem_a_receber
        if simples:
            lado = next((x for x in ls if x['conta_tipo'] in ('receita', 'despesa')), None) if t['tipo'] in ('receita', 'despesa') \
                else next(x for x in ls if x['valor_centavos'] > 0)
            if t['tipo'] in ('receita', 'despesa'):
                opts = categorias(c, lado['conta_tipo'])
            else:
                opts = [(k['id'], k['nome']) for k in razao.contas(c, tipo=lado['conta_tipo'])]
        fechado = c.execute('SELECT 1 FROM meses_fechados WHERE mes=?', (t['data'][:7],)).fetchone()
        tags_t = tags.de(c, tid)
        anexos_t = anexos.listar(c, tid)
        from fin404.dominio import prazos as prazos_dom
        garantias_t = [prazos_dom._com_dias(p, hoje()) for p in prazos_dom.de_transacao(c, tid)]
        from fin404.dominio import notas as notas_dom
        notas_t = notas_dom.de_transacao(c, tid)
        cats_tipo = categorias(c, 'despesa' if t['tipo'] == 'despesa' else 'receita') if t['tipo'] in ('despesa', 'receita') else []
    natureza = {'ativo': 'conta ou bem', 'passivo': 'dívida / cartão', 'receita': 'categoria de receita',
                'despesa': 'categoria de despesa', 'patrimonio': 'controle do sistema'}
    def efeito(x):
        v, t = x['valor_centavos'], x['conta_tipo']
        txt = {('ativo', 1): 'entrou', ('ativo', -1): 'saiu', ('passivo', -1): 'dívida aumentou', ('passivo', 1): 'dívida diminuiu',
               ('despesa', 1): 'gasto', ('despesa', -1): 'gasto devolvido', ('receita', -1): 'recebido', ('receita', 1): 'receita estornada',
               ('patrimonio', 1): 'ajuste', ('patrimonio', -1): 'ajuste'}[(t, 1 if v > 0 else -1)]
        return f'{dinheiro(abs(v))} <span class="fraco">{e(txt)}</span>'
    linhas = [[e(x['conta_nome']), e(natureza[x['conta_tipo']]), e(x['pessoa'] or ''), efeito(x)] for x in ls]
    efeito_t = (-1 if t['tipo'] == 'despesa' else 1) if t['tipo'] in ('despesa', 'receita') else None
    no_cartao_t = any(x['conta_subtipo'] == 'cartao' for x in ls) if ls and 'conta_subtipo' in ls[0].keys() else False
    info = [f'<b>{e(ROTULO_TIPO[t["tipo"]])}</b> em {data_br(t["data"])} · {_status_selo(t["status"], efeito_t, t["data"], no_cartao_t)}']
    if t['plano_id']:
        info.append(f'Parcela {t["parcela_n"]} de um parcelamento. <a href="/parcelamentos#plano-{t["plano_id"]}">Ver parcelamento / antecipar ou cancelar</a>')
    if origem:
        info.append(f'Veio do arquivo <a href="/importacoes/{origem["lote_id"]}">{e(origem["arquivo"])}</a>, linha {origem["ordem"]}: '
                    f'"{e(origem["descricao"])}" {dinheiro(origem["valor_centavos"])}.')
    if original:
        info.append(f'Estorno de <a href="/lancamentos/{original["id"]}">{e(original["descricao"])}</a>.')
    if estornos:
        info.append('Estornos: ' + ', '.join(f'<a href="/lancamentos/{x["id"]}">{data_br(x["data"])}</a>' for x in estornos)
                    + f' (total {dinheiro(estornado)}).')
    if t['meio_pagamento']:
        info.append('Forma de pagamento: ' + e(dict(operacoes.FORMAS_PAGAMENTO)[t['meio_pagamento']]))
    if tags_t:
        info.append('Tags: ' + ' '.join(f'<a class="selo" href="/lancamentos?mes=&amp;tag={e(_q(x))}">{e(x)}</a>' for x in tags_t))
    if t['previsao_id']:
        info.append('Faz parte de um lançamento que se repete. <a href="/previsoes">Mudar ou parar a repetição em Previsões</a>')
    if t['observacao']:
        info.append('Observação: ' + e(t['observacao']))
    partes = [f'<section class="painel"><p>{"<br>".join(info)}</p>'
              f'{tabela(["Conta", "Tipo", "Pessoa", "Efeito"], linhas, (3,))}</section>']
    if fechado:
        ym_f = t['data'][:7]
        partes.append(f'''<div class="aviso atencao">O mês {fmt_mes(ym_f)} está <strong>fechado</strong> (conferido e travado), por isso não dá para
mudar este lançamento. Se precisa corrigir, reabra o mês: os lançamentos voltam a ser editáveis e você fecha de novo depois.
<form method="post" action="/fechamento" class="inline">{tk()}<input type="hidden" name="mes" value="{ym_f}"><input type="hidden" name="acao" value="reabrir">
<input type="hidden" name="volta" value="/lancamentos/{tid}"><button class="secundario">Reabrir {fmt_mes(ym_f)}</button></form></div>''')
    else:
        campos_extra = ''
        if simples:
            rot = 'Categoria' if t['tipo'] in ('receita', 'despesa') else 'Conta de destino'
            outro_lado = next(x for x in ls if x['id'] != lado['id'])
            rot_conta = {'despesa': 'Pago com (conta ou cartão)', 'receita': 'Recebido em (conta)'}.get(t['tipo'], 'Conta de origem')
            trocar_conta = '' if t['plano_id'] else (
                f'<label>{rot_conta}<select name="conta">{opcoes_agrupadas(g_contas_edit, outro_lado["conta_id"])}</select></label>')
            campos_extra = (f'<label>Valor<input name="valor" value="{campo_valor(abs(lado["valor_centavos"]))}"></label>'
                            f'<label>{rot}<select name="contraparte">{opcoes(opts, lado["conta_id"])}</select></label>{trocar_conta}')
            if ps and t['tipo'] in ('receita', 'despesa'):
                campos_extra += f'<label>De quem<select name="pessoa">{opcoes(ps, lado["pessoa_id"], "Do casal / não informar")}</select></label>'
        no_cartao = any(x['conta_subtipo'] == 'cartao' for x in ls)
        importado = bool(t['lote_id'])
        campo_pagamento = ''
        if t['tipo'] in ('despesa', 'receita') and simples:
            rec = t['tipo'] == 'receita'
            if no_cartao:
                campo_pagamento = ('<label>Situação<select name="situacao" disabled><option>No cartão (quem se paga é a fatura)</option></select></label>')
            elif importado and t['status'] != 'agendada':
                campo_pagamento = ('<label>Situação<select name="situacao" disabled><option>'
                                   f'{"Recebido" if rec else "Pago"} (veio do extrato ou da fatura do banco)</option></select></label>')
            else:
                atual = 'pago' if t['status'] != 'agendada' else 'a_pagar'
                ops_sit = [('pago', 'Recebido' if rec else 'Pago'), ('a_pagar', 'A receber' if rec else 'A pagar'),
                           ('parte', 'Recebido em parte' if rec else 'Pago em parte')]
                campo_pagamento = (f'<label>Situação<select name="situacao">{opcoes(ops_sit, atual)}</select></label>'
                                   f'<label>{"Quanto recebeu" if rec else "Quanto pagou"} (se foi só uma parte)<input name="valor_pago" inputmode="decimal" placeholder="0,00"></label>'
                                   f'<label>{"Recebeu" if rec else "Pagou"} em (data)<input type="date" name="data_pagamento" value="{hoje().isoformat()}"></label>')
        partes.append(f'''<section class="painel" id="editar"><h2>Editar</h2><form method="post" action="/lancamentos/{tid}/editar" class="campos">{tk()}
<label>Descrição<input name="descricao" value="{e(t['descricao'])}" required maxlength="200"></label>
<label>Data (vencimento, se a pagar)<input type="date" name="data" value="{e(t['data'])}" required></label>{campos_extra}{campo_pagamento}
{('<label class="marcar"><input type="checkbox" name="proximos" value="1" checked> Aplicar descrição, valor e categoria também aos próximos meses (este lançamento se repete)</label>') if t['previsao_id'] and simples else ''}
{('<label class="marcar"><input type="checkbox" name="todas_parcelas" value="1" checked> Aplicar a descrição e a categoria a todas as parcelas desta compra</label>') if t['plano_id'] and simples else ''}
<label>Forma de pagamento<select name="forma">{opcoes(list(operacoes.FORMAS_PAGAMENTO), t['meio_pagamento'], 'Não informada')}</select></label>
<label>Tags (separadas por vírgula)<input name="tags" value="{e(', '.join(tags_t))}" maxlength="200" placeholder="ex.: viagem, Natal"></label>
<label>Observação<input name="observacao" value="{e(t['observacao'])}" maxlength="500"></label><button>Salvar alterações</button></form></section>''')
        if t['plano_id']:
            if outros_cartoes:
                partes.append(f'''<details class="painel" id="mover"><summary>Mover a compra para outro cartão</summary>
<form method="post" action="/lancamentos/{tid}/mover" class="campos">{tk()}<label>Cartão certo<select name="cartao" required>{opcoes(outros_cartoes, None, "Escolha")}</select></label>
<button class="secundario">Mover todas as parcelas</button></form>
<p class="fraco">Para compra parcelada lançada no cartão errado. Todas as parcelas vão juntas, com as datas pelo fechamento do cartão novo.
Não vale para parcela que veio da fatura importada.</p></details>''')
        if t['tipo'] in ('despesa', 'receita') and not t['previsao_id'] and not t['plano_id']:
            partes.append(f'''<section class="painel"><h2>Repetir este lançamento</h2><form method="post" action="/lancamentos/{tid}/repetir" class="campos">{tk()}
<label>Repete<select name="repetir">{opcoes(list(operacoes.FREQUENCIAS), 'mensal')}</select></label>
<label>Até (opcional)<input type="month" name="repetir_ate"></label><button class="secundario">Tornar recorrente</button></form>
<p class="fraco">Os próximos ficam como previstos (mesmo valor, conta e categoria, no mesmo dia do mês) e aparecem em "A pagar e receber".</p></section>''')
        if t['tipo'] in ('despesa', 'receita') and not estornado:
            atuais = [x for x in ls if x['conta_tipo'] == ('despesa' if t['tipo'] == 'despesa' else 'receita')]
            linhas_div = ''.join(
                f'<label>Categoria {i + 1}<select name="categoria_{i}">{opcoes(cats_tipo, atuais[i]["conta_id"] if i < len(atuais) else None, "—")}</select></label>'
                f'<label>Valor {i + 1}<input name="valor_{i}" inputmode="decimal" value="{campo_valor(abs(atuais[i]["valor_centavos"])) if i < len(atuais) else ""}"></label>'
                for i in range(max(4, len(atuais) + 1)))
            total_cat = abs(sum(x['valor_centavos'] for x in atuais))
            partes.append(f'''<details class="painel"{" open" if len(atuais) > 1 else ""}><summary>Dividir em categorias{f" ({len(atuais)} categorias)" if len(atuais) > 1 else ""}</summary>
<form method="post" action="/lancamentos/{tid}/dividir" class="campos">{tk()}<input type="hidden" name="n" value="{max(4, len(atuais) + 1)}">{linhas_div}
<button class="secundario">Salvar divisão</button></form>
<p class="fraco">Ex.: nota do mercado com farmácia. As partes precisam somar {dinheiro(total_cat)}. Deixe em branco as linhas que não usar.</p></details>''')
        lista_anexos = ''.join(
            f'<li><a href="/anexos/{a["id"]}">{e(a["nome"])}</a> <span class="fraco">({a["tamanho"] // 1024 or 1} KB)</span> '
            + botao_excluir(f'/anexos/{a["id"]}/excluir', f'O arquivo "{a["nome"]}" será apagado.', 'Excluir') + '</li>' for a in anexos_t)
        partes.append(f'''<section class="painel"><h2>Comprovantes {f"({len(anexos_t)})" if anexos_t else ""}</h2>{f"<ul>{lista_anexos}</ul>" if anexos_t else ""}
<form method="post" action="/lancamentos/{tid}/anexos" enctype="multipart/form-data" class="campos">{tk()}
<label>Arquivo (PDF ou foto, até 8 MB)<input type="file" name="arquivo" accept=".pdf,.jpg,.jpeg,.png,.webp" required></label><button class="secundario">Anexar</button></form>
<p class="fraco">Fica guardado no próprio banco de dados e entra nos backups. Útil para recibos médicos (Imposto de Renda) e notas de compras com garantia.</p></section>''')
        if notas_t:
            partes.append('<section class="painel"><h2>Nota fiscal</h2><ul>' + ''.join(
                f'<li><a href="/notas/{n["id"]}">{e(n["loja"])} · {data_br(n["data"])} · {dinheiro(n["total_centavos"])}</a></li>' for n in notas_t)
                + '</ul></section>')
        if t['tipo'] in ('despesa', 'transferencia'):
            lista_g = ''.join(f'<li>{e(g["titulo"])}: até {data_br(g["data_fim"])} '
                              + ('(acabou)' if g['dias'] < 0 else f'({g["dias"]} dias)') + f' · <a href="/prazos/{g["id"]}">editar</a></li>'
                              for g in garantias_t)
            partes.append(f'''<details class="painel"{" open" if garantias_t else ""}><summary>Garantia{f" ({len(garantias_t)})" if garantias_t else ""}</summary>
{f"<ul>{lista_g}</ul>" if garantias_t else ""}<form method="post" action="/lancamentos/{tid}/garantia" class="campos">{tk()}
<label>Item<input name="titulo" value="{e(t['descricao'])}" maxlength="120"></label>
<label>Meses de garantia<select name="meses"><option value="">Informar a data</option>{''.join(f'<option value="{m}">{m} meses</option>' for m in (3, 6, 12, 18, 24, 36, 60))}</select></label>
<label>Ou acaba em<input type="date" name="data_fim"></label><button class="secundario">Registrar garantia</button></form>
<p class="fraco">Conta a partir da data da compra (num parcelamento, vale para todas as parcelas). Anexe a nota em Comprovantes: a busca de Prazos e garantias acha os dois juntos.</p></details>''')
        botoes = []
        if t['status'] == 'confirmada' and t['tipo'] in ('despesa', 'receita') and not t['lote_id'] \
                and not any(x['conta_subtipo'] == 'cartao' for x in ls):
            volta = 'Ainda não foi pago: voltar para "a pagar"' if t['tipo'] == 'despesa' else 'Ainda não recebi: voltar para "a receber"'
            botoes.append(f'<form method="post" action="/lancamentos/{tid}/desmarcar">{tk()}<button class="secundario">{volta}</button></form>')
        if t['status'] == 'agendada':
            rotulo = {'despesa': 'Marcar como pago', 'receita': 'Marcar como recebido'}.get(t['tipo'], 'Marcar como aconteceu')
            botoes.append(f'<form method="post" action="/lancamentos/{tid}/confirmar">{tk()}<button>{rotulo}</button>'
                          f'<p class="fraco">Se a data prevista ainda não chegou, fica com a data de hoje. Para outra data ou outro valor, use <a href="/confirmar">A pagar e receber</a>.</p></form>')
            if len(ls) == 2:
                parte = 'Paguei só uma parte' if t['tipo'] != 'receita' else 'Recebi só uma parte'
                botoes.append(f'''<details class="painel-interno"><summary>{parte}…</summary><form method="post" action="/lancamentos/{tid}/parcial" class="campos">{tk()}
<label>Quanto<input name="valor" required inputmode="decimal" placeholder="0,00"></label><label>Quando<input type="date" name="data" value="{hoje().isoformat()}"></label>
<button>Registrar parte</button></form><p class="fraco">O que foi pago fica como pago nessa data; o resto continua "a pagar" num lançamento
"(restante)" na data prevista, e aparece em A pagar e receber.</p></details>''')
        botoes.append(f'<a href="/lancamentos/{tid}/excluir">Excluir…</a>')
        partes.append(f'<section class="painel"><div class="acoes">{"".join(botoes)}</div></section>')
        if t['tipo'] == 'despesa' and sum(1 for x in ls if x['conta_tipo'] == 'despesa') == 1:
            restante = abs(sum(x['valor_centavos'] for x in ls if x['conta_tipo'] == 'despesa')) - estornado
            if restante > 0:
                partes.append(f'''<section class="painel"><h2>Registrar estorno</h2><form method="post" action="/lancamentos/{tid}/estornar" class="campos">{tk()}
<label>Valor estornado<input name="valor" value="{campo_valor(restante)}" required></label>
<label>Data<input type="date" name="data" value="{hoje().isoformat()}" required></label><button>Registrar estorno</button></form>
<p class="fraco">O valor volta para a mesma conta ou cartão e reduz a despesa da categoria.</p></section>''')
            if not estornado:
                partes.append(f'''<details class="painel"><summary>Foi para outra pessoa? (vira valor a receber)</summary>
<form method="post" action="/lancamentos/{tid}/a-receber" class="campos">{tk()}
<label>Quem deve<select name="pessoa">{opcoes(ps, None, "Escolha ou escreva ao lado")}</select></label>
<label>Ou nome<input name="nome" maxlength="60" placeholder="ex.: Mãe, Carlos"></label><button class="secundario">Passar para a receber</button></form>
<p class="fraco">Para compras pagas por vocês que outra pessoa vai devolver. Sai dos gastos do mês e entra em
<a href="/receber">A receber</a>; quando a pessoa pagar, registre a devolução lá.</p></details>''')
    return req.html(t['descricao'], ''.join(partes))


@rota('POST', r'/lancamentos/(\d+)/repetir')
def lancamento_repetir(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        operacoes.repetir(c, tid, req.f('repetir'), req.f('repetir_ate') or None, hoje=hoje())
    ir(f'/lancamentos/{tid}', f'Agora repete: {dict(operacoes.FREQUENCIAS)[req.f("repetir")].lower()}. Os próximos estão em Previsões.')


@rota('POST', r'/lancamentos/(\d+)/editar')
def lancamento_editar(req):
    tid = int(req.parametros[0])
    valor = centavos(req.f('valor')) if req.f('valor') else None
    situacao = req.f('situacao')
    msg = 'Alterações salvas.'
    msg_parc = None
    with banco.transacao() as c:
        razao.editar(c, tid, req.f('descricao'), req.f('data'), req.f('observacao'), valor,
                     opcional_int(req.f('contraparte')), opcional_int(req.f('pessoa')), opcional_int(req.f('conta')))
        if req.f('todas_parcelas'):
            msg_parc = operacoes.editar_parcelas(c, tid)
            if msg_parc:
                msg = msg_parc
        operacoes.definir_forma(c, [tid], req.f('forma') or None)
        tags.definir(c, tid, req.f('tags'))
        msg = operacoes.mudar_situacao(c, tid, situacao, centavos(req.f('valor_pago')) if req.f('valor_pago') else None,
                                       req.f('data_pagamento') or None) or msg
        t = razao.transacao(c, tid)
        if req.f('proximos') and t['previsao_id']:
            prev = c.execute('SELECT * FROM previsoes WHERE id=?', (t['previsao_id'],)).fetchone()
            ls_ = razao.lancamentos_de(c, tid)
            if prev and len(ls_) == 2:
                nova_cp = next(x['conta_id'] for x in ls_ if x['conta_id'] != prev['conta_id']) \
                    if any(x['conta_id'] == prev['conta_id'] for x in ls_) else prev['contraparte_id']
                total = max(abs(x['valor_centavos']) for x in ls_)
                n = operacoes.atualizar_previsao(c, prev['id'], t['descricao'].replace(' (restante)', ''), total, prev['dia'],
                                                 prev['conta_id'], nova_cp, prev['fim'] or '', hoje=max(hoje().isoformat(), t['data']), manter=tid)
                msg += f' Próximos meses atualizados ({n}).'
    ir(f'/lancamentos/{tid}', msg)


@rota('POST', r'/lancamentos/(\d+)/dividir')
def lancamento_dividir(req):
    tid = int(req.parametros[0])
    n = min(inteiro(req.f('n') or '4', 'linhas'), 12)
    partes = []
    for i in range(n):
        cat, val = req.f(f'categoria_{i}'), req.f(f'valor_{i}').strip()
        if cat and val:
            partes.append((int(cat), centavos(val)))
        elif cat or val:
            raise ErroValidacao(f'Linha {i + 1}: escolha a categoria e informe o valor (ou deixe as duas em branco).')
    with banco.transacao() as c:
        k = razao.dividir(c, tid, partes)
    ir(f'/lancamentos/{tid}', f'Dividido em {k} categorias.' if k > 1 else 'Categoria atualizada.')


@rota('POST', r'/lancamentos/(\d+)/anexos')
def lancamento_anexar(req):
    tid = int(req.parametros[0])
    if 'arquivo' not in req.arquivos or not req.arquivos['arquivo'][1]:
        raise ErroValidacao('Escolha um arquivo.')
    nome, dados = req.arquivos['arquivo']
    with banco.transacao() as c:
        anexos.adicionar(c, tid, nome, dados)
    ir(f'/lancamentos/{tid}', 'Comprovante anexado.')


@rota('GET', r'/anexos/(\d+)')
def anexo_baixar(req):
    import urllib.parse
    with banco.conexao() as c:
        a = anexos.obter(c, int(req.parametros[0]))
    nome = urllib.parse.quote(a['nome'])
    # Sempre como download: o navegador não interpreta o arquivo dentro do app.
    return 200, 'application/octet-stream', bytes(a['dados']), {
        'Content-Disposition': f"attachment; filename=\"anexo{a['id']}\"; filename*=UTF-8''{nome}"}


@rota('POST', r'/anexos/(\d+)/excluir')
def anexo_excluir(req):
    with banco.transacao() as c:
        tid = anexos.excluir(c, int(req.parametros[0]))
    ir(f'/lancamentos/{tid}', 'Comprovante excluído.')


@rota('POST', r'/lancamentos/(\d+)/confirmar')
def lancamento_confirmar(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        t = razao.transacao(c, tid)
        adiantado = t['data'] > hoje().isoformat()        # pagou antes da data prevista: fica com a data de hoje
        operacoes.confirmar_previsto(c, tid, None, hoje().isoformat() if adiantado else None)
    ir(f'/lancamentos/{tid}', {'despesa': 'Marcado como pago.', 'receita': 'Marcado como recebido.'}.get(t['tipo'], 'Marcado como acontecido.'))


@rota('POST', '/lancamentos/situacao')
def lancamentos_situacao(req):
    ids = [int(x) for x in req.lista('ids') if x.isdigit()]
    if not ids:
        raise ErroValidacao('Marque ao menos um lançamento na primeira coluna.')
    situacao = req.f('situacao')
    if situacao not in ('pago', 'a_pagar', 'editar'):
        raise ErroValidacao('Situação inválida.')
    volta = req.f('volta') if req.f('volta').startswith('/lancamentos') else '/lancamentos'
    with banco.transacao() as c:
        if situacao == 'editar':
            feitos, pulados = operacoes.editar_em_lote(c, ids, opcional_int(req.f('categoria_lote')), opcional_int(req.f('conta_lote')))
            msg = f'{feitos} lançamento(s) alterado(s).'
        else:
            feitos, pulados = 0, []
            for tid in ids:
                res = []
                erro = operacoes._tentar(c, lambda: res.append(operacoes.mudar_situacao(c, tid, situacao)))
                if erro:
                    pulados.append((tid, erro))
                elif res and res[0]:
                    feitos += 1
            rot = 'pago(s)/recebido(s)' if situacao == 'pago' else '"a pagar"/"a receber"'
            msg = f'{feitos} lançamento(s) marcado(s) como {rot}.'
            ja = len(ids) - feitos - len(pulados)
            if ja:
                msg += f' {ja} já estava(m) assim.'
        if pulados:
            nomes = {r[0]: r[1] for r in c.execute(f'SELECT id, descricao FROM transacoes WHERE id IN ({",".join("?" * len(pulados))})',
                                                   [p[0] for p in pulados])}
            msg += f' {len(pulados)} ficaram como estavam: ' + '; '.join(f'{nomes.get(i, i)} ({m})' for i, m in pulados[:5]) + \
                   (' …' if len(pulados) > 5 else '') + '.'
    ir(volta, msg)


@rota('POST', r'/lancamentos/(\d+)/mover')
def lancamento_mover(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        msg = operacoes.mover_parcelas(c, tid, inteiro(req.f('cartao'), 'cartão'))
    ir(f'/lancamentos/{tid}', msg)


@rota('POST', r'/lancamentos/(\d+)/desmarcar')
def lancamento_desmarcar(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        operacoes.desmarcar_pago(c, tid)
    ir(f'/lancamentos/{tid}', 'Voltou para "a pagar". Aparece em A pagar e receber e em Em aberto.')


@rota('POST', r'/lancamentos/(\d+)/parcial')
def lancamento_parcial(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        _, nova = operacoes.pagar_parte(c, tid, centavos(req.f('valor')), req.f('data') or None)
    if nova:
        ir(f'/lancamentos/{tid}', f'Parte registrada. O restante continua a pagar (lançamento {nova}).')
    ir(f'/lancamentos/{tid}', 'Valor todo registrado.')


@rota('POST', r'/lancamentos/(\d+)/estornar')
def lancamento_estornar(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        nid = razao.estornar(c, tid, centavos(req.f('valor')), req.f('data'))
    ir(f'/lancamentos/{nid}', 'Estorno registrado.')


@rota('GET', r'/lancamentos/(\d+)/excluir')
def lancamento_excluir_confirmar(req):
    tid = int(req.parametros[0])
    with banco.conexao() as c:
        t = razao.transacao(c, tid)
        total = sum(x['valor_centavos'] for x in razao.lancamentos_de(c, tid) if x['valor_centavos'] > 0)
        n_plano = c.execute('SELECT COUNT(*) FROM transacoes WHERE plano_id=?', (t['plano_id'],)).fetchone()[0] if t['plano_id'] else 0
        importado = c.execute('SELECT 1 FROM linhas_importacao WHERE transacao_id=?', (tid,)).fetchone()
        n_anexos = anexos.contar(c, tid)
    extra = f'<label class="check"><input type="checkbox" name="plano" value="1"> Excluir as {n_plano} parcelas deste parcelamento</label>' if n_plano else ''
    nota = '<p class="fraco">Este lançamento veio de um extrato importado: a linha volta a ficar pendente de revisão.</p>' if importado else ''
    corpo = f'''<section class="painel"><p>Excluir <b>{e(t['descricao'])}</b> de {data_br(t['data'])}, {dinheiro(total)}?</p>{nota}
<p class="fraco">Vai para a Lixeira por 90 dias: dá para restaurar.</p>
{f'<p>{aviso(f"Este lançamento tem {n_anexos} comprovante(s) anexado(s): eles são apagados e não voltam com a Lixeira. Baixe antes, se precisar.", "atencao")}</p>' if n_anexos else ''}
<form method="post" action="/lancamentos/{tid}/excluir" class="acoes">{tk()}{extra}
<label class="check"><input type="checkbox" name="confirmo" value="1" required> Confirmo a exclusão</label>
<button class="perigo">Excluir</button><a href="/lancamentos/{tid}">Cancelar</a></form></section>'''
    return req.html('Confirmar exclusão', corpo)


@rota('POST', r'/lancamentos/(\d+)/excluir')
def lancamento_excluir(req):
    tid = int(req.parametros[0])
    if req.f('confirmo') != '1':
        raise ErroValidacao('Marque a confirmação para excluir.')
    with banco.transacao() as c:
        t = razao.transacao(c, tid)
        n = razao.excluir(c, tid, plano_inteiro=req.f('plano') == '1')
    ir(f'/lancamentos?mes={t["data"][:7]}', f'{n} lançamento(s) excluído(s).')


@rota('GET', '/confirmar')
def confirmar_pagina(req):
    from fin404.dinheiro import fim_do_mes, mes_seguinte
    limite = fim_do_mes(mes_seguinte(hoje().strftime('%Y-%m'))).isoformat()
    with banco.conexao() as c:
        rows = c.execute('''SELECT t.*, (SELECT SUM(valor_centavos) FROM lancamentos WHERE transacao_id=t.id AND valor_centavos>0) total,
            (SELECT group_concat(k.nome, ', ') FROM lancamentos l JOIN contas k ON k.id=l.conta_id WHERE l.transacao_id=t.id AND k.tipo IN ('ativo','passivo')) contas,
            (SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN contas k ON k.id=l.conta_id WHERE l.transacao_id=t.id AND k.tipo IN ('receita','despesa')) efeito
            FROM transacoes t WHERE t.status='agendada' AND t.data<=? ORDER BY t.data, t.id''', (limite,)).fetchall()
    if not rows:
        return req.html('A pagar e receber', '<div class="vazio">Nada a pagar nem a receber até o fim do mês que vem. Para lançar uma conta que ainda vai pagar, '
                        'use Novo lançamento com a situação "A pagar".</div>')
    trs = []
    for t in rows:
        efeito = -(t['efeito'] or 0)
        atrasado = ' <span class="selo vermelho">atrasado</span>' if t['data'] < hoje().isoformat() else ''
        trs.append(f'''<tr><td><label class="check"><input type="checkbox" name="ok_{t['id']}" value="1"> {"paguei" if efeito < 0 else "recebi" if efeito > 0 else "aconteceu"}</label></td>
<td>{e(t['descricao'])}{atrasado}<br><span class="fraco">{e(t['contas'] or '')}</span></td><td class="n">{dinheiro(efeito, cor=True) if t['efeito'] else dinheiro(t['total'])}</td>
<td><input type="date" name="data_{t['id']}" value="{e(t['data'])}"></td><td><input name="valor_{t['id']}" value="{campo_valor(t['total'])}" size="9" inputmode="decimal"></td>
<td><select name="modo_{t['id']}" aria-label="Pagou tudo ou parte"><option value="">É o valor final</option><option value="parte">Foi só uma parte: o resto continua</option></select></td></tr>''')
    corpo = f'''<section class="painel"><form method="post" action="/confirmar">{tk()}
<table><thead><tr><th>Já foi?</th><th>Conta</th><th class="n">Valor previsto</th><th>Data em que pagou/recebeu</th><th>Valor pago/recebido</th><th>Pagou tudo?</th></tr></thead><tbody>{''.join(trs)}</tbody></table>
<div class="acoes"><button>Marcar como pagos/recebidos</button></div></form>
<p class="fraco">Marque o que já foi pago ou recebido e corrija a data ou o valor se mudaram (conta de luz, por exemplo). O que não for
marcado continua "a pagar" ou "a receber", e o atrasado fica em vermelho. Mostra tudo até o fim do mês que vem.
Pagou só uma parte (uma parcela da obra, metade de um boleto)? Escreva quanto pagou e escolha "Foi só uma parte": o resto
continua a pagar. Valor diferente com "É o valor final" (a conta de luz veio menor) troca o valor e encerra.</p></section>'''
    return req.html('A pagar e receber', corpo, 'Contas lançadas que ainda não foram pagas, e dinheiro que ainda vai cair.')


@rota('POST', '/confirmar')
def confirmar_salvar(req):
    n = 0
    with banco.transacao() as c:
        for chave, v in req.form.items():
            if chave.startswith('ok_') and chave[3:].isdigit() and v and v[0] == '1':
                tid = int(chave[3:])
                valor_txt = req.f(f'valor_{tid}')
                if req.f(f'modo_{tid}') == 'parte' and valor_txt:
                    operacoes.pagar_parte(c, tid, centavos(valor_txt), req.f(f'data_{tid}') or None)
                else:
                    operacoes.confirmar_previsto(c, tid, centavos(valor_txt) if valor_txt else None, req.f(f'data_{tid}') or None)
                n += 1
    ir('/confirmar', f'{n} lançamento(s) marcado(s) como pago ou recebido.' if n else 'Nada marcado.')


@rota('POST', '/lancamentos/filtros')
def filtros_salvar(req):
    nome = ' '.join(req.f('nome').split())[:40]
    consulta = req.f('consulta')
    if not nome or not consulta:
        raise ErroValidacao('Dê um nome ao filtro.')
    with banco.transacao() as c:
        salvos = [f for f in (config.obter('filtros_salvos', [], c) or []) if f['nome'].lower() != nome.lower()]
        salvos.append({'nome': nome, 'consulta': consulta})
        config.definir('filtros_salvos', salvos[-20:], c)
    raise Redirecionar(f'/lancamentos?{consulta}')


@rota('GET', '/lancamentos/filtros')
def filtros_gerenciar(req):
    with banco.conexao() as c:
        salvos = config.obter('filtros_salvos', [], c) or []
    linhas = [[f'<a href="/lancamentos?{e(f["consulta"])}">{e(f["nome"])}</a>',
               botao_excluir(f'/lancamentos/filtros/{i}/excluir', f'O filtro "{f["nome"]}" será apagado (os lançamentos não mudam).')]
              for i, f in enumerate(salvos)]
    corpo = f'<section class="painel">{tabela(["Filtro", ""], linhas, (), "Nenhum filtro salvo. Filtre em Lançamentos e use Salvar este filtro.")}</section>'
    return req.html('Filtros salvos', corpo)


@rota('POST', r'/lancamentos/filtros/(\d+)/excluir')
def filtros_excluir(req):
    i = int(req.parametros[0])
    with banco.transacao() as c:
        salvos = config.obter('filtros_salvos', [], c) or []
        if i < len(salvos):
            del salvos[i]
        config.definir('filtros_salvos', salvos, c)
    ir('/lancamentos/filtros', 'Filtro excluído.')
