"""Orçamento, previsões e fechamento do mês."""
import datetime

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao, centavos, fim_do_mes, fmt_mes, formatar, mes as ler_mes, somar_meses
from fin404.dominio import conferencias, operacoes, relatorios
from fin404.web.base import (categorias, grupos_contas, hoje, inteiro, ir, mes_atual, mes_param)
from fin404.web.componentes import aviso, botao_excluir, opcoes, barra, campo_valor, dinheiro, e, mes_br, opcoes_agrupadas, selo, tabela
from fin404.web.servidor import rota, token_html as tk


# ------------------------------------------------------------------ orçamento e previsões

@rota('GET', '/orcamento')
def orcamento(req):
    ym = mes_param(req)
    with banco.conexao() as c:
        itens = relatorios.orcamento(c, ym)
    linhas = []
    for r in itens:
        restante = (r['limite'] - r['gasto']) if r['limite'] else None
        linhas.append(f'''<tr><td>{e(r['nome'])}</td><td class="n"><input name="lim_{r['id']}" value="{campo_valor(r['limite'])}" size="10" inputmode="decimal"></td>
<td class="n">{dinheiro(r['gasto'])}</td><td class="n">{dinheiro(restante, cor=True) if restante is not None else ''}</td><td>{barra(r['gasto'], r['limite']) if r['limite'] else ''}</td></tr>''')
    ant = somar_meses(datetime.date.fromisoformat(ym + '-01'), -1).strftime('%Y-%m')
    corpo = f'''<form method="get" class="acoes painel"><label>Mês<input type="month" name="mes" value="{e(ym)}"></label><button class="secundario">Ver</button></form>
<section class="painel"><form method="post" action="/orcamento">{tk()}<input type="hidden" name="mes" value="{e(ym)}">
<table><thead><tr><th>Categoria</th><th class="n">Limite</th><th class="n">Gasto</th><th class="n">Restante</th><th></th></tr></thead><tbody>{''.join(linhas)}</tbody></table>
<div class="acoes"><button>Salvar limites</button></div></form></section>
<form method="post" action="/orcamento/copiar" class="acoes">{tk()}<input type="hidden" name="mes" value="{e(ym)}"><input type="hidden" name="de" value="{ant}">
<button class="secundario">Copiar limites de {mes_br(ant)}</button></form>'''
    return req.html(f'Orçamento de {fmt_mes(ym)}', corpo, 'Deixe em branco as categorias sem limite. O gasto já desconta estornos.')


@rota('POST', '/orcamento')
def orcamento_salvar(req):
    ym = ler_mes(req.f('mes'))
    with banco.transacao() as c:
        for k, v in req.form.items():
            if k.startswith('lim_') and k[4:].isdigit():
                valor = centavos(v[0], permitir_zero=True) if v and v[0].strip() else 0
                relatorios.definir_orcamento(c, ym, int(k[4:]), valor)
    ir(f'/orcamento?mes={ym}', 'Orçamento salvo.')


@rota('POST', '/orcamento/copiar')
def orcamento_copiar(req):
    ym, de = ler_mes(req.f('mes')), ler_mes(req.f('de'))
    with banco.transacao() as c:
        relatorios.copiar_orcamento(c, de, ym)
    ir(f'/orcamento?mes={ym}', 'Limites copiados (os já definidos foram mantidos).')


@rota('GET', '/previsoes')
def previsoes(req):
    with banco.conexao() as c:
        lista = c.execute('''SELECT p.*, k.nome conta, cp.nome contraparte FROM previsoes p JOIN contas k ON k.id=p.conta_id
                             JOIN contas cp ON cp.id=p.contraparte_id ORDER BY p.ativa DESC, p.dia''').fetchall()
        g_contas = grupos_contas(c, investimentos=True, dividas=True)
        prov = operacoes.provisoes_anuais(c)
        g_cp = [('Categorias de despesa', categorias(c, 'despesa')), ('Categorias de receita', categorias(c, 'receita'))] + \
            grupos_contas(c, investimentos=True, dividas=True)
    def quando(p):
        f = operacoes.frequencia(p)
        if f == 'anual':
            return f'todo ano em {p["dia"]:02d}/{(p["mes_do_ano"] or int(p["inicio"][5:])):02d}'
        if f in operacoes.INTERVALO_DIAS:
            from datetime import date as _d
            dias = ('segunda', 'terça', 'quarta', 'quinta', 'sexta', 'sábado', 'domingo')
            return f'{dict(operacoes.FREQUENCIAS)[f].lower()} ({dias[_d.fromisoformat(p["data_base"]).weekday()]})'
        if f == 'mensal':
            return f'todo mês, dia {p["dia"]}'
        return f'{dict(operacoes.FREQUENCIAS)[f].lower()}, dia {p["dia"]}'
    def editar(p):
        return (f'<details class="editar-prev"><summary>Editar…</summary><form method="post" action="/previsoes/{p["id"]}/editar" class="campos">{tk()}'
                f'<label>Descrição<input name="descricao" value="{e(p["descricao"])}" required maxlength="200"></label>'
                f'<label>Valor<input name="valor" value="{campo_valor(p["valor_centavos"])}" required inputmode="decimal"></label>'
                f'<label>Dia do mês<input type="number" name="dia" min="1" max="31" value="{p["dia"]}" required></label>'
                f'<label>Conta ou cartão<select name="conta" required>{opcoes_agrupadas(g_contas, p["conta_id"], "Escolha…")}</select></label>'
                f'<label>Categoria ou contrapartida<select name="contraparte" required>{opcoes_agrupadas(g_cp, p["contraparte_id"], "Escolha…")}</select></label>'
                f'<label>Termina em<input type="month" name="fim" value="{e(p["fim"] or "")}"></label>'
                '<button>Salvar</button></form><p class="fraco">Vale a partir de hoje: os previstos dos próximos meses são refeitos com os '
                'dados novos. Os já pagos e os atrasados não mudam.</p></details>')
    linhas = [[e(p['descricao']) + (editar(p) if p['ativa'] else ''), dinheiro(p['valor_centavos'] * (1 if p['sentido'] == 'entrada' else -1), cor=True), quando(p),
               e(p['conta']), e(p['contraparte']), f'{mes_br(p["inicio"])} a {mes_br(p["fim"]) if p["fim"] else "sem fim"}',
               ((f'<form method="post" action="/previsoes/{p["id"]}/encerrar">{tk()}<button class="secundario" title="Para de gerar; os já confirmados ficam">'
                 'Encerrar</button></form>') if p['ativa'] else selo('encerrada'))
               + botao_excluir(f'/previsoes/{p["id"]}/excluir', f'"{p["descricao"]}" será apagada, com todos os previstos dela ainda não confirmados. '
                               'Os que já foram confirmados continuam como lançamentos.')] for p in lista]
    prox = somar_meses(hoje(), 12).strftime('%Y-%m')
    caixa_prov = (f'<div class="cartoes"><div class="cartao"><small>Despesas anuais previstas</small><strong>{dinheiro(prov["total_ano"])}</strong>'
                  f'<em>{len(prov["itens"])} item(ns): {e(", ".join(x["descricao"] for x in prov["itens"])[:120])}</em></div>'
                  f'<div class="cartao"><small>Separar por mês</small><strong>{dinheiro(prov["por_mes"])}</strong>'
                  '<em>para não ser pego de surpresa</em></div></div>') if prov['itens'] else ''
    corpo = caixa_prov + f'''<section class="painel">{tabela(['Descrição', 'Valor', 'Quando', 'Conta', 'Categoria / contrapartida', 'Período', ''], linhas, (1,), 'Nenhuma previsão cadastrada.')}</section>
<section class="painel"><h2>Nova previsão</h2><form method="post" action="/previsoes" class="campos">{tk()}
<label>Descrição<input name="descricao" required maxlength="200" placeholder="Salário, aluguel, escola…"></label>
<label>Valor<input name="valor" required inputmode="decimal"></label>
<label>Sentido<select name="sentido"><option value="saida">Saída</option><option value="entrada">Entrada</option></select></label>
<label>Conta ou cartão<select name="conta" required>{opcoes_agrupadas(g_contas, None, 'Escolha…')}</select></label>
<label>Categoria ou conta de contrapartida<select name="contraparte" required>{opcoes_agrupadas(g_cp, None, 'Escolha…')}</select></label>
<label>Repete<select name="periodicidade">{opcoes(list(operacoes.FREQUENCIAS), 'mensal')}</select></label>
<label>Dia do mês<input type="number" name="dia" min="1" max="31" value="5" required></label>
<label>Mês (se for anual)<select name="mes_do_ano"><option value="">—</option>{''.join(f'<option value="{m}">{n}</option>' for m, n in enumerate(('janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'), 1))}</select></label>
<label>1ª vez (se for semanal ou a cada 2 semanas)<input type="date" name="data_base"></label>
<label>Começa em<input type="month" name="inicio" value="{mes_atual()}" required></label><label>Termina em<input type="month" name="fim"></label>
<button>Cadastrar</button></form>
<p class="fraco">Mensal, a cada 2/3/6 meses: usa o dia do mês e começa no mês de início (ex.: trimestral começando em jan = jan, abr, jul, out).
Anual: dia + mês do ano. Semanal ou a cada 2 semanas: repete a partir da data da 1ª vez (diarista, feira, mesada).</p></section>
<section class="painel"><h2>Gerar lançamentos previstos</h2><form method="post" action="/previsoes/gerar" class="acoes">{tk()}
<label>Até<input type="month" name="ate" value="{prox}"></label><button class="secundario">Gerar</button></form>
<p class="fraco">Cria lançamentos "previstos" para os meses futuros, sem duplicar. Eles aparecem no fluxo de caixa e são casados
com os reais ao importar o extrato. Meses passados não são gerados.</p></section>'''
    return req.html('Previsões', corpo, 'Receitas e despesas que se repetem: o que ainda vai acontecer.')


@rota('POST', '/previsoes')
def previsoes_criar(req):
    with banco.transacao() as c:
        operacoes.criar_previsao(c, req.f('descricao'), centavos(req.f('valor')), inteiro(req.f('conta'), 'conta'),
                                 inteiro(req.f('contraparte'), 'categoria'), req.f('sentido'), inteiro(req.f('dia'), 'dia'),
                                 req.f('inicio'), req.f('fim'), req.f('periodicidade') or 'mensal', req.f('mes_do_ano') or None,
                                 req.f('data_base') or None)
        n = operacoes.gerar_previsoes(c, somar_meses(hoje(), 12).strftime('%Y-%m'))
    ir('/previsoes', f'Previsão cadastrada; {n} lançamento(s) previsto(s) criado(s) para os próximos 12 meses.')


@rota('POST', '/previsoes/gerar')
def previsoes_gerar(req):
    with banco.transacao() as c:
        n = operacoes.gerar_previsoes(c, ler_mes(req.f('ate')))
    ir('/previsoes', f'{n} lançamento(s) previsto(s) criado(s).')


@rota('POST', r'/previsoes/(\d+)/editar')
def previsao_editar(req):
    with banco.transacao() as c:
        n = operacoes.atualizar_previsao(c, int(req.parametros[0]), req.f('descricao'), centavos(req.f('valor')), req.f('dia'),
                                         inteiro(req.f('conta'), 'conta'), inteiro(req.f('contraparte'), 'categoria'), req.f('fim'))
    ir('/previsoes', f'Previsão atualizada; {n} previsto(s) dos próximos meses refeito(s).')


@rota('POST', r'/previsoes/(\d+)/encerrar')
def previsoes_encerrar(req):
    with banco.transacao() as c:
        operacoes.encerrar_previsao(c, int(req.parametros[0]))
    ir('/previsoes', 'Previsão encerrada; os previstos futuros foram removidos.')


# ------------------------------------------------------------------ fechamento

@rota('GET', '/fechamento')
def fechamento(req):
    ym = mes_param(req, padrao=somar_meses(hoje().replace(day=1), -1).strftime('%Y-%m'))
    inicio, fim = ym + '-01', fim_do_mes(ym).isoformat()
    with banco.conexao() as c:
        fechados = {r[0] for r in c.execute('SELECT mes FROM meses_fechados')}
        pend_imp = c.execute("SELECT COUNT(*) FROM linhas_importacao li JOIN lotes_importacao lo ON lo.id=li.lote_id WHERE lo.desfeito_em IS NULL "
                             "AND li.situacao IN ('nova','duplicada') AND li.data BETWEEN ? AND ?", (inicio, fim)).fetchone()[0]
        prev = c.execute("SELECT COUNT(*) FROM transacoes WHERE status='agendada' AND data BETWEEN ? AND ?", (inicio, fim)).fetchone()[0]
        nao_conc = c.execute('''SELECT COUNT(*) FROM transacoes t WHERE t.status='confirmada' AND t.data BETWEEN ? AND ?
                                AND EXISTS(SELECT 1 FROM lancamentos l JOIN contas k ON k.id=l.conta_id WHERE l.transacao_id=t.id AND k.subtipo IN ('corrente','cartao'))''',
                             (inicio, fim)).fetchone()[0]
        r = relatorios.resumo_mes(c, ym)
        situ = conferencias.situacao_do_mes(c, ym)
    meses = [somar_meses(hoje().replace(day=1), -i).strftime('%Y-%m') for i in range(12, -1, -1)]
    faltam = [x for x in situ if x['estado'] in ('pendente', 'diferenca')]
    linhas_conf = []
    for x in situ:
        k = x['conta']
        conferir = f'<a href="/contas/{k["id"]}?conferir={fim}#conferir">conferir saldo de {fim[8:10]}/{fim[5:7]}</a>'
        if x['estado'] == 'conferida':
            estado, acoes = selo(f'bateu em {x["conferencia"]["data"][8:10]}/{x["conferencia"]["data"][5:7]}', 'verde'), ''
        elif x['estado'] == 'dispensada':
            mot = x['dispensa']['motivo']
            estado = selo('dispensada', 'amarelo') + (f' <span class="fraco">{e(mot)}</span>' if mot else '')
            acoes = (f'<form method="post" action="/fechamento" class="acoes">{tk()}<input type="hidden" name="mes" value="{ym}">'
                     f'<input type="hidden" name="acao" value="desfazer_dispensa"><input type="hidden" name="conta" value="{k["id"]}">'
                     '<button class="secundario">Desfazer</button></form>') if ym not in fechados else ''
        else:
            estado = (selo(f'diferença de {formatar(x["conferencia"]["diferenca"])}', 'vermelho') if x['estado'] == 'diferenca'
                      else selo('não conferida', 'vermelho'))
            acoes = conferir + (f'''<details><summary>Dispensar neste mês</summary><form method="post" action="/fechamento" class="campos">{tk()}
<input type="hidden" name="mes" value="{ym}"><input type="hidden" name="acao" value="dispensar"><input type="hidden" name="conta" value="{k['id']}">
<label>Motivo<input name="motivo" maxlength="200" placeholder="sem acesso ao app do banco, conta parada…"></label>
<button class="secundario">Dispensar</button></form></details>''' if ym not in fechados else '')
        linhas_conf.append([e(k['nome']), estado, acoes])
    abas = '<div class="abas">' + ''.join(f'<a href="/fechamento?mes={m}"{" class=atual" if m == ym else ""}>{mes_br(m)}{" ✓" if m in fechados else ""}</a>' for m in meses) + '</div>'
    itens = [
        (pend_imp == 0, f'Linhas de extrato pendentes de revisão no mês: {pend_imp}', '/importacoes'),
        (prev == 0, f'Lançamentos previstos não confirmados no mês: {prev}', f'/lancamentos?mes={ym}&status=agendada'),
        (nao_conc == 0, f'Lançamentos de conta corrente/cartão não conferidos com extrato: {nao_conc} (lançados à mão e não casados)', f'/lancamentos?mes={ym}&status=confirmada'),
    ]
    check = ''.join(f'<li>{selo("ok", "verde") if ok else selo("verificar", "amarelo")} <a href="{e(link)}">{e(txt)}</a></li>' for ok, txt, link in itens)
    if ym in fechados:
        acao = f'''<p><a href="/reuniao?mes={ym}">Abrir a reunião de {mes_br(ym)}</a></p><form method="post" action="/fechamento" class="acoes">{tk()}<input type="hidden" name="mes" value="{ym}"><input type="hidden" name="acao" value="reabrir">
<button class="secundario">Reabrir {mes_br(ym)}</button></form>'''
    elif faltam:
        acao = (f'<p><button disabled>Fechar {mes_br(ym)}</button> <span class="fraco">Falta conferir ou dispensar '
                f'{len(faltam)} conta(s) acima.</span></p>')
    else:
        acao = f'''<form method="post" action="/fechamento" class="acoes">{tk()}<input type="hidden" name="mes" value="{ym}"><input type="hidden" name="acao" value="fechar">
<button>Fechar {mes_br(ym)}</button></form>'''
    tabela_conf = tabela(['Conta', 'Saldo conferido com o banco', ''], linhas_conf, (), 'Nenhuma conta com movimento até o fim do mês.')
    corpo = f'''{abas}<section class="painel"><h2>Conferência das contas em {mes_br(ym)}</h2>{tabela_conf}
<p class="fraco">Sem extrato, Pix, boletos e saques só aparecem se forem lançados à mão. Conferir o saldo do fim do mês com o
app do banco é o que mostra o que ficou de fora. Para fechar, cada conta precisa bater ou ter a conferência dispensada.</p></section>
<section class="painel"><h2>Checklist de {mes_br(ym)}</h2><ul class="lista-alertas">{check}</ul>
<p>Receitas {dinheiro(r['total_receitas'])} · despesas {dinheiro(r['total_despesas'])} · resultado {dinheiro(r['resultado'], cor=True)}</p>
<p class="fraco">Mês fechado não aceita inclusão, edição ou exclusão de lançamentos (garantido também pelo banco de dados). Pode ser reaberto.</p>{acao}</section>'''
    return req.html('Fechamento do mês', corpo)


@rota('POST', '/fechamento')
def fechamento_acao(req):
    ym = ler_mes(req.f('mes'))
    with banco.transacao() as c:
        if req.f('acao') == 'fechar':
            conferencias.fechar_mes(c, ym)
            msg = f'{fmt_mes(ym)} fechado. Próximo passo: a reunião do mês.'
        elif req.f('acao') == 'dispensar':
            conferencias.dispensar(c, ym, inteiro(req.f('conta'), 'conta'), req.f('motivo'))
            msg = 'Conferência dispensada para este mês (registrado na auditoria).'
        elif req.f('acao') == 'desfazer_dispensa':
            conferencias.desfazer_dispensa(c, ym, inteiro(req.f('conta'), 'conta'))
            msg = 'Dispensa desfeita.'
        elif req.f('acao') == 'reabrir':
            c.execute('DELETE FROM meses_fechados WHERE mes=?', (ym,))
            banco.auditar(c, 'reabrir', 'mes', None, ym)
            msg = f'{fmt_mes(ym)} reaberto.'
        else:
            raise ErroValidacao('Ação desconhecida.')
    volta = req.f('volta')
    if volta.startswith('/lancamentos/') and req.f('acao') == 'reabrir':
        ir(volta, msg + ' Agora dá para editar.')
    ir(f'/fechamento?mes={ym}', msg)


@rota('POST', r'/previsoes/(\d+)/excluir')
def previsoes_excluir(req):
    with banco.transacao() as c:
        nome, n = operacoes.excluir_previsao(c, int(req.parametros[0]))
    ir('/previsoes', f'Previsão "{nome}" excluída' + (f', com {n} previsto(s) não confirmado(s).' if n else '.'))


@rota('GET', '/proximos')
def proximos_meses(req):
    """Previsão dos próximos meses: entradas, saídas e o saldo no fim de cada mês."""
    _mes_br = mes_br
    n = req.q('meses')
    n = int(n) if n in ('3', '6', '12') else 6
    estimar = req.q('estimar') != '0'
    with banco.conexao() as c:
        r = relatorios.proximos_meses(c, n, estimar)
    linhas = [[_mes_br(x['ym']), dinheiro(x['entradas']), dinheiro(x['faturas']), dinheiro(x['contas']), dinheiro(x['compras']),
               dinheiro(x['estimativa']) if estimar else '<span class="fraco">—</span>', f'<strong>{dinheiro(x["saidas"])}</strong>',
               dinheiro(x['entradas'] - x['saidas'], cor=True), dinheiro(x['saldo_fim'], cor=True)] for x in r['meses']]
    abas = '<div class="abas">' + ''.join(f'<a href="/proximos?meses={m}&amp;estimar={"1" if estimar else "0"}"{" class=atual" if m == n else ""}>{m} meses</a>'
                                          for m in (3, 6, 12)) + '</div>'
    troca = (f'<a href="/proximos?meses={n}&amp;estimar=0">Ver sem a estimativa do dia a dia</a>' if estimar
             else f'<a href="/proximos?meses={n}&amp;estimar=1">Incluir a estimativa do dia a dia</a>')
    alerta = (aviso(f'O dinheiro disponível fica negativo em {_mes_br(r["primeiro_negativo"])}. Veja o que dá para adiar ou cortar antes.', 'erro')
              if r['primeiro_negativo'] else '')
    ultimo = r['meses'][-1]
    corpo = f'''{abas}{alerta}<div class="cartoes">
<div class="cartao"><small>Disponível hoje</small><strong>{dinheiro(r['inicial'])}</strong><em>contas, poupança e dinheiro</em></div>
<div class="cartao"><small>Sai nos próximos {n} meses</small><strong>{dinheiro(sum(x['saidas'] for x in r['meses']))}</strong><em>entra {dinheiro(sum(x['entradas'] for x in r['meses']))}</em></div>
<div class="cartao"><small>Saldo no fim de {_mes_br(ultimo['ym'])}</small><strong>{dinheiro(ultimo['saldo_fim'], cor=True)}</strong><em>se tudo sair como previsto</em></div>
<div class="cartao"><small>Dia a dia (média)</small><strong>{dinheiro(r['media_dia_a_dia'])}</strong><em>por mês, últimos 3 meses</em></div></div>
<section class="painel">{tabela(['Mês', 'Entra', 'Faturas', 'Contas', 'Compras planejadas', 'Dia a dia (estimativa)', 'Sai', 'Resultado', 'Saldo no fim do mês'],
                         linhas, (1, 2, 3, 4, 5, 6, 7, 8), ordenar=False, ocultar_movel=(2, 3, 4, 5))}
<p class="fraco"><b>Entra:</b> salário e receitas previstas ou lançadas com data futura. <b>Faturas:</b> o total de cada fatura no mês do
vencimento (a vencida e não paga entra agora); nas faturas futuras, só o que já está lançado (parcelas e compras). <b>Contas:</b> o que está
"a pagar" e as previsões (condomínio, internet…). <b>Compras planejadas:</b> o que o plano de compras pede para guardar ou pagar no mês.
<b>Dia a dia:</b> estimativa pela média dos gastos dos últimos 3 meses que não são parcela nem conta fixa (mercado, comida, transporte);
no mês atual, só o que falta da média. {troca}.</p></section>
<p class="fraco">Para a previsão ficar boa: cadastre as contas fixas e o salário em <a href="/previsoes">Previsões</a> (ou lance com "Repete todo
mês") e mantenha as compras do cartão em dia.</p>'''
    return req.html('Próximos meses', corpo, 'Quanto entra, quanto sai e com quanto vocês ficam no fim de cada mês.')
