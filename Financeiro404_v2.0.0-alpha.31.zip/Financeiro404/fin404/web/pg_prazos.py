"""Prazos e garantias (R12): painel único, busca ("a geladeira ainda está na garantia?"), renovar e concluir."""
from fin404.dados import banco
from fin404.dominio import prazos
from fin404.web.base import hoje, inteiro, ir, opcional_int
from fin404.web.componentes import botao_excluir, data_br, e, opcoes, selo, tabela
from fin404.web.servidor import rota, token_html as tk

AVISOS = [(7, '7 dias antes'), (15, '15 dias antes'), (30, '30 dias antes'), (60, '60 dias antes'), (90, '90 dias antes')]
REPETE = [(12, 'todo ano'), (24, 'a cada 2 anos'), (36, 'a cada 3 anos'), (60, 'a cada 5 anos'), (120, 'a cada 10 anos'),
          (6, 'a cada 6 meses')]
COR = {'acabou': '', 'acabando': 'amarelo', 'na garantia': 'verde', 'vencido': 'vermelho', 'perto': 'amarelo', 'em dia': 'verde'}


def _estado(p):
    if p['tipo'] == 'garantia' and p['dias'] < 0:
        return selo('garantia acabou', '')
    rot = {'acabando': f'acaba em {p["dias"]} dias', 'na garantia': f'na garantia ({p["dias"]} dias)',
           'vencido': f'venceu há {-p["dias"]} dias', 'perto': f'vence em {p["dias"]} dias', 'em dia': f'{p["dias"]} dias'}
    return selo('vence hoje' if p['dias'] == 0 else rot.get(p['estado'], p['estado']), COR.get(p['estado'], ''))


def _origem(p):
    if p.get('transacao_id'):
        return f'<span class="fraco">·</span> <a href="/lancamentos/{p["transacao_id"]}">ver lançamento</a>'
    if p.get('compra_id'):
        return f'<span class="fraco">·</span> <a href="/compras/{p["compra_id"]}">ver compra</a>'
    if p.get('nota_id'):
        return f'<span class="fraco">·</span> <a href="/notas/{p["nota_id"]}">ver nota fiscal</a>'
    return ''


def _campos(p=None):
    p = dict(p or {})
    return f'''<label>Tipo<select name="tipo">{opcoes(prazos.TIPOS.items(), p.get('tipo', 'cnh'))}</select></label>
<label>Do quê<input name="titulo" value="{e(p.get('titulo', ''))}" maxlength="120" required placeholder="CNH do José, seguro do carro, aluguel…"></label>
<label>Vence ou acaba em<input type="date" name="data_fim" value="{e(p.get('data_fim', ''))}" required></label>
<label>Avisar<select name="avisar">{opcoes(AVISOS, p.get('avisar_dias', 30))}</select></label>
<label>Repete<select name="repete">{opcoes(REPETE, p.get('repete_meses'), 'Não se repete')}</select></label>
<label>Observação<input name="observacao" value="{e(p.get('observacao', ''))}" maxlength="300" placeholder="número da apólice, telefone…"></label>'''


@rota('GET', '/prazos')
def prazos_pagina(req):
    termo = req.q('q')
    with banco.conexao() as c:
        lista = prazos.abertos(c, hoje())
        velhos = prazos.encerrados(c, hoje())
        achados = prazos.buscar(c, termo, hoje()) if termo else None
    def linha(p):
        acoes = (f'<form method="post" action="/prazos/{p["id"]}/concluir" class="acoes">{tk()}'
                 + ('<button name="renovar" value="1" class="secundario">Renovado</button>' if p['tipo'] != 'garantia' else '')
                 + f'<button class="secundario">{"Encerrar" if p["tipo"] == "garantia" else "Concluído"}</button></form>')
        return [f'<span id="prazo-{p["id"]}"></span>{e(prazos.TIPOS.get(p["tipo"], p["tipo"]))}',
                f'<a href="/prazos/{p["id"]}">{e(p["titulo"])}</a> {_origem(p)}', data_br(p['data_fim']), _estado(p), acoes]
    garantias = [linha(p) for p in lista if p['tipo'] == 'garantia']
    outros = [linha(p) for p in lista if p['tipo'] != 'garantia']
    busca = ''
    if achados is not None:
        itens = []
        for p in achados['prazos']:
            anexos = ''.join(f' · <a href="/anexos/{a["id"]}">{e(a["nome"])}</a>' for a in p['anexos'])
            itens.append(f'<li><b>{e(p["titulo"])}</b>: {_estado(p)} até {data_br(p["data_fim"])} {_origem(p)}{anexos}</li>')
        for t in achados['lancamentos']:
            itens.append(f'<li><a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a> em {data_br(t["data"])}: sem garantia registrada'
                         + (f' · {t["n_anexos"]} comprovante(s)' if t['n_anexos'] else '') + '</li>')
        busca = (f'<section class="painel"><h2>Resultado para "{e(termo)}"</h2><ul>{"".join(itens)}</ul></section>' if itens else
                 f'<section class="painel"><p>Nada encontrado para "{e(termo)}".</p></section>')
    hist = [[e(prazos.TIPOS.get(p['tipo'], p['tipo'])), f'<a href="/prazos/{p["id"]}">{e(p["titulo"])}</a>', data_br(p['data_fim']),
             f'concluído em {data_br(p["concluido_em"])}' if p['concluido_em'] else 'garantia acabou'] for p in velhos]
    corpo = f'''<section class="painel"><form method="get" action="/prazos" class="acoes filtros">
<label>Procurar<input name="q" value="{e(termo)}" placeholder="geladeira, seguro, CNH…"></label><button class="secundario">Procurar</button></form></section>
{busca}
<section class="painel"><h2>Documentos, contratos e revisões</h2>{tabela(['Tipo', 'Do quê', 'Vence', 'Situação', ''], outros, (), 'Nenhum prazo cadastrado. Comece por CNH, licenciamento, seguro do carro e fim do contrato de aluguel.', ocultar_movel=(0,))}</section>
<section class="painel"><h2>Garantias em vigor</h2>{tabela(['Tipo', 'Do quê', 'Acaba', 'Situação', ''], garantias, (), 'Nenhuma garantia em vigor. Registre pelo lançamento da compra ou pela compra planejada.', ocultar_movel=(0,))}</section>
<section class="painel"><h2>Novo prazo</h2><form method="post" action="/prazos" class="campos">{tk()}{_campos()}<button>Adicionar</button></form>
<p class="fraco">Garantias nascem no lançamento da compra ("Garantia"), na compra planejada (meses de garantia) ou na nota fiscal.
"Renovado" fecha o prazo e já cria o próximo (licenciamento todo ano, CNH a cada 10 anos…).</p></section>
{f'<details class="painel"><summary>Concluídos e garantias encerradas ({len(hist)})</summary>{tabela(["Tipo", "Do quê", "Data", ""], hist, ())}</details>' if hist else ''}'''
    return req.html('Prazos e garantias', corpo, 'CNH, seguro, licenciamento, contratos e garantias num lugar só, com aviso antes de vencer.')


def _dados(req):
    return dict(tipo=req.f('tipo'), titulo=req.f('titulo'), data_fim=req.f('data_fim'),
                avisar_dias=inteiro(req.f('avisar') or '30', 'aviso'), repete_meses=opcional_int(req.f('repete')),
                observacao=req.f('observacao'))


@rota('POST', '/prazos')
def prazos_criar(req):
    with banco.transacao() as c:
        prazos.criar(c, **_dados(req))
    ir('/prazos', 'Prazo adicionado.')


@rota('GET', r'/prazos/(\d+)')
def prazo_pagina(req):
    pid = int(req.parametros[0])
    with banco.conexao() as c:
        p = prazos._com_dias(prazos.um(c, pid), hoje())
    acao = (f'<form method="post" action="/prazos/{pid}/reabrir" class="acoes">{tk()}<button class="secundario">Reabrir</button></form>'
            if p['concluido_em'] else '')
    corpo = f'''<p><a href="/prazos">← Prazos e garantias</a></p><section class="painel"><p>{_estado(p)} {_origem(p)}</p>
{f'<p>{e(p["observacao"])}</p>' if p['observacao'] else ''}{acao}</section>
<section class="painel"><h2>Editar</h2><form method="post" action="/prazos/{pid}" class="campos">{tk()}{_campos(p)}<button>Salvar</button></form></section>
<section class="painel">{botao_excluir(f"/prazos/{pid}/excluir", "O prazo some do painel e dos alertas.", "Excluir prazo")}</section>'''
    return req.html(p['titulo'], corpo, prazos.TIPOS.get(p['tipo'], p['tipo']))


@rota('POST', r'/prazos/(\d+)')
def prazo_editar(req):
    with banco.transacao() as c:
        prazos.atualizar(c, int(req.parametros[0]), **_dados(req))
    ir(f'/prazos/{req.parametros[0]}', 'Prazo atualizado.')


@rota('POST', r'/prazos/(\d+)/concluir')
def prazo_concluir(req):
    with banco.transacao() as c:
        novo = prazos.concluir(c, int(req.parametros[0]), renovar=req.f('renovar') == '1', hoje=hoje())
        prox = prazos.um(c, novo) if novo else None
    ir('/prazos', f'Renovado: o próximo vence em {data_br(prox["data_fim"])}.' if prox else 'Prazo encerrado.')


@rota('POST', r'/prazos/(\d+)/reabrir')
def prazo_reabrir(req):
    with banco.transacao() as c:
        prazos.reabrir(c, int(req.parametros[0]))
    ir(f'/prazos/{req.parametros[0]}', 'Prazo reaberto.')


@rota('POST', r'/prazos/(\d+)/excluir')
def prazo_excluir(req):
    with banco.transacao() as c:
        nome = prazos.excluir(c, int(req.parametros[0]))
    ir('/prazos', f'"{nome}" excluído.')


@rota('POST', r'/lancamentos/(\d+)/garantia')
def lancamento_garantia(req):
    tid = int(req.parametros[0])
    with banco.transacao() as c:
        prazos.garantia_de_lancamento(c, tid, req.f('titulo'), opcional_int(req.f('meses')), req.f('data_fim') or None)
    ir(f'/lancamentos/{tid}', 'Garantia registrada. Você será avisado 30 dias antes de acabar.')
