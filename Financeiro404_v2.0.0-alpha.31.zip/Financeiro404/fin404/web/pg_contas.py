"""Contas e dívidas: cadastro, extrato, saldo inicial e conciliação."""

from fin404.dados import banco
from fin404.dinheiro import centavos, formatar
from fin404.dominio import cartoes, conferencias, operacoes, razao
from fin404.web.base import (ROTULO_TIPO, hoje, ir, opcional_int, pessoas)
from fin404.web.componentes import botao_excluir, aviso, campo_valor, data_br, dinheiro, e, opcoes, selo, tabela
from fin404.web.pg_lancamentos import _status_selo
from fin404.web.servidor import rota, token_html as tk



# ------------------------------------------------------------------ contas

@rota('GET', '/contas')
def contas_pagina(req):
    with banco.conexao() as c:
        saldos = razao.saldos_por_conta(c)
        ps = pessoas(c)
        inativas = razao.contas(c, tipo=None, incluir_inativas=True)
    grupos = [('Disponível', razao.DISPONIVEIS), ('Investimentos e bens', ('investimento', 'bem')),
              ('Cartões de crédito', ('cartao',)), ('Empréstimos e dívidas', ('emprestimo', 'outro_passivo'))]
    secoes = []
    for nome, subs in grupos:
        itens = [k for k in saldos if k['subtipo'] in subs and not k.get('papel')]
        linhas = [[f'<a href="/contas/{k["id"]}">{e(k["nome"])}</a>', e(k['instituicao']),
                   e(f'fecha dia {k["dia_fechamento"]}, vence dia {k["dia_vencimento"]}' if k['subtipo'] == 'cartao' and k['dia_fechamento']
                     else ('defina os dias' if k['subtipo'] == 'cartao' else razao.SUBTIPOS[k['subtipo']][1])),
                   dinheiro(k['saldo_natural'])] for k in itens]
        total = sum(k['saldo_natural'] for k in itens)
        if itens:
            secoes.append(f'<section class="painel"><h2>{e(nome)} · {dinheiro(total)}</h2>'
                          f'{tabela(["Nome", "Instituição", "Detalhes", "Saldo" if subs[0] not in ("cartao", "emprestimo") else "Devendo"], linhas, (3,))}</section>')
    receber_total = sum(k['saldo_natural'] for k in saldos if k.get('papel') == 'a_receber')
    if receber_total:
        secoes.append(f'<section class="painel"><h2>Valores a receber · {dinheiro(receber_total)}</h2>'
                      '<p>Dinheiro emprestado ou pago por outras pessoas. Entra no patrimônio, mas não no disponível nem na reserva. '
                      '<a href="/receber">Ver quem deve</a></p></section>')
    desativadas = [k for k in inativas if not k['ativa'] and k['tipo'] in ('ativo', 'passivo')]
    if desativadas:
        secoes.append('<details class="painel"><summary>Contas desativadas</summary><ul>' +
                      ''.join(f'<li><a href="/contas/{k["id"]}">{e(k["nome"])}</a></li>' for k in desativadas) + '</ul></details>')
    tipos = [(k, v[1]) for k, v in razao.SUBTIPOS.items()]
    form = f'''<section class="painel"><h2>Nova conta, cartão ou dívida</h2><form method="post" action="/contas" class="campos">{tk()}
<label>Nome<input name="nome" required maxlength="80" placeholder="Ex.: Conta BB, Nubank, Carro"></label>
<label>Tipo<select name="subtipo" required>{opcoes(tipos, 'corrente')}</select></label>
<label>Instituição<input name="instituicao" maxlength="80"></label>
<label>Titular<select name="titular">{opcoes(ps, None, "Do casal / não informar")}</select></label>
<label>Fechamento (cartão)<input type="number" name="dia_fechamento" min="1" max="31" placeholder="dia"></label>
<label>Vencimento (cartão)<input type="number" name="dia_vencimento" min="1" max="31" placeholder="dia"></label>
<label>Limite (cartão)<input name="limite" inputmode="decimal" placeholder="opcional"></label>
<label>Compra no dia do fechamento (cartão)<select name="regra_fechamento"><option value="proxima">Vai para a fatura seguinte</option>
<option value="atual">Entra na fatura que fecha (ex.: Ourocard BB)</option></select></label>
<label>Saldo inicial (ou valor devido)<input name="saldo" inputmode="decimal" placeholder="0,00"></label>
<label>Data do saldo inicial<input type="date" name="data_saldo" value="{hoje().isoformat()}"></label><button>Cadastrar</button></form>
<p class="fraco">Saldo inicial: o valor do extrato na data escolhida. Depois dessa data, importe ou lance as movimentações.
Para cartão, a dívida inicial é o que ainda falta pagar.</p></section>'''
    corpo = (''.join(secoes) or aviso('Nenhuma conta cadastrada ainda.', 'info')) + form
    return req.html('Contas e dívidas', corpo)


@rota('POST', '/contas')
def contas_criar(req):
    limite = centavos(req.f('limite')) if req.f('limite') else None
    saldo = centavos(req.f('saldo'), permitir_negativo=True, permitir_zero=True) if req.f('saldo') else 0
    with banco.transacao() as c:
        cid = razao.criar_conta(c, req.f('nome'), req.f('subtipo'), instituicao=req.f('instituicao'),
                                dia_fechamento=req.f('dia_fechamento') or None, dia_vencimento=req.f('dia_vencimento') or None,
                                limite_centavos=limite, titular_id=opcional_int(req.f('titular')),
                                regra_fechamento=req.f('regra_fechamento') or 'proxima')
        if saldo:
            operacoes.saldo_inicial(c, cid, req.f('data_saldo') or hoje(), saldo)
    ir('/contas', 'Conta cadastrada.')


@rota('GET', r'/contas/(\d+)')
def conta_pagina(req):
    cid = int(req.parametros[0])
    with banco.conexao() as c:
        k = razao.conta(c, cid)
        if k['tipo'] not in ('ativo', 'passivo'):
            ir(f'/lancamentos?mes=&categoria={cid}')
        saldo_hoje = razao.saldo_natural(c, k, hoje())
        uso = razao.uso_da_conta(c, cid)
        abertura = c.execute("SELECT t.data, l.valor_centavos FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id "
                             "WHERE t.chave_origem=? AND l.conta_id=?", (f'abertura:{cid}', cid)).fetchone()
        movs = c.execute('''SELECT t.id, t.data, t.descricao, t.status, t.tipo, l.valor_centavos FROM lancamentos l
                            JOIN transacoes t ON t.id=l.transacao_id WHERE l.conta_id=? ORDER BY t.data DESC, t.id DESC LIMIT 200''',
                         (cid,)).fetchall()
        ps = pessoas(c)
        lim = cartoes.limite(c, cid) if k['subtipo'] == 'cartao' else None
        confs = conferencias.historico(c, cid, 6)
    sinal = -1 if k['tipo'] == 'passivo' else 1
    data_conferir = req.q('conferir') or hoje().isoformat()
    hist_conf = ''
    if confs:
        hist_conf = '<p class="fraco">Últimas conferências: ' + ' · '.join(
            f'{data_br(x["data"])} ' + ('bateu' if x['diferenca'] == 0 else f'diferença de {formatar(x["diferenca"])}') for x in confs) + '</p>'
    hoje_iso = hoje().isoformat()
    def _linha(m):
        return [data_br(m['data']), f'<a href="/lancamentos/{m["id"]}">{e(m["descricao"])}</a>', e(ROTULO_TIPO[m['tipo']]),
                dinheiro(sinal * m['valor_centavos'], cor=True),
                _status_selo(m['status'], {'despesa': -1, 'receita': 1}.get(m['tipo']), m['data'], k['subtipo'] == 'cartao')]
    linhas = [_linha(m) for m in movs if m['data'] <= hoje_iso]
    futuras = [_linha(m) for m in reversed(movs) if m['data'] > hoje_iso]
    cabec = f'''<div class="cartoes"><div class="cartao"><small>{"Devendo hoje" if k['tipo'] == 'passivo' else "Saldo hoje"}</small><strong>{dinheiro(saldo_hoje)}</strong>
<em>{e(razao.SUBTIPOS.get(k['subtipo'], ('', ''))[1])}{(' · ' + e(k['instituicao'])) if k['instituicao'] else ''}</em></div>'''
    if lim:
        cabec += f'<div class="cartao"><small>Limite disponível</small><strong>{dinheiro(lim["disponivel"])}</strong><em>de {dinheiro(lim["limite"])} (inclui parcelas futuras)</em></div>'
    if abertura:
        cabec += f'<div class="cartao"><small>Saldo inicial</small><strong>{dinheiro(sinal * abertura["valor_centavos"])}</strong><em>em {data_br(abertura["data"])}</em></div>'
    cabec += '</div>'
    cartao_campos = (f'<label>Fechamento<input type="number" name="dia_fechamento" min="1" max="31" value="{e(k["dia_fechamento"] or "")}" required></label>'
                     f'<label>Vencimento<input type="number" name="dia_vencimento" min="1" max="31" value="{e(k["dia_vencimento"] or "")}" required></label>'
                     f'<label>Limite<input name="limite" value="{campo_valor(k["limite_centavos"])}"></label>'
                     f'<label>Compra no dia do fechamento<select name="regra_fechamento">'
                     f'{opcoes([("proxima", "Vai para a fatura seguinte"), ("atual", "Entra na fatura que fecha")], k["regra_fechamento"])}</select></label>'
                     '<p class="fraco">As datas reais de fechamento vindas das faturas importadas têm prioridade sobre o dia informado aqui.</p>') if k['subtipo'] == 'cartao' else ''
    if uso['lancamentos'] or uso['importacoes'] or uso['parcelamentos']:
        bloco_excluir = ('<p class="fraco">Excluir: esta conta tem histórico (lançamentos, importações ou parcelamentos), então não pode ser apagada. '
                         'Para tirá-la de uso, desmarque "Conta ativa" e salve: ela some dos formulários e o histórico continua nos relatórios.</p>')
    else:
        extras = []
        if uso['aberturas']:
            extras.append('o saldo inicial (vai para a Lixeira)')
        if uso['previsoes']:
            extras.append(f'{uso["previsoes"]} previsão(ões) que usam esta conta')
        bloco_excluir = botao_excluir(f'/contas/{cid}/excluir', 'A conta será apagada' + (', junto com ' + ' e '.join(extras) if extras else '') +
                                      '. Ela não tem outros lançamentos.', 'Excluir esta conta')
    editar = f'''<section class="painel"><h2>Dados da conta</h2><form method="post" action="/contas/{cid}/editar" class="campos">{tk()}
<label>Nome<input name="nome" value="{e(k['nome'])}" required maxlength="80"></label>
<label>Instituição<input name="instituicao" value="{e(k['instituicao'])}"></label>
<label>Titular<select name="titular">{opcoes(ps, k['titular_id'], "Do casal / não informar")}</select></label>{cartao_campos}
<label>Identificador no banco<input name="identificador" value="{e(k['identificador_externo'])}" placeholder="preenchido ao importar OFX"></label>
<label class="check"><input type="checkbox" name="ativa" value="1"{" checked" if k['ativa'] else ""}> Conta ativa</label><button>Salvar</button></form>{bloco_excluir}</section>'''
    ferramentas = f'''<div class="grade"><section class="painel"><h2>Saldo inicial</h2><form method="post" action="/contas/{cid}/saldo-inicial" class="campos">{tk()}
<label>Data<input type="date" name="data" value="{e(abertura['data'] if abertura else hoje().isoformat())}" required></label>
<label>{"Valor devido" if k['tipo'] == 'passivo' else "Saldo"} nessa data<input name="valor" value="{campo_valor(sinal * abertura['valor_centavos']) if abertura else ''}" required></label>
<button>Definir</button></form></section>
<section class="painel" id="conferir"><h2>Conferir com o banco</h2><form method="post" action="/contas/{cid}/conciliar" class="campos">{tk()}
<label>Data<input type="date" name="data" value="{e(data_conferir)}" required></label>
<label>{"Dívida" if k['tipo'] == 'passivo' else "Saldo"} no extrato<input name="valor" required></label><button>Conferir</button></form>
<p class="fraco">Use o saldo que aparece no app do banco. Mostra a diferença; nada é lançado sem você pedir.</p>{hist_conf}</section></div>'''
    if k['subtipo'] in ('investimento', 'bem', 'poupanca'):
        ferramentas += f'''<section class="painel"><h2>Atualizar valor</h2><form method="post" action="/contas/{cid}/valor" class="campos">{tk()}
<label>Data<input type="date" name="data" value="{hoje().isoformat()}" required></label><label>Valor atual<input name="valor" required></label>
<button>Atualizar</button></form><p class="fraco">A diferença para o saldo registrado entra como rendimento (ou perda).</p></section>'''
    if k['subtipo'] == 'cartao':
        ferramentas += f'<p><a href="/cartoes/{cid}">Ver faturas deste cartão →</a></p>'
    bloco_futuro = (f'<details class="painel"><summary>Próximos lançamentos e previsões ({len(futuras)})</summary>'
                    f'{tabela(["Data", "Descrição", "Tipo", "Valor", "Situação"], futuras, (3,))}</details>') if futuras else ''
    corpo = cabec + ferramentas + bloco_futuro + f'<section class="painel"><h2>Movimentações até hoje</h2>{tabela(["Data", "Descrição", "Tipo", "Valor", "Situação"], linhas, (3,), ocultar_movel=(2, 4))}</section>' + editar
    return req.html(k['nome'], corpo)


@rota('POST', r'/contas/(\d+)/excluir')
def conta_excluir(req):
    with banco.transacao() as c:
        nome = razao.excluir_conta(c, int(req.parametros[0]))
    ir('/contas', f'"{nome}" excluída.')


@rota('POST', r'/contas/(\d+)/editar')
def conta_editar(req):
    cid = int(req.parametros[0])
    with banco.transacao() as c:
        razao.atualizar_conta(c, cid, req.f('nome'), req.f('instituicao'), req.f('dia_fechamento') or None,
                              req.f('dia_vencimento') or None, centavos(req.f('limite')) if req.f('limite') else None,
                              opcional_int(req.f('titular')), req.f('identificador'), req.f('ativa') == '1',
                              req.f('regra_fechamento') or None)
    ir(f'/contas/{cid}', 'Conta atualizada.')


@rota('POST', r'/contas/(\d+)/saldo-inicial')
def conta_saldo_inicial(req):
    cid = int(req.parametros[0])
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, cid, req.f('data'), centavos(req.f('valor'), permitir_negativo=True, permitir_zero=True))
    volta = req.f('volta')
    ir(volta if volta.startswith('/importacoes/') else f'/contas/{cid}', 'Saldo inicial definido.')


def _quadro_pistas(pistas):
    if not pistas:
        return '<p class="fraco">Nada do que já foi lançado nos últimos 60 dias explica a diferença: provavelmente é algo que não foi lançado.</p>'
    itens = []
    for p in pistas:
        links = ' '.join(f'<a href="/lancamentos/{t["id"]}">{e(t["descricao"][:40])} ({dinheiro(t["efeito"])})</a>' for t in p['transacoes'][:5])
        acao = ' · <a href="/confirmar">a pagar e receber</a>' if p['tipo'] == 'previsto' else ''
        itens.append(f'<li>{selo("bate com a diferença", "verde") if p["exata"] else selo("vale conferir", "amarelo")} {e(p["texto"])}<br>'
                     f'<span class="fraco">{links}{acao}</span></li>')
    return f'<h3>Pistas no que já foi lançado</h3><ul class="lista-alertas">{"".join(itens)}</ul>'


@rota('POST', r'/contas/(\d+)/conciliar')
def conta_conciliar(req):
    cid = int(req.parametros[0])
    valor = centavos(req.f('valor'), permitir_negativo=True, permitir_zero=True)
    with banco.transacao() as c:
        k = razao.conta(c, cid)
        r = conferencias.registrar(c, cid, req.f('data'), valor)
        pistas = operacoes.pistas_da_diferenca(c, cid, req.f('data'), r['diferenca']) if r['diferenca'] else []
    if r['diferenca'] == 0:
        ir(f'/contas/{cid}', f'Confere: o saldo calculado em {req.f("data")} é igual ao do banco.')
    sem_extrato = ''
    if k['tipo'] == 'ativo':
        sem_extrato = f'''<section class="painel"><h2>Sem extrato? Lance a diferença</h2>
<p>Se vocês não têm o extrato para achar cada movimento, lance a diferença como
<b>{"gasto não identificado" if r['diferenca'] < 0 else "entrada não identificada"}</b>. Assim o saldo fica certo e o relatório do mês mostra
quanto saiu (ou entrou) sem detalhe. Quanto menor esse valor, mais completo o retrato.</p>
<form method="post" action="/contas/{cid}/diferenca" class="acoes">{tk()}<input type="hidden" name="data" value="{e(req.f('data'))}">
<input type="hidden" name="valor" value="{campo_valor(valor)}"><button>Lançar {dinheiro(abs(r['diferenca']))} como {"gasto" if r['diferenca'] < 0 else "entrada"} não identificado</button></form></section>'''
    corpo = f'''<section class="painel"><p>Calculado pelo Financeiro 404: <b>{dinheiro(r['calculado'])}</b><br>
Informado pelo banco: <b>{dinheiro(r['informado'])}</b><br>Diferença: <b>{dinheiro(r['diferenca'], cor=True)}</b></p>
<p>Antes de ajustar, procure o que falta: lançamentos não importados, datas diferentes, saldo inicial errado ou estornos.</p>
{_quadro_pistas(pistas)}
<p><a href="/lancamentos?mes={e(req.f('data')[:7])}&amp;conta={cid}">Ver lançamentos do mês desta conta</a></p></section>
{sem_extrato}
<section class="painel"><h2>Ajustar sem afetar os relatórios</h2><form method="post" action="/contas/{cid}/ajustar" class="campos">{tk()}
<input type="hidden" name="data" value="{e(req.f('data'))}"><input type="hidden" name="valor" value="{campo_valor(valor)}">
<label>Motivo (obrigatório)<input name="motivo" required maxlength="300"></label><button class="secundario">Lançar ajuste de {dinheiro(r['diferenca'])}</button></form>
<p class="fraco">O ajuste fica rotulado e aparece na auditoria. Ele não entra como receita nem despesa.</p></section>'''
    return req.html(f'Conferência — {k["nome"]}', corpo)


@rota('POST', r'/contas/(\d+)/diferenca')
def conta_diferenca(req):
    cid = int(req.parametros[0])
    with banco.transacao() as c:
        valor = centavos(req.f('valor'), permitir_negativo=True, permitir_zero=True)
        operacoes.lancar_diferenca(c, cid, req.f('data'), valor)
        r = conferencias.registrar(c, cid, req.f('data'), valor)
    ir(f'/contas/{cid}', 'Diferença lançada. O saldo agora confere com o do banco.' if r['diferenca'] == 0 else
       'Diferença lançada, mas ainda não confere: confira de novo.')


@rota('POST', r'/contas/(\d+)/ajustar')
def conta_ajustar(req):
    cid = int(req.parametros[0])
    with banco.transacao() as c:
        valor = centavos(req.f('valor'), permitir_negativo=True, permitir_zero=True)
        operacoes.ajustar_saldo(c, cid, req.f('data'), valor, req.f('motivo'))
        conferencias.registrar(c, cid, req.f('data'), valor)
    ir(f'/contas/{cid}', 'Ajuste lançado. O saldo agora confere com o do banco.')


@rota('POST', r'/contas/(\d+)/valor')
def conta_valor(req):
    cid = int(req.parametros[0])
    with banco.transacao() as c:
        operacoes.atualizar_valor(c, cid, req.f('data'), centavos(req.f('valor'), permitir_zero=True))
    ir(f'/contas/{cid}', 'Valor atualizado.')
