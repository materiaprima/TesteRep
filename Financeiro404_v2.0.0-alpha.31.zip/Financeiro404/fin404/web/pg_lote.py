"""Lançar vários de uma vez: cola o texto anotado no celular, confere a prévia e grava tudo junto."""
from datetime import timedelta

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao, centavos, data as ler_data
from fin404.dominio import categorias as cats
from fin404.dominio import lote, operacoes, razao, tags
from fin404.web.base import categorias, grupos_contas, hoje, inteiro, ir, opcional_int
from fin404.web.componentes import campo_valor, e, opcoes, opcoes_agrupadas, selo
from fin404.web.servidor import rota, token_html as tk

EXEMPLO = '18,50 padaria pix\n05/11 uber 23,90 crédito\nontem farmácia 32,90\n+500 freela pix'


def _conta_mais_usada(c):
    r = c.execute('''SELECT l.conta_id FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                     WHERE t.tipo='despesa' AND t.lote_id IS NULL AND k.subtipo IN ('corrente','dinheiro','carteira','poupanca')
                     AND t.data>=? GROUP BY l.conta_id ORDER BY COUNT(*) DESC LIMIT 1''',
                  ((hoje() - timedelta(days=60)).isoformat(),)).fetchone()
    return r[0] if r else None


@rota('GET', '/lote')
def lote_pagina(req):
    with banco.conexao() as c:
        g_contas = grupos_contas(c, cartoes_=False)
        cartoes = [(k['id'], k['nome']) for k in razao.contas(c, subtipos=('cartao',))]
        padrao = _conta_mais_usada(c)
    corpo = f'''<section class="painel"><form method="post" action="/lote/previa" class="empilhado">{tk()}
<label>Uma linha por lançamento<textarea name="texto" rows="10" required placeholder="{e(EXEMPLO)}">{e(req.q('texto'))}</textarea></label>
<div class="campos"><label>Conta padrão (Pix, débito, dinheiro)<select name="conta" required>{opcoes_agrupadas(g_contas, padrao, 'Escolha…')}</select></label>
<label>Cartão para "crédito"<select name="cartao">{opcoes(cartoes, cartoes[0][0] if cartoes else None, 'Nenhum')}</select></label>
<label>Tags para todos (opcional)<input name="tags" maxlength="200" placeholder="ex.: viagem"></label>
<button>Conferir antes de gravar</button></div></form></section>
<section class="painel"><h2>Como escrever</h2><ul class="fraco">
<li>Valor, descrição e, se quiser, a forma de pagamento (pix, débito, crédito, dinheiro, boleto, vr), em qualquer ordem: <code>18,50 padaria pix</code>.</li>
<li>Data no começo: <code>05/11 uber 23,90</code>, ou <code>ontem</code> / <code>anteontem</code>. Sem data, vale hoje.</li>
<li>Entrada de dinheiro com <b>+</b> na frente do valor: <code>+500 freela pix</code>.</li>
<li>"crédito" vai para o cartão escolhido acima; o resto, para a conta padrão. Tudo pode ser trocado na prévia.</li>
<li>A categoria é adivinhada pelo que vocês já lançaram. Nada é gravado antes da prévia.</li></ul>
<p class="fraco">Dica: anote no bloco de notas do celular ao longo do dia e cole aqui à noite.</p></section>'''
    return req.html('Lançar vários de uma vez', corpo, 'Cole o que anotou no celular e grave tudo de uma vez.')


@rota('POST', '/lote/previa')
def lote_previa(req):
    itens = lote.interpretar(req.f('texto'), hoje())
    conta_padrao = inteiro(req.f('conta'), 'conta padrão')
    cartao = opcional_int(req.f('cartao'))
    with banco.conexao() as c:
        cats_d, cats_r = categorias(c, 'despesa'), categorias(c, 'receita')
        g_d = grupos_contas(c)
        g_r = grupos_contas(c, cartoes_=False)
        for x in itens:
            achada = cats.inferir(c, x['descricao'], x['tipo']) if x['descricao'] else None
            x['categoria'] = achada[0] if achada else None
            x['conta'] = cartao if (x['forma'] == 'credito' and cartao and x['tipo'] == 'despesa') else conta_padrao
    formas = list(operacoes.FORMAS_PAGAMENTO)
    linhas = []
    for i, x in enumerate(itens):
        despesa = x['tipo'] == 'despesa'
        aviso_linha = selo(x['erro'], 'vermelho') if x['erro'] else ('' if x['categoria'] else selo('escolha a categoria', 'amarelo'))
        marcado = '' if x['erro'] else ' checked'
        linhas.append(f'''<tr><td><input type="checkbox" name="incluir_{i}" value="1"{marcado} aria-label="Gravar linha {i + 1}">
<input type="hidden" name="tipo_{i}" value="{x['tipo']}"></td>
<td><input type="date" name="data_{i}" value="{x['data'].isoformat()}" required></td>
<td><input name="descricao_{i}" value="{e(x['descricao'])}" maxlength="200"><br><span class="fraco">{e(x['linha'])}</span> {aviso_linha}</td>
<td class="n"><input name="valor_{i}" value="{campo_valor(x['valor']) if x['valor'] else ''}" inputmode="decimal" size="9">
<br><span class="fraco">{"saída" if despesa else "entrada"}</span></td>
<td><select name="categoria_{i}">{opcoes(cats_d if despesa else cats_r, x['categoria'], 'Escolha…')}</select></td>
<td><select name="conta_{i}">{opcoes_agrupadas(g_d if despesa else g_r, x['conta'])}</select></td>
<td><select name="forma_{i}">{opcoes(formas, x['forma'], '—')}</select></td></tr>''')
    validas = sum(1 for x in itens if not x['erro'])
    corpo = f'''<form method="post" action="/lote/gravar">{tk()}<input type="hidden" name="n" value="{len(itens)}">
<input type="hidden" name="tags" value="{e(req.f('tags'))}">
<section class="painel"><p>{validas} de {len(itens)} linha(s) entendida(s). Confira, ajuste o que precisar e grave.
Só as linhas marcadas são gravadas.</p>
<div class="rolagem"><table class="editavel"><thead><tr><th>Gravar</th><th>Data</th><th>Descrição</th><th class="n">Valor</th><th>Categoria</th>
<th>Conta ou cartão</th><th>Forma</th></tr></thead><tbody>{''.join(linhas)}</tbody></table></div>
<div class="acoes"><button>Gravar lançamentos marcados</button><a href="/lote?texto={e(_url(req.f('texto')))}">Voltar e editar o texto</a></div></section></form>'''
    return req.html('Conferir antes de gravar', corpo)


def _url(texto):
    import urllib.parse
    return urllib.parse.quote(texto or '')[:6000]


@rota('POST', '/lote/gravar')
def lote_gravar(req):
    n = inteiro(req.f('n') or '0', 'quantidade')
    if not 1 <= n <= lote.MAX_LINHAS:
        raise ErroValidacao('Nada para gravar.')
    feitos = []
    with banco.transacao() as c:
        for i in range(n):
            if req.f(f'incluir_{i}') != '1':
                continue
            rotulo = f'Linha {i + 1}'
            try:
                valor = centavos(req.f(f'valor_{i}'))
                quando = ler_data(req.f(f'data_{i}'))
                descricao = req.f(f'descricao_{i}').strip()
                categoria = inteiro(req.f(f'categoria_{i}'), 'categoria')
                conta = inteiro(req.f(f'conta_{i}'), 'conta')
                if not descricao:
                    raise ErroValidacao('informe a descrição.')
                if req.f(f'tipo_{i}') == 'receita':
                    ids = [operacoes.receita(c, quando, descricao, valor, categoria, conta)]
                else:
                    ids = operacoes.despesa(c, quando, descricao, valor, categoria, conta)
                forma = req.f(f'forma_{i}') or operacoes.forma_padrao(c, conta)
                operacoes.definir_forma(c, ids, forma)
                if req.f('tags'):
                    tags.adicionar(c, ids, req.f('tags'))
                feitos.extend(ids)
            except ErroValidacao as exc:
                raise ErroValidacao(f'{rotulo} ("{req.f(f"descricao_{i}")[:40]}"): {exc} Nada foi gravado; volte e corrija.')
    if not feitos:
        raise ErroValidacao('Nenhuma linha marcada para gravar.')
    ir('/lancamentos?mes=', f'{len(feitos)} lançamento(s) gravado(s).')
