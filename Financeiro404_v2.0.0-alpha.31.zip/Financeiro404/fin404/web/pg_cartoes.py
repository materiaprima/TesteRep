"""Cartões e faturas."""
import datetime

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao, centavos, formatar
from fin404.dominio import cartoes, razao
from fin404.web.base import (grupos_contas, hoje, inteiro, ir)
from fin404.web.componentes import aviso, campo_valor, data_br, dinheiro, e, opcoes_agrupadas, selo, tabela
from fin404.web.servidor import rota, token_html as tk

COR_FATURA = {'paga': 'verde', 'vencida': 'vermelho', 'aberta': '', 'sem saldo': ''}


# ------------------------------------------------------------------ cartões

def _pendencias_cartao(c, k):
    """O que faz a fatura do app não bater com a do banco, com o conserto de um clique."""
    html = ''
    si = cartoes.saldo_inicial_pendente(c, k['id'])
    if si:
        html += (f'''<div class="aviso atencao"><strong>{e(k["nome"])}: falta a dívida que já existia antes do app.</strong>
A primeira fatura importada (fechou em {data_br(si["fechamento"])}) começa com saldo anterior de <b>{dinheiro(si["banco"])}</b> segundo o
banco; no app, a dívida em {data_br(si["data"])} é {dinheiro(si["no_app"])}. Por isso as faturas do app ficam menores que as do banco.
Isso não é gasto do mês: é dívida antiga, e entra só no saldo do cartão.
<form method="post" action="/cartoes/{k["id"]}/saldo-inicial" class="acoes">{tk()}<input type="hidden" name="data" value="{si["data"].isoformat()}">
<input type="hidden" name="valor" value="{campo_valor(si["banco"])}"><button>Usar {dinheiro(si["banco"])} como saldo inicial em {data_br(si["data"])}</button></form></div>''')
    pags = cartoes.pagamentos_como_gasto(c, k['id'])
    if pags:
        ativos = [x for x in razao.contas(c, tipo='ativo') if x['subtipo'] in ('corrente', 'dinheiro', 'poupanca')]
        itens = ''
        for pg in pags:
            sug = cartoes.origem_sugerida(c, pg['descricao'])
            opcs = ''.join(f'<option value="{x["id"]}"{" selected" if sug and x["id"] == sug["id"] else ""}>{e(x["nome"])}</option>' for x in ativos)
            form = (f'<form method="post" action="/cartoes/pagamentos/{pg["id"]}" class="acoes">{tk()}<select name="origem" required>'
                    f'<option value="">De onde saiu?</option>{opcs}</select><button class="secundario">É pagamento</button></form>') if ativos else \
                '<em>cadastre antes a conta ou o "Dinheiro" de onde saiu o pagamento (Contas e dívidas)</em>'
            itens += (f'<li>{data_br(pg["data"])} · <a href="/lancamentos/{pg["id"]}">{e(pg["descricao"])}</a> · {dinheiro(pg["valor"])} '
                      f'(lançado como estorno de "{e(pg["categoria"])}") {form}</li>')
        html += (f'<div class="aviso atencao"><strong>{e(k["nome"])}: {len(pags)} pagamento(s) de fatura lançado(s) como estorno de gasto.</strong> '
                 f'Isso diminui o gasto do mês pelo valor pago. Corrija dizendo de onde saiu o dinheiro:<ul class="lista-imp">{itens}</ul></div>')
    return html


def _bloco_cartao(k, ant, aberta, lim, devendo):
    """Um cartão na lista: quanto se deve hoje, a fatura a pagar e a que está aberta (que já carrega o que não foi pago)."""
    def linha(f):
        doc = (dinheiro(f['documento']) + (f'<br><small class="neg">diferença {dinheiro(f["diferenca"])}</small>' if f['diferenca'] else '')
               if f['documento'] is not None else '<span class="fraco">—</span>')
        link = f'/cartoes/{k["id"]}/fatura/{f["fechamento"].isoformat()}'
        acao = (f' <a href="{link}#pagar">pagar</a>' if f['restante'] and f['situacao'] in ('vencida', 'fechada', 'paga parcialmente') else '')
        abatido = f['pagos_no_ciclo'] + f['estornos']
        falta = dinheiro(f['restante']) + (f'<br><small class="fraco">pago {dinheiro(f["pagos"])}</small>' if f['pagos'] else '')
        if f is aberta and ant['restante'] > 0 and ant['situacao'] in ('vencida', 'fechada', 'paga parcialmente'):
            # a aberta carrega a anterior: mostrar "falta pagar" cheio aqui convida a somar a mesma dívida duas vezes
            falta = (f'{dinheiro(max(f["restante"] - ant["restante"], 0))}<br><small class="fraco">só o novo; '
                     f'o resto está na linha de cima</small>')
        return [f'<a href="{link}">fecha {data_br(f["fechamento"])}</a>', data_br(f['vencimento']),
                dinheiro(f['saldo_anterior']) if f['saldo_anterior'] > 0 else '<span class="fraco">—</span>',
                dinheiro(f['compras']), (f'−{dinheiro(abatido)}' if abatido else '<span class="fraco">—</span>'),
                f'<strong>{dinheiro(f["valor"])}</strong>', falta, doc,
                selo(f['situacao'], COR_FATURA.get(f['situacao'], 'amarelo')) + acao]
    a_pagar = ant['restante'] if ant['situacao'] in ('vencida', 'fechada', 'paga parcialmente') else 0
    # a aberta carrega a anterior inteira só quando nada foi pago dela (com pagamento parcial, a conta fica confusa: não explica)
    carregado = a_pagar if a_pagar and ant['pagos'] == 0 and aberta['saldo_anterior'] >= a_pagar else 0
    cartoes_html = (f'<div class="cartoes"><div class="cartao"><small>Devendo no cartão hoje</small><strong>{dinheiro(max(devendo, 0))}</strong>'
                    f'<em>{"tudo que já passou no cartão e não foi pago" if devendo >= 0 else "crédito a favor de vocês: " + dinheiro(-devendo)}</em></div>'
                    + (f'<div class="cartao"><small>Fatura a pagar (vence {data_br(ant["vencimento"])})</small><strong>{dinheiro(a_pagar)}</strong>'
                       f'<em>{"vencida" if ant["situacao"] == "vencida" else ant["situacao"]}</em></div>' if a_pagar else '')
                    + f'<div class="cartao"><small>Fatura aberta (fecha {data_br(aberta["fechamento"])})</small><strong>{dinheiro(aberta["compras"])}</strong>'
                    f'<em>compras e parcelas deste ciclo{" · com o saldo anterior: " + dinheiro(aberta["valor"]) if carregado else ""}</em></div>'
                    + (f'<div class="cartao"><small>Limite</small><strong>{dinheiro(lim["disponivel"])}</strong>'
                       f'<em>disponível de {dinheiro(lim["limite"])}, contando parcelas futuras</em></div>' if lim else '')
                    + '</div>')
    nota = ''
    if carregado:
        nota = aviso(f'A fatura aberta já inclui {formatar(carregado)} da fatura anterior que ainda não foi paga (saldo anterior). '
                     f'Não some as duas linhas: o total devido é {formatar(max(devendo, 0))}. Se você já pagou, registre o pagamento '
                     f'na fatura de {data_br(ant["fechamento"])} e a aberta volta para {formatar(max(aberta["valor"] - carregado, 0))}.', 'atencao')
    return (f'<section class="painel"><h2><a href="/cartoes/{k["id"]}">{e(k["nome"])}</a></h2>'
            f'<p class="fraco">Fecha dia {k["dia_fechamento"]}, vence dia {k["dia_vencimento"]}</p>{cartoes_html}{nota}'
            f'{tabela(["Fatura", "Vence", "Saldo anterior", "Compras", "Pagamentos e estornos", "Valor da fatura", "Falta pagar", "No PDF do banco", "Situação"], [linha(ant), linha(aberta)], (2, 3, 4, 5, 6, 7), ocultar_movel=(2, 3, 4, 7))}'
            f'<p class="fraco">Valor da fatura = saldo anterior + compras − pagamentos e estornos feitos dentro do ciclo. '
            f'"Falta pagar" desconta o que foi pago depois do fechamento. '
            f'<a href="/cartoes/{k["id"]}">Todas as faturas →</a></p></section>')


@rota('GET', '/cartoes')
def cartoes_pagina(req):
    blocos = []
    with banco.conexao() as c:
        lista = cartoes.lista(c)
        for k in lista:
            if not k['dia_fechamento']:
                blocos.append(f'<section class="painel"><h2>{e(k["nome"])}</h2>{aviso("Defina os dias de fechamento e vencimento para ver as faturas.", "atencao")}'
                              f'<a href="/contas/{k["id"]}">Configurar →</a></section>')
                continue
            atual = cartoes.fechamento_da_compra(k, hoje())
            ant, aberta = cartoes.fatura(c, k['id'], cartoes.fechamento_anterior(k, atual)), cartoes.fatura(c, k['id'], atual)
            lim = cartoes.limite(c, k['id'])
            devendo = -razao.saldo(c, k['id'], hoje())
            blocos.append(_pendencias_cartao(c, k) + _bloco_cartao(k, ant, aberta, lim, devendo))
    if not lista:
        blocos.append(aviso('Nenhum cartão cadastrado. Cadastre em "Contas e dívidas".', 'info'))
    return req.html('Cartões e faturas', ''.join(blocos),
                    'Fatura = tudo o que você deve no cartão no fim do ciclo, inclusive saldo anterior não pago. Pagar a fatura não é despesa.')


@rota('GET', r'/cartoes/(\d+)')
def cartao_faturas(req):
    cid = int(req.parametros[0])
    with banco.conexao() as c:
        k = razao.conta(c, cid)
        fats = cartoes.faturas_recentes(c, cid)
    linhas = [[f'<a href="/cartoes/{cid}/fatura/{f["fechamento"].isoformat()}">{data_br(f["fechamento"])}</a>', data_br(f['vencimento']),
               dinheiro(f['compras']), dinheiro(f['valor']), dinheiro(f['pagos']), dinheiro(f['restante']),
               dinheiro(f['documento']) if f['documento'] is not None else '<span class="fraco">—</span>',
               dinheiro(f['diferenca'], cor=True) if f['diferenca'] else '',
               selo(f['situacao'], COR_FATURA.get(f['situacao'], 'amarelo'))] for f in fats]
    corpo = f'<section class="painel">{tabela(["Fechamento", "Vencimento", "Compras no ciclo", "Valor da fatura", "Pago", "Falta", "Documento do banco", "Diferença", "Situação"], linhas, (2, 3, 4, 5, 6, 7))}</section>'
    return req.html(f'Faturas — {k["nome"]}', corpo, 'Valor da fatura inclui saldo anterior não pago. Faturas futuras mostram as parcelas já contratadas.')


@rota('GET', r'/cartoes/(\d+)/fatura/(\d{4}-\d{2}-\d{2})')
def fatura_pagina(req):
    cid, f = int(req.parametros[0]), req.parametros[1]
    with banco.conexao() as c:
        fat = cartoes.fatura(c, cid, f)
        g_ativos = grupos_contas(c, cartoes_=False)
        minimo = cartoes.minimo_da_fatura(c, cid, fat['fechamento'])
    k = fat['cartao']
    linhas = [[data_br(i['data']), f'<a href="/lancamentos/{i["id"]}">{e(i["descricao"])}</a>', e(i['contrapartida'] or ''),
               dinheiro(-i['valor_centavos'], cor=False)] for i in fat['itens']]
    resumo = f'''<div class="cartoes"><div class="cartao"><small>Valor da fatura</small><strong>{dinheiro(fat['valor'])}</strong>
<em>saldo anterior {dinheiro(fat['saldo_anterior'])} + compras {dinheiro(fat['compras'])} − créditos {dinheiro(fat['creditos'])}</em></div>
<div class="cartao"><small>Vencimento{' (data do banco)' if fat['data_real'] else ' (calculado)'}</small><strong>{data_br(fat['vencimento'])}</strong><em>{selo(fat['situacao'], COR_FATURA.get(fat['situacao'], 'amarelo'))}</em></div>
<div class="cartao"><small>Pago</small><strong>{dinheiro(fat['pagos'])}</strong><em>falta {dinheiro(fat['restante'])}</em></div></div>'''
    botoes_pagar = ''
    if fat['restante'] > 0:
        botoes_pagar += f'<button name="modo" value="total">Total em aberto ({dinheiro(fat["restante"])})</button>'
    if minimo:
        botoes_pagar += f'<button name="modo" value="minimo" class="secundario">Mínimo ({dinheiro(minimo)})</button>'
    botoes_pagar += '<button name="modo" value="outro" class="secundario">Outro valor</button>'
    nota_minimo = ('O mínimo é o informado no PDF desta fatura. Pagar menos que o total leva o resto para o rotativo.' if minimo else
                   'O mínimo aparece aqui quando esta fatura é importada em PDF. Pagar menos que o total leva o resto para o rotativo.')
    doc = ''
    if fat['documento'] is not None:
        doc = aviso('Confere com o documento do banco.', 'ok')
        if fat['diferenca']:
            doc = (f'<div class="aviso atencao">O banco informa {dinheiro(fat["documento"])}; aqui somam {dinheiro(fat["valor"])}. '
                   f'Diferença de {dinheiro(fat["diferenca"])}: procure compras não lançadas, juros, IOF ou estornos.</div>')
    corpo = f'''{resumo}{doc}<section class="painel"><h2>Itens do ciclo ({data_br(fat['inicio'])} a {data_br(fat['fim'] - datetime.timedelta(days=1))})</h2>
{tabela(['Data', 'Descrição', 'Categoria / origem', 'Valor'], linhas, (3,), 'Nenhuma compra neste ciclo.')}</section>
<div class="grade"><section class="painel" id="pagar"><h2>Pagar esta fatura</h2><form method="post" action="/cartoes/{cid}/pagar/confirmar" class="campos">{tk()}
<input type="hidden" name="volta" value="{e(f)}">
<label>Sai de<select name="origem" required>{opcoes_agrupadas(g_ativos, None, 'Escolha…')}</select></label>
<label>Data<input type="date" name="data" value="{hoje().isoformat()}" required></label>
<label>Outro valor<input name="valor" inputmode="decimal" placeholder="só para &quot;Outro valor&quot;"></label>
<div class="acoes">{botoes_pagar}</div></form>
<p class="fraco">{nota_minimo}</p>
<p class="fraco">Se o pagamento vai aparecer no extrato que você importa, não precisa lançar aqui: a importação reconhece.</p></section>
<section class="painel" id="documento"><h2>Total segundo o banco</h2><form method="post" action="/cartoes/{cid}/fatura/{e(f)}/documento" class="campos">{tk()}
<label>Total da fatura no documento<input name="valor" value="{campo_valor(fat['documento']) if fat['documento'] is not None else ''}" required></label>
<button class="secundario">Guardar e comparar</button></form></section></div>'''
    return req.html(f'Fatura {k["nome"]} — fecha {data_br(fat["fechamento"])}', corpo)


@rota('POST', r'/cartoes/(\d+)/fatura/(\d{4}-\d{2}-\d{2})/documento')
def fatura_documento(req):
    cid, f = int(req.parametros[0]), req.parametros[1]
    with banco.transacao() as c:
        cartoes.registrar_total_documento(c, cid, f, centavos(req.f('valor'), permitir_zero=True, permitir_negativo=True))
    ir(f'/cartoes/{cid}/fatura/{f}', 'Total do documento guardado.')


@rota('POST', r'/cartoes/(\d+)/pagar/confirmar')
def cartao_pagar_confirmar(req):
    """Mostra o valor escolhido (total, mínimo ou outro) e os avisos antes de registrar. Nada é gravado aqui."""
    cid, f = int(req.parametros[0]), req.f('volta')
    with banco.conexao() as c:
        fat = cartoes.fatura(c, cid, f)
        minimo = cartoes.minimo_da_fatura(c, cid, fat['fechamento'])
        origem = razao.conta(c, inteiro(req.f('origem'), 'conta de origem'))
    modo = req.f('modo')
    if modo == 'total':
        valor = fat['restante']
    elif modo == 'minimo':
        if not minimo:
            raise ErroValidacao('Esta fatura não tem pagamento mínimo informado (importe o PDF dela).')
        valor = minimo
    else:
        valor = centavos(req.f('valor'))
    if valor <= 0:
        raise ErroValidacao('Não há valor a pagar.')
    avisos = []
    if valor < fat['restante']:
        avisos.append(aviso(f'Faltam {formatar(fat["restante"] - valor)} para quitar. Esse resto entra no rotativo do cartão, '
                            'um dos créditos mais caros que existem: os juros correm até a próxima fatura. '
                            'Compare o custo no Simulador de dívidas antes de decidir.', 'erro'))
    elif valor > fat['restante']:
        avisos.append(aviso(f'O valor é maior que o que falta pagar ({formatar(fat["restante"])}). Confira se não é erro de digitação: '
                            'o excedente fica como crédito no cartão.'))
    corpo = f'''{''.join(avisos)}<section class="painel"><p>Pagar <b>{dinheiro(valor)}</b> da fatura de {e(fat['cartao']['nome'])}
que fecha em {data_br(fat['fechamento'])} (vence {data_br(fat['vencimento'])}), saindo de <b>{e(origem['nome'])}</b> em {data_br(req.f('data'))}.</p>
<form method="post" action="/cartoes/{cid}/pagar" class="acoes">{tk()}<input type="hidden" name="volta" value="{e(f)}">
<input type="hidden" name="origem" value="{origem['id']}"><input type="hidden" name="valor" value="{campo_valor(valor)}">
<input type="hidden" name="data" value="{e(req.f('data'))}"><button>Confirmar pagamento</button></form>
<p><a href="/cartoes/{cid}/fatura/{e(f)}">Voltar sem pagar</a>{' · <a href="/simulador">Simulador de dívidas</a>' if valor < fat['restante'] else ''}</p></section>'''
    return req.html('Confirmar pagamento da fatura', corpo)


@rota('POST', r'/cartoes/(\d+)/pagar')
def cartao_pagar(req):
    cid = int(req.parametros[0])
    with banco.transacao() as c:
        cartoes.pagar(c, inteiro(req.f('origem'), 'conta de origem'), cid, centavos(req.f('valor')), req.f('data'))
    volta = req.f('volta')
    ir(f'/cartoes/{cid}/fatura/{volta}' if volta else f'/cartoes/{cid}', 'Pagamento registrado.')


# ------------------------------------------------------------------ parcelamentos

@rota('GET', '/parcelamentos')
def parcelamentos(req):
    with banco.conexao() as c:
        lista = cartoes.planos(c, hoje(), incluir_encerrados=req.q('todos') == '1')
        ausentes = cartoes.parcelas_ausentes(c)
    blocos = []
    if ausentes:
        linhas = []
        for x in ausentes:
            acoes = (f'<a class="botao-link" href="/parcelamentos/{x["plano_id"]}/encerrar?a_partir_de={x["parcela_n"]}">Encerrar a partir desta</a> '
                     f'<a href="/lancamentos/{x["id"]}/excluir">Excluir só esta parcela</a>')
            linhas.append([data_br(x['data']), f'<a href="/lancamentos/{x["id"]}">{e(x["descricao"])}</a>', e(x['cartao']),
                           f'fecha {data_br(x["fechamento"])}', dinheiro(x['valor']), acoes])
        blocos.append(f'''<section class="painel"><h2>Parcelas que não vieram na fatura</h2>
{aviso("Estavam previstas para faturas já importadas e não apareceram nelas. Costuma ser antecipação, cancelamento da compra ou lançamento em dobro.", "atencao")}
{tabela(['Data', 'Parcela', 'Cartão', 'Fatura', 'Valor', ''], linhas, (4,), ocultar_movel=(2, 3))}
<p class="fraco">Antecipação ou cancelamento: encerre o parcelamento (as parcelas seguintes também saem). Se a parcela foi lançada em dobro
ou importada como outra linha, exclua só ela.</p></section>''')
    for p in lista:
        pagas = sum(1 for x in p['parcelas'] if x['situacao'] != 'futura')
        situ = (selo(cartoes.MOTIVOS_ENCERRAMENTO.get(p['motivo_encerramento'], 'encerrado'), '') if p['encerrado_em'] else
                f'faltam {p["n_futuras"]} · {dinheiro(p["restante"])}')
        prox = f' · próxima {data_br(p["proxima"]["data"])}' if p['proxima'] else ''
        botao = '' if p['encerrado_em'] else f'<a href="/parcelamentos/{p["id"]}/encerrar">Antecipei ou cancelei…</a>'
        detalhe = ''.join(f'<li>{e(x["parcela_n"])}/{e(p["n_parcelas"])} · {data_br(x["data"])} · {dinheiro(x["valor"])} · '
                          f'<span class="fraco">{e(x["situacao"])}</span></li>' for x in p['parcelas'])
        blocos.append(f'''<section class="painel" id="plano-{p['id']}"><h2>{e(p['descricao'])}</h2>
<p>{e(p['cartao'])} · compra em {data_br(p['data_compra'])} · {e(p['n_parcelas'])}x · {pagas} já cobrada(s) · {situ}{prox}</p>
<details><summary>Ver parcelas</summary><ul>{detalhe}</ul></details><p>{botao}</p></section>''')
    if not blocos:
        blocos.append('<div class="vazio">Nenhuma compra parcelada em andamento.</div>')
    todos = '' if req.q('todos') == '1' else '<p><a href="/parcelamentos?todos=1">Mostrar também os encerrados</a></p>'
    return req.html('Parcelamentos', ''.join(blocos) + todos, 'Compras parceladas (cartão, carnê, boleto ou Pix parcelado): o que falta pagar, e como tirar parcelas antecipadas ou canceladas.')


@rota('GET', r'/parcelamentos/(\d+)/encerrar')
def parcelamento_encerrar_confirmar(req):
    pid = int(req.parametros[0])
    with banco.conexao() as c:
        p = next((x for x in cartoes.planos(c, hoje(), incluir_encerrados=True) if x['id'] == pid), None)
    if p is None:
        raise ErroValidacao('Parcelamento não encontrado.')
    a_partir = req.q('a_partir_de')
    sairao = [x for x in p['parcelas'] if x['situacao'] != 'na fatura' and
              (x['parcela_n'] >= int(a_partir) if a_partir.isdigit() else x['situacao'] == 'futura')]
    lista = ''.join(f'<li>{e(x["parcela_n"])}/{e(p["n_parcelas"])} · {data_br(x["data"])} · {dinheiro(x["valor"])}</li>' for x in sairao)
    motivos = ''.join(f'<option value="{k}">{e(v)}</option>' for k, v in cartoes.MOTIVOS_ENCERRAMENTO.items())
    corpo = f'''<section class="painel"><h2>{e(p['descricao'])}</h2>
<p>Estas parcelas saem do planejamento ({len(sairao)}, total {dinheiro(sum(x['valor'] for x in sairao))}):</p><ul>{lista or '<li>nenhuma</li>'}</ul>
<p>Elas vão para a Lixeira (dá para desfazer). Parcelas que já vieram em faturas importadas não são tocadas.</p>
<p class="fraco">O valor cobrado na antecipação, ou o crédito do cancelamento, aparece na fatura como uma linha própria: lance essa linha
(na importação ou à mão). Não precisa lançar mais nada aqui.</p>
<form method="post" action="/parcelamentos/{pid}/encerrar" class="campos">{tk()}<input type="hidden" name="a_partir_de" value="{e(a_partir)}">
<label>Motivo<select name="motivo">{motivos}</select></label><button class="perigo">Encerrar parcelamento</button></form></section>
<p><a href="/parcelamentos">Voltar</a></p>'''
    return req.html('Encerrar parcelamento', corpo)


@rota('POST', r'/parcelamentos/(\d+)/encerrar')
def parcelamento_encerrar(req):
    a_partir = req.f('a_partir_de')
    with banco.transacao() as c:
        n = cartoes.encerrar_parcelamento(c, int(req.parametros[0]), req.f('motivo'), int(a_partir) if a_partir.isdigit() else None, hoje())
    ir('/parcelamentos', f'Parcelamento encerrado: {n} parcela(s) retirada(s) do planejamento (estão na Lixeira).')


@rota('POST', r'/cartoes/(\d+)/saldo-inicial')
def cartao_saldo_inicial(req):
    cid = int(req.parametros[0])
    from fin404.dominio import operacoes
    with banco.transacao() as c:
        operacoes.saldo_inicial(c, cid, req.f('data'), centavos(req.f('valor'), permitir_zero=True))
    ir('/cartoes', 'Saldo inicial do cartão definido. As faturas do app agora partem da mesma dívida que o banco.')


@rota('POST', r'/cartoes/pagamentos/(\d+)')
def cartao_virar_pagamento(req):
    origem = inteiro(req.f('origem'), 'conta de origem')
    with banco.transacao() as c:
        cartoes.virar_pagamento(c, int(req.parametros[0]), origem)
    ir('/cartoes', 'Corrigido: agora é pagamento de fatura, não estorno. O gasto do mês voltou ao valor certo.')
