"""Página inicial: o resumo do mês, alertas e lançamento rápido."""
from datetime import timedelta

from fin404.dados import banco
from fin404.dominio import cartoes, razao, relatorios
from fin404.web.base import (categorias, grupos_contas, hoje, ir, mes_atual, tem_contas)
from fin404.web.componentes import barra, data_br, dinheiro, e, mes_br, opcoes, opcoes_agrupadas, selo, tabela
from fin404.web.servidor import rota, token_html as tk



# ------------------------------------------------------------------ início

@rota('GET', '/')
def inicio(req):
    from fin404 import migracao_v09
    with banco.conexao() as c:
        if not tem_contas(c):
            legado = migracao_v09.arquivo_legado()
            extra = (f'<div class="aviso atencao">Encontrei dados da versão anterior em <code>{e(legado.name)}</code>. '
                     f'<a href="/migrar">Trazer esses dados para cá</a> antes de começar.</div>') if legado else ''
            corpo = f'''{extra}<section class="painel"><h2>Primeiros passos</h2><ol>
<li><a href="/contas">Cadastre suas contas</a>: conta corrente, poupança, dinheiro e cada cartão (com dias de fechamento e vencimento).</li>
<li>Informe o <b>saldo inicial</b> de cada conta numa data de referência (o saldo do extrato naquele dia).</li>
<li><a href="/pessoas">Cadastre as pessoas</a> (vocês dois) para ver gastos por pessoa.</li>
<li><a href="/importar">Importe os extratos e faturas</a> a partir da data de referência, ou lance à mão.</li>
<li>Use <a href="/previsoes">Previsões</a> para salário, aluguel e contas fixas, e veja o <a href="/fluxo">fluxo de caixa</a>.</li></ol></section>'''
            return req.html('Bem-vindos', corpo, 'Vamos montar o retrato financeiro de vocês.')
        p = relatorios.posicao(c)
        ym = mes_atual()
        m = relatorios.resumo_mes(c, ym)
        alertas, n_ocultos = relatorios.alertas_visiveis(c)
        orc = {r['id']: r['limite'] for r in relatorios.orcamento(c, ym) if r['limite']}
        comp = relatorios.compromissos(c, 6)
        from fin404.dominio import analises
        rx = analises.raio_x(c)
        cats_rapido = categorias(c, 'despesa')
        contas_rapido = grupos_contas(c)
        usada = c.execute('''SELECT l.conta_id FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                             WHERE t.tipo='despesa' AND t.lote_id IS NULL AND k.tipo IN ('ativo','passivo') AND t.data>=?
                             GROUP BY l.conta_id ORDER BY COUNT(*) DESC LIMIT 1''', ((hoje() - timedelta(days=60)).isoformat(),)).fetchone()
        conta_padrao = usada[0] if usada else None
        cartoes_vence = []          # por cartão: a fatura a pagar e a aberta (que já carrega a anterior: não somar)
        for k in cartoes.lista(c):
            if k['dia_fechamento']:
                atual = cartoes.fechamento_da_compra(k, hoje())
                ant = cartoes.fatura(c, k['id'], cartoes.fechamento_anterior(k, atual))
                aberta = cartoes.fatura(c, k['id'], atual)
                cartoes_vence.append((k, ant, aberta))
        limite_pagar = (hoje() + timedelta(days=15)).isoformat()
        a_pagar = c.execute('''SELECT t.id, t.data, t.descricao,
                                      (SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                                       WHERE l.transacao_id=t.id AND k.tipo IN ('receita','despesa')) efeito
                               FROM transacoes t WHERE t.status='agendada' AND t.data<=? ORDER BY t.data LIMIT 8''',
                            (limite_pagar,)).fetchall()
    aviso_incompleto = ''
    if m['despesas_fora_cartao'] == 0 and hoje().day >= 7:
        # Sem extrato, um mês sem nenhum Pix, boleto, débito ou saque lançado quase sempre é lançamento faltando.
        aviso_incompleto = (' · <a class="neg" href="/lote">nada lançado fora do cartão: faltam Pix, boletos, débitos ou saques?</a>')
    cartao_reserva = ''
    if rx['custo_minimo'] > 0:
        cob = rx['cobertura_minimo']
        cor = ' class="neg"' if cob < 30 else ' class="pos"' if cob >= 60 else ''
        cartao_reserva = (f'<div class="cartao"><small><a href="/raio-x">Reserva cobre</a></small><strong{cor}>{cob // 10},{cob % 10} meses</strong>'
                          f'<em>do custo de vida mínimo ({dinheiro(rx["custo_minimo"])}/mês)</em></div>')
    cards = f'''<div class="cartoes">
<div class="cartao"><small>Disponível agora</small><strong>{dinheiro(p['disponivel'])}</strong><em>contas, poupança e dinheiro · livre depois dos cartões: {dinheiro(p['disponivel'] - p['cartoes'], cor=True)}</em></div>
<div class="cartao"><small><a href="/devo">Dívida nos cartões</a></small><strong>{dinheiro(p['cartoes'])}</strong><em>+ {dinheiro(p['parcelas_futuras'])} em parcelas a vencer</em></div>
<div class="cartao"><small>Resultado de {mes_br(ym)}</small><strong>{dinheiro(m['resultado'], cor=True)}</strong><em>{dinheiro(m['total_receitas'])} entrou · {dinheiro(m['total_despesas'])} saiu</em></div>
<div class="cartao"><small><a href="/gastos?mes={ym}">Gastos de {mes_br(ym)}</a></small><strong>{dinheiro(m['total_despesas'])}</strong><em>{dinheiro(m['despesas_no_cartao'])} no cartão · {dinheiro(m['despesas_fora_cartao'])} fora{aviso_incompleto}</em></div>{cartao_reserva}</div>'''
    cor_alerta = {'urgente': 'vermelho', 'conferir': 'amarelo', 'importacao': 'amarelo', 'config': ''}
    lista_alertas = ''.join(f'<li>{selo({"urgente": "urgente", "conferir": "conferir", "importacao": "revisar", "config": "configurar"}[t], cor_alerta[t])} '
                            f'<a href="{e(link)}">{e(txt)}</a><form method="post" action="/alertas/dispensar" class="dispensar">{tk()}'
                            f'<input type="hidden" name="chave" value="{chave}"><input type="hidden" name="tipo" value="{e(t)}">'
                            f'<button class="secundario" title="Esconder por {3 if t == "urgente" else 30} dias">Dispensar</button></form></li>'
                            for t, txt, link, chave in alertas)
    ocultos = (f'<form method="post" action="/alertas/reexibir" class="acoes">{tk()}<span class="fraco">{n_ocultos} alerta(s) dispensado(s).</span>'
               f'<button class="secundario">Mostrar de novo</button></form>') if n_ocultos else ''
    painel_alertas = (f'<section class="painel"><h2>Atenção</h2><ul class="lista-alertas">{lista_alertas}</ul>{ocultos}</section>'
                      if alertas or ocultos else '')
    total_desp = m['total_despesas'] or 1
    gastos = ''.join(f'<div class="item-barra"><div class="acoes"><a href="/lancamentos?mes={ym}&amp;categoria={cid}">{e(nome)}</a>'
                     f'<span class="fraco">{dinheiro(v)}{" / orçado " + dinheiro(orc[cid]) if cid in orc else ""}</span></div>'
                     f'{barra(v, orc.get(cid) or total_desp)}</div>' for cid, nome, v in m['despesas'][:10])
    vence = []
    for k, ant, aberta in cartoes_vence:
        if ant['restante'] and ant['situacao'] in ('vencida', 'fechada', 'paga parcialmente'):
            cor = 'vermelho' if ant['situacao'] == 'vencida' else 'amarelo'
            vence.append([data_br(ant['vencimento']), f'<a href="/cartoes/{k["id"]}/fatura/{ant["fechamento"].isoformat()}#pagar">Fatura {e(k["nome"])}</a>',
                          dinheiro(ant['restante']), selo(ant['situacao'], cor)])
        if aberta['compras']:
            vence.append([data_br(aberta['vencimento']), f'<a href="/cartoes/{k["id"]}/fatura/{aberta["fechamento"].isoformat()}">Fatura {e(k["nome"])} (aberta)</a>',
                          dinheiro(aberta['compras']) + '<br><small class="fraco">compras até agora</small>', selo('aberta', '')])
    for t in a_pagar:
        ef = -(t['efeito'] or 0)
        atrasado = t['data'] < hoje().isoformat()
        vence.append([data_br(t['data']), f'<a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a>', dinheiro(abs(ef), cor=False) if ef < 0 else dinheiro(ef, cor=True),
                      selo(('a pagar' if ef < 0 else 'a receber') + (' · atrasado' if atrasado else ''), 'vermelho' if atrasado else 'amarelo')])
    vence.sort(key=lambda x: x[0][6:] + x[0][3:5] + x[0][:2])
    comp_linhas = [[mes_br(k), dinheiro(v['parcelas']), dinheiro(v['previstas_saida']), dinheiro(v['previstas_entrada'])] for k, v in comp.items()]
    contas_linhas = [[f'<a href="/contas/{k["id"]}">{e(k["nome"])}</a>', e(razao.SUBTIPOS.get(k['subtipo'], ('', k['subtipo']))[1]),
                      dinheiro(k['saldo_natural'])] for k in p['contas']]
    rapido = f'''<section class="painel"><h2>Lançamento rápido</h2><form method="post" action="/novo" class="campos">{tk()}
<input type="hidden" name="tipo" value="despesa"><input type="hidden" name="data" value="{hoje().isoformat()}"><input type="hidden" name="volta" value="/">
<label>O que foi<input name="descricao" required maxlength="200" placeholder="Pix padaria, gasolina…"></label>
<label>Valor (R$)<input name="valor" required inputmode="decimal" placeholder="0,00"></label>
<label>Categoria<select name="categoria">{opcoes(cats_rapido, None, "Adivinhar pela descrição")}</select></label>
<label>Saiu de<select name="conta" required>{opcoes_agrupadas(contas_rapido, conta_padrao)}</select></label>
<button>Lançar gasto de hoje</button></form>
<p class="fraco">Anotou vários no celular? <a href="/lote">Lançar vários de uma vez</a> · <a href="/resumo">Resumo do mês para mostrar ou imprimir</a></p></section>'''
    corpo = f'''{painel_alertas}{cards}{rapido}<div class="grade"><section class="painel"><h2>O que vence nos próximos 15 dias</h2>
{tabela(['Data', 'O quê', 'Valor', 'Situação'], vence, (2,), 'Nada a pagar nos próximos 15 dias.')}
<p class="fraco">A fatura aberta já inclui o que ficou da anterior; o valor dela aqui é só o das compras novas. <a href="/confirmar">A pagar e receber →</a></p></section>
<section class="painel"><h2>Gastos de {mes_br(ym)} por categoria</h2>
{gastos or '<div class="vazio">Nenhuma despesa neste mês.</div>'}<p><a href="/gastos?mes={ym}">Quanto gastei, em detalhe →</a></p></section></div>
<div class="grade"><section class="painel"><h2>Compromissos dos próximos meses</h2>
{tabela(['Mês', 'Parcelas nas faturas', 'Saídas previstas', 'Entradas previstas'], comp_linhas, (1, 2, 3))}
<p class="fraco">Parcelas já contratadas, no mês em que a fatura vence, e previsões cadastradas. <a href="/fluxo">Ver fluxo de caixa dia a dia →</a></p></section>
<section class="painel"><h2>Saldos</h2>{tabela(['Conta', 'Tipo', 'Saldo'], contas_linhas, (2,))}</section></div>'''
    return req.html('Início', corpo, f'Situação em {hoje().strftime("%d/%m/%Y")}.')


@rota('POST', '/alertas/dispensar')
def alerta_dispensar(req):
    with banco.transacao() as c:
        dias = relatorios.dispensar_alerta(c, req.f('chave'), req.f('tipo'))
    ir('/', f'Alerta escondido por {dias} dias. Se a situação mudar, ele volta.')


@rota('POST', '/alertas/reexibir')
def alerta_reexibir(req):
    with banco.transacao() as c:
        relatorios.reexibir_alertas(c)
    ir('/', 'Alertas dispensados voltaram a aparecer.')


@rota('GET', '/devo')
def quanto_devo(req):
    """Tudo o que vocês devem hoje, num lugar só: cartões (com a dívida antiga), empréstimos e contas lançadas como a pagar."""
    with banco.conexao() as c:
        p = relatorios.posicao(c)
        linhas_cartao, faturas_pagar = [], []
        limite_dt = hoje() + timedelta(days=31)
        for k in cartoes.lista(c):
            if k['dia_fechamento']:
                atual = cartoes.fechamento_da_compra(k, hoje())
                ant = cartoes.fatura(c, k['id'], cartoes.fechamento_anterior(k, atual))
                aberta = cartoes.fatura(c, k['id'], atual)
                pendente = ant['restante'] if ant['situacao'] in ('vencida', 'fechada', 'paga parcialmente') else 0
                if pendente:
                    faturas_pagar.append((ant['vencimento'], k, ant, pendente, ant['situacao']))
                if aberta['vencimento'] <= limite_dt:
                    # a aberta já carrega o que ficou da anterior: aqui só o que é novo, para não contar duas vezes
                    novo = max(aberta['valor'] - pendente, 0)
                    if novo:
                        faturas_pagar.append((aberta['vencimento'], k, aberta, novo, 'aberta'))
            devendo = -razao.saldo(c, k['id'], hoje())
            futuras = -c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                                     WHERE l.conta_id=? AND t.status<>'agendada' AND t.data>?''', (k['id'], hoje().isoformat())).fetchone()[0]
            pend = cartoes.saldo_inicial_pendente(c, k['id'])
            obs = (f'<br><small class="neg">falta a dívida de antes do app ({dinheiro(pend["banco"])}): <a href="/cartoes">usar como saldo inicial</a></small>'
                   if pend else '')
            linhas_cartao.append([f'<a href="/cartoes/{k["id"]}">{e(k["nome"])}</a>{obs}', dinheiro(devendo), dinheiro(futuras)])
        dividas = [k for k in p['contas'] if k['tipo'] == 'passivo' and k['subtipo'] != 'cartao']
        linhas_div = [[f'<a href="/contas/{k["id"]}">{e(k["nome"])}</a>', dinheiro(k['saldo_natural'])] for k in dividas]
        a_pagar = c.execute('''SELECT t.id, t.data, t.descricao,
                                    -(SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                                      WHERE l.transacao_id=t.id AND k.tipo IN ('receita','despesa')) efeito
                             FROM transacoes t WHERE t.status='agendada' AND t.data<=? ORDER BY t.data''',
                          ((hoje() + timedelta(days=31)).isoformat(),)).fetchall()
    contas_pagar = [t for t in a_pagar if (t['efeito'] or 0) < 0]
    contas_receber = [t for t in a_pagar if (t['efeito'] or 0) > 0]
    with banco.conexao() as c2:
        from fin404.dominio import receber as _rec
        devedores = _rec.quem_deve(c2)
    atrasadas = sum(-t['efeito'] for t in contas_pagar if t['data'] < hoje().isoformat())
    proximas = sum(-t['efeito'] for t in contas_pagar if t['data'] >= hoje().isoformat())
    total_cartoes = p['cartoes']
    itens = [(t['data'], f'<a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a>', -t['efeito'],
              selo('atrasado', 'vermelho') if t['data'] < hoje().isoformat() else selo('a pagar', 'amarelo')) for t in contas_pagar]
    cor_fat = {'vencida': 'vermelho', 'fechada': 'amarelo', 'paga parcialmente': 'amarelo', 'aberta': ''}
    for venc, k, f, valor, sit in faturas_pagar:
        rotulo = f'Fatura {e(k["nome"])}' + (' <small class="fraco">(aberta: compras até agora)</small>' if sit == 'aberta' else '')
        itens.append((venc.isoformat(), f'<a href="/cartoes/{k["id"]}/fatura/{f["fechamento"].isoformat()}#pagar">{rotulo}</a>', valor,
                      selo('vencida' if sit == 'vencida' else sit, cor_fat.get(sit, 'amarelo'))))
    itens.sort(key=lambda x: x[0])
    linhas_pagar = [[data_br(d), o, dinheiro(v), sel] for d, o, v, sel in itens]
    total_pagar = sum(v for _, _, v, _ in itens)
    corpo = f'''<div class="cartoes">
<div class="cartao"><small>Para pagar até {data_br(limite_dt.isoformat())}</small><strong>{dinheiro(total_pagar)}</strong><em>faturas e contas da lista abaixo{(" + " + dinheiro(p['outras_dividas']) + " de empréstimos") if p['outras_dividas'] else ""}</em></div>
<div class="cartao"><small>Nos cartões, hoje</small><strong>{dinheiro(total_cartoes)}</strong><em>+ {dinheiro(p['parcelas_futuras'])} em parcelas futuras</em></div>
<div class="cartao"><small>Contas a pagar</small><strong>{dinheiro(atrasadas + proximas)}</strong><em>{dinheiro(atrasadas)} atrasado</em></div>
<div class="cartao"><small>Empréstimos e financiamentos</small><strong>{dinheiro(p['outras_dividas'])}</strong><em>saldo devedor</em></div></div>
<section class="painel"><h2>Cartões</h2>{tabela(['Cartão', 'Devendo hoje', 'Parcelas futuras'], linhas_cartao, (1, 2), 'Nenhum cartão cadastrado.')}
<p class="fraco">"Devendo hoje" é tudo o que já passou no cartão e não foi pago, inclusive a fatura vencida. As parcelas futuras ainda não
caíram em nenhuma fatura. Compras que vocês ainda não lançaram (nem vieram em PDF) não estão aqui.</p></section>
<div class="grade"><section class="painel"><h2>O que pagar até {data_br(limite_dt.isoformat())}</h2>{tabela(['Data', 'O quê', 'Valor', ''], linhas_pagar, (2,), 'Nada a pagar nos próximos 31 dias.')}
<p><strong>Total a pagar até {data_br(limite_dt.isoformat())}: {dinheiro(total_pagar)}</strong></p>
<p class="fraco">As faturas dos cartões entram sozinhas, pelo que está lançado ou importado. Não lance a fatura como conta a pagar:
as compras dela já estão no cartão, e ela contaria duas vezes. Fatura aberta mostra só as compras novas (a parte da anterior que
ficou sem pagar está na linha da fatura anterior). <a href="/confirmar">Marcar contas como pagas →</a></p></section>
<section class="painel"><h2>A receber</h2>{tabela(['Data', 'O quê', 'Valor'],
    [[data_br(t['data']), f'<a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a>', dinheiro(t['efeito'], cor=True)] for t in contas_receber]
    + [['—', f'<a href="/receber">{e(d["nome"])} deve</a> <small class="fraco">desde {data_br(d["desde"])}</small>', dinheiro(d['aberto'], cor=True)] for d in devedores],
    (2,), 'Nada a receber lançado nem emprestado.')}</section>
<section class="painel"><h2>Empréstimos e financiamentos</h2>{tabela(['Dívida', 'Saldo devedor'], linhas_div, (1,), 'Nenhuma cadastrada (Ajustes → Contas e dívidas).')}</section></div>
<p class="fraco">O que está em aberto é diferente do que foi gasto: a dívida de antes do app e os juros entram aqui, mas não são gasto do mês.
O que vocês têm para pagar isso: {dinheiro(p['disponivel'])} disponível agora.</p>'''
    return req.html('Em aberto', corpo, 'Tudo o que falta pagar e receber: cartões, contas, empréstimos e dinheiro emprestado.')
