"""Registro das páginas: importar este módulo registra todas as rotas (cada área fica no seu módulo pg_*)."""
from fin404.web import (pg_analises, pg_cadastros, pg_cartoes, pg_compras, pg_contas, pg_importacao, pg_inicio,  # noqa: F401
                        pg_lancamentos, pg_lote, pg_manutencao, pg_notas, pg_planejamento, pg_prazos, pg_receber, pg_reuniao, pg_relatorios, pg_seguranca)
