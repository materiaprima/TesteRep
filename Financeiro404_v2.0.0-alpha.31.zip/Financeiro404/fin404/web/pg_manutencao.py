"""Backup manual, restauração, verificação de integridade e migração da v0.9."""
from pathlib import Path

from fin404 import migracao_v09
from fin404.dados import banco
from fin404.dinheiro import ErroValidacao
from fin404.dominio import razao
from fin404.seguranca import backup
from fin404.web.base import ir
from fin404.web.componentes import aviso, data_br, dinheiro, e, mes_br, selo, tabela
from fin404.web.servidor import rota, token_html as tk


# ------------------------------------------------------------------ segurança

@rota('POST', '/backup')
def backup_gerar(req):
    if req.f('senha') != req.f('senha2'):
        raise ErroValidacao('As senhas não são iguais.')
    nome, dados = backup.gerar(req.f('senha'))
    with banco.transacao() as c:
        banco.auditar(c, 'backup', 'banco', None, nome)
    return 200, 'application/octet-stream', dados, {'Content-Disposition': f'attachment; filename="{nome}"'}


@rota('GET', '/restaurar')
def restaurar_pagina(req):
    pasta = banco.pasta_dados() / 'restauracoes'
    prontos = sorted(pasta.glob('recuperado_*.sqlite3'), reverse=True)[:5] if pasta.exists() else []
    lista = ''.join(f'<li>{e(p.name)}</li>' for p in prontos)
    corpo = f'''<section class="painel"><h2>1. Verificar o backup</h2><form method="post" action="/restaurar" enctype="multipart/form-data" class="campos">{tk()}
<label>Arquivo .fin404<input type="file" name="arquivo" accept=".fin404" required></label>
<label>Senha<input type="password" name="senha" required></label><button>Verificar</button></form>
<p class="fraco">Decifra e confere a integridade. Nada é alterado no banco em uso nesta etapa.</p></section>
{f'<details class="painel"><summary>Restaurações já verificadas</summary><ul>{lista}</ul></details>' if lista else ''}'''
    return req.html('Restaurar backup', corpo)


@rota('POST', '/restaurar')
def restaurar_verificar(req):
    if 'arquivo' not in req.arquivos:
        raise ErroValidacao('Escolha o arquivo do backup.')
    destino, info = backup.preparar_restauracao(req.arquivos['arquivo'][1], req.f('senha'))
    if info['formato'] != 'v2':
        corpo = (aviso('Backup válido, mas da versão antiga (v0.9/v1.0).', 'atencao') +
                 f'<section class="painel"><p>{info["transacoes"]} lançamentos, último em {e(info["ultima_data"])}.</p>'
                 '<p>Para trazer esses dados, copie o arquivo recuperado para a pasta <code>data</code> com o nome <code>financeiro.sqlite3</code> '
                 f'e use <a href="/migrar">Trazer dados da versão anterior</a>. Arquivo recuperado: <code>{e(destino.name)}</code>.</p></section>')
        return req.html('Backup verificado', corpo)
    corpo = f'''{aviso('Backup íntegro e senha correta.', 'ok')}<section class="painel"><p>{info['transacoes']} lançamentos em {info['contas']} contas.
Último lançamento: {data_br(info['ultima_data']) if info['ultima_data'] else '—'}.</p></section>
<section class="painel"><h2>2. Substituir os dados atuais por este backup</h2>
<p>Antes da troca, uma cópia do banco atual é guardada em <code>data/copias</code>. Se algo falhar, o banco atual é devolvido automaticamente.</p>
<form method="post" action="/restaurar/ativar" class="acoes">{tk()}<input type="hidden" name="arquivo" value="{e(destino.name)}">
<label class="check"><input type="checkbox" name="confirmo" value="1" required> Entendo que os dados atuais serão substituídos pelos do backup</label>
<button class="perigo">Restaurar agora</button></form></section>'''
    return req.html('Backup verificado', corpo)


@rota('POST', '/restaurar/ativar')
def restaurar_ativar(req):
    if req.f('confirmo') != '1':
        raise ErroValidacao('Marque a confirmação.')
    nome = Path(req.f('arquivo')).name
    r = backup.ativar_restauracao(banco.pasta_dados() / 'restauracoes' / nome)
    ir('/', f'Backup restaurado ({r["transacoes"]} lançamentos). Os dados anteriores foram guardados em {r["copia_anterior"].name}.')


@rota('GET', '/integridade')
def integridade(req):
    from fin404 import VERSAO
    r = banco.integridade()
    with banco.conexao() as c:
        problemas = razao.verificar_tudo(c)
        n = {t: c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0] for t in ('transacoes', 'lancamentos', 'contas', 'lotes_importacao', 'auditoria')}
    ok = r['integridade'] == 'ok' and not r['chaves_estrangeiras'] and not r['transacoes_desequilibradas'] and not problemas
    linhas = [[e(k), e(v)] for k, v in {**r, **n}.items()]
    corpo = (aviso('Tudo certo: banco íntegro e todas as transações equilibradas.', 'ok') if ok else
             aviso('Foram encontrados problemas: ' + '; '.join(problemas[:10]), 'erro')) + \
        f'<section class="painel">{tabela(["Verificação", "Resultado"], linhas)}<p class="fraco">Versão {e(VERSAO)} · banco em {e(banco.caminho_banco())}</p></section>'
    return req.html('Integridade', corpo)


@rota('GET', '/migrar')
def migrar_pagina(req):
    legado = migracao_v09.arquivo_legado()
    if not legado:
        return req.html('Trazer dados da versão anterior', aviso('Não encontrei data/financeiro.sqlite3 (banco da versão anterior) nesta pasta.', 'info'))
    with banco.conexao() as c:
        ja_tem = c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0]
    if ja_tem:
        return req.html('Trazer dados da versão anterior', aviso(f'O banco atual já tem {ja_tem} lançamentos. A migração só é feita num banco vazio, '
                                                                  'para não misturar dados. Se quiser refazer, restaure um backup vazio ou fale comigo.', 'atencao'))
    rel = migracao_v09.simular(legado)
    comp = [[mes_br(x['mes']), dinheiro(x['receitas_antes']), dinheiro(x['receitas_depois']), dinheiro(x['despesas_antes']), dinheiro(x['despesas_depois']),
             selo('confere', 'verde') if x['receitas_antes'] == x['receitas_depois'] and x['despesas_antes'] == x['despesas_depois'] else selo('diferente', 'vermelho')]
            for x in rel['comparacao']]
    revisar = ''.join(f'<li>{e(x)}</li>' for x in rel['revisar'] + rel['nao_migrado'])
    corpo = f'''{aviso('Simulação feita num banco temporário. Nada foi gravado ainda; o arquivo antigo nunca é alterado.', 'info')}
<section class="painel"><p>{rel['contas']} contas · {rel['lancamentos']} lançamentos ({rel['agendados']} como previstos) · {rel['transferencias']} transferências ·
{rel['pagamentos']} pagamentos de fatura · {rel['estornos']} estornos · {rel['saldos_iniciais']} saldos iniciais · {rel['previsoes']} recorrências · {rel['orcamentos']} orçamentos.</p>
{tabela(['Mês', 'Receitas antes', 'Receitas depois', 'Despesas antes', 'Despesas depois', ''], comp, (1, 2, 3, 4))}</section>
{f'<section class="painel"><h2>Para revisar depois</h2><ul>{revisar}</ul></section>' if revisar else ''}
<form method="post" action="/migrar" class="acoes painel">{tk()}<label class="check"><input type="checkbox" name="confirmo" value="1" required> Conferi a simulação</label>
<button{" disabled" if not rel['totais_conferem'] else ""}>Trazer os dados</button></form>'''
    return req.html('Trazer dados da versão anterior', corpo)


@rota('POST', '/migrar')
def migrar_executar(req):
    if req.f('confirmo') != '1':
        raise ErroValidacao('Marque a confirmação.')
    legado = migracao_v09.arquivo_legado()
    if not legado:
        raise ErroValidacao('Banco da versão anterior não encontrado.')
    rel = migracao_v09.executar(legado)
    ir('/', f'Dados trazidos: {rel["lancamentos"]} lançamentos. Confira os alertas e configure os cartões.')
