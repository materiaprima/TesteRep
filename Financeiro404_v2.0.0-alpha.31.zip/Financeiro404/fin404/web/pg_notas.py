"""Notas fiscais e preços (R10): importar CSV, ver a nota e ligar ao lançamento, agrupar produtos, histórico de preços."""
from datetime import timedelta
from urllib.parse import quote

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao, formatar
from fin404.dominio import catalogo, fotos_nota, notas
from fin404.web.base import categorias, grupos_contas, hoje, inteiro, ir
from fin404.web.componentes import (aviso, botao_excluir, data_br, dinheiro, e, grafico_linhas, opcoes, opcoes_agrupadas, selo,
                                    tabela)
from fin404.web.servidor import rota, token_html as tk

ABAS = [('/notas', 'Por arquivo'), ('/notas/fotos', 'Por foto'), ('/precos', 'Preços'), ('/precos/agrupar', 'Agrupar produtos')]


def _abas(atual):
    """Só as subdivisões da parte atual (Notas: por arquivo ou por foto; Preços: lista ou agrupar); a área já tem as abas principais."""
    familia = [x for x in ABAS if x[0].split('/')[1] == atual.split('/')[1]]
    return '<div class="abas sub">' + ''.join(f'<a href="{h}"{" class=atual" if h == atual else ""}>{e(n)}</a>' for h, n in familia) + '</div>'


def _atribuicao(c):
    fontes = catalogo.atribuicoes(c)
    return ('<p class="fraco">' + ' '.join(e(f['atribuicao']) for f in fontes) + '</p>') if fontes else ''


ORIGENS = {'pagina': 'página', 'lista_nfp': 'lista NFP', 'foto': 'foto'}


def _origem(n):
    o = ORIGENS.get(n['origem'])
    return f' <span class="fraco">· {o}</span>' if o else ''


def _msg_importacao(r):
    partes = []
    if r['notas']:
        partes.append(f'{r["notas"]} nota(s) nova(s)')
    if r['completadas']:
        partes.append(f'{r["completadas"]} nota(s) da lista completada(s) com os itens')
    msg = (', '.join(partes) or 'Nenhuma nota nova') + f'; {r["itens"]} item(ns); {r["ligadas"]} ligada(s) a lançamentos.'
    if r['puladas']:
        msg += f' {len(r["puladas"])} já estava(m) no app e foi(ram) pulada(s).'
    return msg


def _qtd(it):
    return f'{notas.formatar_quantidade(it["quantidade_mil"])} {e(it["unidade"].lower())}'


# ------------------------------------------------------------------ notas

@rota('GET', '/notas')
def notas_pagina(req):
    fim = hoje()
    inicio = fim - timedelta(days=90)
    filtro = req.q('filtro')
    with banco.conexao() as c:
        lista = notas.listar(c, filtro=filtro if filtro in ('sem_lancamento', 'sem_itens') else '')
        todas = c.execute('SELECT COUNT(*) FROM notas_fiscais').fetchone()[0]
        conf = notas.conferencia(c)
        n_fotos = len(fotos_nota.pendentes(c))
        g = catalogo.gasto_por_tipo(c, inicio, fim)
        imps = c.execute('''SELECT i.*, (SELECT COUNT(*) FROM notas_fiscais n WHERE n.importacao_id=i.id)
                                   + (SELECT COUNT(DISTINCT it.nota_id) FROM itens_nota it JOIN notas_fiscais n2 ON n2.id=it.nota_id
                                      WHERE it.importacao_id=i.id AND COALESCE(n2.importacao_id, -1)<>i.id) n FROM importacoes_notas i
                            WHERE i.desfeito_em IS NULL ORDER BY i.id DESC LIMIT 10''').fetchall()
    linhas = [[data_br(n['data']), f'<a href="/notas/{n["id"]}">{e(n["loja"])}</a>' + _origem(n),
               str(n['n_itens']) if n['n_itens'] else '<span class="fraco">—</span>', dinheiro(n['total_centavos']),
               (f'<a href="/lancamentos/{n["transacao_id"]}">{selo("ligada", "verde")}</a>' if n['transacao_id']
                else selo('sem lançamento', 'amarelo'))] for n in lista]
    total_tipos = sum(t['v'] for t in g['tipos']) or 1
    tipos = [[e(t['tipo']), str(t['n']), dinheiro(t['v']), f'{t["v"] * 100 // total_tipos}%'] for t in g['tipos']]
    lojas = [[e(x['loja']), str(x['n']), dinheiro(x['v'])] for x in g['lojas']]
    imp_html = ''.join(f'<li>{e(i["arquivo"])} · {i["n"]} nota(s) · {data_br(i["criado_em"][:10])} '
                       f'<form method="post" action="/notas/importacoes/{i["id"]}/desfazer" class="acoes">{tk()}'
                       f'<button class="secundario">Desfazer</button></form></li>' for i in imps)
    filtros = ''.join(f'<a href="/notas{q}"{" class=atual" if filtro == f else ""}>{e(r)}</a>' for f, q, r in
                      (('', '', 'Todas'), ('sem_lancamento', '?filtro=sem_lancamento', 'Sem lançamento'),
                       ('sem_itens', '?filtro=sem_itens', 'Sem itens')))
    alerta_conf = ''
    if conf['sem_lancamento']:
        alerta_conf = f'''<section class="painel"><h2>Conferência: compras que podem estar fora do app</h2>
<p><strong>{conf['sem_lancamento']}</strong> nota(s) sem lançamento ligado, somando <strong>{dinheiro(conf['sem_lancamento_total'])}</strong>
(desde {data_br(conf['desde'])}). Cada uma é uma compra com CPF na nota que não achei nos lançamentos (mesmo valor, até 3 dias).
Pode ser compra paga em dinheiro, Pix ou débito que não foi lançada, ou lançada com outro valor.</p>
<div class="acoes"><a class="botao secundario" href="/notas?filtro=sem_lancamento">Ver as notas soltas</a>
<form method="post" action="/notas/religar" class="acoes">{tk()}<button class="secundario">Tentar ligar de novo</button></form></div>
<p class="fraco">Abra cada nota: se a compra não está no app, use "Lançar esta compra"; se está com outro valor, corrija o lançamento e ligue.</p></section>'''
    corpo = f'''{_abas('/notas')}<div class="cartoes">
<div class="cartao"><small>Notas registradas</small><strong>{todas}</strong><em>{conf['sem_lancamento']} sem lançamento · {conf['sem_itens']} sem itens</em></div>
<div class="cartao"><small>Gasto em notas (90 dias)</small><strong>{dinheiro(sum(t['v'] for t in g['tipos']) - g['desconto'])}</strong>
<em>{dinheiro(g['desconto'])} de desconto</em></div>
<div class="cartao"><small>Fotos para digitar</small><strong>{n_fotos}</strong><em><a href="/notas/fotos">Notas por foto</a></em></div></div>
{alerta_conf}
<section class="painel"><h2>Trazer notas</h2>
<details class="bloco-import"><summary><strong>Página da nota</strong> (Nota Fiscal Paulista ou QR code) — com os itens</summary>
<form method="post" action="/notas/importar-pagina" enctype="multipart/form-data" class="campos">{tk()}
<label>Páginas salvas (.html), pode escolher várias<input type="file" name="arquivo" accept=".html,.htm" multiple required></label>
<button>Importar páginas</button></form>
<p class="fraco">No navegador, abra o detalhe da nota (no site da Nota Fiscal Paulista ou lendo o QR code do cupom) e salve com
Ctrl+S, tipo "Página da Web, somente HTML". Cada página vira uma nota com todos os itens. Se a página não fechar (soma dos itens
≠ total) ou não for reconhecida, nada é gravado e o app diz qual arquivo.</p></details>
<details class="bloco-import"><summary><strong>Lista da Nota Fiscal Paulista</strong> — para achar compras fora do app</summary>
<form method="post" action="/notas/importar-lista" enctype="multipart/form-data" class="campos">{tk()}
<label>Página da lista salva (.html)<input type="file" name="arquivo" accept=".html,.htm" required></label>
<button>Importar lista</button></form>
<p class="fraco">Em "Consultar documentos", filtre o período, e salve a página do resultado (Ctrl+S, "somente HTML"); se tiver
mais de uma página de resultados, salve e importe cada uma. Cada documento vira uma nota <em>sem itens</em> (data, loja, valor), que
o app tenta ligar a um lançamento. Depois, a página da nota ou a foto completa os itens da mesma nota, sem duplicar.</p></details>
<details class="bloco-import"><summary><strong>Foto da nota</strong> — digitar os itens olhando a foto</summary>
<form method="post" action="/notas/fotos" enctype="multipart/form-data" class="campos">{tk()}
<label>Fotos (JPG, PNG ou WEBP), pode escolher várias<input type="file" name="foto" accept="image/jpeg,image/png,image/webp" multiple required></label>
<button>Enviar fotos</button></form>
<p class="fraco">As fotos ficam guardadas dentro do app (entram no backup). Depois você abre cada uma e digita os itens ao lado.</p></details>
<details class="bloco-import"><summary><strong>Planilha CSV</strong> — uma linha por item</summary>
<form method="post" action="/notas/importar" enctype="multipart/form-data" class="campos">{tk()}
<label>Arquivo CSV<input type="file" name="arquivo" accept=".csv,.txt" required></label><button>Importar</button></form>
<p class="fraco">Separado por ponto e vírgula. <a href="/notas/modelo.csv">Baixar o modelo</a>. O arquivo
inteiro é recusado se um item não fechar (quantidade × preço) ou se os itens não somarem o total da nota.</p></details>
<p class="fraco">A nota nunca cria despesa sozinha: ela é ligada ao lançamento de mesmo valor (até 3 dias de diferença), ou você lança a partir dela.</p>
{f'<p>Últimas importações:</p><ul class="lista-imp">{imp_html}</ul>' if imps else ''}</section>
<div class="grade"><section class="painel"><h2>Gasto por tipo (90 dias)</h2>{tabela(['Tipo', 'Itens', 'Valor', ''], tipos, (1, 2, 3), 'Nenhuma nota no período.')}</section>
<section class="painel"><h2>Por loja (90 dias)</h2>{tabela(['Loja', 'Notas', 'Valor'], lojas, (1, 2), 'Nenhuma nota no período.')}</section></div>
<section class="painel"><h2>Notas</h2><div class="abas">{filtros}</div>
{tabela(['Data', 'Loja', 'Itens', 'Total', 'Lançamento'], linhas, (2, 3), 'Nenhuma nota aqui.', ocultar_movel=(2,))}</section>'''
    return req.html('Notas fiscais', corpo, 'O que foi comprado, item por item, e quanto custou em cada loja.')


@rota('GET', '/notas/modelo.csv')
def notas_modelo(req):
    return 200, 'text/csv; charset=utf-8', notas.modelo_csv(), {'Content-Disposition': 'attachment; filename="modelo_notas.csv"'}


@rota('POST', '/notas/importar')
def notas_importar(req):
    if 'arquivo' not in req.arquivos or not req.arquivos['arquivo'][1]:
        raise ErroValidacao('Escolha o arquivo CSV.')
    nome, dados = req.arquivos['arquivo']
    with banco.transacao() as c:
        r = notas.importar_csv(c, nome, dados)
    ir('/notas', _msg_importacao(r))


def _arquivos(req, campo, rotulo):
    arqs = [(n, d) for n, d in req.arquivos.get(campo + '[]', []) if d]
    if not arqs and campo in req.arquivos and req.arquivos[campo][1]:
        arqs = [req.arquivos[campo]]
    if not arqs:
        raise ErroValidacao(f'Escolha {rotulo}.')
    return arqs


@rota('POST', '/notas/importar-pagina')
def notas_importar_pagina(req):
    arqs = _arquivos(req, 'arquivo', 'a página salva da nota (.html)')
    with banco.transacao() as c:
        r = notas.importar_paginas(c, arqs)
    ir(f'/notas/{r["ids"][0]}' if len(r['ids']) == 1 else '/notas', _msg_importacao(r))


@rota('POST', '/notas/importar-lista')
def notas_importar_lista(req):
    nome, dados = _arquivos(req, 'arquivo', 'a página salva da lista (.html)')[0]
    with banco.transacao() as c:
        r = notas.importar_lista(c, nome, dados)
    ir('/notas?filtro=sem_lancamento' if r['notas'] and r['ligadas'] < r['notas'] else '/notas', _msg_importacao(r))


@rota('POST', '/notas/religar')
def notas_religar(req):
    with banco.transacao() as c:
        n = notas.religar_todas(c)
    ir('/notas', f'{n} nota(s) ligada(s) agora.' if n else 'Nenhuma nota nova pôde ser ligada automaticamente (sem lançamento de mesmo valor e data, ou com mais de um candidato).')


@rota('POST', r'/notas/importacoes/(\d+)/desfazer')
def notas_desfazer(req):
    with banco.transacao() as c:
        n = notas.desfazer(c, int(req.parametros[0]))
    ir('/notas', f'Importação desfeita: {n} nota(s) removida(s) ou revertida(s). Os lançamentos continuam.')


@rota('GET', r'/notas/(\d+)')
def nota_pagina(req):
    nid = int(req.parametros[0])
    with banco.conexao() as c:
        n = notas.uma(c, nid)
        its = notas.itens(c, nid)
        cands = [] if n['transacao_id'] else notas.candidatos(c, nid)
        t = c.execute('SELECT id, data, descricao FROM transacoes WHERE id=?', (n['transacao_id'],)).fetchone() if n['transacao_id'] else None
        cats = categorias(c, 'despesa')
        g_pag = grupos_contas(c)
        from fin404.dominio import categorias as cats_dom
        sugerida = cats_dom.inferir(c, n['loja'])
        fotos = fotos_nota.da_nota(c, nid)
    linhas = [[e(i['descricao']) + (f'<br><span class="fraco">{e(i["produto"])}{" · " + e(i["marca"]) if i["marca"] else ""}</span>'
                                    if i['produto'] and i['produto'] != i['descricao'] else ''),
               _qtd(i), dinheiro(i['preco_unit_centavos']), dinheiro(i['total_centavos']), e(i['tipo']),
               f'<a href="/precos/item?chave={quote(("p" + str(i["produto_id"])) if i["produto_id"] else ("d" + i["descricao_norm"]))}">preços</a>']
              for i in its]
    if t:
        ligacao = (f'<p>{selo("ligada", "verde")} ao lançamento <a href="/lancamentos/{t["id"]}">{e(t["descricao"])}</a> de {data_br(t["data"])}.</p>'
                   f'<form method="post" action="/notas/{nid}/desligar" class="acoes">{tk()}<button class="secundario">Desligar</button></form>')
    else:
        botoes = ''.join(f'<form method="post" action="/notas/{nid}/ligar" class="acoes">{tk()}<input type="hidden" name="transacao" value="{x["id"]}">'
                         f'<button class="secundario">Ligar a "{e(x["descricao"])}" de {data_br(x["data_compra"])}</button></form>' for x in cands)
        ligacao = f'''<p>{selo("sem lançamento", "amarelo")} Nenhum lançamento com o mesmo valor e data foi ligado automaticamente.</p>{botoes}
<form method="post" action="/notas/{nid}/lancar" class="campos">{tk()}
<label>Pago com<select name="conta" required>{opcoes_agrupadas(g_pag, None, "Escolha")}</select></label>
<label>Categoria<select name="categoria" required>{opcoes(cats, sugerida[0] if sugerida else None, "Escolha")}</select></label>
<label>Parcelas<input name="parcelas" value="1" inputmode="numeric"></label><button>Lançar esta compra</button></form>
<p class="fraco">Use "Lançar" só se a compra ainda não está no app (não veio na fatura nem foi lançada à mão).</p>'''
    garantia_opts = [(i['id'], i['descricao']) for i in its]
    corpo = f'''<p><a href="/notas">← Notas fiscais</a></p><div class="cartoes">
<div class="cartao"><small>{e(n['loja'])}</small><strong>{dinheiro(n['total_centavos'])}</strong>
<em>{data_br(n['data'])}{" · desconto " + e(dinheiro(n['desconto_centavos'])) if n['desconto_centavos'] else ""}{" · CNPJ " + e(n['cnpj']) if n['cnpj'] else ""}</em></div></div>
<section class="painel"><h2>Itens</h2>{tabela(['Item', 'Qtd', 'Preço', 'Total', 'Tipo', ''], linhas, (2, 3), '', ocultar_movel=(4,)) if linhas else
  '<p>Esta nota veio da lista da Nota Fiscal Paulista, sem itens. Importe a página da nota ou envie a foto para completar.</p>'}</section>
{('<section class="painel"><h2>Foto</h2><div class="fotos-nota">' + ''.join(f'<a href="/notas/fotos/{f["id"]}/imagem"><img src="/notas/fotos/{f["id"]}/imagem" alt="Foto da nota"></a>' for f in fotos) + '</div></section>') if fotos else ''}
<section class="painel"><h2>Lançamento</h2>{ligacao}</section>
<details class="painel"><summary>Garantia de um item</summary><form method="post" action="/notas/{nid}/garantia" class="campos">{tk()}
<label>Item<select name="item" required>{opcoes(garantia_opts, None, "Escolha")}</select></label>
<label>Meses<select name="meses">{''.join(f'<option value="{m}">{m} meses</option>' for m in (3, 6, 12, 24, 36))}</select></label>
<button class="secundario">Registrar garantia</button></form><p class="fraco">Conta da data da nota e aparece em Prazos e garantias.</p></details>
<section class="painel">{botao_excluir(f"/notas/{nid}/excluir", "Apaga a nota e os itens. O lançamento continua.", "Excluir nota")}
{f'<p class="fraco">Chave {e(n["chave"])}</p>' if n['chave'] else ''}</section>'''
    return req.html(f'Nota de {n["loja"]}', corpo)


@rota('POST', r'/notas/(\d+)/ligar')
def nota_ligar(req):
    with banco.transacao() as c:
        notas.ligar(c, int(req.parametros[0]), inteiro(req.f('transacao'), 'lançamento'))
    ir(f'/notas/{req.parametros[0]}', 'Nota ligada ao lançamento.')


@rota('POST', r'/notas/(\d+)/desligar')
def nota_desligar(req):
    with banco.transacao() as c:
        notas.desligar(c, int(req.parametros[0]))
    ir(f'/notas/{req.parametros[0]}', 'Nota desligada do lançamento.')


@rota('POST', r'/notas/(\d+)/lancar')
def nota_lancar(req):
    with banco.transacao() as c:
        notas.lancar(c, int(req.parametros[0]), inteiro(req.f('conta'), 'conta'), inteiro(req.f('categoria'), 'categoria'),
                     inteiro(req.f('parcelas') or '1', 'parcelas'))
    ir(f'/notas/{req.parametros[0]}', 'Compra lançada e ligada à nota.')


@rota('POST', r'/notas/(\d+)/garantia')
def nota_garantia(req):
    from fin404.dominio import prazos
    nid = int(req.parametros[0])
    with banco.transacao() as c:
        n = notas.uma(c, nid)
        it = c.execute('SELECT descricao FROM itens_nota WHERE id=? AND nota_id=?', (inteiro(req.f('item'), 'item'), nid)).fetchone()
        if not it:
            raise ErroValidacao('Item não encontrado nesta nota.')
        prazos.garantia(c, it['descricao'], n['data'], inteiro(req.f('meses'), 'meses'), nota_id=nid, transacao_id=n['transacao_id'])
    ir(f'/notas/{nid}', 'Garantia registrada em Prazos e garantias.')


@rota('POST', r'/notas/(\d+)/excluir')
def nota_excluir(req):
    with banco.transacao() as c:
        loja = notas.excluir(c, int(req.parametros[0]))
    ir('/notas', f'Nota de {loja} excluída.')


# ------------------------------------------------------------------ preços

@rota('GET', '/precos')
def precos_pagina(req):
    termo = req.q('q')
    with banco.conexao() as c:
        lista = catalogo.lista_precos(c, termo)
        n_sem = c.execute('SELECT COUNT(DISTINCT descricao_norm) FROM itens_nota WHERE produto_id IS NULL').fetchone()[0]
        atrib = _atribuicao(c)
    def variacao(x):
        if x['variacao'] is None:
            return '<span class="fraco">—</span>'
        cls = 'neg' if x['variacao'] > 0 else 'pos' if x['variacao'] < 0 else ''
        return f'<span class="{cls}">{"+" if x["variacao"] > 0 else ""}{x["variacao"]}%</span>'
    linhas = [[f'<a href="/precos/item?chave={quote(x["chave"])}">{e(x["nome"])}</a>'
               + (f' <span class="fraco">{e(x["marca"])}</span>' if x['marca'] else '')
               + ('' if x['chave'].startswith('p') else ' ' + selo('sem produto')),
               e(x['tipo']), str(x['n']), f'{dinheiro(x["ultimo"])}/{e(x["unidade"].lower())}', dinheiro(x['menor']), dinheiro(x['maior']),
               variacao(x), str(x['lojas'])] for x in lista]
    corpo = f'''{_abas('/precos')}<section class="painel"><form method="get" action="/precos" class="acoes filtros">
<label>Procurar produto<input name="q" value="{e(termo)}" placeholder="leite, arroz, detergente…"></label><button class="secundario">Procurar</button></form>
{f'<p>{n_sem} descrição(ões) ainda sem produto. <a href="/precos/agrupar">Agrupar</a> junta o mesmo produto escrito de jeitos diferentes em lojas diferentes.</p>' if n_sem else ''}
{tabela(['Produto', 'Tipo', 'Compras', 'Último', 'Menor', 'Maior', 'Variação', 'Lojas'], linhas, (2, 3, 4, 5, 6, 7),
        'Nenhum item de nota ainda. Importe notas em Notas fiscais.', ocultar_movel=(1, 4, 5, 7))}
<p class="fraco">Variação = último preço comparado com o primeiro registrado. Preço por unidade da nota (un, kg, l).</p>{atrib}</section>'''
    return req.html('Preços', corpo, 'Quanto cada produto custou, quando e onde.')


@rota('GET', '/precos/item')
def preco_item(req):
    chave = req.q('chave')
    with banco.conexao() as c:
        h = catalogo.historico_preco(c, chave)
        atrib = _atribuicao(c)
    compras = h['compras']
    rotulos = [f'{r["data"][8:10]}/{r["data"][5:7]}' for r in compras]
    grafico = grafico_linhas(rotulos, [('Preço por unidade', [r['preco_unit_centavos'] for r in compras])]) if len(compras) > 1 else ''
    linhas = [[data_br(r['data']), e(r['loja']), e(r['descricao']), _qtd(r), dinheiro(r['preco_unit_centavos']), dinheiro(r['total_centavos']),
               f'<a href="/notas/{r["nota_id"]}">nota</a>'] for r in reversed(compras)]
    lojas = [[e(x['loja']), str(x['n']), dinheiro(x['menor']), dinheiro(x['media']), dinheiro(x['ultimo'])] for x in h['por_loja']]
    extra = ''
    if h['produto_id']:
        apelidos = ''.join(f'<li>{e(d)} <form method="post" action="/precos/separar" class="acoes">{tk()}'
                           f'<input type="hidden" name="d" value="{e(notas.normalizar(d))}"><input type="hidden" name="volta" value="{e(chave)}">'
                           '<button class="secundario">Separar</button></form></li>' for d in h['descricoes'])
        extra = f'''<div class="grade"><section class="painel"><h2>Tipo</h2><form method="post" action="/precos/tipo" class="campos">{tk()}
<input type="hidden" name="produto" value="{h['produto_id']}"><label>Tipo<select name="tipo">{opcoes([(t, t) for t in catalogo.TIPOS_PRODUTO], h['tipo'])}</select></label>
<button class="secundario">Salvar</button></form></section>
<section class="painel"><h2>Escrito nas notas como</h2><ul>{apelidos}</ul></section></div>'''
    else:
        extra = f'<section class="painel"><p>Esta descrição ainda não está ligada a um produto. <a href="/precos/agrupar?d={quote(chave[1:])}">Agrupar</a></p></section>'
    corpo = f'''<p><a href="/precos">← Preços</a></p><div class="cartoes">
<div class="cartao"><small>{e(h['marca'] or 'Produto')}{(' · ' + e(h['tamanho'])) if h['tamanho'] else ''}</small><strong>{dinheiro(compras[-1]['preco_unit_centavos'])}</strong>
<em>último preço, em {data_br(compras[-1]['data'])} ({e(compras[-1]['loja'])})</em></div>
<div class="cartao"><small>Mais barato em</small><strong>{e(h['por_loja'][0]['loja'])}</strong><em>média {dinheiro(h['por_loja'][0]['media'])}</em></div></div>
{f'<section class="painel"><h2>Preço ao longo do tempo</h2>{grafico}</section>' if grafico else ''}
<section class="painel"><h2>Por loja</h2>{tabela(['Loja', 'Compras', 'Menor', 'Média', 'Último'], lojas, (1, 2, 3, 4))}</section>
<section class="painel"><h2>Compras</h2>{tabela(['Data', 'Loja', 'Na nota', 'Qtd', 'Preço', 'Total', ''], linhas, (4, 5), '', ocultar_movel=(2, 3, 5))}{atrib}</section>
{extra}'''
    return req.html(h['nome'], corpo, 'Histórico de preço')


@rota('GET', '/precos/agrupar')
def precos_agrupar(req):
    alvo, termo = req.q('d'), req.q('q')
    with banco.conexao() as c:
        sem = catalogo.sem_produto(c)
        if alvo and alvo not in {s['descricao_norm'] for s in sem}:
            alvo = ''
        lista = [s for s in sem if s['descricao_norm'] == alvo] if alvo else sem[:15]
        blocos = []
        for s in lista:
            sug = catalogo.sugestoes(c, s['descricao_norm'])
            if termo and alvo:
                sug = [dict(r) for r in c.execute('SELECT id, nome, marca, tamanho FROM produtos WHERE nome_norm LIKE ? ORDER BY length(nome) LIMIT 15',
                                                  (f'%{notas.normalizar(termo)}%',))]
            botoes = ''.join(f'<form method="post" action="/precos/associar" class="acoes">{tk()}<input type="hidden" name="d" value="{e(s["descricao_norm"])}">'
                             f'<input type="hidden" name="produto" value="{p["id"]}"><button class="secundario">É {e(p["nome"])}'
                             f'{" · " + e(p["marca"]) if p.get("marca") else ""}{" " + e(p["tamanho"]) if p.get("tamanho") else ""}</button></form>'
                             for p in sug)
            blocos.append(f'''<section class="painel"><h2>{e(s['exemplo'])} <small class="fraco">{s['n']} compra(s) · {dinheiro(s['total'])}</small></h2>
{botoes or '<p class="fraco">Sem sugestão parecida no catálogo.</p>'}
<form method="get" action="/precos/agrupar" class="acoes filtros"><input type="hidden" name="d" value="{e(s['descricao_norm'])}">
<label>Procurar no catálogo<input name="q" value="{e(termo if alvo else '')}"></label><button class="secundario">Procurar</button></form>
<form method="post" action="/precos/novo" class="campos">{tk()}<input type="hidden" name="d" value="{e(s['descricao_norm'])}">
<label>Ou criar produto<input name="nome" value="{e(s['exemplo'].title())}" maxlength="200" required></label>
<label>Marca<input name="marca" maxlength="120"></label><label>Tamanho<input name="tamanho" maxlength="60" placeholder="1 L, 500 g"></label>
<label>Tipo<select name="tipo">{opcoes([(t, t) for t in catalogo.TIPOS_PRODUTO], s['tipo'])}</select></label>
<button class="secundario">Criar e agrupar</button></form></section>''')
        n_cat = c.execute("SELECT COUNT(*) FROM produtos WHERE fonte NOT IN ('nota','manual')").fetchone()[0]
        atrib = _atribuicao(c)
    corpo = f'''{_abas('/precos/agrupar')}
{aviso('Tudo agrupado: cada descrição das notas já aponta para um produto.', 'ok') if not sem else ''}
{''.join(blocos)}
<section class="painel"><h2>Catálogo de produtos</h2><p>{n_cat} produto(s) importado(s) de bases abertas.</p>
<form method="post" action="/precos/catalogo" enctype="multipart/form-data" class="campos">{tk()}
<label>Base<select name="fonte">{opcoes([(k, v[0]) for k, v in catalogo.FONTES.items()], 'off')}</select></label>
<label>País<input name="pais" value="brazil"></label>
<label>Arquivo (CSV ou .csv.gz, até 25 MB)<input type="file" name="arquivo" required></label><button class="secundario">Importar catálogo</button></form>
<p class="fraco">O arquivo completo do Open Food Facts tem vários GB: importe pelo terminal, na pasta do programa,
<code>.venv\\Scripts\\python ferramentas\\importar_catalogo.py arquivo.csv.gz --fonte off</code>. Só produtos do país escolhido entram.
O programa não baixa nada da internet.</p>{atrib}</section>'''
    return req.html('Agrupar produtos', corpo, 'O mesmo produto escrito de jeitos diferentes em lojas diferentes vira um só.')


@rota('POST', '/precos/associar')
def precos_associar(req):
    with banco.transacao() as c:
        n = catalogo.associar(c, req.f('d'), inteiro(req.f('produto'), 'produto'))
    ir('/precos/agrupar', f'Agrupado ({n} item(ns) de nota).')


@rota('POST', '/precos/novo')
def precos_novo(req):
    with banco.transacao() as c:
        pid = catalogo.novo_produto(c, req.f('nome'), req.f('marca'), req.f('tamanho'), req.f('tipo'))
        catalogo.associar(c, req.f('d'), pid)
    ir('/precos/agrupar', 'Produto criado e agrupado.')


@rota('POST', '/precos/separar')
def precos_separar(req):
    with banco.transacao() as c:
        catalogo.separar(c, req.f('d'))
    ir('/precos/item?chave=' + quote(req.f('volta') or ''), 'Descrição separada do produto.')


@rota('POST', '/precos/tipo')
def precos_tipo(req):
    pid = inteiro(req.f('produto'), 'produto')
    with banco.transacao() as c:
        catalogo.definir_tipo(c, pid, req.f('tipo'))
    ir(f'/precos/item?chave=p{pid}', 'Tipo atualizado.')


@rota('POST', '/precos/catalogo')
def precos_catalogo(req):
    if 'arquivo' not in req.arquivos or not req.arquivos['arquivo'][1]:
        raise ErroValidacao('Escolha o arquivo do catálogo.')
    with banco.transacao() as c:
        r = catalogo.importar_bytes(c, req.arquivos['arquivo'][1], req.f('fonte'), req.f('pais'))
    ir('/precos/agrupar', f'Catálogo: {r["gravados"]} produto(s) gravados de {r["lidos"]} lidos ({r["ignorados"]} de outro país ou sem código).')


# ------------------------------------------------------------------ notas por foto

@rota('GET', '/notas/fotos')
def fotos_pagina(req):
    with banco.conexao() as c:
        pend = fotos_nota.pendentes(c)
        feitas = c.execute('''SELECT f.id, f.nome, n.id nota, n.loja, n.data, n.total_centavos FROM fotos_nota f
                              JOIN notas_fiscais n ON n.id=f.nota_id ORDER BY f.id DESC LIMIT 20''').fetchall()
    linhas = [[f'<a href="/notas/fotos/{f["id"]}">{e(f["nome"])}</a>', f'{f["tamanho"] // 1024} KB', data_br(f['criado_em'][:10]),
               f'<a class="botao secundario" href="/notas/fotos/{f["id"]}">Digitar</a>'] for f in pend]
    feitas_l = [[f'<a href="/notas/{f["nota"]}">{e(f["loja"])}</a>', data_br(f['data']), dinheiro(f['total_centavos']), e(f['nome'])]
                for f in feitas]
    corpo = f'''{_abas('/notas/fotos')}<section class="painel"><h2>Enviar fotos de notas</h2>
<form method="post" action="/notas/fotos" enctype="multipart/form-data" class="campos">{tk()}
<label>Fotos (JPG, PNG ou WEBP; até 8 MB cada)<input type="file" name="foto" accept="image/jpeg,image/png,image/webp" multiple required></label>
<button>Enviar</button></form>
<p class="fraco">A foto fica guardada no app. Você abre e digita os itens ao lado dela; a soma tem de bater com o total da nota.
Dica: foto reta, com boa luz, o cupom inteiro. Cupom muito longo pode ir em duas fotos (envie as duas e digite numa só; descarte a outra).</p></section>
<section class="painel"><h2>Para digitar ({len(pend)})</h2>{tabela(['Foto', 'Tamanho', 'Enviada', ''], linhas, (1,), 'Nenhuma foto esperando.')}</section>
<section class="painel"><h2>Já viraram nota</h2>{tabela(['Loja', 'Data', 'Total', 'Foto'], feitas_l, (2,), 'Nenhuma ainda.')}</section>'''
    return req.html('Notas por foto', corpo, 'Fotos de cupons para digitar os itens olhando a imagem.')


@rota('POST', '/notas/fotos')
def fotos_enviar(req):
    arqs = _arquivos(req, 'foto', 'ao menos uma foto')
    with banco.transacao() as c:
        novas, repetidas = fotos_nota.guardar_varias(c, arqs)
    msg = f'{len(novas)} foto(s) recebida(s).' + (f' {repetidas} já estava(m) no app.' if repetidas else '')
    ir(f'/notas/fotos/{novas[0]}' if novas else '/notas/fotos', msg)


@rota('GET', r'/notas/fotos/(\d+)/imagem')
def foto_imagem(req):
    with banco.conexao() as c:
        f = fotos_nota.uma(c, int(req.parametros[0]), com_dados=True)
    tipo = fotos_nota.tipo_imagem(bytes(f['dados'][:16]))
    if tipo is None:          # só serve o que foi conferido como imagem
        raise ErroValidacao('Foto inválida.')
    return 200, tipo, bytes(f['dados']), {'Content-Disposition': f'inline; filename="nota{f["id"]}"', 'Cache-Control': 'private, max-age=3600'}


def _resumo_itens(texto, total, desconto):
    itens, erros = fotos_nota.ler_itens(texto)
    soma = sum(i['total'] for i in itens)
    linhas = [[e(i['descricao']), f'{notas.formatar_quantidade(i["quantidade_mil"])} {e(i["unidade"].lower())}',
               dinheiro(i['preco']), dinheiro(i['total'])] for i in itens]
    situacao = ''
    if total is not None:
        dif = soma - desconto - total
        situacao = (aviso(f'Fecha: itens {formatar(soma)} − desconto {formatar(desconto)} = total {formatar(total)}.', 'ok') if dif == 0
                    else aviso(f'Não fecha: itens {formatar(soma)} − desconto {formatar(desconto)} = {formatar(soma - desconto)}; '
                               f'total da nota {formatar(total)}; {"sobram" if dif > 0 else "faltam"} {formatar(abs(dif))}.', 'erro'))
    return (situacao + ''.join(aviso(x, 'erro') for x in erros[:10])
            + tabela(['Item', 'Qtd', 'Preço', 'Total'], linhas, (1, 2, 3), 'Nenhum item lido ainda.'))


def _tela_foto(req, fid, valores=None, erro='', conferir=False, status=200):
    from fin404.dinheiro import centavos
    with banco.conexao() as c:
        f = fotos_nota.uma(c, fid)
        pend = [p['id'] for p in fotos_nota.pendentes(c)]
    if f['nota_id']:
        ir(f'/notas/{f["nota_id"]}', 'Esta foto já virou nota.')
    v = {'loja': '', 'cnpj': '', 'data': hoje().strftime('%d/%m/%Y'), 'chave': '', 'total': '', 'desconto': '', 'itens': ''}
    v.update(valores or {})
    conferencia = ''
    if conferir or erro:
        try:
            total = centavos(v['total']) if v['total'] else None
            desconto = centavos(v['desconto'] or '0', permitir_zero=True)
        except ErroValidacao:
            total, desconto = None, 0
        conferencia = f'<section class="painel"><h2>Conferência</h2>{_resumo_itens(v["itens"], total, desconto)}</section>'
    pos = pend.index(fid) + 1 if fid in pend else 0
    corpo = f'''<p><a href="/notas/fotos">← Notas por foto</a>{f" · foto {pos} de {len(pend)}" if pos else ""}</p>
{aviso(erro, "erro")}
<div class="foto-e-form"><section class="painel foto-grande"><a href="/notas/fotos/{fid}/imagem" title="Abrir a foto inteira">
<img src="/notas/fotos/{fid}/imagem" alt="Foto da nota {e(f['nome'])}"></a><p class="fraco">{e(f['nome'])} · clique para abrir em tamanho real</p></section>
<section class="painel"><h2>Digitar a nota</h2><form method="post" action="/notas/fotos/{fid}" class="campos coluna">{tk()}
<label>Loja<input name="loja" value="{e(v['loja'])}" required maxlength="120"></label>
<label>Data<input name="data" value="{e(v['data'])}" required placeholder="dd/mm/aaaa"></label>
<label>CNPJ (opcional)<input name="cnpj" value="{e(v['cnpj'])}" inputmode="numeric"></label>
<label>Total da nota (valor a pagar)<input name="total" value="{e(v['total'])}" required inputmode="decimal"></label>
<label>Desconto (opcional)<input name="desconto" value="{e(v['desconto'])}" inputmode="decimal"></label>
<label>Chave de acesso, 44 dígitos (opcional)<input name="chave" value="{e(v['chave'])}" inputmode="numeric"></label>
<label>Itens, um por linha<textarea name="itens" rows="14" required placeholder="ARROZ 5KG 24,90&#10;LEITE INTEGRAL 1L 2 5,49&#10;BANANA PRATA 0,850 KG 6,99 5,94">{e(v['itens'])}</textarea></label>
<p class="fraco">No fim de cada linha: só o total; ou quantidade e preço unitário; ou quantidade, preço unitário e total.
Código de barras no começo da linha é guardado. Quantidade com vírgula para peso (0,850).</p>
<div class="acoes"><button name="acao" value="conferir" class="secundario">Conferir soma</button><button name="acao" value="salvar">Salvar nota</button></div>
</form>
<details class="excluir"><summary>Descartar foto…</summary><p>Apaga a foto (repetida, ilegível ou não é nota).</p>
<form method="post" action="/notas/fotos/{fid}/descartar">{tk()}<button class="perigo">Descartar</button></form></details></section></div>
{conferencia}'''
    return req.html('Digitar nota da foto', corpo, status=status)


@rota('GET', r'/notas/fotos/(\d+)')
def foto_pagina(req):
    return _tela_foto(req, int(req.parametros[0]))


@rota('POST', r'/notas/fotos/(\d+)')
def foto_salvar(req):
    fid = int(req.parametros[0])
    valores = {k: req.form.get(k, [''])[0] for k in ('loja', 'cnpj', 'data', 'chave', 'total', 'desconto', 'itens')}
    if req.f('acao') == 'conferir':
        return _tela_foto(req, fid, valores, conferir=True)
    try:
        with banco.transacao() as c:
            nid, _ = fotos_nota.salvar_nota(c, fid, valores)
            proxima = fotos_nota.proxima_pendente(c, fid)
    except ErroValidacao as exc:      # volta para a mesma tela com tudo que foi digitado
        return _tela_foto(req, fid, valores, erro=str(exc), status=422)
    if proxima:
        ir(f'/notas/fotos/{proxima}', f'Nota salva (nota {nid}). Próxima foto.')
    ir(f'/notas/{nid}', 'Nota salva a partir da foto.')


@rota('POST', r'/notas/fotos/(\d+)/descartar')
def foto_descartar(req):
    fid = int(req.parametros[0])
    with banco.transacao() as c:
        fotos_nota.descartar(c, fid)
        proxima = fotos_nota.proxima_pendente(c, fid)
    ir(f'/notas/fotos/{proxima}' if proxima else '/notas/fotos', 'Foto descartada.')
