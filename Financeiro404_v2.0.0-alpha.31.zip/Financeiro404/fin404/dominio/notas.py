"""Notas fiscais (R10, camada 1 — local): importar itens de notas por CSV, ligar ao lançamento, tipo de cada item.

Formato do CSV (separador ponto e vírgula, decimais com vírgula; uma linha por item, os dados da nota repetidos):

    data;loja;cnpj;chave;item;codigo;quantidade;unidade;preco_unitario;total_item;desconto_nota;total_nota

- `chave` (44 dígitos da NFC-e), `codigo` (código de barras/GTIN), `cnpj` e `desconto_nota` podem ficar vazios.
- Itens da mesma nota: mesma `chave`; sem chave, mesma data + CNPJ (ou loja) + total.
- **Travas** (o arquivo inteiro é recusado se alguma falhar, nada é gravado):
  quantidade × preço unitário = total do item (tolerância de 1 centavo de arredondamento);
  soma dos itens − desconto = total da nota (exato).
- Nota com chave já importada é pulada (avisada); o mesmo arquivo duas vezes é recusado.
- A nota **não cria despesa**: ela detalha um lançamento que já existe (casado por valor e data ±3 dias, inclusive compra
  parcelada pelo total do parcelamento) ou que o usuário lança a partir dela.
"""
import csv
import hashlib
import io
import re
import unicodedata
from datetime import timedelta

from fin404.dinheiro import ErroValidacao, centavos, data as ler_data

COLUNAS = ('data', 'loja', 'cnpj', 'chave', 'item', 'codigo', 'quantidade', 'unidade', 'preco_unitario', 'total_item',
           'desconto_nota', 'total_nota')
OBRIGATORIAS = ('data', 'loja', 'item', 'quantidade', 'preco_unitario', 'total_item', 'total_nota')
MAX_LINHAS = 20000
TOLERANCIA_DIAS = 3
MIL = 1000

# Tipo de item de mercado, por palavra (normalizada, sem acento). Prefixos pegam abreviações de cupom ("DETERG", "SAB").
TIPOS = {
    'Carnes e peixes': ('carne', 'frango', 'coxa', 'sobrecoxa', 'peito frango', 'file', 'alcatra', 'patinho', 'picanha', 'acem',
                        'costela', 'linguica', 'salsicha', 'bacon', 'peixe', 'tilapia', 'sardinha', 'atum', 'moida', 'bisteca', 'pernil'),
    'Frios e laticínios': ('leite', 'queijo', 'mussarela', 'muçarela', 'iogurte', 'manteiga', 'margarina', 'requeijao', 'presunto',
                           'mortadela', 'creme leite', 'nata', 'peito peru', 'salame'),
    'Hortifrúti': ('banana', 'maca', 'tomate', 'cebola', 'alho', 'batata', 'cenoura', 'alface', 'laranja', 'limao', 'mamao',
                   'abacate', 'uva', 'melancia', 'pepino', 'abobrinha', 'brocolis', 'couve', 'repolho', 'pimentao', 'manga',
                   'morango', 'mandioca', 'chuchu', 'beterraba', 'hortifruti', 'fruta', 'verdura', 'legume'),
    'Padaria': ('pao', 'bisnaguinha', 'bolo', 'rosca', 'torrada', 'baguete', 'croissant'),
    'Mercearia': ('arroz', 'feijao', 'acucar', 'cafe', 'oleo', 'azeite', 'farinha', 'macarrao', 'massa', 'sal', 'molho', 'extrato',
                  'biscoito', 'bolacha', 'ovo', 'ovos', 'aveia', 'milho', 'achocolatado', 'tempero', 'vinagre', 'fuba', 'granola', 'cereal'),
    'Bebidas': ('agua', 'refrigerante', 'refri', 'suco', 'cerveja', 'vinho', 'coca', 'guarana', 'energetico', 'cha'),
    'Limpeza': ('detergente', 'sabao', 'amaciante', 'desinfetante', 'sanitaria', 'alvejante', 'esponja', 'multiuso', 'lava roupa',
                'saco lixo', 'limpador', 'cloro', 'pano', 'sab po', 'sabao po', 'lava lou', 'lava rou'),
    'Higiene e beleza': ('shampoo', 'condicionador', 'sabonete', 'creme dental', 'dental', 'escova', 'desodorante', 'papel higienico',
                         'absorvente', 'fralda', 'algodao', 'cotonete', 'fio dental', 'hidratante', 'barbear', 'pap hig',
                         'cr dental', 'sab liq'),
    'Pet': ('racao', 'areia gato', 'petisco', 'pet'),
}


def normalizar(texto):
    s = unicodedata.normalize('NFKD', texto or '').encode('ascii', 'ignore').decode('ascii').lower()
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9]+', ' ', s)).strip()


def tipo_do_item(descricao):
    norm = normalizar(descricao)
    tokens = norm.split()
    for tipo, chaves in TIPOS.items():
        for chave in chaves:
            ck = normalizar(chave)
            if ' ' in ck:
                if ck in norm:
                    return tipo
                continue
            for t in tokens:
                if t == ck or (len(ck) >= 4 and t.startswith(ck)) or (len(t) >= 4 and ck.startswith(t)):
                    return tipo
    return 'Outros'


def quantidade_mil(texto):
    """'2' → 2000; '0,512' → 512; '1.5' → 1500. Até 3 casas decimais."""
    t = (texto or '').strip().replace(' ', '')
    if not t:
        raise ValueError('vazia')
    if ',' in t:
        t = t.replace('.', '').replace(',', '.')
    m = re.fullmatch(r'(\d+)(?:\.(\d{1,3}))?', t)
    if not m:
        raise ValueError(t)
    inteiro, frac = m.group(1), (m.group(2) or '')
    q = int(inteiro) * MIL + int((frac + '000')[:3])
    if q <= 0:
        raise ValueError(t)
    return q


def formatar_quantidade(mil):
    inteiro, frac = divmod(int(mil), MIL)
    return str(inteiro) if not frac else f'{inteiro},{frac:03d}'.rstrip('0')


def _ler(dados):
    if b'\x00' in dados[:65536]:
        raise ErroValidacao('Este arquivo não é um CSV de texto.')
    try:
        texto = dados.decode('utf-8-sig')
    except UnicodeDecodeError:
        texto = dados.decode('cp1252', errors='replace')   # CSV salvo pelo Excel no Windows
    primeira = texto.split('\n', 1)[0]
    sep = ';' if primeira.count(';') >= primeira.count('\t') else '\t'
    leitor = csv.reader(io.StringIO(texto), delimiter=sep)
    try:
        cab = [normalizar(x).replace(' ', '_') for x in next(leitor)]
    except StopIteration:
        raise ErroValidacao('Arquivo vazio.')
    faltam = [x for x in OBRIGATORIAS if x not in cab]
    if faltam:
        raise ErroValidacao('Faltam colunas no CSV: ' + ', '.join(faltam) + '. Baixe o modelo na página Notas fiscais.')
    idx = {nome: cab.index(nome) for nome in COLUNAS if nome in cab}
    linhas = []
    for n, row in enumerate(leitor, start=2):
        if not any(x.strip() for x in row):
            continue
        if len(linhas) >= MAX_LINHAS:
            raise ErroValidacao(f'Arquivo acima de {MAX_LINHAS} itens; divida em partes.')
        linhas.append((n, {k: (row[i].strip() if i < len(row) else '') for k, i in idx.items()}))
    if not linhas:
        raise ErroValidacao('O CSV não tem itens.')
    return linhas


def interpretar(dados):
    """Valida tudo e agrupa em notas. Devolve (notas, erros). Não grava nada."""
    erros, notas = [], {}
    for n, x in _ler(dados):
        try:
            data = ler_data(x['data'])
            qtd = quantidade_mil(x['quantidade'])
            preco = centavos(x['preco_unitario'], permitir_zero=True)
            total_item = centavos(x['total_item'], permitir_zero=True)
            total_nota = centavos(x['total_nota'])
            desconto = centavos(x.get('desconto_nota') or '0', permitir_zero=True)
        except (ErroValidacao, ValueError) as exc:
            erros.append(f'Linha {n}: valor ou data inválidos ({exc}).')
            continue
        if not x['item'] or not x['loja']:
            erros.append(f'Linha {n}: falta o nome do item ou da loja.')
            continue
        if abs(qtd * preco - total_item * MIL) > MIL:
            erros.append(f'Linha {n}: {x["item"]}: quantidade × preço unitário não dá o total do item.')
            continue
        chave = re.sub(r'\D', '', x.get('chave') or '') or None
        if chave and len(chave) != 44:
            erros.append(f'Linha {n}: a chave da NFC-e tem 44 dígitos (veio com {len(chave)}).')
            continue
        cnpj = re.sub(r'\D', '', x.get('cnpj') or '')
        grupo = chave or (data.isoformat(), cnpj or normalizar(x['loja']), total_nota)
        nota = notas.setdefault(grupo, {'data': data, 'loja': x['loja'][:120], 'cnpj': cnpj, 'chave': chave, 'total': total_nota,
                                        'desconto': desconto, 'itens': [], 'linha': n})
        if nota['total'] != total_nota or nota['desconto'] != desconto or nota['data'] != data:
            erros.append(f'Linha {n}: a mesma nota aparece com data, desconto ou total diferentes.')
            continue
        nota['itens'].append({'descricao': x['item'][:200], 'gtin': re.sub(r'\D', '', x.get('codigo') or ''),
                              'quantidade_mil': qtd, 'unidade': (x.get('unidade') or 'UN').upper()[:6],
                              'preco': preco, 'total': total_item})
    for nota in notas.values():
        soma = sum(i['total'] for i in nota['itens'])
        if soma - nota['desconto'] != nota['total']:
            erros.append(f'Nota de {nota["loja"]} em {nota["data"].strftime("%d/%m/%Y")} (linha {nota["linha"]}): itens somam '
                         f'{soma} centavos, menos desconto {nota["desconto"]}, mas o total da nota é {nota["total"]}.')
    return list(notas.values()), erros


def _produto_para(c, descricao_norm, gtin):
    if gtin:
        r = c.execute('SELECT id FROM produtos WHERE gtin=?', (gtin,)).fetchone()
        if r:
            return r[0]
    r = c.execute('SELECT produto_id FROM produto_apelidos WHERE descricao_norm=?', (descricao_norm,)).fetchone()
    return r[0] if r else None


def _gravar_itens(c, nid, itens, imp, ordem0=0):
    for ordem, it in enumerate(itens, start=ordem0 + 1):
        norm = normalizar(it['descricao'])
        pid = _produto_para(c, norm, it['gtin'])
        if not pid and it['gtin']:            # código de barras fora do catálogo: vira produto, para agrupar entre lojas
            pid = c.execute("INSERT INTO produtos(gtin, nome, nome_norm, tipo, fonte) VALUES(?,?,?,?, 'nota')",
                            (it['gtin'], it['descricao'], norm, tipo_do_item(it['descricao']))).lastrowid
        tipo = (c.execute('SELECT tipo FROM produtos WHERE id=?', (pid,)).fetchone()[0] if pid else '') or tipo_do_item(it['descricao'])
        c.execute('''INSERT INTO itens_nota(nota_id, ordem, descricao, descricao_norm, gtin, quantidade_mil, unidade,
                     preco_unit_centavos, total_centavos, tipo, produto_id, importacao_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''',
                  (nid, ordem, it['descricao'], norm, it['gtin'], it['quantidade_mil'], it['unidade'], it['preco'], it['total'],
                   tipo, pid, imp))


def _ja_existe(c, nota):
    """A mesma compra já registrada: mesma chave, ou mesma data + CNPJ + total (a lista da Nota Fiscal Paulista não traz itens
    e às vezes não traz a chave)."""
    if nota['chave']:
        r = c.execute('SELECT * FROM notas_fiscais WHERE chave=?', (nota['chave'],)).fetchone()
        if r:
            return r
    if nota['cnpj']:
        return c.execute('''SELECT * FROM notas_fiscais WHERE data=? AND cnpj=? AND total_centavos=?
                            AND (chave IS NULL OR ? IS NULL OR chave=?) ORDER BY id LIMIT 1''',
                         (nota['data'].isoformat(), nota['cnpj'], nota['total'], nota['chave'], nota['chave'])).fetchone()
    return None


def gravar_nota(c, nota, imp, origem):
    """Grava uma nota já validada. Devolve ('nova' | 'completada' | 'pulada', id).
    Se a mesma compra já existe **sem itens** (veio da lista), os itens entram nela em vez de duplicar."""
    atual = _ja_existe(c, nota)
    if atual:
        tem_itens = c.execute('SELECT 1 FROM itens_nota WHERE nota_id=? LIMIT 1', (atual['id'],)).fetchone()
        if tem_itens or not nota['itens']:
            if nota['chave'] and not atual['chave']:
                c.execute('UPDATE notas_fiscais SET chave=? WHERE id=?', (nota['chave'], atual['id']))
            return 'pulada', atual['id']
        loja = nota['loja'] if atual['loja'].startswith('CNPJ ') else atual['loja']
        c.execute('UPDATE notas_fiscais SET desconto_centavos=?, chave=COALESCE(chave, ?), loja=? WHERE id=?',
                  (nota['desconto'], nota['chave'], loja, atual['id']))
        _gravar_itens(c, atual['id'], nota['itens'], imp)
        return 'completada', atual['id']
    nid = c.execute('''INSERT INTO notas_fiscais(importacao_id, data, loja, cnpj, chave, desconto_centavos, total_centavos, origem)
                       VALUES(?,?,?,?,?,?,?,?)''', (imp, nota['data'].isoformat(), nota['loja'], nota['cnpj'], nota['chave'],
                                                    nota['desconto'], nota['total'], origem)).lastrowid
    _gravar_itens(c, nid, nota['itens'], None)
    ligar_automatico(c, nid)
    return 'nova', nid


def nova_importacao(c, arquivo, sha):
    if c.execute('SELECT 1 FROM importacoes_notas WHERE sha256=? AND desfeito_em IS NULL', (sha,)).fetchone():
        raise ErroValidacao('Este arquivo já foi importado.')
    return c.execute('INSERT INTO importacoes_notas(arquivo, sha256) VALUES(?,?)', (arquivo[:200], sha)).lastrowid


def gravar_lote(c, arquivo, sha, notas, origem):
    """Grava várias notas validadas numa importação só (atômico pela transação de quem chama)."""
    imp = nova_importacao(c, arquivo, sha)
    res = {'importacao': imp, 'notas': 0, 'completadas': 0, 'itens': 0, 'ligadas': 0, 'puladas': [], 'ids': []}
    for nota in sorted(notas, key=lambda n: (n['data'], n['loja'])):
        situacao, nid = gravar_nota(c, nota, imp, origem)
        if situacao == 'pulada':
            res['puladas'].append(f'{nota["loja"]} {nota["data"].strftime("%d/%m/%Y")}')
            continue
        res['ids'].append(nid)
        res['itens'] += len(nota['itens'])
        res['notas' if situacao == 'nova' else 'completadas'] += 1
        if c.execute('SELECT transacao_id FROM notas_fiscais WHERE id=?', (nid,)).fetchone()[0]:
            res['ligadas'] += 1
    if not res['ids']:
        c.execute("UPDATE importacoes_notas SET desfeito_em=datetime('now') WHERE id=?", (imp,))
    return res


def importar_csv(c, nome_arquivo, dados):
    """Atômico: ou grava todas as notas válidas do arquivo, ou nada (com a lista de problemas)."""
    sha = hashlib.sha256(dados).hexdigest()
    if c.execute('SELECT 1 FROM importacoes_notas WHERE sha256=? AND desfeito_em IS NULL', (sha,)).fetchone():
        raise ErroValidacao('Este arquivo já foi importado.')
    notas, erros = interpretar(dados)
    if erros:
        mais = f' (e mais {len(erros) - 8})' if len(erros) > 8 else ''
        raise ErroValidacao('Nada foi gravado. ' + ' '.join(erros[:8]) + mais)
    return gravar_lote(c, nome_arquivo, sha, notas, 'csv')


def importar_paginas(c, arquivos):
    """Páginas de NFC-e salvas (uma nota por arquivo). Atômico: se uma página não for reconhecida, nada é gravado."""
    from fin404.dominio import nfce_pagina
    if not arquivos:
        raise ErroValidacao('Escolha ao menos uma página salva (.html).')
    notas, erros, vistos = [], [], set()
    for nome, dados in arquivos:
        sha = hashlib.sha256(dados).hexdigest()
        if sha in vistos:
            continue
        vistos.add(sha)
        try:
            notas.append(nfce_pagina.ler_pagina(dados))
        except ErroValidacao as exc:
            erros.append(f'{nome}: {exc}')
    if erros:
        raise ErroValidacao('Nada foi gravado. ' + ' '.join(erros[:5]) + (f' (e mais {len(erros) - 5})' if len(erros) > 5 else ''))
    sha_lote = hashlib.sha256(''.join(sorted(vistos)).encode()).hexdigest()
    nome = arquivos[0][0] if len(arquivos) == 1 else f'{len(arquivos)} páginas de nota'
    return gravar_lote(c, nome, sha_lote, notas, 'pagina')


def importar_lista(c, nome_arquivo, dados):
    """Lista de documentos da Nota Fiscal Paulista: notas sem itens, para conferir com os lançamentos."""
    from fin404.dominio import nfce_pagina
    docs = nfce_pagina.ler_lista(dados)
    return gravar_lote(c, nome_arquivo, hashlib.sha256(dados).hexdigest(), docs, 'lista_nfp')


def desfazer(c, importacao_id):
    """Tira o que a importação trouxe: as notas dela e os itens que ela acrescentou em notas de outra importação.
    Nota desta importação que foi completada por outra continua (passa a ser daquela)."""
    imp = c.execute('SELECT * FROM importacoes_notas WHERE id=?', (importacao_id,)).fetchone()
    if not imp or imp['desfeito_em']:
        raise ErroValidacao('Importação não encontrada ou já desfeita.')
    completadas = [r[0] for r in c.execute('''SELECT DISTINCT i.nota_id FROM itens_nota i JOIN notas_fiscais n ON n.id=i.nota_id
                                              WHERE i.importacao_id=? AND COALESCE(n.importacao_id, -1)<>?''',
                                           (importacao_id, importacao_id))]
    c.execute('''DELETE FROM itens_nota WHERE importacao_id=?
                 AND nota_id NOT IN (SELECT id FROM notas_fiscais WHERE importacao_id=?)''', (importacao_id, importacao_id))
    for nid in completadas:
        c.execute('UPDATE notas_fiscais SET desconto_centavos=0 WHERE id=? AND NOT EXISTS(SELECT 1 FROM itens_nota WHERE nota_id=?)',
                  (nid, nid))
    ids = []
    for (nid,) in c.execute('SELECT id FROM notas_fiscais WHERE importacao_id=?', (importacao_id,)).fetchall():
        outra = c.execute('''SELECT importacao_id FROM itens_nota WHERE nota_id=? AND importacao_id IS NOT NULL
                             AND importacao_id<>? LIMIT 1''', (nid, importacao_id)).fetchone()
        if outra:
            c.execute('UPDATE notas_fiscais SET importacao_id=? WHERE id=?', (outra[0], nid))
            c.execute('UPDATE itens_nota SET importacao_id=NULL WHERE nota_id=? AND importacao_id=?', (nid, outra[0]))
        else:
            ids.append(nid)
    if ids:
        marcas = ','.join('?' * len(ids))
        c.execute(f'UPDATE prazos SET nota_id=NULL WHERE nota_id IN ({marcas})', ids)
        c.execute(f'DELETE FROM notas_fiscais WHERE id IN ({marcas})', ids)
    if imp['sha256'].startswith('foto:'):      # a foto volta para "para digitar"
        c.execute('UPDATE fotos_nota SET nota_id=NULL WHERE sha256=?', (imp['sha256'][5:],))
    c.execute("UPDATE importacoes_notas SET desfeito_em=datetime('now') WHERE id=?", (importacao_id,))
    return len(ids) + len(completadas)


def excluir(c, nota_id):
    from fin404.dados.banco import auditar
    n = uma(c, nota_id)
    c.execute('UPDATE prazos SET nota_id=NULL WHERE nota_id=?', (nota_id,))
    c.execute('DELETE FROM notas_fiscais WHERE id=?', (nota_id,))
    auditar(c, 'excluir_nota', 'nota_fiscal', nota_id, f'{n["loja"]} {n["data"]} {n["total_centavos"]}')
    return n['loja']


def uma(c, nota_id):
    n = c.execute('SELECT * FROM notas_fiscais WHERE id=?', (nota_id,)).fetchone()
    if not n:
        raise ErroValidacao('Nota não encontrada.')
    return n


def itens(c, nota_id):
    return c.execute('''SELECT i.*, p.nome produto, p.marca FROM itens_nota i LEFT JOIN produtos p ON p.id=i.produto_id
                        WHERE i.nota_id=? ORDER BY i.ordem''', (nota_id,)).fetchall()


# ------------------------------------------------------------------ ligação com o lançamento

def candidatos(c, nota_id):
    """Lançamentos de despesa que podem ser esta nota: mesmo valor (ou compra parcelada de mesmo total), data ±3 dias,
    ainda sem nota. Ordenados pela distância da data."""
    n = uma(c, nota_id)
    d = ler_data(n['data'])
    ini, fim = (d - timedelta(days=TOLERANCIA_DIAS)).isoformat(), (d + timedelta(days=TOLERANCIA_DIAS)).isoformat()
    rows = c.execute('''
        SELECT t.id, t.data, t.descricao, t.plano_id, COALESCE(pp.data_compra, t.data) data_compra,
               COALESCE(pp.total_centavos, (SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                                             WHERE l.transacao_id=t.id AND k.tipo='despesa')) valor
        FROM transacoes t LEFT JOIN planos_parcelas pp ON pp.id=t.plano_id
        WHERE t.tipo='despesa' AND t.status<>'agendada' AND COALESCE(pp.data_compra, t.data) BETWEEN ? AND ?
          AND (t.plano_id IS NULL OR t.id=(SELECT MIN(t2.id) FROM transacoes t2 WHERE t2.plano_id=t.plano_id))
          AND NOT EXISTS(SELECT 1 FROM notas_fiscais nf WHERE nf.transacao_id=t.id AND nf.id<>?)''', (ini, fim, nota_id)).fetchall()
    out = [dict(r, dias=abs((ler_data(r['data_compra']) - d).days)) for r in rows if r['valor'] == n['total_centavos']]
    return sorted(out, key=lambda r: (r['dias'], r['id']))


def ligar_automatico(c, nota_id):
    """Liga só quando não há dúvida: um único candidato na menor distância de data."""
    cs = candidatos(c, nota_id)
    if not cs or (len(cs) > 1 and cs[0]['dias'] == cs[1]['dias']):
        return False
    c.execute('UPDATE notas_fiscais SET transacao_id=? WHERE id=?', (cs[0]['id'], nota_id))
    return True


def ligar(c, nota_id, transacao_id):
    uma(c, nota_id)
    if not any(x['id'] == int(transacao_id) for x in candidatos(c, nota_id)):
        raise ErroValidacao('Esse lançamento não tem o valor e a data desta nota (ou já tem outra nota).')
    c.execute('UPDATE notas_fiscais SET transacao_id=? WHERE id=?', (int(transacao_id), nota_id))


def desligar(c, nota_id):
    c.execute('UPDATE notas_fiscais SET transacao_id=NULL WHERE id=?', (nota_id,))


def lancar(c, nota_id, conta_id, categoria_id, parcelas=1):
    """Nota de uma compra que ainda não foi lançada: lança a despesa (pela rotina normal) e liga."""
    from fin404.dominio import operacoes
    n = uma(c, nota_id)
    if n['transacao_id']:
        raise ErroValidacao('Esta nota já está ligada a um lançamento.')
    ids = operacoes.despesa(c, ler_data(n['data']), n['loja'], n['total_centavos'], categoria_id, conta_id, int(parcelas or 1))
    c.execute('UPDATE notas_fiscais SET transacao_id=? WHERE id=?', (ids[0], nota_id))
    return ids


def de_transacao(c, tid):
    from fin404.dominio import prazos
    ref, _ = prazos.compra_de(c, tid)
    return c.execute('SELECT * FROM notas_fiscais WHERE transacao_id=?', (ref,)).fetchall()


def listar(c, limite=200, filtro=''):
    onde = {'sem_lancamento': 'WHERE n.transacao_id IS NULL',
            'sem_itens': 'WHERE NOT EXISTS(SELECT 1 FROM itens_nota i WHERE i.nota_id=n.id)'}.get(filtro, '')
    return c.execute(f'''SELECT n.*, (SELECT COUNT(*) FROM itens_nota i WHERE i.nota_id=n.id) n_itens
                         FROM notas_fiscais n {onde} ORDER BY n.data DESC, n.id DESC LIMIT ?''', (limite,)).fetchall()


def conferencia(c):
    """Para achar compras que ficaram fora do app: notas sem lançamento ligado (quantas e quanto), e notas sem itens."""
    r = c.execute('''SELECT COUNT(*) n, COALESCE(SUM(total_centavos), 0) total, MIN(data) desde FROM notas_fiscais
                     WHERE transacao_id IS NULL''').fetchone()
    sem_itens = c.execute('''SELECT COUNT(*) FROM notas_fiscais n
                             WHERE NOT EXISTS(SELECT 1 FROM itens_nota i WHERE i.nota_id=n.id)''').fetchone()[0]
    return {'sem_lancamento': r['n'], 'sem_lancamento_total': r['total'], 'desde': r['desde'], 'sem_itens': sem_itens}


def religar_todas(c):
    """Tenta de novo a ligação automática nas notas soltas (útil depois de lançar a fatura ou importar extrato)."""
    n = 0
    for (nid,) in c.execute('SELECT id FROM notas_fiscais WHERE transacao_id IS NULL').fetchall():
        if ligar_automatico(c, nid):
            n += 1
    return n


def modelo_csv():
    linhas = [';'.join(COLUNAS),
              '05/11/2026;MERCADO EXEMPLO LTDA;00000000000000;;LEITE INTEGRAL 1L;7890000000001;2;UN;5,49;10,98;0,00;29,46',
              '05/11/2026;MERCADO EXEMPLO LTDA;00000000000000;;BANANA PRATA KG;;0,850;KG;6,99;5,94;0,00;29,46',
              '05/11/2026;MERCADO EXEMPLO LTDA;00000000000000;;DETERGENTE 500ML;;3;UN;4,18;12,54;0,00;29,46']
    return ('﻿' + '\n'.join(linhas) + '\n').encode('utf-8')
