"""Compras e projetos: o que a família precisa ou quer comprar, organizado em projetos (casa, carro, viagem, trocas…).

Modelo:
- **Projeto** (planos_compra): agrupa itens com um objetivo, prazo e teto de orçamento opcionais. Pode nascer de um modelo
  pronto (lista de itens "a cotar" por ambiente/grupo).
- **Item** (compras_planejadas): pertence ou não a um projeto, tem grupo (cozinha, manutenção, hospedagem…), tipo (compra,
  troca, manutenção, serviço, reserva), prioridade, valor (pode faltar: "a cotar"), já guardado, revenda do usado,
  mês-alvo, forma (à vista ou N parcelas) e vida útil (gera a próxima troca quando comprado).
- **Cotação**: preços de lojas para um item; "usar esta" passa o valor (com frete) e as parcelas para o item.

Regras do plano financeiro (detalhes e exemplo em INDICADORES.md):
- Falta = valor − já guardado − revenda do usado.
- À vista: a falta é dividida pelos meses de hoje até o mês-alvo (contando o atual). Parcelado: N parcelas a partir dele.
- Sem mês-alvo ou sem preço: fica na lista, fora do calendário e do "cabe?".
- "Cabe?" segue a ordem de prioridade e compara o acumulado de cada mês com a sobra média do Raio-X.
- Itens de projetos concluídos ou arquivados saem do calendário.
- Comprar lança a despesa de verdade (operacoes.despesa); só aí o dinheiro aparece nos saldos e relatórios.
"""
from datetime import date

from fin404.dinheiro import ErroValidacao, data as ler_data, dividir, mes as ler_mes, somar_meses

PRIORIDADES = {'necessario': 'Necessário', 'importante': 'Importante', 'desejo': 'Desejo'}
SITUACOES = {'planejada': 'Planejada', 'comprada': 'Comprada', 'desistiu': 'Desistimos'}
TIPOS_ITEM = {'compra': 'Compra nova', 'troca': 'Troca (substituir)', 'manutencao': 'Manutenção ou conserto',
              'servico': 'Serviço', 'reserva': 'Reserva para imprevistos'}
TIPOS_PLANO = {'casa': 'Casa e móveis', 'carro': 'Carro e transporte', 'viagem': 'Viagem', 'reposicao': 'Trocas e reposições',
               'reforma': 'Reforma e manutenção da casa', 'filhos': 'Filhos e bebê', 'evento': 'Festa ou evento',
               'estudo': 'Estudos e trabalho', 'outro': 'Outro'}
SITUACOES_PLANO = {'ativo': 'Em andamento', 'concluido': 'Concluído', 'arquivado': 'Arquivado'}
HORIZONTE = 12

CATEGORIA_DO_TIPO = {'casa': 'Casa nova', 'carro': 'Transporte', 'viagem': 'Lazer e viagens', 'reposicao': 'Casa nova',
                     'reforma': 'Moradia', 'filhos': 'Filhos', 'evento': 'Outras despesas', 'estudo': 'Educação',
                     'outro': 'Outras despesas'}

# Modelos: (grupo, item, prioridade, tipo de item, vida útil em meses ou None, categoria se diferente da do projeto)
N, I, D = 'necessario', 'importante', 'desejo'
MODELOS = {
    'casa': [
        ('Cozinha', 'Geladeira', N, 'compra', 120, None), ('Cozinha', 'Fogão ou cooktop', N, 'compra', 120, None),
        ('Cozinha', 'Micro-ondas', I, 'compra', 96, None), ('Cozinha', 'Panelas', N, 'compra', 36, None),
        ('Cozinha', 'Louças, copos e talheres', N, 'compra', None, None), ('Cozinha', 'Purificador ou filtro de água', I, 'compra', None, None),
        ('Cozinha', 'Liquidificador e utensílios', I, 'compra', None, None), ('Cozinha', 'Armários e organização', I, 'compra', None, None),
        ('Lavanderia', 'Máquina de lavar', N, 'compra', 120, None), ('Lavanderia', 'Varal, cestos e tábua de passar', I, 'compra', None, None),
        ('Lavanderia', 'Ferro de passar', D, 'compra', None, None),
        ('Sala', 'Sofá', I, 'compra', 96, None), ('Sala', 'Rack ou painel', D, 'compra', None, None),
        ('Sala', 'TV', D, 'compra', 96, None), ('Sala', 'Cortinas', I, 'compra', None, None), ('Sala', 'Tapete', D, 'compra', None, None),
        ('Quarto', 'Cama', N, 'compra', None, None), ('Quarto', 'Colchão', N, 'compra', 96, None),
        ('Quarto', 'Guarda-roupa', N, 'compra', None, None), ('Quarto', 'Roupa de cama e travesseiros', N, 'compra', 24, None),
        ('Banheiro', 'Box, gabinete e espelho', I, 'compra', None, None), ('Banheiro', 'Toalhas e tapetes', N, 'compra', 24, None),
        ('Geral', 'Lâmpadas e luminárias', N, 'compra', None, None), ('Geral', 'Ventilador ou ar-condicionado', I, 'compra', 120, None),
        ('Geral', 'Ferramentas básicas', I, 'compra', None, None), ('Geral', 'Produtos e utensílios de limpeza', N, 'compra', None, None),
        ('Mudança e serviços', 'Frete ou mudança', N, 'servico', None, None),
        ('Mudança e serviços', 'Instalação de eletros, chuveiro e suportes', N, 'servico', None, None),
        ('Mudança e serviços', 'Pintura', D, 'servico', None, None),
        ('Mudança e serviços', 'Reserva para imprevistos', I, 'reserva', None, None),
    ],
    'carro': [
        ('Manutenção', 'Revisão', N, 'manutencao', 12, None), ('Manutenção', 'Troca de óleo e filtros', N, 'manutencao', 6, None),
        ('Manutenção', 'Pneus', N, 'troca', 48, None), ('Manutenção', 'Alinhamento e balanceamento', I, 'manutencao', 12, None),
        ('Manutenção', 'Pastilhas e discos de freio', N, 'troca', 24, None), ('Manutenção', 'Bateria', N, 'troca', 36, None),
        ('Documentação e seguro', 'IPVA', N, 'servico', 12, 'Impostos e taxas'),
        ('Documentação e seguro', 'Licenciamento', N, 'servico', 12, 'Impostos e taxas'),
        ('Documentação e seguro', 'Seguro do carro', I, 'servico', 12, 'Seguros'),
        ('Acessórios', 'Tapetes, capas e organização', D, 'compra', None, None),
        ('Reserva', 'Reserva para imprevistos (franquia, conserto)', I, 'reserva', None, None),
    ],
    'viagem': [
        ('Transporte', 'Passagens', N, 'compra', None, None), ('Transporte', 'Combustível e pedágios', I, 'compra', None, None),
        ('Transporte', 'Transporte no destino (aluguel de carro, app)', I, 'servico', None, None),
        ('Hospedagem', 'Hospedagem', N, 'servico', None, None),
        ('Alimentação', 'Alimentação', N, 'compra', None, None),
        ('Passeios', 'Passeios e ingressos', I, 'compra', None, None),
        ('Documentos e seguro', 'Seguro viagem', I, 'servico', None, 'Seguros'),
        ('Documentos e seguro', 'Documentos (passaporte, visto)', I, 'servico', None, 'Impostos e taxas'),
        ('Compras', 'Lembranças e compras', D, 'compra', None, None),
        ('Reserva', 'Reserva para imprevistos', I, 'reserva', None, None),
    ],
    'reposicao': [
        ('Casa', 'Colchão', I, 'troca', 96, None), ('Casa', 'Travesseiros', I, 'troca', 24, None),
        ('Casa', 'Refil do filtro de água', N, 'troca', 6, None), ('Casa', 'Toalhas e roupa de cama', I, 'troca', 24, None),
        ('Casa', 'Panelas antiaderentes', D, 'troca', 36, None),
        ('Eletrônicos', 'Celular', I, 'troca', 36, None), ('Eletrônicos', 'Notebook ou computador', I, 'troca', 60, None),
        ('Roupas', 'Tênis e calçados', I, 'troca', 12, 'Vestuário'), ('Roupas', 'Roupas de trabalho', I, 'troca', 12, 'Vestuário'),
        ('Saúde', 'Óculos ou lentes', N, 'troca', 24, 'Saúde'),
    ],
    'reforma': [
        ('Diagnóstico', 'Orçamento com profissional', N, 'servico', None, None),
        ('Materiais', 'Materiais', N, 'compra', None, None), ('Mão de obra', 'Mão de obra', N, 'servico', None, None),
        ('Acabamento', 'Pintura e acabamento', I, 'servico', None, None),
        ('Manutenção periódica', 'Limpeza de caixa d\'água', N, 'manutencao', 6, None),
        ('Manutenção periódica', 'Manutenção do ar-condicionado', I, 'manutencao', 12, None),
        ('Manutenção periódica', 'Dedetização', I, 'servico', 12, None),
        ('Reserva', 'Reserva para imprevistos', I, 'reserva', None, None),
    ],
    'filhos': [
        ('Enxoval', 'Berço e colchão', N, 'compra', None, None), ('Enxoval', 'Roupinhas', N, 'compra', None, None),
        ('Enxoval', 'Carrinho e bebê-conforto', N, 'compra', None, None), ('Saúde', 'Consultas e exames', N, 'servico', None, 'Saúde'),
        ('Escola', 'Material escolar', N, 'compra', 12, 'Educação'), ('Escola', 'Uniforme', N, 'compra', 12, 'Educação'),
        ('Escola', 'Matrícula', N, 'servico', 12, 'Educação'),
    ],
    'evento': [
        ('Local e comida', 'Local', N, 'servico', None, None), ('Local e comida', 'Comida e bebida', N, 'compra', None, None),
        ('Local e comida', 'Bolo e doces', I, 'compra', None, None), ('Decoração', 'Decoração', I, 'compra', None, None),
        ('Convidados', 'Convites e lembrancinhas', D, 'compra', None, None),
        ('Reserva', 'Reserva para imprevistos', I, 'reserva', None, None),
    ],
    'estudo': [
        ('Cursos', 'Curso ou certificação', I, 'servico', None, None), ('Cursos', 'Taxa de prova', I, 'servico', None, None),
        ('Material', 'Livros e material', I, 'compra', None, None),
        ('Equipamento', 'Computador, cadeira e mesa', I, 'compra', 60, None),
    ],
    'outro': [],
}
GRUPOS_SUGERIDOS = {t: sorted({g for g, *_ in itens}) for t, itens in MODELOS.items()}


def _ym(d):
    return d.strftime('%Y-%m')


def _meses_ate(ym, hoje):
    """Meses de hoje até o mês-alvo, contando o atual (alvo no mês atual = 1; alvo passado = 0 ou menos)."""
    return (int(ym[:4]) - hoje.year) * 12 + (int(ym[5:7]) - hoje.month) + 1


def link_seguro(link):
    """Só guarda links http(s): a página usa o link num href, e 'javascript:' ali seria uma porta de ataque."""
    link = (link or '').strip()[:500]
    return link if link.lower().startswith(('https://', 'http://')) else ''


def _categoria_por_nome(c, nome):
    if not nome:
        return None
    r = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND subtipo='categoria' AND nome=? AND ativa=1", (nome,)).fetchone()
    return r[0] if r else None


# ---------------------------------------------------------------- projetos

def _validar_plano(nome, tipo, orcamento, mes_alvo):
    nome = (nome or '').strip()
    if not nome:
        raise ErroValidacao('Dê um nome ao projeto.')
    if tipo not in TIPOS_PLANO:
        raise ErroValidacao('Escolha o tipo do projeto.')
    if orcamento is not None and orcamento <= 0:
        raise ErroValidacao('O teto do orçamento precisa ser maior que zero (ou deixe em branco).')
    return nome[:80], (ler_mes(mes_alvo) if mes_alvo else None)


def criar_plano(c, nome, tipo='outro', orcamento=None, mes_alvo=None, observacao='', usar_modelo=False):
    nome, mes_alvo = _validar_plano(nome, tipo, orcamento, mes_alvo)
    pid = c.execute('INSERT INTO planos_compra(nome, tipo, orcamento_centavos, mes_alvo, observacao) VALUES(?,?,?,?,?)',
                    (nome, tipo, orcamento, mes_alvo, (observacao or '').strip()[:300])).lastrowid
    if usar_modelo:
        aplicar_modelo(c, pid)
    return pid


def remover_sugestoes(c, plano_id):
    """Tira do projeto os itens da lista pronta que ninguém mexeu (sem preço, nada guardado, ainda planejados)."""
    from fin404.dados.banco import auditar
    p = um_plano(c, plano_id)
    do_modelo = {(g.lower(), d.lower()) for g, d, *_ in MODELOS.get(p['tipo'], [])}
    ids = [r['id'] for r in c.execute('''SELECT id, grupo, descricao FROM compras_planejadas WHERE plano_id=? AND situacao='planejada'
                                         AND valor_centavos IS NULL AND guardado_centavos=0 AND revenda_centavos=0
                                         AND observacao='' ''', (plano_id,)).fetchall()
           if (r['grupo'].lower(), r['descricao'].lower()) in do_modelo]
    if ids:
        c.execute(f'DELETE FROM compras_planejadas WHERE id IN ({",".join("?" * len(ids))})', ids)
        auditar(c, 'remover_sugestoes', 'plano_compra', plano_id, f'{len(ids)} item(ns) da lista pronta sem uso')
    return len(ids)


def aplicar_modelo(c, plano_id):
    """Cria os itens do modelo do tipo do projeto, sem preço ("a cotar"). Não repete item que já existe no projeto."""
    p = um_plano(c, plano_id)
    existentes = {(r['grupo'].lower(), r['descricao'].lower())
                  for r in c.execute('SELECT grupo, descricao FROM compras_planejadas WHERE plano_id=?', (plano_id,))}
    padrao = _categoria_por_nome(c, CATEGORIA_DO_TIPO.get(p['tipo']))
    n = 0
    for grupo, desc, prio, tipo_item, vida, cat in MODELOS.get(p['tipo'], []):
        if (grupo.lower(), desc.lower()) in existentes:
            continue
        criar(c, desc, None, _categoria_por_nome(c, cat) if cat else padrao, prio, p['mes_alvo'], plano_id=plano_id,
              grupo=grupo, tipo_item=tipo_item, vida_util_meses=vida)
        n += 1
    return n


def atualizar_plano(c, plano_id, nome, tipo, orcamento=None, mes_alvo=None, observacao=''):
    um_plano(c, plano_id)
    nome, mes_alvo = _validar_plano(nome, tipo, orcamento, mes_alvo)
    c.execute('UPDATE planos_compra SET nome=?, tipo=?, orcamento_centavos=?, mes_alvo=?, observacao=? WHERE id=?',
              (nome, tipo, orcamento, mes_alvo, (observacao or '').strip()[:300], plano_id))


def mudar_situacao_plano(c, plano_id, situacao):
    um_plano(c, plano_id)
    if situacao not in SITUACOES_PLANO:
        raise ErroValidacao('Situação inválida.')
    c.execute('UPDATE planos_compra SET situacao=? WHERE id=?', (situacao, plano_id))


def um_plano(c, plano_id):
    p = c.execute('SELECT * FROM planos_compra WHERE id=?', (plano_id,)).fetchone()
    if not p:
        raise ErroValidacao('Projeto não encontrado.')
    return p


def excluir_plano(c, plano_id):
    """Apaga o projeto e os itens ainda planejados. Comprados e desistências ficam no histórico, sem projeto."""
    from fin404.dados.banco import auditar
    p = um_plano(c, plano_id)
    n = c.execute("DELETE FROM compras_planejadas WHERE plano_id=? AND situacao='planejada'", (plano_id,)).rowcount
    c.execute('DELETE FROM planos_compra WHERE id=?', (plano_id,))
    auditar(c, 'excluir_projeto_compra', 'plano_compra', plano_id, f'{p["nome"]}; {n} item(ns) planejado(s) apagado(s)')
    return p['nome'], n


def planos(c, incluir_inativos=True):
    filtro = '' if incluir_inativos else "WHERE situacao='ativo'"
    rows = c.execute(f"SELECT * FROM planos_compra {filtro} ORDER BY situacao<>'ativo', mes_alvo IS NULL, mes_alvo, nome").fetchall()
    return [resumo_plano(c, r) for r in rows]


def resumo_plano(c, p):
    itens = c.execute('SELECT * FROM compras_planejadas WHERE plano_id=?', (p['id'],)).fetchall()
    abertos = [i for i in itens if i['situacao'] == 'planejada']
    comprados = [i for i in itens if i['situacao'] == 'comprada']
    com_preco = [i for i in abertos if i['valor_centavos']]
    planejado = sum(i['valor_centavos'] for i in com_preco)
    falta = sum(max(i['valor_centavos'] - i['guardado_centavos'] - i['revenda_centavos'], 0) for i in com_preco)
    gasto = sum(i['valor_pago_centavos'] or 0 for i in comprados)
    orc = p['orcamento_centavos']
    feitos = len(comprados)
    total = len(abertos) + feitos
    return {**dict(p), 'n_abertos': len(abertos), 'n_comprados': feitos, 'n_sem_preco': len(abertos) - len(com_preco),
            'planejado': planejado, 'falta': falta, 'gasto': gasto, 'previsto': gasto + planejado,
            'livre': (orc - gasto - planejado) if orc else None, 'pct': (feitos * 100 // total) if total else 0}


# ---------------------------------------------------------------- itens

def _validar(c, descricao, valor, guardado, categoria_id, prioridade, mes_alvo, parcelas, plano_id=None, tipo_item='compra',
             quantidade=1, revenda=0, vida_util_meses=None):
    descricao = (descricao or '').strip()
    if not descricao:
        raise ErroValidacao('Diga o que vai comprar.')
    if valor is not None and valor <= 0:
        raise ErroValidacao('O valor estimado precisa ser maior que zero (ou deixe em branco para cotar depois).')
    guardado, revenda = guardado or 0, revenda or 0
    if guardado < 0 or revenda < 0:
        raise ErroValidacao('Valores guardados ou de revenda não podem ser negativos.')
    if prioridade not in PRIORIDADES:
        raise ErroValidacao('Escolha a prioridade.')
    if tipo_item not in TIPOS_ITEM:
        raise ErroValidacao('Escolha o tipo do item.')
    parcelas = int(parcelas or 1)
    if not 1 <= parcelas <= 72:
        raise ErroValidacao('Número de parcelas deve ficar entre 1 e 72.')
    quantidade = int(quantidade or 1)
    if not 1 <= quantidade <= 9999:
        raise ErroValidacao('Quantidade inválida.')
    if vida_util_meses is not None and not 1 <= int(vida_util_meses) <= 600:
        raise ErroValidacao('Vida útil deve ficar entre 1 e 600 meses.')
    if valor is not None:
        guardado = min(guardado, valor)
        revenda = min(revenda, valor - guardado)
        if parcelas > 1 and valor - guardado - revenda < parcelas:
            raise ErroValidacao('O valor a parcelar é menor que o número de parcelas.')
    if categoria_id:
        k = c.execute('SELECT tipo FROM contas WHERE id=?', (categoria_id,)).fetchone()
        if not k or k['tipo'] != 'despesa':
            raise ErroValidacao('Escolha uma categoria de despesa.')
    if plano_id:
        um_plano(c, plano_id)
    return dict(descricao=descricao[:120], valor_centavos=valor, guardado_centavos=guardado, revenda_centavos=revenda,
                categoria_id=categoria_id or None, prioridade=prioridade, mes_alvo=ler_mes(mes_alvo) if mes_alvo else None,
                parcelas=parcelas, plano_id=plano_id or None, tipo_item=tipo_item, quantidade=quantidade,
                vida_util_meses=int(vida_util_meses) if vida_util_meses else None)


def criar(c, descricao, valor, categoria_id=None, prioridade='importante', mes_alvo=None, parcelas=1, guardado=0,
          observacao='', plano_id=None, grupo='', tipo_item='compra', quantidade=1, revenda=0, vida_util_meses=None,
          origem_id=None, garantia_meses=None):
    d = _validar(c, descricao, valor, guardado, categoria_id, prioridade, mes_alvo, parcelas, plano_id, tipo_item, quantidade,
                 revenda, vida_util_meses)
    d.update(observacao=(observacao or '').strip()[:300], grupo=(grupo or '').strip()[:40], origem_id=origem_id,
             garantia_meses=_garantia(garantia_meses))
    cols = ', '.join(d)
    return c.execute(f'INSERT INTO compras_planejadas({cols}) VALUES({", ".join("?" * len(d))})', tuple(d.values())).lastrowid


def atualizar(c, compra_id, descricao, valor, categoria_id, prioridade, mes_alvo, parcelas, guardado, observacao='',
              plano_id=None, grupo='', tipo_item='compra', quantidade=1, revenda=0, vida_util_meses=None, garantia_meses=None):
    if uma(c, compra_id)['situacao'] != 'planejada':
        raise ErroValidacao('Só dá para editar uma compra que ainda está planejada.')
    d = _validar(c, descricao, valor, guardado, categoria_id, prioridade, mes_alvo, parcelas, plano_id, tipo_item, quantidade,
                 revenda, vida_util_meses)
    d.update(observacao=(observacao or '').strip()[:300], grupo=(grupo or '').strip()[:40], garantia_meses=_garantia(garantia_meses))
    c.execute(f'UPDATE compras_planejadas SET {", ".join(k + "=?" for k in d)} WHERE id=?', (*d.values(), compra_id))


def _garantia(meses):
    if meses in (None, '', 0):
        return None
    meses = int(meses)
    if not 1 <= meses <= 240:
        raise ErroValidacao('Garantia entre 1 e 240 meses.')
    return meses


def _registrar_garantia(c, item, quando, transacao_id=None):
    if not item['garantia_meses']:
        return None
    from fin404.dominio import prazos
    return prazos.garantia(c, item['descricao'], quando, item['garantia_meses'], compra_id=item['id'], transacao_id=transacao_id)


def uma(c, compra_id):
    r = c.execute('''SELECT p.*, k.nome categoria, pl.nome plano, pl.tipo plano_tipo FROM compras_planejadas p
                     LEFT JOIN contas k ON k.id=p.categoria_id LEFT JOIN planos_compra pl ON pl.id=p.plano_id
                     WHERE p.id=?''', (compra_id,)).fetchone()
    if not r:
        raise ErroValidacao('Compra planejada não encontrada.')
    return r


def comprar(c, compra_id, quando, conta_id, valor=None, parcelas=None, categoria_id=None):
    """Lança a despesa (à vista, no cartão ou parcelada) e marca o item como comprado, ligado ao lançamento.
    Se o item tem vida útil, já planeja a próxima troca (mesmo projeto, grupo e prioridade; preço a confirmar)."""
    from fin404.dominio import operacoes
    item = uma(c, compra_id)
    if item['situacao'] != 'planejada':
        raise ErroValidacao('Esta compra já foi concluída.')
    categoria_id = categoria_id or item['categoria_id']
    if not categoria_id:
        raise ErroValidacao('Escolha a categoria da compra.')
    valor = valor or item['valor_centavos']
    if not valor:
        raise ErroValidacao('Informe o valor pago.')
    quando = ler_data(quando)
    ids = operacoes.despesa(c, quando, item['descricao'], valor, categoria_id, conta_id,
                            parcelas=int(parcelas or item['parcelas'] or 1))
    c.execute('''UPDATE compras_planejadas SET situacao='comprada', transacao_id=?, valor_pago_centavos=?, categoria_id=?,
                 concluida_em=? WHERE id=?''', (ids[0], valor, categoria_id, quando.isoformat(), compra_id))
    proxima = _planejar_reposicao(c, item, quando, valor, categoria_id)
    _registrar_garantia(c, item, quando, ids[0])
    return ids, proxima


def _planejar_reposicao(c, item, quando, valor, categoria_id):
    if not item['vida_util_meses']:
        return None
    return criar(c, item['descricao'], valor, categoria_id, item['prioridade'],
                 _ym(somar_meses(date(quando.year, quando.month, 1), item['vida_util_meses'])),
                 item['parcelas'], 0, f'Próxima troca (vida útil de {item["vida_util_meses"]} meses).',
                 item['plano_id'], item['grupo'], 'troca' if item['tipo_item'] == 'compra' else item['tipo_item'],
                 item['quantidade'], 0, item['vida_util_meses'], origem_id=item['id'])


def marcar_comprada(c, compra_id, valor=None, hoje=None):
    """Para quando o lançamento já existe (veio na fatura ou no extrato): só tira o item do plano."""
    item = uma(c, compra_id)
    if item['situacao'] != 'planejada':
        raise ErroValidacao('Esta compra já foi concluída.')
    hoje = ler_data(hoje or date.today())
    valor = valor or item['valor_centavos']
    c.execute('''UPDATE compras_planejadas SET situacao='comprada', valor_pago_centavos=?, concluida_em=? WHERE id=?''',
              (valor, hoje.isoformat(), compra_id))
    _registrar_garantia(c, item, hoje)
    return _planejar_reposicao(c, item, hoje, valor, item['categoria_id'])


def desistir(c, compra_id, hoje=None):
    if uma(c, compra_id)['situacao'] != 'planejada':
        raise ErroValidacao('Esta compra já foi concluída.')
    c.execute("UPDATE compras_planejadas SET situacao='desistiu', concluida_em=? WHERE id=?",
              (ler_data(hoje or date.today()).isoformat(), compra_id))


def reabrir(c, compra_id):
    item = uma(c, compra_id)
    if item['situacao'] == 'planejada':
        raise ErroValidacao('Esta compra já está planejada.')
    if item['transacao_id']:
        raise ErroValidacao('Esta compra tem lançamento. Para voltar ao plano, exclua o lançamento primeiro.')
    c.execute('''UPDATE compras_planejadas SET situacao='planejada', concluida_em=NULL, valor_pago_centavos=NULL
                 WHERE id=?''', (compra_id,))


def excluir(c, compra_id):
    from fin404.dados.banco import auditar
    item = uma(c, compra_id)
    c.execute('DELETE FROM compras_planejadas WHERE id=?', (compra_id,))
    auditar(c, 'excluir_compra_planejada', 'compra_planejada', compra_id, item['descricao'])
    return item['descricao']


# ---------------------------------------------------------------- cotações

def adicionar_cotacao(c, compra_id, loja, valor, parcelas=1, frete=0, link='', observacao='', quando=None):
    if uma(c, compra_id)['situacao'] != 'planejada':
        raise ErroValidacao('Esta compra já foi concluída.')
    loja = (loja or '').strip()
    if not loja:
        raise ErroValidacao('Diga a loja ou o vendedor.')
    if not valor or valor <= 0:
        raise ErroValidacao('O preço precisa ser maior que zero.')
    parcelas = int(parcelas or 1)
    if not 1 <= parcelas <= 72:
        raise ErroValidacao('Número de parcelas deve ficar entre 1 e 72.')
    if (frete or 0) < 0:
        raise ErroValidacao('Frete não pode ser negativo.')
    return c.execute('''INSERT INTO cotacoes(compra_id, loja, valor_centavos, parcelas, frete_centavos, link, data, observacao)
                        VALUES(?,?,?,?,?,?,?,?)''',
                     (compra_id, loja[:80], valor, parcelas, frete or 0, link_seguro(link),
                      ler_data(quando or date.today()).isoformat(), (observacao or '').strip()[:200])).lastrowid


def cotacoes(c, compra_id):
    rows = c.execute('SELECT * FROM cotacoes WHERE compra_id=? ORDER BY valor_centavos+frete_centavos, id', (compra_id,)).fetchall()
    return [{**dict(r), 'total': r['valor_centavos'] + r['frete_centavos']} for r in rows]


def usar_cotacao(c, cotacao_id):
    r = c.execute('SELECT * FROM cotacoes WHERE id=?', (cotacao_id,)).fetchone()
    if not r:
        raise ErroValidacao('Cotação não encontrada.')
    item = uma(c, r['compra_id'])
    if item['situacao'] != 'planejada':
        raise ErroValidacao('Esta compra já foi concluída.')
    total = r['valor_centavos'] + r['frete_centavos']
    falta = total - min(item['guardado_centavos'], total) - min(item['revenda_centavos'], total)
    parcelas = r['parcelas'] if falta >= r['parcelas'] else 1
    c.execute('UPDATE compras_planejadas SET valor_centavos=?, parcelas=? WHERE id=?', (total, parcelas, r['compra_id']))
    return r['compra_id']


def excluir_cotacao(c, cotacao_id):
    r = c.execute('SELECT compra_id FROM cotacoes WHERE id=?', (cotacao_id,)).fetchone()
    if not r:
        raise ErroValidacao('Cotação não encontrada.')
    c.execute('DELETE FROM cotacoes WHERE id=?', (cotacao_id,))
    return r['compra_id']


# ---------------------------------------------------------------- o plano financeiro

def _falta(item):
    if not item['valor_centavos']:
        return None
    return max(item['valor_centavos'] - item['guardado_centavos'] - item['revenda_centavos'], 0)


def _impacto(item, hoje):
    """Quanto o item pesa em cada mês (dict ym → centavos), o esforço mensal máximo e a situação no plano."""
    falta = _falta(item)
    if falta is None:
        return {}, None, 'a cotar', None
    if not item['mes_alvo']:
        return {}, None, 'sem data', falta
    meses = _meses_ate(item['mes_alvo'], hoje)
    atual = date(hoje.year, hoje.month, 1)
    if item['parcelas'] > 1 and falta >= item['parcelas']:
        inicio = max(meses, 1) - 1           # parcelado com mês já passado começa agora
        partes = dividir(falta, item['parcelas'])
        mapa = {_ym(somar_meses(atual, inicio + k)): v for k, v in enumerate(partes)}
        return mapa, partes[0], ('atrasada' if meses <= 0 else 'parcelado'), falta
    if falta == 0:
        return {}, 0, 'dinheiro separado', 0
    if meses <= 0:
        return {_ym(atual): falta}, falta, 'atrasada', falta
    partes = dividir(falta, meses)            # o resto vai para os primeiros meses: arredonda para cima
    return {_ym(somar_meses(atual, k)): v for k, v in enumerate(partes)}, partes[0], 'guardando', falta


def _ordem(item):
    return (list(PRIORIDADES).index(item['prioridade']) if item['prioridade'] in PRIORIDADES else 9,
            item['mes_alvo'] is None, item['mes_alvo'] or '', item['id'])


def sobra_media(c, hoje):
    """Renda média − gasto médio (com despesas anuais), pelos meses completos recentes. None sem dados de renda."""
    from fin404.dominio import analises
    r = analises.raio_x(c, hoje)
    if not r['meses_com_dados'] or r['renda'] <= 0:
        return None
    return r['sobra']


_SQL_ITENS = '''SELECT p.*, k.nome categoria, pl.nome plano, pl.tipo plano_tipo, pl.situacao plano_situacao
                FROM compras_planejadas p LEFT JOIN contas k ON k.id=p.categoria_id LEFT JOIN planos_compra pl ON pl.id=p.plano_id'''


def plano(c, hoje=None, sobra=...):
    """O plano financeiro de todas as compras abertas de projetos em andamento (ou sem projeto)."""
    hoje = ler_data(hoje or date.today())
    if sobra is ...:
        sobra = sobra_media(c, hoje)
    abertos = c.execute(_SQL_ITENS + " WHERE p.situacao='planejada' AND (pl.id IS NULL OR pl.situacao='ativo')").fetchall()
    abertos = sorted((dict(r) for r in abertos), key=_ordem)
    atual = date(hoje.year, hoje.month, 1)
    yms = [_ym(somar_meses(atual, k)) for k in range(HORIZONTE)]
    guardar = {ym: 0 for ym in yms}
    parcelas = {ym: 0 for ym in yms}
    acumulado = {ym: 0 for ym in yms}
    itens = []
    for it in abertos:
        mapa, por_mes, estado, falta = _impacto(it, hoje)
        no_horizonte = {ym: v for ym, v in mapa.items() if ym in acumulado}
        for ym, v in no_horizonte.items():
            parcelado = it['parcelas'] > 1 and falta and falta >= it['parcelas']
            (parcelas if parcelado else guardar)[ym] += v
            acumulado[ym] += v
        if por_mes is None or sobra is None:
            cabe = None
        elif not no_horizonte:
            cabe = True
        else:
            cabe = all(acumulado[ym] <= sobra for ym in no_horizonte)
        itens.append({**it, 'falta': falta, 'por_mes': por_mes, 'estado': estado, 'cabe': cabe,
                      'meses': _meses_ate(it['mes_alvo'], hoje) if it['mes_alvo'] else None})
    calendario = [{'ym': ym, 'guardar': guardar[ym], 'parcelas': parcelas[ym], 'total': acumulado[ym],
                   'folga': None if sobra is None else sobra - acumulado[ym]} for ym in yms]
    por_prioridade = {p: {'n': 0, 'falta': 0} for p in PRIORIDADES}
    categorias = {}
    for it in itens:
        f = it['falta'] or 0
        if it['prioridade'] in por_prioridade:
            por_prioridade[it['prioridade']]['n'] += 1
            por_prioridade[it['prioridade']]['falta'] += f
        k = categorias.setdefault(it['categoria'] or 'Sem categoria', {'n': 0, 'falta': 0})
        k['n'] += 1
        k['falta'] += f
    proximo = _ym(somar_meses(atual, 3))
    return {'itens': itens, 'calendario': calendario, 'sobra': sobra, 'este_mes': acumulado[yms[0]],
            'total_falta': sum(it['falta'] or 0 for it in itens),
            'total_guardado': sum(it['guardado_centavos'] for it in itens),
            'por_prioridade': por_prioridade,
            'por_categoria': sorted(categorias.items(), key=lambda kv: -kv[1]['falta']),
            'nao_cabem': sum(1 for it in itens if it['cabe'] is False),
            'sem_preco': [it for it in itens if it['estado'] == 'a cotar'],
            'atrasadas': [it for it in itens if it['estado'] == 'atrasada'],
            'proximas_trocas': [it for it in itens if it['tipo_item'] in ('troca', 'manutencao') and it['mes_alvo']
                                and it['mes_alvo'] <= proximo],
            'historico': historico(c)}


def historico(c, limite=50):
    return [dict(r) for r in c.execute(_SQL_ITENS + " WHERE p.situacao<>'planejada' ORDER BY p.concluida_em DESC, p.id DESC LIMIT ?",
                                       (limite,))]


def detalhe_plano(c, plano_id, hoje=None, sobra=...):
    """Projeto com itens agrupados (grupo → itens, com os cálculos do plano financeiro)."""
    hoje = ler_data(hoje or date.today())
    p = resumo_plano(c, um_plano(c, plano_id))
    calc = {it['id']: it for it in plano(c, hoje, sobra)['itens']}
    grupos = {}
    for r in c.execute(_SQL_ITENS + ' WHERE p.plano_id=? ORDER BY p.grupo, p.situacao<>\'planejada\', p.id', (plano_id,)):
        it = dict(r)
        if it['situacao'] == 'planejada' and it['id'] not in calc:      # projeto pausado: mostra sem o "cabe?"
            mapa, por_mes, estado, falta = _impacto(it, hoje)
            it.update(falta=falta, por_mes=por_mes, estado=estado, cabe=None)
        elif it['id'] in calc:
            it = calc[it['id']]
        g = grupos.setdefault(it['grupo'] or 'Geral', {'itens': [], 'falta': 0, 'gasto': 0, 'n': 0, 'feitos': 0})
        g['itens'].append(it)
        g['n'] += 1
        if it['situacao'] == 'planejada':
            g['falta'] += it.get('falta') or 0
        elif it['situacao'] == 'comprada':
            g['feitos'] += 1
            g['gasto'] += it['valor_pago_centavos'] or 0
    return {'plano': p, 'grupos': grupos}


def filtrar(itens, plano_id=None, prioridade='', tipo_item='', estado=''):
    """Filtros da lista de compras (sobre os itens já calculados por `plano`)."""
    out = []
    for it in itens:
        if plano_id == 0 and it['plano_id'] is not None:
            continue
        if plano_id and it['plano_id'] != plano_id:
            continue
        if prioridade and it['prioridade'] != prioridade:
            continue
        if tipo_item and it['tipo_item'] != tipo_item:
            continue
        if estado == 'nao_cabe' and it['cabe'] is not False:
            continue
        if estado and estado != 'nao_cabe' and it['estado'] != estado:
            continue
        out.append(it)
    return out
