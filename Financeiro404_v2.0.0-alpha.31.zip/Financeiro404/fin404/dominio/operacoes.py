"""Operações do dia a dia, traduzidas para o livro-razão."""
from datetime import date, timedelta

from fin404.dinheiro import ErroValidacao, data as ler_data, dia_no_mes, formatar, mes as ler_mes, mes_seguinte, somar_meses
from fin404.dominio import cartoes, razao


def _categoria(c, cid, tipo):
    k = razao.conta(c, cid)
    if k['tipo'] != tipo or k['subtipo'] != 'categoria':
        raise ErroValidacao('Escolha uma categoria de ' + ('despesa.' if tipo == 'despesa' else 'receita.'))
    return k


def despesa(c, quando, descricao, valor, categoria_id, conta_id, parcelas=1, pessoa_id=None,
            status='confirmada', observacao=''):
    _categoria(c, categoria_id, 'despesa')
    k = razao.conta(c, conta_id)
    if k['subtipo'] == 'cartao':
        return cartoes.compra(c, conta_id, quando, descricao, valor, categoria_id, parcelas, pessoa_id, observacao)
    if k['tipo'] not in ('ativo', 'passivo'):
        raise ErroValidacao('Escolha a conta ou o cartão de onde saiu o dinheiro.')
    if int(parcelas) != 1:
        return _parcelado_fora_do_cartao(c, quando, descricao, valor, categoria_id, conta_id, int(parcelas), pessoa_id,
                                         status, observacao)
    return [razao.registrar(c, quando, descricao, 'despesa', [(categoria_id, valor, pessoa_id), (conta_id, -valor)],
                            status=status, observacao=observacao)]


def _parcelado_fora_do_cartao(c, quando, descricao, total, categoria_id, conta_id, parcelas, pessoa_id, status, observacao):
    """Carnê, boleto parcelado, Pix parcelado, crediário: uma parcela por mês, no mesmo dia, a partir da data informada.

    A primeira segue a situação escolhida; as seguintes ficam como previstas (o dinheiro ainda não saiu) e aparecem
    em "A pagar e receber" no mês de cada uma. O conjunto aparece em Parcelamentos, como as compras no cartão.
    """
    from fin404.dinheiro import dividir
    if not 2 <= parcelas <= 72:
        raise ErroValidacao('Número de parcelas deve ficar entre 1 e 72.')
    if total < parcelas:
        raise ErroValidacao('O total é menor que o número de parcelas.')
    quando = ler_data(quando)
    plano = c.execute('''INSERT INTO planos_parcelas(descricao,total_centavos,n_parcelas,conta_cartao_id,data_compra)
                         VALUES(?,?,?,?,?)''', (descricao.strip(), total, parcelas, conta_id, quando.isoformat())).lastrowid
    ids = []
    for n, valor in enumerate(dividir(total, parcelas), start=1):
        mes = somar_meses(date(quando.year, quando.month, 1), n - 1)
        data_n = dia_no_mes(mes.year, mes.month, quando.day)
        ids.append(razao.registrar(c, data_n, f'{descricao.strip()} ({n}/{parcelas})', 'despesa',
                                   [(categoria_id, valor, pessoa_id), (conta_id, -valor)],
                                   status=status if n == 1 else 'agendada', plano_id=plano, parcela_n=n, observacao=observacao))
    return ids


def receita(c, quando, descricao, valor, categoria_id, conta_id, pessoa_id=None, status='confirmada', observacao=''):
    _categoria(c, categoria_id, 'receita')
    k = razao.conta(c, conta_id)
    if k['tipo'] != 'ativo':
        raise ErroValidacao('Receitas entram numa conta, poupança ou dinheiro.')
    return razao.registrar(c, quando, descricao, 'receita', [(conta_id, valor), (categoria_id, -valor, pessoa_id)],
                           status=status, observacao=observacao)


def transferencia(c, quando, descricao, valor, origem_id, destino_id, observacao=''):
    o, d = razao.conta(c, origem_id), razao.conta(c, destino_id)
    if o['id'] == d['id']:
        raise ErroValidacao('Origem e destino devem ser contas diferentes.')
    if d['subtipo'] in ('cartao', 'emprestimo', 'outro_passivo') and o['tipo'] == 'ativo':
        return cartoes.pagar(c, origem_id, destino_id, valor, quando, descricao)
    if o['tipo'] != 'ativo' and o['subtipo'] != 'emprestimo':
        raise ErroValidacao('A origem deve ser uma conta, poupança, dinheiro ou empréstimo recebido.')
    if d['tipo'] != 'ativo':
        raise ErroValidacao('O destino deve ser uma conta, poupança, dinheiro ou dívida.')
    return razao.registrar(c, quando, descricao or f'{o["nome"]} → {d["nome"]}', 'transferencia',
                           [(destino_id, valor), (origem_id, -valor)], observacao=observacao)


def saldo_inicial(c, conta_id, quando, valor_natural):
    """Define (ou redefine) o saldo inicial: positivo = dinheiro em conta; para dívidas, valor devido."""
    k = razao.conta(c, conta_id)
    if k['tipo'] not in ('ativo', 'passivo'):
        raise ErroValidacao('Saldo inicial só se aplica a contas e dívidas.')
    chave = f'abertura:{conta_id}'
    existente = c.execute('SELECT id FROM transacoes WHERE chave_origem=?', (chave,)).fetchone()
    if existente:
        razao.excluir(c, existente[0])
    if valor_natural == 0:
        return None
    contabil = valor_natural if k['tipo'] == 'ativo' else -valor_natural
    return razao.registrar(c, quando, f'Saldo inicial — {k["nome"]}', 'abertura',
                           [(conta_id, contabil), (razao.conta_sistema(c, 'abertura'), -contabil)],
                           chave_origem=chave)


def atualizar_valor(c, conta_id, quando, valor_atual):
    """Atualiza o valor de um investimento ou bem; a diferença vira rendimento (ou perda)."""
    k = razao.conta(c, conta_id)
    if k['subtipo'] not in ('investimento', 'bem', 'poupanca'):
        raise ErroValidacao('Atualização de valor serve para investimentos, poupança e bens.')
    diferenca = valor_atual - razao.saldo(c, conta_id, quando)
    if diferenca == 0:
        return None
    cat = c.execute("SELECT id FROM contas WHERE tipo='receita' AND nome='Rendimentos de investimentos'").fetchone()
    if cat is None:
        raise ErroValidacao('Crie a categoria de receita "Rendimentos de investimentos".')
    if k['subtipo'] == 'bem':
        return razao.registrar(c, quando, f'Reavaliação — {k["nome"]}', 'ajuste',
                               [(conta_id, diferenca), (razao.conta_sistema(c, 'ajuste'), -diferenca)])
    return razao.registrar(c, quando, f'Rendimento — {k["nome"]}', 'rendimento' if diferenca > 0 else 'ajuste',
                           [(conta_id, diferenca), (cat[0], -diferenca)])


def conciliar_saldo(c, conta_id, quando, saldo_banco):
    """Compara o saldo calculado com o informado pelo banco. Não cria ajuste automaticamente."""
    k = razao.conta(c, conta_id)
    calc = razao.saldo_natural(c, k, quando)
    return {'calculado': calc, 'informado': saldo_banco, 'diferenca': saldo_banco - calc}


def ajustar_saldo(c, conta_id, quando, saldo_banco, motivo):
    """Lança explicitamente a diferença como ajuste (rotulado), quando o usuário decide."""
    if not (motivo or '').strip():
        raise ErroValidacao('Explique o motivo do ajuste.')
    r = conciliar_saldo(c, conta_id, quando, saldo_banco)
    if r['diferenca'] == 0:
        return None
    k = razao.conta(c, conta_id)
    contabil = r['diferenca'] if k['tipo'] == 'ativo' else -r['diferenca']
    return razao.registrar(c, quando, f'Ajuste de conciliação — {k["nome"]}', 'ajuste',
                           [(conta_id, contabil), (razao.conta_sistema(c, 'ajuste'), -contabil)], observacao=motivo)


def pistas_da_diferenca(c, conta_id, quando, diferenca, dias=60):
    """Procura no que já foi lançado o que pode explicar a diferença com o saldo do banco.

    Devolve pistas (dicts com tipo, texto, transacoes, exata). O que nunca foi lançado não tem como ser achado aqui.
    Diferença = saldo do banco - saldo calculado, no sentido natural da conta.
    """
    from itertools import combinations
    from fin404.dominio.categorias import assinatura
    k = razao.conta(c, conta_id)
    sinal = -1 if k['tipo'] in razao.NATUREZA_CREDORA else 1
    quando = ler_data(quando)
    inicio = (quando - timedelta(days=dias)).isoformat()
    sql = ('SELECT t.id, t.data, t.descricao, t.status, l.valor_centavos v FROM transacoes t '
           'JOIN lancamentos l ON l.transacao_id=t.id WHERE l.conta_id=? AND t.data BETWEEN ? AND ? ORDER BY t.data')
    movs = [dict(r, efeito=r['v'] * sinal) for r in c.execute(sql, (conta_id, inicio, quando.isoformat()))]
    previstos = [m for m in movs if m['status'] == 'agendada']
    reais = [m for m in movs if m['status'] != 'agendada']
    dm = lambda d: f'{d[8:10]}/{d[5:7]}'  # noqa: E731
    pistas = []
    # 1. Previstos que aconteceram e não foram confirmados (confirmar soma o efeito ao saldo calculado).
    for m in previstos:
        if m['efeito'] == diferenca:
            pistas.append({'tipo': 'previsto', 'exata': True, 'transacoes': [m],
                           'texto': f'"{m["descricao"]}" estava previsto para {dm(m["data"])} e não foi confirmado: o valor bate com a diferença.'})
    for a, b in combinations(previstos[:40], 2):
        if a['efeito'] + b['efeito'] == diferenca:
            pistas.append({'tipo': 'previsto', 'exata': True, 'transacoes': [a, b],
                           'texto': f'Dois previstos não confirmados somam a diferença: "{a["descricao"]}" e "{b["descricao"]}".'})
    if previstos and not any(p['tipo'] == 'previsto' for p in pistas):
        pistas.append({'tipo': 'previsto', 'exata': False, 'transacoes': previstos[:10],
                       'texto': f'{len(previstos)} previsto(s) até esta data ainda não confirmado(s). Algum aconteceu?'})
    # 2. Lançamento em dobro (excluir um tira o efeito dele do saldo calculado).
    vistos = set()
    for a, b in combinations(reais[:400], 2):
        if (a['v'] == b['v'] and b['id'] not in vistos and abs((ler_data(a['data']) - ler_data(b['data'])).days) <= 3
                and assinatura(a['descricao'])[:12] == assinatura(b['descricao'])[:12]):
            vistos.add(b['id'])
            exata = -b['efeito'] == diferenca
            pistas.append({'tipo': 'duplicado', 'exata': exata, 'transacoes': [a, b],
                           'texto': f'Possível lançamento em dobro: "{b["descricao"]}" ({dm(b["data"])}) aparece duas vezes'
                                    + (', e o valor bate com a diferença.' if exata else '.')})
    # 3. Sentido trocado (saída lançada como entrada, ou o contrário): corrigir muda o saldo em duas vezes o valor.
    for m in reais:
        if diferenca and -2 * m['efeito'] == diferenca:
            pistas.append({'tipo': 'sinal', 'exata': True, 'transacoes': [m],
                           'texto': f'"{m["descricao"]}" ({dm(m["data"])}) pode ter sido lançado no sentido errado: '
                                    'a diferença é o dobro do valor dele.'})
    pistas.sort(key=lambda p: not p['exata'])
    return pistas


def lancar_diferenca(c, conta_id, quando, saldo_banco):
    """Sem extrato: a diferença entre o saldo do banco e o calculado vira gasto (ou entrada) não identificado,
    para que os relatórios mostrem o dinheiro que saiu mesmo sem detalhe."""
    k = razao.conta(c, conta_id)
    if k['tipo'] != 'ativo':
        raise ErroValidacao('Use isto em contas e dinheiro. Para cartão, importe a fatura.')
    r = conciliar_saldo(c, conta_id, quando, saldo_banco)
    d = r['diferenca']
    if d == 0:
        return None
    if d < 0:
        cat = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND nome='Gastos não identificados'").fetchone()
        return razao.registrar(c, quando, f'Gastos não identificados — {k["nome"]}', 'despesa', [(cat[0], -d), (conta_id, d)],
                               observacao='Diferença entre o saldo informado pelo banco e o calculado')
    cat = c.execute("SELECT id FROM contas WHERE tipo='receita' AND nome='Entradas não identificadas'").fetchone()
    return razao.registrar(c, quando, f'Entradas não identificadas — {k["nome"]}', 'receita', [(conta_id, d), (cat[0], -d)],
                           observacao='Diferença entre o saldo informado pelo banco e o calculado')


def confirmar_previsto(c, tid, valor=None, quando=None):
    """Marca um lançamento previsto como acontecido, ajustando valor e data se mudaram."""
    t = razao.transacao(c, tid)
    if t['status'] != 'agendada':
        raise ErroValidacao('Este lançamento já foi confirmado.')
    if (valor is not None and valor > 0) or quando:
        razao.editar(c, tid, t['descricao'], quando or t['data'], t['observacao'], valor)
    razao.confirmar(c, tid, 'confirmada')


def _tentar(c, fn):
    """Roda fn() num SAVEPOINT: se der erro de validação, desfaz só aquele item e devolve a mensagem."""
    c.execute('SAVEPOINT item')
    try:
        fn()
    except ErroValidacao as exc:
        c.execute('ROLLBACK TO item')
        c.execute('RELEASE item')
        return str(exc)
    c.execute('RELEASE item')
    return None


def editar_em_lote(c, ids, categoria_id=None, conta_id=None):
    """Troca a categoria e/ou a conta (ou cartão) de vários lançamentos de uma vez. Despesa só recebe categoria de despesa,
    receita só de receita. A conta não muda em parcela de compra parcelada (use "mover para outro cartão") nem no que veio
    de extrato ou fatura importada (aconteceu naquela conta). Devolve (alterados, [(id, motivo)] dos que ficaram como estavam)."""
    if not categoria_id and not conta_id:
        raise ErroValidacao('Escolha a categoria nova, a conta nova, ou as duas.')
    tipo_cat = razao.conta(c, int(categoria_id))['tipo'] if categoria_id else None
    if conta_id and razao.conta(c, int(conta_id))['tipo'] not in ('ativo', 'passivo'):
        raise ErroValidacao('Escolha uma conta, cartão ou dívida.')
    feitos, pulados = 0, []
    for tid in ids:
        t = razao.transacao(c, tid)
        if t['tipo'] not in ('despesa', 'receita'):
            pulados.append((tid, 'não é despesa nem receita')); continue
        cat = int(categoria_id) if categoria_id and tipo_cat == t['tipo'] else None
        if categoria_id and cat is None:
            pulados.append((tid, f'categoria de {tipo_cat} não serve para {t["tipo"]}')); continue
        nova_conta = int(conta_id) if conta_id else None
        if nova_conta and (t['lote_id'] or c.execute('SELECT 1 FROM linhas_importacao WHERE transacao_id=?', (tid,)).fetchone()):
            pulados.append((tid, 'veio de extrato ou fatura importada: a conta não muda')); continue
        if nova_conta and t['plano_id']:
            pulados.append((tid, 'parcela: use "Mover a compra para outro cartão"')); continue
        if nova_conta and any(x['conta_id'] == nova_conta for x in razao.lancamentos_de(c, tid)):
            nova_conta = None
            if not cat:
                continue
        erro = _tentar(c, lambda: razao.editar(c, tid, t['descricao'], t['data'], t['observacao'], None, cat, None, nova_conta))
        if erro:
            pulados.append((tid, erro))
        else:
            feitos += 1
    return feitos, pulados


def mover_parcelas(c, tid, cartao_id):
    """Compra parcelada lançada no cartão errado: passa todas as parcelas para outro cartão, com as datas recalculadas pelo
    fechamento do cartão novo. Vale para a compra inteira, ou não vale (meio parcelamento em cada cartão não existe)."""
    from fin404.dados.banco import auditar
    t = razao.transacao(c, tid)
    if not t['plano_id']:
        raise ErroValidacao('Este lançamento não é parcela de compra parcelada.')
    plano = c.execute('SELECT * FROM planos_parcelas WHERE id=?', (t['plano_id'],)).fetchone()
    novo = cartoes.completo(c, int(cartao_id))
    if novo['subtipo'] != 'cartao':
        raise ErroValidacao('Escolha um cartão de crédito.')
    antigo = plano['conta_cartao_id']
    if int(cartao_id) == antigo:
        raise ErroValidacao('A compra já está neste cartão.')
    cartoes._exigir_ciclo(novo)
    parcelas = c.execute('SELECT id, data, parcela_n, status, lote_id FROM transacoes WHERE plano_id=? ORDER BY parcela_n',
                         (plano['id'],)).fetchall()
    if any(p['lote_id'] or p['status'] == 'conciliada' for p in parcelas) or c.execute(
            f'SELECT 1 FROM linhas_importacao WHERE transacao_id IN ({",".join("?" * len(parcelas))})', [p['id'] for p in parcelas]).fetchone():
        raise ErroValidacao('Alguma parcela veio da fatura importada ou já foi conferida com o banco: '
                            'ela aconteceu naquele cartão. Se o lançamento está duplicado, exclua o que você lançou à mão.')
    novas = {p['id']: cartoes.data_da_parcela(novo, plano['data_compra'], p['parcela_n'] or 1).isoformat() for p in parcelas}
    meses = sorted({d[:7] for p in parcelas for d in (p['data'], novas[p['id']])})
    fechados = [r[0] for r in c.execute(f'SELECT mes FROM meses_fechados WHERE mes IN ({",".join("?" * len(meses))})', meses)]
    if fechados:
        raise ErroValidacao('Há parcela em mês fechado (' + ', '.join(f'{m[5:]}/{m[:4]}' for m in fechados) +
                            '). Reabra esse(s) mês(es) em Fechamento e tente de novo.')
    for p in parcelas:
        c.execute('UPDATE transacoes SET data=? WHERE id=?', (novas[p['id']], p['id']))
        c.execute('UPDATE lancamentos SET conta_id=? WHERE transacao_id=? AND conta_id=?', (int(cartao_id), p['id'], antigo))
        razao.verificar_transacao(c, p['id'])
    c.execute('UPDATE planos_parcelas SET conta_cartao_id=? WHERE id=?', (int(cartao_id), plano['id']))
    auditar(c, 'mover_parcelas', 'plano', plano['id'], f'cartao {antigo} -> {cartao_id}')
    return f'{len(parcelas)} parcela(s) passaram para {novo["nome"]}, com as datas do fechamento dele.'


def editar_parcelas(c, tid):
    """Leva a descrição e a categoria desta parcela para as outras parcelas da mesma compra (o valor de cada uma não muda)."""
    import re as _re
    t = razao.transacao(c, tid)
    if not t['plano_id']:
        return None
    ls = razao.lancamentos_de(c, tid)
    cat = next((x['conta_id'] for x in ls if x['conta_tipo'] in ('receita', 'despesa')), None)
    base = _re.sub(r'\s*\(\d+/\d+\)\s*$', '', t['descricao']).strip()
    n = 0
    for r in c.execute('SELECT id, descricao, data FROM transacoes WHERE plano_id=? AND id<>?', (t['plano_id'], tid)).fetchall():
        sufixo = _re.search(r'\(\d+/\d+\)\s*$', r['descricao'])
        nova = f'{base} {sufixo.group(0).strip()}' if sufixo else base
        obs = razao.transacao(c, r['id'])['observacao']
        if not _tentar(c, lambda: razao.editar(c, r['id'], nova[:200], r['data'], obs, None, cat)):
            n += 1                    # parcela em mês fechado fica como está
    c.execute('UPDATE planos_parcelas SET descricao=? WHERE id=?', (base[:200], t['plano_id'])) \
        if c.execute("SELECT 1 FROM pragma_table_info('planos_parcelas') WHERE name='descricao'").fetchone() else None
    return f'Alterações salvas nesta e em mais {n} parcela(s).'


def desmarcar_pago(c, tid):
    """Marcou como pago por engano: volta para "a pagar" (ou "a receber"). Não vale para compra no cartão (quem se paga é a
    fatura), nem para o que veio de extrato ou fatura importada (aquilo aconteceu no banco)."""
    from fin404.dados.banco import auditar
    t = razao.transacao(c, tid)
    if t['status'] != 'confirmada' or t['tipo'] not in ('despesa', 'receita'):
        raise ErroValidacao('Só despesa ou receita marcada como paga (ou recebida) pode voltar para "a pagar".')
    if t['lote_id'] or c.execute("SELECT 1 FROM linhas_importacao WHERE transacao_id=?", (tid,)).fetchone():
        raise ErroValidacao('Este lançamento veio de extrato ou fatura importada: aconteceu no banco.')
    if c.execute("""SELECT 1 FROM lancamentos l JOIN contas k ON k.id=l.conta_id WHERE l.transacao_id=? AND k.subtipo='cartao'""",
                 (tid,)).fetchone():
        raise ErroValidacao('Compra no cartão não fica "a pagar": ela entra na fatura, e quem se paga é a fatura (em Cartões).')
    razao.confirmar(c, tid, 'agendada')
    auditar(c, 'desmarcar_pago', 'transacao', tid, t['descricao'])


def mudar_situacao(c, tid, situacao, valor_pago=None, quando=None):
    """Situação escolhida no formulário do lançamento: 'pago', 'a_pagar' ou 'parte' (com o valor pago). Devolve a mensagem."""
    if not situacao:
        return None
    t = razao.transacao(c, tid)
    pago = t['status'] != 'agendada'
    if situacao == 'a_pagar':
        if pago:
            desmarcar_pago(c, tid)
            return 'Salvo como "a pagar".'
        return None
    if situacao == 'pago':
        if not pago:
            hoje_iso = date.today().isoformat()
            data_pg = quando or (t['data'] if t['data'] <= hoje_iso else hoje_iso)
            confirmar_previsto(c, tid, None, data_pg)
            return 'Salvo como pago.'
        return None
    if situacao == 'parte':
        if not valor_pago:
            raise ErroValidacao('Informe quanto foi pago (o resto continua a pagar).')
        if pago:
            desmarcar_pago(c, tid)
        _, nova = pagar_parte(c, tid, valor_pago, quando)
        return 'Parte paga registrada; o restante continua a pagar.' if nova else 'Era o valor todo: salvo como pago.'
    raise ErroValidacao('Situação inválida.')


def pagar_parte(c, tid, valor, quando=None):
    """Pagamento parcial de uma conta "a pagar" (ou recebimento parcial): o que foi pago vira pago, na data informada;
    o resto continua "a pagar", num lançamento separado na data prevista. Pagar o valor todo (ou mais) = confirmar."""
    t = razao.transacao(c, tid)
    if t['status'] != 'agendada':
        raise ErroValidacao('Este lançamento já foi pago (ou recebido).')
    ls = razao.lancamentos_de(c, tid)
    if len(ls) != 2:
        raise ErroValidacao('Pagamento parcial só para lançamentos simples (uma conta e uma categoria). Use "Dividir em categorias" antes.')
    total = max(abs(x['valor_centavos']) for x in ls)
    valor = int(valor)
    if valor <= 0:
        raise ErroValidacao('Informe quanto foi pago.')
    if valor >= total:
        return confirmar_previsto(c, tid, valor, quando), None
    resto = total - valor
    nova = razao.registrar(c, t['data'], f'{t["descricao"]} (restante)'[:200], t['tipo'],
                           [(x['conta_id'], (resto if x['valor_centavos'] > 0 else -resto), x['pessoa_id']) for x in ls],
                           status='agendada', observacao=f'Restante do lançamento {tid}: pago {formatar(valor)} de {formatar(total)}.'[:500])
    obs = ((t['observacao'] or '') + f' Pagamento parcial: {formatar(valor)} de {formatar(total)}; o restante ficou a pagar.').strip()[:500]
    razao.editar(c, tid, t['descricao'], quando or t['data'], obs, valor)
    razao.confirmar(c, tid, 'confirmada')
    return tid, nova


# ---------------------------------------------------------------- previsões

def criar_previsao(c, descricao, valor, conta_id, contraparte_id, sentido, dia, inicio, fim='', periodicidade='mensal', mes_do_ano=None,
                   data_base=None):
    descricao = (descricao or '').strip()
    if not 1 <= len(descricao) <= 200:
        raise ErroValidacao('Informe uma descrição.')
    inicio = ler_mes(inicio)
    fim = ler_mes(fim) if fim else None
    if fim and fim < inicio:
        raise ErroValidacao('O fim deve ser depois do início.')
    if sentido not in ('entrada', 'saida'):
        raise ErroValidacao('Sentido inválido.')
    dia = int(dia)
    if not 1 <= dia <= 31:
        raise ErroValidacao('Dia deve estar entre 1 e 31.')
    k = razao.conta(c, conta_id)
    cp = razao.conta(c, contraparte_id)
    if k['tipo'] not in ('ativo', 'passivo'):
        raise ErroValidacao('Escolha a conta ou cartão afetado.')
    if sentido == 'saida' and cp['tipo'] not in ('despesa', 'ativo', 'passivo'):
        raise ErroValidacao('Para saídas, escolha uma categoria de despesa ou a conta de destino.')
    if sentido == 'entrada' and cp['tipo'] not in ('receita', 'ativo'):
        raise ErroValidacao('Para entradas, escolha uma categoria de receita ou a conta de origem.')
    if periodicidade not in dict(FREQUENCIAS):
        raise ErroValidacao('Escolha de quanto em quanto tempo repete.')
    if periodicidade in INTERVALO_DIAS:
        if not data_base:
            raise ErroValidacao('Para "toda semana" ou "a cada 2 semanas", informe a data da primeira vez.')
        data_base = ler_data(data_base)
        inicio, dia = data_base.strftime('%Y-%m'), data_base.day
        if fim and fim < inicio:
            raise ErroValidacao('O fim deve ser depois do início.')
        data_base = data_base.isoformat()
    else:
        data_base = None
    if periodicidade == 'anual':
        try:
            mes_do_ano = int(mes_do_ano)
        except (TypeError, ValueError):
            raise ErroValidacao('Informe o mês do ano.')
        if not 1 <= mes_do_ano <= 12:
            raise ErroValidacao('Informe o mês do ano.')
    else:
        mes_do_ano = None
    return c.execute('''INSERT INTO previsoes(descricao,valor_centavos,conta_id,contraparte_id,sentido,dia,inicio,fim,periodicidade,mes_do_ano,
                                              frequencia,data_base)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)''', (descricao, valor, conta_id, contraparte_id, sentido, dia, inicio, fim,
                                                             'anual' if periodicidade == 'anual' else 'mensal', mes_do_ano,
                                                             periodicidade, data_base)).lastrowid


def frequencia(p):
    return p['frequencia'] or p['periodicidade'] or 'mensal'


def _meses_entre(a, b):
    return (int(b[:4]) - int(a[:4])) * 12 + int(b[5:7]) - int(a[5:7])


FORMAS_PAGAMENTO = (('pix', 'Pix'), ('debito', 'Cartão de débito'), ('credito', 'Cartão de crédito'), ('boleto', 'Boleto'),
                    ('debito_automatico', 'Débito automático'), ('transferencia', 'TED / transferência'), ('dinheiro', 'Dinheiro'),
                    ('carteira_digital', 'Carteira digital (PicPay, Mercado Pago, PayPal)'), ('beneficio', 'Vale-refeição / alimentação'),
                    ('crediario', 'Crediário / carnê da loja'), ('desconto_folha', 'Desconto em folha'),
                    ('pontos', 'Pontos, milhas ou cashback'), ('outro', 'Outro'))

FREQUENCIAS = (('semanal', 'Toda semana'), ('quinzenal', 'A cada 2 semanas'), ('mensal', 'Todo mês'),
               ('bimestral', 'A cada 2 meses'), ('trimestral', 'A cada 3 meses'), ('semestral', 'A cada 6 meses'),
               ('anual', 'Todo ano'))
INTERVALO_MESES = {'mensal': 1, 'bimestral': 2, 'trimestral': 3, 'semestral': 6, 'anual': 12}
INTERVALO_DIAS = {'semanal': 7, 'quinzenal': 14}


def forma_padrao(c, conta_id):
    """Forma de pagamento óbvia pela conta: cartão de crédito é crédito; dinheiro em espécie é dinheiro."""
    sub = razao.conta(c, conta_id)['subtipo']
    return {'cartao': 'credito', 'dinheiro': 'dinheiro'}.get(sub)


def definir_forma(c, ids, forma):
    if forma and forma not in dict(FORMAS_PAGAMENTO):
        raise ErroValidacao('Forma de pagamento inválida.')
    marc = ','.join('?' * len(ids))
    c.execute(f'UPDATE transacoes SET meio_pagamento=? WHERE id IN ({marc})', (forma or None, *ids))


def repetir(c, transacao_id, periodicidade, ate=None, horizonte_meses=13, hoje=None):
    """Transforma um lançamento em recorrente: cria a previsão a partir da próxima ocorrência e gera os previstos.

    O lançamento original fica como está; os próximos aparecem em "A pagar e receber" e casam com a fatura importada.
    """
    if periodicidade not in dict(FREQUENCIAS):
        raise ErroValidacao('Escolha de quanto em quanto tempo repete.')
    t = razao.transacao(c, transacao_id)
    if t['tipo'] not in ('despesa', 'receita'):
        raise ErroValidacao('Só despesas e receitas podem repetir.')
    if t['plano_id']:
        raise ErroValidacao('Compra parcelada não pode ser recorrente: as parcelas já são lançadas uma em cada fatura.')
    ls = razao.lancamentos_de(c, transacao_id)
    cats = [x for x in ls if x['conta_tipo'] in ('receita', 'despesa')]
    if len(cats) != 1:
        raise ErroValidacao('Lançamento dividido em várias categorias não pode repetir; junte numa categoria antes.')
    cat = cats[0]
    conta = next(x for x in ls if x['conta_tipo'] in ('ativo', 'passivo'))
    quando = ler_data(t['data'])
    data_base = None
    if periodicidade in INTERVALO_DIAS:
        data_base = quando + timedelta(days=INTERVALO_DIAS[periodicidade])
        inicio = data_base.strftime('%Y-%m')
    else:
        inicio = somar_meses(date(quando.year, quando.month, 1), INTERVALO_MESES[periodicidade]).strftime('%Y-%m')
    if ate and ler_mes(ate) < inicio:
        raise ErroValidacao('O mês final da repetição precisa ser depois deste lançamento.')
    pid = criar_previsao(c, t['descricao'], abs(cat['valor_centavos']), conta['conta_id'], cat['conta_id'],
                         'saida' if t['tipo'] == 'despesa' else 'entrada', quando.day, inicio, ate or '',
                         periodicidade, quando.month if periodicidade == 'anual' else None, data_base)
    c.execute('UPDATE previsoes SET meio_pagamento=? WHERE id=?', (t['meio_pagamento'], pid))
    c.execute('UPDATE transacoes SET previsao_id=? WHERE id=?', (pid, transacao_id))
    hoje = ler_data(hoje or date.today())
    gerar_previsoes(c, somar_meses(date(hoje.year, hoje.month, 1), horizonte_meses).strftime('%Y-%m'), hoje)
    return pid


def gerar_previsoes(c, ate_mes, hoje=None):
    """Cria transações agendadas para os meses da previsão até `ate_mes`. Idempotente.
    Meses já passados não são gerados (o que passou deve vir do extrato)."""
    hoje = ler_data(hoje or date.today())
    ate_mes = ler_mes(ate_mes)
    criadas = 0
    for p in c.execute('SELECT * FROM previsoes WHERE ativa=1').fetchall():
        k, cp = razao.conta(c, p['conta_id']), razao.conta(c, p['contraparte_id'])
        for quando, chave in _ocorrencias(p, hoje, ate_mes):
            if quando >= hoje and not c.execute('SELECT 1 FROM transacoes WHERE chave_origem=?', (chave,)).fetchone():
                v = p['valor_centavos']
                if p['sentido'] == 'saida':
                    tipo = 'despesa' if cp['tipo'] == 'despesa' else ('pagamento_fatura' if k['tipo'] == 'ativo' and cp['tipo'] == 'passivo' else 'transferencia')
                    linhas = [(cp['id'], v), (k['id'], -v)]
                else:
                    tipo = 'receita' if cp['tipo'] == 'receita' else 'transferencia'
                    linhas = [(k['id'], v), (cp['id'], -v)]
                tid = razao.registrar(c, quando, p['descricao'], tipo, linhas, status='agendada',
                                      previsao_id=p['id'], chave_origem=chave)
                if p['meio_pagamento']:
                    c.execute('UPDATE transacoes SET meio_pagamento=? WHERE id=?', (p['meio_pagamento'], tid))
                criadas += 1
    return criadas


def _ocorrencias(p, hoje, ate_mes):
    """Datas (e chaves de idempotência) da previsão entre hoje e o fim de `ate_mes`."""
    freq = frequencia(p)
    if freq in INTERVALO_DIAS:
        passo = INTERVALO_DIAS[freq]
        d = ler_data(p['data_base'])
        if d < hoje:
            d += timedelta(days=-(-(hoje - d).days // passo) * passo)
        while d.strftime('%Y-%m') <= ate_mes and (not p['fim'] or d.strftime('%Y-%m') <= p['fim']):
            yield d, f'previsao:{p["id"]}:{d.isoformat()}'
            d += timedelta(days=passo)
        return
    intervalo = INTERVALO_MESES[freq]
    ym = max(p['inicio'], hoje.strftime('%Y-%m'))
    while ym <= ate_mes and (not p['fim'] or ym <= p['fim']):
        if freq == 'anual':
            vale = int(ym[5:]) == (p['mes_do_ano'] or int(p['inicio'][5:]))
        else:
            vale = _meses_entre(p['inicio'], ym) % intervalo == 0
        if vale:
            yield dia_no_mes(int(ym[:4]), int(ym[5:]), p['dia']), f'previsao:{p["id"]}:{ym}'
        ym = mes_seguinte(ym)


def atualizar_previsao(c, previsao_id, descricao, valor, dia, conta_id, contraparte_id, fim='', hoje=None, manter=None):
    """Edita a previsão e refaz os previstos dela a partir de hoje (os já pagos e os atrasados ficam como estão)."""
    from fin404.dados.banco import auditar
    p = c.execute('SELECT * FROM previsoes WHERE id=?', (previsao_id,)).fetchone()
    if p is None:
        raise ErroValidacao('Previsão não encontrada.')
    descricao = (descricao or '').strip()
    if not 1 <= len(descricao) <= 200:
        raise ErroValidacao('Informe uma descrição.')
    valor = int(valor)
    if valor <= 0:
        raise ErroValidacao('O valor tem de ser maior que zero.')
    dia = int(dia)
    if not 1 <= dia <= 31:
        raise ErroValidacao('Dia deve estar entre 1 e 31.')
    fim = ler_mes(fim) if fim else None
    if fim and fim < p['inicio']:
        raise ErroValidacao('O fim deve ser depois do início.')
    k, cp = razao.conta(c, conta_id), razao.conta(c, contraparte_id)
    if k['tipo'] not in ('ativo', 'passivo') or k['id'] == cp['id']:
        raise ErroValidacao('Escolha a conta e a categoria (ou conta de contrapartida).')
    hoje = ler_data(hoje or date.today())
    futuras = c.execute("SELECT id, data FROM transacoes WHERE previsao_id=? AND status='agendada' AND data>=? AND id<>?",
                        (previsao_id, hoje.isoformat(), manter or 0)).fetchall()
    ate = max([r['data'][:7] for r in futuras] + [somar_meses(date(hoje.year, hoje.month, 1), 12).strftime('%Y-%m')])
    for r in futuras:
        razao.excluir(c, r['id'])
    c.execute('''UPDATE previsoes SET descricao=?, valor_centavos=?, dia=?, conta_id=?, contraparte_id=?, fim=? WHERE id=?''',
              (descricao, valor, dia, conta_id, contraparte_id, fim, previsao_id))
    auditar(c, 'atualizar_previsao', 'previsao', previsao_id, f'{p["descricao"]} {p["valor_centavos"]} → {descricao} {valor}')
    if p['ativa']:
        gerar_previsoes(c, ate, hoje)
    return len(futuras)


def encerrar_previsao(c, previsao_id, apagar_futuras=True, hoje=None):
    hoje = ler_data(hoje or date.today()).isoformat()
    c.execute('UPDATE previsoes SET ativa=0 WHERE id=?', (previsao_id,))
    if apagar_futuras:
        for (tid,) in c.execute("SELECT id FROM transacoes WHERE previsao_id=? AND status='agendada' AND data>=?",
                                (previsao_id, hoje)).fetchall():
            razao.excluir(c, tid)


def provisoes_anuais(c):
    """Saídas previstas que não são mensais (IPVA, IPTU, seguro, mensalidade trimestral…) e quanto separar por mês."""
    rows = [dict(r) for r in c.execute("""SELECT p.*, k.nome categoria FROM previsoes p JOIN contas k ON k.id=p.contraparte_id
                                         WHERE p.ativa=1 AND p.sentido='saida'
                                         AND COALESCE(p.frequencia, p.periodicidade) IN ('bimestral','trimestral','semestral','anual')
                                         ORDER BY p.mes_do_ano, p.dia""")]
    total = 0
    for r in rows:
        r['por_ano'] = r['valor_centavos'] * (12 // INTERVALO_MESES[frequencia(r)])
        total += r['por_ano']
    return {'itens': rows, 'total_ano': total, 'por_mes': -(-total // 12)}


def excluir_previsao(c, previsao_id):
    """Apaga a previsão e todos os previstos dela ainda não confirmados. Os já confirmados ficam (são lançamentos reais)."""
    p = c.execute('SELECT * FROM previsoes WHERE id=?', (previsao_id,)).fetchone()
    if p is None:
        raise ErroValidacao('Previsão não encontrada.')
    n = 0
    for (tid,) in c.execute("SELECT id FROM transacoes WHERE previsao_id=? AND status='agendada'", (previsao_id,)).fetchall():
        razao.excluir(c, tid)
        n += 1
    c.execute('DELETE FROM previsoes WHERE id=?', (previsao_id,))
    return p['descricao'], n
