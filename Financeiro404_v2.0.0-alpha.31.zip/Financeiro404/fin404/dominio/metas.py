"""Metas de economia (reserva de emergência, viagem, entrada do apartamento…).

Uma meta pode acompanhar o saldo de uma conta (por exemplo, a poupança da reserva) ou um valor guardado informado à mão.
"""
from datetime import date

from fin404.dinheiro import ErroValidacao, data as ler_data, mes as ler_mes
from fin404.dominio import razao


def criar(c, nome, alvo, conta_id=None, guardado=0, prazo=None):
    nome = (nome or '').strip()
    if not nome:
        raise ErroValidacao('Dê um nome para a meta.')
    if alvo <= 0:
        raise ErroValidacao('O valor da meta precisa ser maior que zero.')
    if conta_id:
        k = razao.conta(c, conta_id)
        if k['tipo'] != 'ativo':
            raise ErroValidacao('A meta só pode acompanhar uma conta de dinheiro ou investimento.')
    prazo = ler_mes(prazo) if prazo else None
    cur = c.execute('INSERT INTO metas(nome, alvo_centavos, conta_id, guardado_centavos, prazo) VALUES(?,?,?,?,?)',
                    (nome[:80], alvo, conta_id, max(guardado, 0), prazo))
    return cur.lastrowid


def atualizar(c, meta_id, nome, alvo, conta_id, guardado, prazo):
    _uma(c, meta_id)
    if alvo <= 0:
        raise ErroValidacao('O valor da meta precisa ser maior que zero.')
    if conta_id and razao.conta(c, conta_id)['tipo'] != 'ativo':
        raise ErroValidacao('A meta só pode acompanhar uma conta de dinheiro ou investimento.')
    c.execute('UPDATE metas SET nome=?, alvo_centavos=?, conta_id=?, guardado_centavos=?, prazo=? WHERE id=?',
              ((nome or '').strip()[:80] or 'Meta', alvo, conta_id, max(guardado, 0), ler_mes(prazo) if prazo else None, meta_id))


def encerrar(c, meta_id):
    _uma(c, meta_id)
    c.execute('UPDATE metas SET ativa=0 WHERE id=?', (meta_id,))


def _uma(c, meta_id):
    m = c.execute('SELECT * FROM metas WHERE id=?', (meta_id,)).fetchone()
    if not m:
        raise ErroValidacao('Meta não encontrada.')
    return m


def _meses_ate(prazo, hoje):
    a, m = int(prazo[:4]), int(prazo[5:7])
    return (a - hoje.year) * 12 + (m - hoje.month) + 1  # conta o mês atual


def situacao(c, m, hoje=None):
    hoje = ler_data(hoje or date.today())
    if m['conta_id']:
        atual = max(razao.saldo(c, m['conta_id'], hoje), 0)  # contas de ativo: saldo natural = saldo contábil
        origem = 'saldo da conta'
    else:
        atual = m['guardado_centavos']
        origem = 'informado'
    falta = max(m['alvo_centavos'] - atual, 0)
    por_mes = meses = None
    atrasada = False
    if m['prazo'] and falta:
        meses = _meses_ate(m['prazo'], hoje)
        if meses <= 0:
            atrasada = True
        else:
            por_mes = -(-falta // meses)  # arredonda para cima: guardar isso por mês garante a meta
    return {**dict(m), 'atual': atual, 'falta': falta, 'pct': min(atual * 100 // m['alvo_centavos'], 100),
            'por_mes': por_mes, 'meses': meses, 'atrasada': atrasada, 'origem': origem, 'concluida': falta == 0}


def listar(c, hoje=None, todas=False):
    filtro = '' if todas else 'WHERE m.ativa=1'
    rows = c.execute(f'SELECT m.*, k.nome conta FROM metas m LEFT JOIN contas k ON k.id=m.conta_id {filtro} ORDER BY m.ativa DESC, m.prazo IS NULL, m.prazo, m.id').fetchall()
    return [situacao(c, r, hoje) for r in rows]


def excluir(c, meta_id):
    m = _uma(c, meta_id)
    c.execute('DELETE FROM metas WHERE id=?', (meta_id,))
    return m['nome']
