"""Cartões de crédito como passivo: ciclos, faturas calculadas e parcelamentos.

Regras de ciclo (documentadas e testadas):
- a fatura fecha no `dia_fechamento` de cada mês (ajustado ao último dia em meses curtos), MAS datas reais
  informadas pelo banco (tabela fechamentos_conhecidos, preenchida ao importar a fatura) substituem a data
  calculada daquele mês — o BB, por exemplo, fecha em dias diferentes;
- compra no dia do fechamento: regra do cartão. 'proxima' = vai para a fatura seguinte; 'atual' = entra na que fecha;
- vencimento = o informado pelo banco, ou o próximo `dia_vencimento` depois do fechamento;
- valor da fatura = dívida total do cartão no último dia do ciclo (inclui saldo anterior não pago);
- pagamentos feitos entre o fim deste ciclo e o fim do seguinte abatem esta fatura.
"""
from datetime import date, timedelta

from fin404.dinheiro import ErroValidacao, data as ler_data, dia_no_mes, dividir, somar_meses
from fin404.dominio import razao

JANELA_SUBSTITUICAO = 12   # dias: uma data real substitui a calculada que estiver a até 12 dias dela


def completo(c, cartao):
    """Cartão com as datas reais de fechamento conhecidas. Aceita id ou linha."""
    k = dict(razao.conta(c, cartao) if isinstance(cartao, int) else cartao)
    k['fech_doc'] = {ler_data(r['fechamento']): (ler_data(r['vencimento']) if r['vencimento'] else None)
                     for r in c.execute('SELECT fechamento, vencimento FROM fechamentos_conhecidos WHERE conta_cartao_id=?', (k['id'],))}
    return k


def lista(c):
    return [completo(c, k) for k in razao.contas(c, subtipos=('cartao',))]


def _docs(cartao):
    return cartao['fech_doc'] if isinstance(cartao, dict) and 'fech_doc' in cartao else {}


def _regra(cartao):
    try:
        return cartao['regra_fechamento'] or 'proxima'
    except (KeyError, IndexError):
        return 'proxima'


def _exigir_ciclo(cartao):
    if cartao['subtipo'] != 'cartao' or not cartao['dia_fechamento'] or not cartao['dia_vencimento']:
        raise ErroValidacao(f'Configure os dias de fechamento e vencimento do cartão "{cartao["nome"]}".')


def _fechamentos_perto(cartao, d):
    """Fechamentos (calculados, trocados pelos reais quando conhecidos) de ~3 meses antes a ~3 depois de d."""
    _exigir_ciclo(cartao)
    base = date(d.year, d.month, 1)
    calculados = [dia_no_mes(m.year, m.month, cartao['dia_fechamento']) for m in (somar_meses(base, i) for i in range(-4, 5))]
    docs = sorted(_docs(cartao))
    resultado = []
    for f in calculados:
        perto = [x for x in docs if abs((x - f).days) <= JANELA_SUBSTITUICAO]
        resultado.append(min(perto, key=lambda x: abs((x - f).days)) if perto else f)
    return sorted(set(resultado))


def fechamento_da_compra(cartao, d):
    d = ler_data(d)
    atual = _regra(cartao) == 'atual'
    for f in _fechamentos_perto(cartao, d):
        if d < f or (atual and d == f):
            return f
    raise ErroValidacao('Não foi possível calcular o fechamento da fatura.')


def fechamento_anterior(cartao, fechamento):
    return max(x for x in _fechamentos_perto(cartao, fechamento) if x < fechamento)


def fechamento_seguinte(cartao, fechamento):
    return min(x for x in _fechamentos_perto(cartao, fechamento) if x > fechamento)


def ciclo(cartao, fechamento):
    """(primeiro dia, dia seguinte ao último) das compras que entram na fatura que fecha em `fechamento`."""
    anterior = fechamento_anterior(cartao, fechamento)
    if _regra(cartao) == 'atual':
        return anterior + timedelta(days=1), fechamento + timedelta(days=1)
    return anterior, fechamento


def vencimento(cartao, fechamento):
    _exigir_ciclo(cartao)
    doc = _docs(cartao).get(fechamento)
    if doc:
        return doc
    v = dia_no_mes(fechamento.year, fechamento.month, cartao['dia_vencimento'])
    if v <= fechamento:
        prox = somar_meses(date(fechamento.year, fechamento.month, 1), 1)
        v = dia_no_mes(prox.year, prox.month, cartao['dia_vencimento'])
    return v


def data_da_parcela(cartao, data_compra, k):
    """Data contábil da parcela k (1..n): cai no k-ésimo ciclo a partir da compra."""
    data_compra = ler_data(data_compra)
    if k == 1:
        return data_compra
    alvo = fechamento_da_compra(cartao, data_compra)
    for _ in range(k - 1):
        alvo = fechamento_seguinte(cartao, alvo)
    inicio, fim = ciclo(cartao, alvo)
    candidata = somar_meses(data_compra, k - 1)
    return max(inicio, min(candidata, fim - timedelta(days=1)))


def ajustar_ao_ciclo(cartao, fechamento, d):
    """Traz uma data para dentro do ciclo da fatura (lançamento informado pelo banco nessa fatura)."""
    inicio, fim = ciclo(cartao, fechamento)
    return max(inicio, min(ler_data(d), fim - timedelta(days=1)))


def compra(c, cartao_id, quando, descricao, total, categoria_id, parcelas=1, pessoa_id=None, observacao=''):
    cartao = completo(c, cartao_id)
    if cartao['subtipo'] != 'cartao':
        raise ErroValidacao('Escolha um cartão de crédito.')
    if razao.conta(c, categoria_id)['tipo'] != 'despesa':
        raise ErroValidacao('Escolha uma categoria de despesa.')
    parcelas = int(parcelas)
    if not 1 <= parcelas <= 72:
        raise ErroValidacao('Número de parcelas deve ficar entre 1 e 72.')
    if total < parcelas:
        raise ErroValidacao('O total é menor que o número de parcelas.')
    if parcelas == 1:
        return [razao.registrar(c, quando, descricao, 'despesa',
                                [(categoria_id, total, pessoa_id), (cartao_id, -total)], observacao=observacao)]
    _exigir_ciclo(cartao)
    plano = c.execute('''INSERT INTO planos_parcelas(descricao,total_centavos,n_parcelas,conta_cartao_id,data_compra)
                         VALUES(?,?,?,?,?)''', (descricao.strip(), total, parcelas, cartao_id, ler_data(quando).isoformat())).lastrowid
    ids = []
    for k, valor in enumerate(dividir(total, parcelas), start=1):
        ids.append(razao.registrar(c, data_da_parcela(cartao, quando, k), f'{descricao.strip()} ({k}/{parcelas})', 'despesa',
                                   [(categoria_id, valor, pessoa_id), (cartao_id, -valor)],
                                   plano_id=plano, parcela_n=k, observacao=observacao))
    return ids


def fatura(c, cartao_id, fechamento, hoje=None):
    cartao = completo(c, cartao_id)
    _exigir_ciclo(cartao)
    fechamento = ler_data(fechamento)
    hoje = ler_data(hoje or date.today())
    inicio, fim = ciclo(cartao, fechamento)
    _, fim_seguinte = ciclo(cartao, fechamento_seguinte(cartao, fechamento))
    venc = vencimento(cartao, fechamento)
    ultimo_dia = fim - timedelta(days=1)
    valor = -razao.saldo(c, cartao_id, ultimo_dia)
    saldo_anterior = -razao.saldo(c, cartao_id, inicio - timedelta(days=1))
    itens = c.execute('''SELECT t.id, t.data, t.descricao, t.tipo, t.status, t.plano_id, t.parcela_n, l.valor_centavos,
                                (SELECT k.nome FROM lancamentos l2 JOIN contas k ON k.id=l2.conta_id
                                 WHERE l2.transacao_id=t.id AND l2.id<>l.id ORDER BY abs(l2.valor_centavos) DESC LIMIT 1) contrapartida
                         FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                         WHERE l.conta_id=? AND t.status<>'agendada' AND t.data>=? AND t.data<?
                         ORDER BY t.data, t.id''', (cartao_id, inicio.isoformat(), fim.isoformat())).fetchall()
    pagos = c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                         WHERE l.conta_id=? AND t.status<>'agendada' AND t.tipo IN ('pagamento_fatura','transferencia')
                         AND l.valor_centavos>0 AND t.data>=? AND t.data<?''',
                      (cartao_id, fim.isoformat(), fim_seguinte.isoformat())).fetchone()[0]
    doc = c.execute('SELECT total_centavos FROM faturas_documento WHERE conta_cartao_id=? AND fechamento=?',
                    (cartao_id, fechamento.isoformat())).fetchone()
    restante = max(valor - pagos, 0)
    if hoje < fim:
        situacao = 'aberta'
    elif valor <= 0:
        situacao = 'sem saldo'
    elif restante == 0:
        situacao = 'paga'
    elif hoje > venc:
        situacao = 'vencida' if pagos == 0 else 'paga parcialmente'
    else:
        situacao = 'fechada' if pagos == 0 else 'paga parcialmente'
    return {
        'cartao': cartao, 'inicio': inicio, 'fim': fim, 'fechamento': fechamento, 'vencimento': venc,
        'data_real': fechamento in _docs(cartao),
        'valor': valor, 'saldo_anterior': saldo_anterior, 'itens': itens, 'pagos': pagos,
        'restante': restante, 'situacao': situacao,
        'documento': doc[0] if doc else None,
        'diferenca': (doc[0] - valor) if doc else None,
        'compras': -sum(i['valor_centavos'] for i in itens if i['valor_centavos'] < 0),
        'creditos': sum(i['valor_centavos'] for i in itens if i['valor_centavos'] > 0),
        # dentro do ciclo: pagamentos (abatem a dívida) e estornos/créditos de compra (abatem o gasto)
        'pagos_no_ciclo': sum(i['valor_centavos'] for i in itens if i['valor_centavos'] > 0 and i['tipo'] in ('pagamento_fatura', 'transferencia')),
        'estornos': sum(i['valor_centavos'] for i in itens if i['valor_centavos'] > 0 and i['tipo'] not in ('pagamento_fatura', 'transferencia')),
    }


def faturas_recentes(c, cartao_id, antes=6, depois=3, hoje=None):
    cartao = completo(c, cartao_id)
    _exigir_ciclo(cartao)
    hoje = ler_data(hoje or date.today())
    f = fechamento_da_compra(cartao, hoje)
    for _ in range(antes):
        f = fechamento_anterior(cartao, f)
    resultado = []
    for _ in range(antes + depois + 1):
        resultado.append(fatura(c, cartao_id, f, hoje))
        f = fechamento_seguinte(cartao, f)
    return list(reversed(resultado))


def registrar_fechamento(c, cartao_id, fechamento, vencimento_real=None, origem='manual'):
    c.execute('''INSERT INTO fechamentos_conhecidos(conta_cartao_id,fechamento,vencimento,origem) VALUES(?,?,?,?)
                 ON CONFLICT(conta_cartao_id,fechamento) DO UPDATE SET vencimento=COALESCE(excluded.vencimento, vencimento),
                 origem=excluded.origem''',
              (cartao_id, ler_data(fechamento).isoformat(), ler_data(vencimento_real).isoformat() if vencimento_real else None, origem))


def registrar_total_documento(c, cartao_id, fechamento, total, origem='manual'):
    fechamento = ler_data(fechamento).isoformat()
    c.execute('''INSERT INTO faturas_documento(conta_cartao_id,fechamento,total_centavos,origem) VALUES(?,?,?,?)
                 ON CONFLICT(conta_cartao_id,fechamento) DO UPDATE SET total_centavos=excluded.total_centavos, origem=excluded.origem''',
              (cartao_id, fechamento, total, origem))


def pagar(c, origem_id, cartao_id, valor, quando, descricao=None):
    origem = razao.conta(c, origem_id)
    cartao = razao.conta(c, cartao_id)
    if origem['tipo'] != 'ativo':
        raise ErroValidacao('O pagamento deve sair de uma conta ou do dinheiro.')
    if cartao['tipo'] != 'passivo':
        raise ErroValidacao('Escolha o cartão ou a dívida que está sendo paga.')
    return razao.registrar(c, quando, descricao or f'Pagamento {cartao["nome"]}', 'pagamento_fatura',
                           [(cartao_id, valor), (origem_id, -valor)])


def limite(c, cartao_id):
    cartao = razao.conta(c, cartao_id)
    if not cartao['limite_centavos']:
        return None
    comprometido = -razao.saldo(c, cartao_id, ate=None)
    return {'limite': cartao['limite_centavos'], 'comprometido': comprometido,
            'disponivel': cartao['limite_centavos'] - comprometido}


# ---------------------------------------------------------------- parcelamentos: antecipação e cancelamento

MOTIVOS_ENCERRAMENTO = {'antecipado': 'Parcelas antecipadas', 'cancelado': 'Compra cancelada ou devolvida',
                        'outro': 'Outro motivo'}


def _ligadas_a_importacao(c, ids):
    if not ids:
        return set()
    marc = ','.join('?' * len(ids))
    return {r[0] for r in c.execute(f'''SELECT li.transacao_id FROM linhas_importacao li JOIN lotes_importacao lo ON lo.id=li.lote_id
                                        WHERE lo.desfeito_em IS NULL AND li.situacao IN ('casada','criada')
                                        AND li.transacao_id IN ({marc})''', list(ids))}


def parcelas_do_plano(c, plano_id, hoje=None):
    """Parcelas com a situação de cada uma: 'na fatura' (veio numa fatura importada), 'passada' ou 'futura'."""
    hoje = ler_data(hoje or date.today())
    rows = [dict(r) for r in c.execute('''SELECT t.id, t.data, t.descricao, t.parcela_n, t.status, -l.valor_centavos valor
                                          FROM transacoes t JOIN planos_parcelas p ON p.id=t.plano_id
                                          JOIN lancamentos l ON l.transacao_id=t.id AND l.conta_id=p.conta_cartao_id
                                          WHERE t.plano_id=? ORDER BY t.parcela_n, t.data''', (plano_id,))]
    ligadas = _ligadas_a_importacao(c, [r['id'] for r in rows])
    for r in rows:
        r['situacao'] = 'na fatura' if r['id'] in ligadas else ('futura' if ler_data(r['data']) > hoje else 'passada')
    return rows


def planos(c, hoje=None, incluir_encerrados=False):
    hoje = ler_data(hoje or date.today())
    # Sem "todos": só planos abertos com alguma parcela depois de hoje (filtro no banco; o laço abaixo ainda confere a
    # situação de cada parcela). Evita calcular, um a um, anos de parcelamentos já terminados.
    filtro, args = '', []
    if not incluir_encerrados:
        filtro = 'WHERE p.encerrado_em IS NULL AND EXISTS (SELECT 1 FROM transacoes t WHERE t.plano_id=p.id AND t.data>?)'
        args = [hoje.isoformat()]
    itens = []
    for p in c.execute(f'''SELECT p.*, k.nome cartao FROM planos_parcelas p JOIN contas k ON k.id=p.conta_cartao_id {filtro}
                           ORDER BY p.encerrado_em IS NOT NULL, p.data_compra DESC''', args).fetchall():
        ps = parcelas_do_plano(c, p['id'], hoje)
        futuras = [x for x in ps if x['situacao'] == 'futura']
        if not futuras and not incluir_encerrados and not p['encerrado_em']:
            continue  # já terminou
        itens.append({**dict(p), 'parcelas': ps, 'restante': sum(x['valor'] for x in futuras), 'n_futuras': len(futuras),
                      'proxima': futuras[0] if futuras else None})
    return itens


def encerrar_parcelamento(c, plano_id, motivo, a_partir_de=None, hoje=None):
    """Tira do razão as parcelas que não vão mais ser cobradas (a partir da parcela `a_partir_de`, ou as futuras).

    Parcelas que vieram numa fatura importada nunca são tiradas. As tiradas vão para a lixeira (auditadas) e o plano fica
    marcado como encerrado, com o motivo. O valor cobrado na antecipação ou o crédito do cancelamento vem na fatura,
    como uma linha própria: é ele que deve ser lançado, não estas parcelas.
    """
    if motivo not in MOTIVOS_ENCERRAMENTO:
        raise ErroValidacao('Escolha o motivo.')
    p = c.execute('SELECT * FROM planos_parcelas WHERE id=?', (plano_id,)).fetchone()
    if p is None:
        raise ErroValidacao('Parcelamento não encontrado.')
    if p['encerrado_em']:
        raise ErroValidacao('Este parcelamento já foi encerrado.')
    ps = parcelas_do_plano(c, plano_id, hoje)
    if a_partir_de is None:
        alvos = [x for x in ps if x['situacao'] == 'futura']
    else:
        alvos = [x for x in ps if x['parcela_n'] and x['parcela_n'] >= int(a_partir_de) and x['situacao'] != 'na fatura']
    if not alvos:
        raise ErroValidacao('Não há parcelas a tirar: as restantes já vieram em faturas importadas.')
    for x in alvos:
        razao.excluir(c, x['id'])
    c.execute("UPDATE planos_parcelas SET encerrado_em=datetime('now'), motivo_encerramento=? WHERE id=?", (motivo, plano_id))
    from fin404.dados.banco import auditar
    auditar(c, 'encerrar_parcelamento', 'plano', plano_id,
            f'{MOTIVOS_ENCERRAMENTO[motivo]}; {len(alvos)} parcela(s) retirada(s): ' + ', '.join(str(x['parcela_n']) for x in alvos))
    return len(alvos)


def parcelas_ausentes(c, lote_id=None):
    """Parcelas previstas para o ciclo de uma fatura importada que não casaram com nenhuma linha dela.

    Sem `lote_id`: olha as faturas já revisadas (sem linhas pendentes). Com `lote_id`: olha a fatura em revisão e
    considera as sugestões de casamento. Uma parcela ausente costuma ser antecipação, cancelamento ou lançamento em dobro.
    """
    if lote_id is None:
        lotes = c.execute('''SELECT lo.* FROM lotes_importacao lo WHERE lo.desfeito_em IS NULL AND lo.fatura_fechamento IS NOT NULL
                             AND NOT EXISTS(SELECT 1 FROM linhas_importacao li WHERE li.lote_id=lo.id AND li.situacao='nova')''').fetchall()
    else:
        lotes = c.execute('SELECT * FROM lotes_importacao WHERE id=? AND desfeito_em IS NULL AND fatura_fechamento IS NOT NULL',
                          (lote_id,)).fetchall()
    itens = []
    for lo in lotes:
        cartao = completo(c, lo['conta_id'])
        if not cartao['dia_fechamento']:
            continue
        inicio, fim = ciclo(cartao, ler_data(lo['fatura_fechamento']))
        cobertas = set()
        for li in c.execute('SELECT transacao_id, sugestao, situacao FROM linhas_importacao WHERE lote_id=?', (lo['id'],)):
            if li['transacao_id'] and li['situacao'] in ('casada', 'criada'):
                cobertas.add(li['transacao_id'])
            if lote_id is not None and (li['sugestao'] or '').startswith('casar:'):
                cobertas.add(int(li['sugestao'][6:]))
        for t in c.execute('''SELECT t.id, t.data, t.descricao, t.parcela_n, t.plano_id, -l.valor_centavos valor, p.n_parcelas
                              FROM transacoes t JOIN planos_parcelas p ON p.id=t.plano_id AND p.encerrado_em IS NULL
                              JOIN lancamentos l ON l.transacao_id=t.id AND l.conta_id=?
                              WHERE t.data>=? AND t.data<? ORDER BY t.data''', (lo['conta_id'], inicio.isoformat(), fim.isoformat())):
            if t['id'] in cobertas or t['id'] in _ligadas_a_importacao(c, [t['id']]):
                continue
            itens.append({**dict(t), 'cartao': cartao['nome'], 'cartao_id': cartao['id'], 'lote_id': lo['id'],
                          'fechamento': ler_data(lo['fatura_fechamento'])})
    return itens


def minimo_da_fatura(c, cartao_id, fechamento):
    """Pagamento mínimo informado no PDF da fatura que fecha em `fechamento` (None se essa fatura não foi importada
    ou o banco não informou). É sempre o da própria fatura, nunca o de outra."""
    import json
    r = c.execute('''SELECT fatura_info FROM lotes_importacao WHERE conta_id=? AND fatura_fechamento=? AND desfeito_em IS NULL
                     AND fatura_info IS NOT NULL ORDER BY id DESC LIMIT 1''', (cartao_id, ler_data(fechamento).isoformat())).fetchone()
    if not r:
        return None
    try:
        v = json.loads(r[0] or '{}').get('minimo')
    except ValueError:
        return None
    return v if isinstance(v, int) and v > 0 else None


# ---------------------------------------------------------------- conferência com o banco: saldo inicial e pagamentos

def saldo_inicial_pendente(c, cartao_id):
    """Primeira fatura importada em PDF: o saldo anterior do banco é a dívida que já existia antes do app.
    Se o app não tem esse valor na véspera do ciclo, a fatura calculada fica menor que a do banco."""
    lote = c.execute('''SELECT fatura_fechamento, fatura_saldo_anterior FROM lotes_importacao
                        WHERE conta_id=? AND fatura_fechamento IS NOT NULL AND fatura_saldo_anterior IS NOT NULL
                        AND desfeito_em IS NULL ORDER BY fatura_fechamento LIMIT 1''', (cartao_id,)).fetchone()
    if not lote:
        return None
    k = completo(c, cartao_id)
    if not k['dia_fechamento']:
        return None
    inicio, _ = ciclo(k, ler_data(lote['fatura_fechamento']))
    vespera = inicio - timedelta(days=1)
    no_app = -razao.saldo(c, cartao_id, vespera)
    if no_app == lote['fatura_saldo_anterior']:
        return None
    return {'data': vespera, 'banco': lote['fatura_saldo_anterior'], 'no_app': no_app,
            'fechamento': ler_data(lote['fatura_fechamento'])}


def pagamentos_como_gasto(c, cartao_id=None):
    """Pagamentos de fatura que entraram como estorno de uma categoria (crédito no cartão contra despesa/receita).
    Isso derruba o gasto do mês pelo valor do pagamento e o pagamento some do caixa."""
    from fin404.importacao.pipeline import RE_PAGAMENTO_NA_FATURA
    filtro = 'AND lc.conta_id=?' if cartao_id else ''
    args = (cartao_id,) if cartao_id else ()
    rows = c.execute(f'''SELECT t.id, t.data, t.descricao, lc.conta_id cartao_id, kc.nome cartao, lc.valor_centavos valor,
                                ko.nome categoria
                         FROM transacoes t JOIN lancamentos lc ON lc.transacao_id=t.id JOIN contas kc ON kc.id=lc.conta_id
                         JOIN lancamentos lo ON lo.transacao_id=t.id AND lo.id<>lc.id JOIN contas ko ON ko.id=lo.conta_id
                         WHERE kc.subtipo='cartao' AND lc.valor_centavos>0 AND ko.tipo IN ('despesa','receita')
                         AND t.tipo IN ('despesa','receita','estorno') AND (SELECT COUNT(*) FROM lancamentos x WHERE x.transacao_id=t.id)=2
                         {filtro} ORDER BY t.data''', args).fetchall()
    return [r for r in rows if RE_PAGAMENTO_NA_FATURA.search(r['descricao'])]


def origem_sugerida(c, descricao=''):
    """De onde provavelmente saiu o dinheiro de um pagamento de fatura (a pessoa confirma): conta corrente, senão dinheiro."""
    contas_ativas = [k for k in razao.contas(c, tipo='ativo') if k['subtipo'] in ('corrente', 'dinheiro', 'poupanca')]
    for sub in ('corrente', 'dinheiro', 'poupanca'):
        for k in contas_ativas:
            if k['subtipo'] == sub:
                return k
    return None


def virar_pagamento(c, tid, origem_id):
    """Transforma um 'estorno' que na verdade é pagamento de fatura em pagamento (sai de uma conta, abate a dívida)."""
    from fin404.dados.banco import auditar
    origem = razao.conta(c, origem_id)
    if origem['tipo'] != 'ativo':
        raise ErroValidacao('O pagamento sai de uma conta ou do dinheiro.')
    alvo = next((p for p in pagamentos_como_gasto(c) if p['id'] == tid), None)
    if alvo is None:
        raise ErroValidacao('Este lançamento não parece um pagamento de fatura lançado como gasto.')
    antes = razao.snapshot(c, tid)
    c.execute('''UPDATE lancamentos SET conta_id=?, pessoa_id=NULL WHERE transacao_id=? AND id<>(
                     SELECT id FROM lancamentos WHERE transacao_id=? AND conta_id=?)''', (origem_id, tid, tid, alvo['cartao_id']))
    c.execute("UPDATE transacoes SET tipo='pagamento_fatura', estorno_de=NULL WHERE id=?", (tid,))
    razao.verificar_transacao(c, tid)
    auditar(c, 'virar_pagamento', 'transacao', tid, antes)
