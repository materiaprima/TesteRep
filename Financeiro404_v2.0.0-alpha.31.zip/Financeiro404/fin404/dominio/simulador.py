"""Simulador de dívida do cartão: quanto custa cada caminho, com as taxas reais da fatura.

Todas as contas em Decimal e centavos inteiros. Taxas em % ao mês. Use o CET (custo efetivo total, com IOF)
quando o banco informar: é ele que mostra o custo real.

Teto legal: desde 03/01/2024 (Lei 14.690/2023 e Resolução CMN 5.112), juros e encargos do rotativo e do
parcelamento da fatura, somados, não podem passar de 100% do valor original da dívida (o IOF fica fora do teto).
O simulador aplica esse teto ao rotativo e ao parcelamento da fatura; empréstimo pessoal não tem esse teto.
"""
from decimal import ROUND_HALF_UP, Decimal

from fin404.dinheiro import ErroValidacao

MAX_MESES = 120


def _centavos(x):
    return int(Decimal(x).quantize(Decimal('1'), rounding=ROUND_HALF_UP))


def price(divida, taxa_am, n, teto_legal=False):
    """Parcela fixa (tabela Price). Com teto_legal, os juros totais ficam limitados ao valor da dívida."""
    i = Decimal(taxa_am).scaleb(-2)
    n = int(n)
    if not 1 <= n <= MAX_MESES:
        raise ErroValidacao('Número de parcelas entre 1 e 120.')
    if i == 0:
        parcela = _centavos(Decimal(divida) / n)
    else:
        parcela = _centavos(Decimal(divida) * i / (1 - (1 + i) ** -n))
    total = parcela * n
    if teto_legal and total - divida > divida:
        parcela = _centavos(Decimal(2 * divida) / n)
        total = parcela * n
        return {'parcela': parcela, 'meses': n, 'total': total, 'juros': total - divida, 'teto': True}
    return {'parcela': parcela, 'meses': n, 'total': total, 'juros': total - divida, 'teto': False}


def rotativo(divida, taxa_am, pagamento_mensal):
    """Paga um valor fixo por mês e o resto rola com juros, respeitando o teto legal (juros <= dívida original)."""
    i = Decimal(taxa_am).scaleb(-2)
    saldo = Decimal(divida)
    pago = juros_total = 0
    if pagamento_mensal <= 0:
        raise ErroValidacao('Informe quanto conseguem pagar por mês.')
    for mes in range(1, MAX_MESES + 1):
        juros = min(_centavos(saldo * i), divida - juros_total)
        juros_total += juros
        saldo += juros
        pagamento = min(pagamento_mensal, _centavos(saldo))
        saldo -= pagamento
        pago += pagamento
        if saldo <= 0:
            return {'nunca_quita': False, 'meses': mes, 'total': pago, 'juros': pago - divida, 'parcela': pagamento_mensal,
                    'teto': juros_total >= divida, 'juros_mes': _centavos(Decimal(divida) * i)}
    return {'nunca_quita': True, 'juros_mes': _centavos(Decimal(divida) * i), 'meses': None, 'total': None, 'juros': None, 'teto': False}


def anual(taxa_am):
    return ((1 + Decimal(taxa_am).scaleb(-2)) ** 12 - 1) * 100


def _pct(t):
    return str(t).replace('.', ',')


def comparar(divida, pagamento_mensal, taxa_rotativo, taxa_parcelamento, parcelas, taxa_emprestimo=None, parcelas_emprestimo=None):
    if divida <= 0:
        raise ErroValidacao('Informe o valor da dívida.')
    opcoes = [{'nome': 'Pagar tudo agora', 'parcela': divida, 'meses': 1, 'total': divida, 'juros': 0,
               'nota': 'Sem juros. Só é possível se houver dinheiro disponível.'}]
    r = rotativo(divida, taxa_rotativo, pagamento_mensal) if pagamento_mensal else None
    if r:
        if r['nunca_quita']:  # só acontece com pagamentos muito pequenos (mais de 10 anos)
            from fin404.dinheiro import formatar
            opcoes.append({'nome': 'Rotativo (pagar o que der por mês)', 'parcela': pagamento_mensal,
                           'meses': None, 'total': None, 'juros': None,
                           'nota': f'Com esse valor, a dívida não acaba em 10 anos (juros do 1º mês: cerca de {formatar(r["juros_mes"])}).'})
        else:
            nota = f'{_pct(taxa_rotativo)}% a.m. sobre o saldo que sobra.'
            if r['teto']:
                nota += ' Os juros bateram no teto legal (100% da dívida original).'
            opcoes.append({'nome': 'Rotativo (pagar o que der por mês)', 'parcela': pagamento_mensal, 'meses': r['meses'],
                           'total': r['total'], 'juros': r['juros'], 'nota': nota})
    p = price(divida, taxa_parcelamento, parcelas, teto_legal=True)
    nota = f'{_pct(taxa_parcelamento)}% a.m., parcela fixa.' + (' Limitado pelo teto legal (juros até 100% da dívida).' if p['teto'] else '')
    opcoes.append({'nome': f'Parcelar a fatura em {parcelas}x', 'nota': nota, **p})
    if taxa_emprestimo and parcelas_emprestimo:
        e = price(divida, taxa_emprestimo, parcelas_emprestimo, teto_legal=False)
        opcoes.append({'nome': f'Empréstimo em {parcelas_emprestimo}x para quitar', 'nota': f'{_pct(taxa_emprestimo)}% a.m. (taxa da proposta).', **e})
    return opcoes
