"""Nota por foto (R10): a foto fica guardada no banco e o usuário digita os itens olhando para ela, na mesma tela.

Sem leitura automática da imagem (OCR): o app não usa internet nem bibliotecas de fora, e o cupom térmico fotografado
engana qualquer leitor. O que garante a nota é a mesma trava do CSV: a soma dos itens menos o desconto tem de dar o total.

Formato de cada linha de item (os números ficam no fim; separar com ponto e vírgula também vale):

    ARROZ 5KG 24,90                  → só o total (quantidade 1)
    LEITE INTEGRAL 1L 2 5,49         → quantidade e preço unitário (o total é calculado)
    BANANA PRATA 0,850 KG 6,99 5,94  → quantidade, preço unitário e total (conferidos)
    7891000100103 CAFE 500G 1 x 18,90 → código de barras no começo é guardado; "x" e a unidade são aceitos
"""
import hashlib
import re
from pathlib import PurePath

from fin404.dinheiro import ErroValidacao, centavos, data as ler_data, formatar
from fin404.dominio import notas

LIMITE = 8_000_000
ASSINATURAS = ((b'\xff\xd8\xff', 'image/jpeg'), (b'\x89PNG\r\n\x1a\n', 'image/png'), (b'RIFF', 'image/webp'))
UNIDADES = {'UN', 'UND', 'UNID', 'KG', 'G', 'GR', 'L', 'LT', 'ML', 'PC', 'PCT', 'CX', 'DZ', 'M', 'FD', 'BD'}
RE_NUM = re.compile(r'^\d{1,3}(?:\.\d{3})*(?:,\d{1,3})?$|^\d+(?:[.,]\d{1,3})?$')
MAX_ITENS = 400


def tipo_imagem(dados):
    for assinatura, tipo in ASSINATURAS:
        if dados.startswith(assinatura) and (tipo != 'image/webp' or dados[8:12] == b'WEBP'):
            return tipo
    return None


def guardar(c, nome, dados):
    if not dados:
        raise ErroValidacao('Escolha uma foto.')
    if len(dados) > LIMITE:
        raise ErroValidacao(f'{nome}: foto maior que 8 MB. Reduza a foto (ou mande pelo WhatsApp para você mesmo, que ele reduz).')
    tipo = tipo_imagem(dados)
    if tipo is None:
        if dados[4:12] in (b'ftypheic', b'ftypheix', b'ftypmif1', b'ftyphevc'):
            raise ErroValidacao(f'{nome}: foto HEIC (iPhone). No iPhone: Ajustes > Câmera > Formatos > "Mais compatível"; '
                                'ou compartilhe a foto como JPG.')
        raise ErroValidacao(f'{nome}: envie foto JPG, PNG ou WEBP.')
    sha = hashlib.sha256(dados).hexdigest()
    r = c.execute('SELECT id FROM fotos_nota WHERE sha256=?', (sha,)).fetchone()
    if r:
        return r[0], False
    nome = PurePath((nome or 'foto').replace('\\', '/')).name.strip()[:200] or 'foto'
    fid = c.execute('INSERT INTO fotos_nota(nome, tipo, tamanho, sha256, dados) VALUES(?,?,?,?,?)',
                    (nome, tipo, len(dados), sha, dados)).lastrowid
    return fid, True


def guardar_varias(c, arquivos):
    if not arquivos:
        raise ErroValidacao('Escolha ao menos uma foto.')
    novas, repetidas = [], 0
    for nome, dados in arquivos:
        fid, nova = guardar(c, nome, dados)
        if nova:
            novas.append(fid)
        else:
            repetidas += 1
    return novas, repetidas


def uma(c, foto_id, com_dados=False):
    campos = '*' if com_dados else 'id, nota_id, nome, tipo, tamanho, criado_em'
    f = c.execute(f'SELECT {campos} FROM fotos_nota WHERE id=?', (foto_id,)).fetchone()
    if not f:
        raise ErroValidacao('Foto não encontrada.')
    return f


def pendentes(c):
    return c.execute('SELECT id, nome, tamanho, criado_em FROM fotos_nota WHERE nota_id IS NULL ORDER BY id').fetchall()


def da_nota(c, nota_id):
    return c.execute('SELECT id, nome, tamanho FROM fotos_nota WHERE nota_id=? ORDER BY id', (nota_id,)).fetchall()


def proxima_pendente(c, depois_de=0):
    r = c.execute('SELECT id FROM fotos_nota WHERE nota_id IS NULL AND id>? ORDER BY id LIMIT 1', (depois_de,)).fetchone() \
        or c.execute('SELECT id FROM fotos_nota WHERE nota_id IS NULL ORDER BY id LIMIT 1').fetchone()
    return r[0] if r else None


def descartar(c, foto_id):
    f = uma(c, foto_id)
    if f['nota_id']:
        raise ErroValidacao('Esta foto já virou nota. Exclua a nota (ou desfaça a importação) antes.')
    c.execute('DELETE FROM fotos_nota WHERE id=?', (foto_id,))


def ler_itens(texto):
    """Linhas digitadas → itens. Devolve (itens, erros por linha)."""
    itens, erros = [], []
    for n, linha in enumerate((texto or '').splitlines(), start=1):
        linha = linha.strip()
        if not linha:
            continue
        partes = [p.strip() for p in linha.split(';')] if ';' in linha else linha.split()
        partes = [p for p in partes if p]
        nums, unidade = [], 'UN'
        while partes and (RE_NUM.match(partes[-1].replace('R$', '')) or partes[-1].lower() == 'x'
                          or (partes[-1].upper() in UNIDADES and nums)):
            p = partes.pop().replace('R$', '')
            if p.lower() == 'x':
                continue
            if p.upper() in UNIDADES:
                unidade = p.upper()[:6]
                continue
            nums.insert(0, p)
        nums = nums[-3:] if len(nums) > 3 else nums
        if len(nums) > 3 or not nums:
            erros.append(f'Linha {n}: faltou o valor no fim ("{linha[:40]}").')
            continue
        gtin = ''
        if partes and re.fullmatch(r'\d{8,14}', partes[0]):
            gtin = partes.pop(0)
        descricao = ' '.join(partes).strip(' -–:')
        if not descricao:
            erros.append(f'Linha {n}: faltou o nome do item.')
            continue
        try:
            if len(nums) == 1:
                qtd, total = 1000, centavos(nums[0])
                preco = total
            else:
                qtd = notas.quantidade_mil(nums[0])
                preco = centavos(nums[1])
                calculado = (qtd * preco + 500) // 1000
                total = centavos(nums[2]) if len(nums) == 3 else calculado
                if qtd <= 0:
                    raise ValueError('quantidade zero')
                if abs(qtd * preco - total * 1000) > 1000:
                    erros.append(f'Linha {n}: {descricao}: quantidade × preço unitário não dá o total do item.')
                    continue
        except (ErroValidacao, ValueError) as exc:
            erros.append(f'Linha {n}: número inválido ({exc}).')
            continue
        itens.append({'descricao': descricao[:200], 'gtin': gtin, 'quantidade_mil': qtd, 'unidade': unidade,
                      'preco': preco, 'total': total})
    if len(itens) > MAX_ITENS:
        erros.append(f'Mais de {MAX_ITENS} itens numa nota só.')
    return itens, erros


def salvar_nota(c, foto_id, campos):
    """Monta a nota a partir do formulário digitado olhando a foto. Atômico; a foto fica ligada à nota."""
    f = uma(c, foto_id)
    if f['nota_id']:
        raise ErroValidacao('Esta foto já virou nota.')
    loja = (campos.get('loja') or '').strip()[:120]
    if not loja:
        raise ErroValidacao('Informe a loja.')
    dia = ler_data(campos.get('data'))
    total = centavos(campos.get('total'))
    desconto = centavos(campos.get('desconto') or '0', permitir_zero=True)
    cnpj = re.sub(r'\D', '', campos.get('cnpj') or '')
    if cnpj and len(cnpj) != 14:
        raise ErroValidacao('O CNPJ tem 14 dígitos.')
    chave = re.sub(r'\D', '', campos.get('chave') or '') or None
    if chave and len(chave) != 44:
        raise ErroValidacao(f'A chave da NFC-e tem 44 dígitos (veio com {len(chave)}).')
    itens, erros = ler_itens(campos.get('itens'))
    if erros:
        raise ErroValidacao(' '.join(erros[:6]) + (f' (e mais {len(erros) - 6})' if len(erros) > 6 else ''))
    if not itens:
        raise ErroValidacao('Digite ao menos um item.')
    soma = sum(i['total'] for i in itens)
    if soma - desconto != total:
        raise ErroValidacao(f'Os itens somam {formatar(soma)}; menos o desconto ({formatar(desconto)}) dá '
                            f'{formatar(soma - desconto)}, mas o total da nota é {formatar(total)}. '
                            f'Diferença: {formatar(abs(soma - desconto - total))}.')
    nota = {'data': dia, 'loja': loja, 'cnpj': cnpj, 'chave': chave, 'total': total, 'desconto': desconto, 'itens': itens}
    existente = notas._ja_existe(c, nota)
    if existente and c.execute('SELECT 1 FROM itens_nota WHERE nota_id=? LIMIT 1', (existente['id'],)).fetchone():
        raise ErroValidacao(f'Esta nota já está no app com itens (nota {existente["id"]}). Descarte a foto se for repetida.')
    sha = c.execute('SELECT sha256 FROM fotos_nota WHERE id=?', (foto_id,)).fetchone()[0]
    res = notas.gravar_lote(c, f'foto: {f["nome"]}', 'foto:' + sha, [nota], 'foto')
    nid = res['ids'][0]
    c.execute('UPDATE fotos_nota SET nota_id=? WHERE id=?', (nid, foto_id))
    return nid, res
