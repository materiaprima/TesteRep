"""Catálogo de produtos (R10, camada 2 — local, de arquivo) e histórico de preços.

- **Catálogo:** importado de arquivo baixado pelo usuário (Open Food Facts, Open Beauty Facts, Open Products Facts — licença
  ODbL, que exige atribuição: ela fica gravada em `fontes_catalogo` e aparece nas telas de preços). Lido em fluxo, linha a
  linha (o arquivo completo tem vários GB), filtrando por país. Nada é baixado pelo programa.
- **Agrupamento:** descrições diferentes do mesmo produto ("LEITE INT ITALAC 1L" e "LT ITALAC INTEGRAL") viram apelidos de
  um produto; o sistema sugere candidatos por semelhança de palavras, o usuário confirma.
- **Preços:** por produto (ou por descrição, enquanto não agrupada), ao longo do tempo e por loja; gasto por tipo de item.
"""
import csv
import gzip
import io
import re
import sys

from fin404.dinheiro import ErroValidacao, data as ler_data
from fin404.dominio.notas import TIPOS, normalizar, tipo_do_item

FONTES = {
    'off': ('Open Food Facts', 'Dados de produtos © colaboradores do Open Food Facts (world.openfoodfacts.org), '
                               'sob a Open Database License (ODbL) 1.0.'),
    'obf': ('Open Beauty Facts', 'Dados de produtos © colaboradores do Open Beauty Facts (world.openbeautyfacts.org), '
                                 'sob a Open Database License (ODbL) 1.0.'),
    'opf': ('Open Products Facts', 'Dados de produtos © colaboradores do Open Products Facts (world.openproductsfacts.org), '
                                   'sob a Open Database License (ODbL) 1.0.'),
}
ALIASES = {
    'gtin': ('code', 'gtin', 'ean', 'codigo', 'codigo_de_barras'),
    'nome': ('product_name_pt', 'product_name', 'nome', 'generic_name_pt', 'generic_name'),
    'marca': ('brands', 'marca'),
    'tamanho': ('quantity', 'tamanho', 'quantidade'),
    'pais': ('countries_tags', 'countries_en', 'countries', 'paises', 'pais'),
}
TIPOS_PRODUTO = list(TIPOS) + ['Outros']


def _linhas_de_arquivo(caminho):
    if str(caminho).endswith('.gz'):
        return gzip.open(caminho, 'rt', encoding='utf-8', errors='replace', newline='')
    return open(caminho, 'r', encoding='utf-8', errors='replace', newline='')


def importar(c, linhas, fonte, pais='brazil', limite=None):
    """`linhas`: iterável de texto (arquivo aberto). Devolve {'lidos', 'gravados', 'ignorados'}."""
    if fonte not in FONTES:
        raise ErroValidacao('Fonte desconhecida.')
    csv.field_size_limit(min(sys.maxsize, 2 ** 31 - 1))       # o dump tem campos enormes; no Windows o limite é um long de C
    it = iter(linhas)
    try:
        cab = next(it)
    except StopIteration:
        raise ErroValidacao('Arquivo vazio.')
    sep = '\t' if cab.count('\t') >= max(cab.count(';'), cab.count(',')) else (';' if cab.count(';') >= cab.count(',') else ',')
    nomes = [normalizar(x).replace(' ', '_') for x in next(csv.reader([cab], delimiter=sep))]
    col = {}
    for campo, opcoes in ALIASES.items():
        for o in opcoes:
            if o in nomes:
                col[campo] = nomes.index(o)
                break
    if 'gtin' not in col or 'nome' not in col:
        raise ErroValidacao('O arquivo precisa das colunas de código de barras (code) e nome (product_name).')
    filtro = normalizar(pais) if pais else ''
    lidos = gravados = ignorados = 0
    for row in csv.reader(it, delimiter=sep):
        lidos += 1
        def v(campo):
            i = col.get(campo)
            return row[i].strip() if i is not None and i < len(row) else ''
        gtin, nome = re.sub(r'\D', '', v('gtin')), v('nome')
        if not (8 <= len(gtin) <= 14) or not nome:
            ignorados += 1
            continue
        if filtro and 'pais' in col:
            paises = normalizar(v('pais'))
            if filtro not in paises and not (filtro == 'brazil' and 'brasil' in paises):
                ignorados += 1
                continue
        nome = nome[:200]
        c.execute('''INSERT INTO produtos(gtin, nome, nome_norm, marca, tamanho, tipo, fonte) VALUES(?,?,?,?,?,?,?)
                     ON CONFLICT(gtin) DO UPDATE SET
                       nome=CASE WHEN produtos.fonte='nota' THEN excluded.nome ELSE produtos.nome END,
                       nome_norm=CASE WHEN produtos.fonte='nota' THEN excluded.nome_norm ELSE produtos.nome_norm END,
                       marca=CASE WHEN produtos.marca='' THEN excluded.marca ELSE produtos.marca END,
                       tamanho=CASE WHEN produtos.tamanho='' THEN excluded.tamanho ELSE produtos.tamanho END,
                       fonte=CASE WHEN produtos.fonte='nota' THEN excluded.fonte ELSE produtos.fonte END''',
                  (gtin, nome, normalizar(nome), v('marca')[:120], v('tamanho')[:60], tipo_do_item(nome), FONTES[fonte][0]))
        gravados += 1
        if limite and gravados >= limite:
            break
    nome_fonte, atrib = FONTES[fonte]
    c.execute('''INSERT INTO fontes_catalogo(fonte, atribuicao, registros) VALUES(?,?,?)
                 ON CONFLICT(fonte) DO UPDATE SET registros=registros+excluded.registros, importado_em=CURRENT_TIMESTAMP''',
              (nome_fonte, atrib, gravados))
    # Itens de nota com código de barras passam a apontar para o produto do catálogo
    c.execute('''UPDATE itens_nota SET produto_id=(SELECT p.id FROM produtos p WHERE p.gtin=itens_nota.gtin)
                 WHERE gtin<>'' AND produto_id IS NULL AND EXISTS(SELECT 1 FROM produtos p WHERE p.gtin=itens_nota.gtin)''')
    return {'lidos': lidos, 'gravados': gravados, 'ignorados': ignorados}


def importar_bytes(c, dados, fonte, pais='brazil'):
    if dados[:2] == b'\x1f\x8b':
        texto = gzip.decompress(dados).decode('utf-8', errors='replace')
    else:
        texto = dados.decode('utf-8-sig', errors='replace')
    return importar(c, io.StringIO(texto, newline=''), fonte, pais)


def atribuicoes(c):
    return c.execute('SELECT * FROM fontes_catalogo ORDER BY fonte').fetchall()


# ------------------------------------------------------------------ agrupamento

def _tokens(norm):
    return {t for t in norm.split() if len(t) >= 2 and not t.isdigit()}


def _parecido(a, b):
    """Semelhança por palavras, aceitando abreviação ("int" ~ "integral", "lt" não casa com "leite": curto demais)."""
    if not a or not b:
        return 0
    comuns = 0
    usados = set()
    for x in a:
        for y in b:
            if y in usados:
                continue
            if x == y or (min(len(x), len(y)) >= 3 and (x.startswith(y) or y.startswith(x))):
                comuns += 1
                usados.add(y)
                break
    # Cada par casado conta uma vez (abreviação e palavra inteira são o mesmo termo): Jaccard sobre termos casados
    return comuns * 100 // (len(a) + len(b) - comuns)


def sugestoes(c, descricao_norm, limite=5):
    alvo = _tokens(descricao_norm)
    if not alvo:
        return []
    chaves = sorted(alvo, key=len, reverse=True)[:2]
    vistos = {}
    for t in chaves:
        for r in c.execute('SELECT id, nome, nome_norm, marca, tamanho FROM produtos WHERE nome_norm LIKE ? LIMIT 300', (f'%{t}%',)):
            vistos[r['id']] = (dict(r), _tokens(r['nome_norm'] + ' ' + normalizar(r['marca'])))
        for r in c.execute('''SELECT p.id, p.nome, p.nome_norm, p.marca, p.tamanho, a.descricao_norm apelido FROM produto_apelidos a
                              JOIN produtos p ON p.id=a.produto_id WHERE a.descricao_norm LIKE ? LIMIT 300''', (f'%{t}%',)):
            atual = vistos.get(r['id'])
            toks = _tokens(r['apelido'])
            vistos[r['id']] = (dict(r), (atual[1] | toks) if atual else toks)
    pontuados = [(_parecido(alvo, toks), p) for p, toks in vistos.values()]
    return [dict(p, nota=n) for n, p in sorted(pontuados, key=lambda x: -x[0]) if n >= 34][:limite]


def sem_produto(c, limite=60):
    return c.execute('''SELECT descricao_norm, MIN(descricao) exemplo, COUNT(*) n, SUM(total_centavos) total, MAX(tipo) tipo
                        FROM itens_nota WHERE produto_id IS NULL GROUP BY descricao_norm ORDER BY n DESC, total DESC LIMIT ?''',
                     (limite,)).fetchall()


def novo_produto(c, nome, marca='', tamanho='', tipo=''):
    nome = (nome or '').strip()
    if not nome:
        raise ErroValidacao('Dê um nome ao produto.')
    tipo = tipo if tipo in TIPOS_PRODUTO else tipo_do_item(nome)
    return c.execute("INSERT INTO produtos(nome, nome_norm, marca, tamanho, tipo, fonte) VALUES(?,?,?,?,?, 'manual')",
                     (nome[:200], normalizar(nome), (marca or '')[:120], (tamanho or '')[:60], tipo)).lastrowid


def associar(c, descricao_norm, produto_id):
    p = c.execute('SELECT * FROM produtos WHERE id=?', (produto_id,)).fetchone()
    if not p:
        raise ErroValidacao('Produto não encontrado.')
    c.execute('INSERT INTO produto_apelidos(descricao_norm, produto_id) VALUES(?,?) '
              'ON CONFLICT(descricao_norm) DO UPDATE SET produto_id=excluded.produto_id', (descricao_norm, produto_id))
    n = c.execute('UPDATE itens_nota SET produto_id=? WHERE descricao_norm=?', (produto_id, descricao_norm)).rowcount
    if p['tipo']:
        c.execute('UPDATE itens_nota SET tipo=? WHERE descricao_norm=?', (p['tipo'], descricao_norm))
    return n


def separar(c, descricao_norm):
    c.execute('DELETE FROM produto_apelidos WHERE descricao_norm=?', (descricao_norm,))
    c.execute('''UPDATE itens_nota SET produto_id=(SELECT p.id FROM produtos p WHERE p.gtin=itens_nota.gtin AND itens_nota.gtin<>'')
                 WHERE descricao_norm=?''', (descricao_norm,))


def definir_tipo(c, produto_id, tipo):
    if tipo not in TIPOS_PRODUTO:
        raise ErroValidacao('Tipo inválido.')
    c.execute('UPDATE produtos SET tipo=? WHERE id=?', (tipo, produto_id))
    c.execute('UPDATE itens_nota SET tipo=? WHERE produto_id=?', (tipo, produto_id))


# ------------------------------------------------------------------ preços

_SQL_ITENS = '''SELECT i.*, n.data, n.loja, n.cnpj, p.nome produto, p.marca, p.tamanho
                FROM itens_nota i JOIN notas_fiscais n ON n.id=i.nota_id LEFT JOIN produtos p ON p.id=i.produto_id'''


def _chave(r):
    return f'p{r["produto_id"]}' if r['produto_id'] else f'd{r["descricao_norm"]}'


def lista_precos(c, termo='', limite=200):
    """Um registro por produto (ou descrição ainda não agrupada): compras, último preço, menor, maior, variação, lojas."""
    args, filtro = [], ''
    if termo:
        filtro = ' WHERE (i.descricao_norm LIKE ? OR p.nome_norm LIKE ?)'
        args = [f'%{normalizar(termo)}%'] * 2
    grupos = {}
    for r in c.execute(_SQL_ITENS + filtro + ' ORDER BY n.data, i.id', args):
        g = grupos.setdefault(_chave(r), {'chave': _chave(r), 'nome': r['produto'] or r['descricao'], 'marca': r['marca'] or '',
                                          'unidade': r['unidade'], 'tipo': r['tipo'], 'precos': [], 'lojas': set(), 'gasto': 0})
        g['precos'].append((r['data'], r['preco_unit_centavos']))
        g['lojas'].add(r['loja'])
        g['gasto'] += r['total_centavos']
    out = []
    for g in grupos.values():
        valores = [v for _, v in g['precos']]
        primeiro, ultimo = valores[0], valores[-1]
        out.append({**g, 'n': len(valores), 'ultimo': ultimo, 'ultima_data': g['precos'][-1][0], 'menor': min(valores),
                    'maior': max(valores), 'lojas': len(g['lojas']),
                    'variacao': ((ultimo - primeiro) * 100 // primeiro) if primeiro and len(valores) > 1 else None})
    return sorted(out, key=lambda x: (-x['n'], -x['gasto']))[:limite]


def historico_preco(c, chave):
    if chave.startswith('p') and chave[1:].isdigit():
        rows = c.execute(_SQL_ITENS + ' WHERE i.produto_id=? ORDER BY n.data, i.id', (int(chave[1:]),)).fetchall()
    elif chave.startswith('d'):
        rows = c.execute(_SQL_ITENS + ' WHERE i.descricao_norm=? AND i.produto_id IS NULL ORDER BY n.data, i.id',
                         (chave[1:],)).fetchall()
    else:
        raise ErroValidacao('Produto inválido.')
    if not rows:
        raise ErroValidacao('Nenhuma compra registrada para este produto.')
    lojas = {}
    for r in rows:
        x = lojas.setdefault(r['loja'], [])
        x.append(r['preco_unit_centavos'])
    por_loja = sorted(({'loja': k, 'n': len(v), 'menor': min(v), 'media': sum(v) // len(v), 'ultimo': v[-1]} for k, v in lojas.items()),
                      key=lambda x: x['media'])
    descricoes = sorted({r['descricao'] for r in rows})
    return {'chave': chave, 'nome': rows[0]['produto'] or rows[0]['descricao'], 'marca': rows[0]['marca'] or '',
            'tamanho': rows[0]['tamanho'] or '', 'produto_id': rows[0]['produto_id'], 'tipo': rows[0]['tipo'],
            'compras': rows, 'por_loja': por_loja, 'descricoes': descricoes}


def gasto_por_tipo(c, inicio, fim):
    inicio, fim = ler_data(inicio).isoformat(), ler_data(fim).isoformat()
    tipos = c.execute('''SELECT i.tipo, SUM(i.total_centavos) v, COUNT(*) n FROM itens_nota i JOIN notas_fiscais n ON n.id=i.nota_id
                         WHERE n.data BETWEEN ? AND ? GROUP BY i.tipo ORDER BY v DESC''', (inicio, fim)).fetchall()
    lojas = c.execute('''SELECT loja, SUM(total_centavos) v, COUNT(*) n FROM notas_fiscais WHERE data BETWEEN ? AND ?
                         GROUP BY loja ORDER BY v DESC''', (inicio, fim)).fetchall()
    desconto = c.execute('SELECT COALESCE(SUM(desconto_centavos),0) FROM notas_fiscais WHERE data BETWEEN ? AND ?',
                         (inicio, fim)).fetchone()[0]
    return {'tipos': tipos, 'lojas': lojas, 'desconto': desconto}
