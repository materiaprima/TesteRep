"""Adivinha a categoria pela descrição: primeiro pelo que vocês já classificaram, depois por palavras comuns."""
import re
import unicodedata

PALAVRAS = {
    'Contas da casa': ('energia', 'enel', 'cpfl', 'sabesp', 'sanasa', 'comgas', 'conta de luz', 'conta de agua', 'internet',
                       'vivo fibra', 'claro net', 'tim fibra', 'oi fibra', 'celular', 'recarga'),
    'Pets': ('petz', 'cobasi', 'pet shop', 'petshop', 'veterinari', 'racao', 'banho e tosa'),
    'Academia e esportes': ('smart fit', 'smartfit', 'academia', 'bluefit', 'gympass', 'wellhub', 'crossfit', 'natacao'),
    'Serviços domésticos': ('diarista', 'faxina', 'lavanderia', 'passadeira'),
    'Filhos': ('fralda', 'ri happy', 'brinquedo', 'pediatra', 'creche', 'berçario', 'bercario'),
    'Transporte': ('uber', '99 ride', '99app', 'taxi', 'posto', 'gasolina', 'combustivel', 'etanol', 'estacionamento',
                   'pedagio', 'sem parar', 'onibus', 'metro', 'bilhete unico', 'pop '),
    'Mercado': ('mercado', 'supermercado', 'atacadao', 'assai', 'carrefour', 'padaria', 'hortifruti', 'acougue', 'feira',
                'pao de acucar', 'sams club', 'dia brasil'),
    'Restaurantes e delivery': ('ifood', 'restaurante', 'lanchonete', 'pizza', 'burger', 'mc donalds', 'mcdonalds', 'outback',
                                'cafe', 'cafeteria', 'rappi', 'delivery', 'churrascaria', 'sushi', 'bar '),
    'Farmácia e remédios': ('farmacia', 'drogaria', 'drogasil', 'droga raia', 'raia ', 'pacheco', 'pague menos', 'panvel',
                            'drogao', 'ultrafarma', 'sao joao farm'),
    'Saúde': ('medico', 'consulta', 'exame', 'dentista', 'odonto', 'hospital', 'laboratorio', 'clinica', 'unimed', 'fleury',
              'dasa', 'psicolog', 'fisioterap', 'amil', 'bradesco saude', 'sulamerica'),
    'Assinaturas': ('netflix', 'spotify', 'amazon prime', 'prime video', 'disney', 'hbo', 'youtube', 'openai', 'chatgpt',
                    'icloud', 'apple.com', 'google one', 'dl google', 'deezer', 'assinatura', 'globoplay', 'melimais'),
    'Moradia': ('aluguel', 'condominio', 'iptu', 'imobiliaria'),
    'Educação': ('escola', 'curso', 'faculdade', 'universidade', 'livraria', 'mensalidade escolar', 'udemy', 'alura'),
    'Vestuário': ('renner', 'riachuelo', 'c&a', 'cea ', 'zara', 'hering', 'centauro', 'netshoes', 'calcados', 'roupa'),
    'Lazer e viagens': ('cinema', 'cinemark', 'viagem', 'hotel', 'airbnb', 'booking', 'passagem', 'latam', 'gol linhas',
                        'azul linhas', 'ingresso', 'sympla', 'show'),
    'Juros, tarifas e IOF': ('tarifa', 'juros', 'iof', 'anuidade', 'encargo', 'multa'),
    'Beleza e cuidados': ('salao', 'cabelo', 'manicure', 'barbearia', 'estetica', 'boticario', 'natura', 'sephora'),
}


def normalizar(s):
    s = unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode().lower()
    return re.sub(r'\s+', ' ', s).strip()


def assinatura(descricao):
    s = normalizar(descricao)
    s = re.sub(r'\d+/\d+', ' ', s)
    s = re.sub(r'[\d\-\*\.#:/]+', ' ', s)
    return re.sub(r'\s+', ' ', s).strip()[:60]


def chave_grupo(descricao):
    """Chave curta para juntar linhas parecidas (ex.: as várias formas de 'UBER *TRIP')."""
    tokens = [t for t in assinatura(descricao).split(' ') if len(t) > 1 or t.isalpha()]
    return ' '.join(tokens[:2]) if tokens else ''


def inferir(c, descricao, tipo='despesa'):
    """(conta_id, motivo) ou None."""
    alvo = assinatura(descricao)
    if len(alvo) >= 3:
        for r in c.execute('''SELECT t.descricao, k.id, k.nome FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                              JOIN contas k ON k.id=l.conta_id WHERE k.tipo=? AND k.subtipo='categoria' AND k.ativa=1
                              ORDER BY t.id DESC LIMIT 3000''', (tipo,)):
            if assinatura(r['descricao']) == alvo:
                return r['id'], f'Como em lançamentos anteriores ({r["nome"]}).'
        grupo = chave_grupo(descricao)
        if len(grupo) >= 4:
            for r in c.execute('''SELECT t.descricao, k.id, k.nome FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                                  JOIN contas k ON k.id=l.conta_id WHERE k.tipo=? AND k.subtipo='categoria' AND k.ativa=1
                                  ORDER BY t.id DESC LIMIT 3000''', (tipo,)):
                if chave_grupo(r['descricao']) == grupo:
                    return r['id'], f'Parecido com "{r["descricao"][:40]}" ({r["nome"]}).'
    if tipo != 'despesa':
        return None
    texto = ' ' + normalizar(descricao) + ' '
    for nome, palavras in PALAVRAS.items():
        if any((' ' + p) in texto or texto.startswith(' ' + p) for p in palavras):
            row = c.execute("SELECT id FROM contas WHERE tipo='despesa' AND subtipo='categoria' AND nome=? AND ativa=1", (nome,)).fetchone()
            if row:
                return row[0], f'Pela descrição: {nome}.'
    return None
