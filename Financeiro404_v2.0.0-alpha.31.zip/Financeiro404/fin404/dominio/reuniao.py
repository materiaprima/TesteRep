"""Reunião financeira do mês (R13): 15 minutos, uma vez por mês, para quem não opera o sistema acompanhar.

Só junta o que já existe (resumo do mês, Raio-X, compras, alertas, a receber); nenhum cálculo novo de dinheiro.
Grava a data da reunião e as decisões. Lembra a partir do dia 10 se a do mês anterior não aconteceu.
"""
from datetime import date

from fin404.dinheiro import ErroValidacao, data as ler_data, formatar, mes as ler_mes, somar_meses

DIA_LEMBRETE = 10


def pauta(c, ym, hoje=None):
    from fin404.dominio import analises, compras, receber, relatorios
    ym = ler_mes(ym)
    hoje = ler_data(hoje or date.today())
    r = relatorios.resumo_mes(c, ym)
    rx = analises.raio_x(c, hoje)
    plano = compras.plano(c, hoje)
    limite = somar_meses(date(hoje.year, hoje.month, 1), 3).strftime('%Y-%m')
    proximas = sorted((it for it in plano['itens'] if it['mes_alvo'] and it['mes_alvo'] < limite and it['valor_centavos']),
                      key=lambda it: (it['mes_alvo'], -(it['valor_centavos'] or 0)))[:6]
    alertas = [(t, txt) for t, txt, _ in relatorios.alertas(c, hoje) if t in ('urgente', 'conferir')][:6]
    fora = analises.gastos_fora_do_padrao(c, ym)
    devem = receber.quem_deve(c, hoje)
    sugestoes = []
    if r['resultado'] < 0:
        sugestoes.append(f'O mês fechou {formatar(-r["resultado"])} no negativo: onde cortar no próximo?')
    for x in fora[:2]:
        sugestoes.append(f'{x["categoria"]} passou {formatar(x["excesso"])} da média: foi pontual ou mudou o padrão?')
    nao_cabem = [it for it in plano['itens'] if it['cabe'] is False]
    if nao_cabem:
        sugestoes.append('Compras que não cabem na sobra: ' + ', '.join(it['descricao'] for it in nao_cabem[:3])
                         + '. Adiar, parcelar ou cortar outro gasto?')
    for t, txt in alertas:
        if t == 'urgente' and len(sugestoes) < 5:
            sugestoes.append(txt)
    for x in devem:
        if x['dias'] > receber.DIAS_ALERTA:
            sugestoes.append(f'Combinar a devolução com {x["nome"]} ({formatar(x["aberto"])}).')
    if rx['custo_minimo'] > 0 and rx['cobertura_minimo'] is not None and rx['cobertura_minimo'] < 30:
        sugestoes.append('A reserva cobre menos de 3 meses do custo mínimo: quanto guardar por mês até chegar lá?')
    return {'mes': ym, 'resumo': r, 'raio_x': rx, 'proximas': proximas, 'alertas': alertas, 'sugestoes': sugestoes[:5],
            'registro': registro(c, ym)}


def registro(c, ym):
    return c.execute('SELECT * FROM reunioes_mes WHERE mes=?', (ler_mes(ym),)).fetchone()


def registrar(c, ym, feita_em, decisoes):
    from fin404.dados.banco import auditar
    ym = ler_mes(ym)
    feita_em = ler_data(feita_em)
    if feita_em.strftime('%Y-%m') < ym:
        raise ErroValidacao('A reunião de um mês acontece depois que ele começa.')
    decisoes = (decisoes or '').strip()[:2000]
    c.execute('''INSERT INTO reunioes_mes(mes, feita_em, decisoes) VALUES(?,?,?)
                 ON CONFLICT(mes) DO UPDATE SET feita_em=excluded.feita_em, decisoes=excluded.decisoes''',
              (ym, feita_em.isoformat(), decisoes))
    auditar(c, 'reuniao_mes', 'mes', None, ym)


def historico(c, limite=12):
    return c.execute('SELECT * FROM reunioes_mes ORDER BY mes DESC LIMIT ?', (limite,)).fetchall()


def lembrete(c, hoje=None):
    """Mês anterior sem reunião registrada, a partir do dia 10 (só se aquele mês teve lançamentos)."""
    hoje = ler_data(hoje or date.today())
    if hoje.day < DIA_LEMBRETE:
        return None
    anterior = somar_meses(date(hoje.year, hoje.month, 1), -1).strftime('%Y-%m')
    if registro(c, anterior):
        return None
    teve = c.execute("SELECT 1 FROM transacoes WHERE status<>'agendada' AND substr(data,1,7)=? LIMIT 1", (anterior,)).fetchone()
    return anterior if teve else None
