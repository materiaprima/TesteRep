"""Análises sobre o razão: custo do crédito, cobranças recorrentes, gastos fora do padrão, limite e apoio ao IRPF."""
from collections import defaultdict
from datetime import date, timedelta

from fin404.dinheiro import data as ler_data, fim_do_mes, formatar, somar_meses
from fin404.dominio import cartoes, razao
from fin404.dominio.categorias import assinatura

_REAL = "t.status<>'agendada'"
CUSTO_CREDITO = ('Juros, tarifas e IOF',)


def custo_credito(c, inicio, fim):
    """Juros, tarifas e IOF lançados no período (já descontados estornos)."""
    marc = ','.join('?' * len(CUSTO_CREDITO))
    return c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                         JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND t.data BETWEEN ? AND ?
                         AND k.tipo='despesa' AND k.nome IN ({marc})''', (str(inicio), str(fim), *CUSTO_CREDITO)).fetchone()[0]


def _mediana(valores):
    v = sorted(valores)
    n = len(v)
    return v[n // 2] if n % 2 else (v[n // 2 - 1] + v[n // 2]) // 2


def recorrentes(c, hoje=None, meses=6, minimo_meses=3):
    """Cobranças que se repetem em vários meses (assinaturas, contas fixas), sem contar parcelas.

    Agrupa pela descrição sem números. Aponta aumento quando o último valor passa 5% (e R$ 1) da mediana anterior.
    """
    hoje = ler_data(hoje or date.today())
    inicio = somar_meses(date(hoje.year, hoje.month, 1), -(meses - 1))
    por_assinatura = defaultdict(list)
    for r in c.execute(f'''SELECT t.id, t.data, t.descricao, l.valor_centavos v, k.nome categoria
                           FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id JOIN contas k ON k.id=l.conta_id
                           WHERE {_REAL} AND t.plano_id IS NULL AND t.tipo='despesa' AND k.tipo='despesa'
                           AND t.data BETWEEN ? AND ? ORDER BY t.data''', (inicio.isoformat(), hoje.isoformat())):
        chave = assinatura(r['descricao'])
        if len(chave) >= 3:
            por_assinatura[chave].append(r)
    itens = []
    for chave, linhas in por_assinatura.items():
        por_mes = {}
        for r in linhas:
            por_mes.setdefault(r['data'][:7], []).append(r)
        if len(por_mes) < minimo_meses or any(len(v) > 2 for v in por_mes.values()):
            continue  # pouco frequente, ou várias compras no mês (padaria, Uber): não é cobrança fixa
        mensais = [(ym, sum(x['v'] for x in v)) for ym, v in sorted(por_mes.items())]
        ultimo_ym, ultimo = mensais[-1]
        anteriores = [v for _, v in mensais[:-1]]
        base = _mediana(anteriores)
        aumento = ultimo - base if ultimo * 100 > base * 105 and ultimo - base >= 100 else 0
        if max(v for _, v in mensais) > 3 * min(v for _, v in mensais):
            continue  # valores muito diferentes: provavelmente lojas diferentes com nome parecido
        ult = linhas[-1]
        itens.append({'descricao': ult['descricao'], 'categoria': ult['categoria'], 'meses': len(por_mes),
                      'ultimo_mes': ultimo_ym, 'ultimo': ultimo, 'anterior': base, 'aumento': aumento,
                      'por_ano': ultimo * 12, 'ultima_data': ler_data(ult['data']), 'transacao_id': ult['id']})
    itens.sort(key=lambda x: -x['ultimo'])
    return itens


def gastos_fora_do_padrao(c, ym, fator_pct=130, minimo=5000):
    """Categorias cujo gasto no mês passa de 130% da média dos 3 meses anteriores (com pelo menos 2 meses de histórico)."""
    base = date.fromisoformat(ym + '-01')
    meses = [somar_meses(base, -i).strftime('%Y-%m') for i in (1, 2, 3)]
    hist = defaultdict(dict)
    for r in c.execute(f'''SELECT k.id, k.nome, substr(t.data,1,7) ym, SUM(l.valor_centavos) v FROM lancamentos l
                           JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                           WHERE {_REAL} AND k.tipo='despesa' AND t.data BETWEEN ? AND ? GROUP BY k.id, ym''',
                       (meses[-1] + '-01', fim_do_mes(ym).isoformat())):
        hist[(r['id'], r['nome'])][r['ym']] = r['v']
    itens = []
    for (cid, nome), por_mes in hist.items():
        anteriores = [por_mes[m] for m in meses if por_mes.get(m, 0) > 0]
        atual = por_mes.get(ym, 0)
        if len(anteriores) < 2 or atual <= 0:
            continue
        media = sum(anteriores) // len(anteriores)
        if atual * 100 > media * fator_pct and atual - media >= minimo:
            itens.append({'categoria_id': cid, 'categoria': nome, 'atual': atual, 'media': media, 'excesso': atual - media})
    itens.sort(key=lambda x: -x['excesso'])
    return itens


def limites_apertados(c, pct=90):
    itens = []
    for k in cartoes.lista(c):
        lim = cartoes.limite(c, k['id'])
        if lim and lim['limite'] > 0 and lim['comprometido'] * 100 >= lim['limite'] * pct:
            itens.append({'cartao': k, 'uso_pct': lim['comprometido'] * 100 // lim['limite'], **lim})
    return itens


SAUDE = 'Saúde'
FARMACIA = 'Farmácia e remédios'
EDUCACAO = 'Educação'


def irpf(c, ano):
    """Material de apoio para a declaração: despesas de saúde e educação e a posição em 31/12.

    Não calcula imposto nem aplica limites de dedução: as regras mudam a cada ano e dependem do caso.
    """
    inicio, fim = f'{ano}-01-01', f'{ano}-12-31'
    despesas = {}
    for nome in (SAUDE, EDUCACAO, FARMACIA):
        despesas[nome] = [dict(r) for r in c.execute(f'''SELECT t.id, t.data, t.descricao, l.valor_centavos v, p.nome pessoa
                                FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                                LEFT JOIN pessoas p ON p.id=l.pessoa_id
                                WHERE {_REAL} AND k.nome=? AND k.tipo='despesa' AND t.data BETWEEN ? AND ?
                                ORDER BY t.data''', (nome, inicio, fim))]
    from fin404.dominio.categorias import PALAVRAS, normalizar
    for x in despesas[SAUDE]:  # farmácia lançada em Saúde por engano (comum em dados antigos)
        texto = ' ' + normalizar(x['descricao']) + ' '
        x['parece_farmacia'] = any(' ' + p in texto for p in PALAVRAS['Farmácia e remédios'])
    saldos = razao.saldos_por_conta(c, date(ano, 12, 31))
    bens = [k for k in saldos if k['tipo'] == 'ativo' and k['saldo_natural']]
    dividas = [k for k in saldos if k['tipo'] == 'passivo' and k['saldo_natural']]
    saldos_ant = {k['id']: k['saldo_natural'] for k in razao.saldos_por_conta(c, date(ano - 1, 12, 31))}
    for k in bens + dividas:
        k['saldo_anterior'] = saldos_ant.get(k['id'], 0)
    receitas = c.execute(f'''SELECT k.nome, -SUM(l.valor_centavos) v FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                             JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND k.tipo='receita' AND t.data BETWEEN ? AND ?
                             GROUP BY k.id HAVING v<>0 ORDER BY v DESC''', (inicio, fim)).fetchall()
    return {'ano': ano, 'despesas': despesas, 'bens': bens, 'dividas': dividas,
            'receitas': [(r['nome'], r['v']) for r in receitas],
            'total_saude': sum(x['v'] for x in despesas[SAUDE]), 'total_educacao': sum(x['v'] for x in despesas[EDUCACAO]),
            'total_farmacia': sum(x['v'] for x in despesas[FARMACIA])}


def alertas_extras(c, hoje=None):
    """Alertas de padrão: limite quase no fim, categoria acima do normal, cobrança recorrente mais cara."""
    hoje = ler_data(hoje or date.today())
    itens = []
    for x in limites_apertados(c):
        nome = x["cartao"]["nome"]
        if x['disponivel'] < 0:
            texto = (f'Limite do cartão {nome} todo usado, contando as parcelas futuras: {formatar(-x["disponivel"])} acima do limite '
                     '(o banco mostra disponível R$ 0,00). Novas compras podem ser recusadas.')
        else:
            texto = f'Cartão {nome} com {x["uso_pct"]}% do limite comprometido, contando parcelas futuras (disponível {formatar(x["disponivel"])}).'
        itens.append(('conferir', texto, f'/cartoes/{x["cartao"]["id"]}'))
    ym = hoje.strftime('%Y-%m')
    for x in gastos_fora_do_padrao(c, ym)[:3]:
        itens.append(('conferir', f'{x["categoria"]}: {formatar(x["atual"])} neste mês, acima da média de {formatar(x["media"])}.',
                      f'/lancamentos?mes={ym}&categoria={x["categoria_id"]}'))
    ja = {x['categoria_id'] for x in gastos_fora_do_padrao(c, ym)[:3]}
    for x in tendencias(c, hoje)[:2]:
        if x['categoria_id'] not in ja:
            a, _, d = x['valores']
            itens.append(('conferir', f'{x["categoria"]} sobe há 3 meses seguidos: de {formatar(a)} para {formatar(d)} por mês.',
                          f'/lancamentos?categoria={x["categoria_id"]}'))
    for x in recorrentes(c, hoje):
        if x['aumento'] and (hoje - x['ultima_data']).days <= 40:
            itens.append(('conferir', f'"{x["descricao"][:40]}" subiu de {formatar(x["anterior"])} para {formatar(x["ultimo"])}.', '/recorrentes'))
    return itens


# ---------------------------------------------------------------- raio-x: custo de vida, reserva e cenários

NATUREZAS = ('essencial', 'comprometido', 'discricionario', None)
CEM = 100


def _meses_completos(hoje, n):
    base = date(hoje.year, hoje.month, 1)
    return [somar_meses(base, -i).strftime('%Y-%m') for i in range(n, 0, -1)]


def _despesas_por_mes(c, meses):
    """{(categoria_id, nome, natureza): {ym: valor}} sem as despesas de previsões anuais (essas entram como provisão)."""
    inicio, fim = meses[0] + '-01', fim_do_mes(meses[-1]).isoformat()
    por = defaultdict(dict)
    for r in c.execute(f'''SELECT k.id, k.nome, k.natureza, substr(t.data,1,7) ym, SUM(l.valor_centavos) v FROM lancamentos l
                           JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                           LEFT JOIN previsoes p ON p.id=t.previsao_id
                           WHERE {_REAL} AND k.tipo='despesa' AND t.data BETWEEN ? AND ?
                           AND COALESCE(p.frequencia, p.periodicidade, 'mensal') NOT IN ('bimestral','trimestral','semestral','anual') GROUP BY k.id, ym''', (inicio, fim)):
        por[(r['id'], r['nome'], r['natureza'])][r['ym']] = r['v']
    return por


def raio_x(c, hoje=None, meses=3, queda_pct=20):
    """Custo de vida mínimo (essencial + comprometido), quanto a reserva cobre e o que acontece se a renda cair."""
    from fin404.dominio import operacoes, relatorios
    hoje = ler_data(hoje or date.today())
    janela = _meses_completos(hoje, meses)
    por = _despesas_por_mes(c, janela)
    media = {n: 0 for n in NATUREZAS}
    categorias = []
    for (cid, nome, natureza), v in por.items():
        m = sum(v.values()) // meses
        if m <= 0:
            continue
        media[natureza] += m
        categorias.append({'id': cid, 'nome': nome, 'natureza': natureza, 'media': m})
    categorias.sort(key=lambda x: -x['media'])
    inicio, fim = janela[0] + '-01', fim_do_mes(janela[-1]).isoformat()
    receitas = -c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                              JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND k.tipo='receita' AND t.data BETWEEN ? AND ?''',
                          (inicio, fim)).fetchone()[0]
    renda = receitas // meses
    meses_com_dados = len({ym for v in por.values() for ym in v})
    prov = operacoes.provisoes_anuais(c)['por_mes']
    sem_classe = media[None]
    minimo = media['essencial'] + media['comprometido'] + sem_classe + prov   # sem classificação conta como essencial
    total = sum(media.values()) + prov
    pos = relatorios.posicao(c, hoje)
    # Liquidez: "imediata" é o que dá para usar hoje (contas, dinheiro, carteira) menos a dívida dos cartões.
    # "reserva" soma os investimentos, que podem levar dias para resgatar ou ter carência. Bens nunca entram.
    reserva_imediata = pos['disponivel'] - pos['cartoes']
    reserva = reserva_imediata + pos['investimentos']

    def cobertura(custo):
        return None if custo <= 0 else max(reserva, 0) * 10 // custo  # em décimos de mês

    nova_renda = renda * (100 - queda_pct) // CEM  # divisão inteira: continua em centavos

    def cenario(custo):
        deficit = custo - nova_renda
        return {'custo': custo, 'deficit': max(deficit, 0), 'sobra': max(-deficit, 0),
                'meses': (max(reserva, 0) * 10 // deficit) if deficit > 0 else None}
    return {'janela': janela, 'meses_com_dados': meses_com_dados, 'media': media, 'categorias': categorias,
            'provisao_mes': prov, 'custo_minimo': minimo, 'custo_total': total, 'renda': renda,
            'sobra': renda - total, 'reserva': reserva, 'reserva_imediata': reserva_imediata, 'posicao': pos,
            'cobertura_imediata': None if minimo <= 0 else max(reserva_imediata, 0) * 10 // minimo,
            'cobertura_minimo': cobertura(minimo), 'cobertura_total': cobertura(total),
            'queda_pct': queda_pct, 'nova_renda': nova_renda,
            'mantendo': cenario(total), 'cortando': cenario(minimo),
            'cortes': [x for x in categorias if x['natureza'] == 'discricionario'][:6],
            'sem_classificacao': [x for x in categorias if x['natureza'] is None]}


def tendencias(c, hoje=None, minimo=10000):
    """Categorias que cresceram três meses seguidos (mês a mês), somando pelo menos 30% e R$ 100 no período."""
    hoje = ler_data(hoje or date.today())
    janela = _meses_completos(hoje, 3)
    itens = []
    for (cid, nome, _), v in _despesas_por_mes(c, janela).items():
        a, b, d = (v.get(m, 0) for m in janela)
        if 0 < a < b < d and d * 100 >= a * 130 and d - a >= minimo:
            itens.append({'categoria_id': cid, 'categoria': nome, 'valores': (a, b, d), 'meses': janela})
    itens.sort(key=lambda x: -(x['valores'][2] - x['valores'][0]))
    return itens


# ---------------------------------------------------------------- evolução e folga

def evolucao(c, hoje=None, meses=12, top=4):
    """Séries mensais (fim de cada mês; o mês atual até hoje): patrimônio, disponível, dívida dos cartões,
    entradas, saídas e as categorias de despesa que mais pesaram no período."""
    from fin404.dominio import relatorios
    hoje = ler_data(hoje or date.today())
    base = date(hoje.year, hoje.month, 1)
    yms = [somar_meses(base, -i).strftime('%Y-%m') for i in range(meses - 1, -1, -1)]
    pat, disp, cart, ent, sai = [], [], [], [], []
    for ym in yms:
        fim = min(fim_do_mes(ym), hoje)
        p = relatorios.posicao(c, fim)
        pat.append(p['patrimonio_liquido']); disp.append(p['disponivel']); cart.append(p['cartoes'])
        m = relatorios.resumo_mes(c, ym)
        ent.append(m['total_receitas']); sai.append(m['total_despesas'])
    por = _despesas_por_mes(c, yms)
    tot = sorted(((sum(v.values()), nome, v) for (_, nome, _), v in por.items()), reverse=True)[:top]
    cats = [(nome, [v.get(ym, 0) for ym in yms]) for _, nome, v in tot]
    return {'meses': yms, 'patrimonio': pat, 'disponivel': disp, 'cartoes': cart, 'entradas': ent, 'saidas': sai,
            'categorias': cats}


def folga_dias(c, hoje=None, dias=90):
    """Quantos dias de gasto o dinheiro livre hoje cobre, pela média de despesas dos últimos 90 dias.

    Dinheiro livre = disponível − dívida atual dos cartões (a fatura vai sair dele). Investimentos não entram.

    Menos de 30 = vivendo do salário do mês; acima de 30 = um mês de folga.
    """
    from fin404.dominio import relatorios
    hoje = ler_data(hoje or date.today())
    inicio = (hoje - timedelta(days=dias)).isoformat()
    gasto = c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                          JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND k.tipo='despesa' AND t.data>? AND t.data<=?''',
                      (inicio, hoje.isoformat())).fetchone()[0]
    primeiro = c.execute(f"SELECT MIN(t.data) FROM transacoes t WHERE {_REAL} AND t.tipo='despesa'").fetchone()[0]
    if not gasto or not primeiro:
        return None
    janela = min(dias, max((hoje - ler_data(primeiro)).days + 1, 1))
    pos = relatorios.posicao(c, hoje)
    livre = pos['disponivel'] - pos['cartoes']
    return {'dias': max(livre, 0) * janela // gasto, 'gasto_dia': gasto // janela, 'disponivel': pos['disponivel'],
            'cartoes': pos['cartoes'], 'livre': livre, 'janela': janela}
