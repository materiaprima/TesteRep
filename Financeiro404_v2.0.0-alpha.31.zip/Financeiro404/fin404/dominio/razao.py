"""Livro-razão de partidas dobradas: contas, transações e lançamentos.

Único caminho de escrita de transações. Invariantes garantidas aqui:
- toda transação tem ao menos dois lançamentos e soma zero;
- nenhum valor é zero ou float;
- tipos de conta compatíveis com o tipo de transação;
- mês fechado não aceita escrita (também garantido por gatilho no banco).
"""
import json
import sqlite3
from datetime import date

from fin404.dados.banco import auditar
from fin404.dinheiro import ErroValidacao, data as ler_data, formatar

SUBTIPOS = {
    'corrente': ('ativo', 'Conta corrente'),
    'poupanca': ('ativo', 'Poupança'),
    'dinheiro': ('ativo', 'Dinheiro em espécie'),
    'carteira': ('ativo', 'Carteira digital / benefício'),
    'investimento': ('ativo', 'Investimento'),
    'bem': ('ativo', 'Bem (imóvel, veículo)'),
    'cartao': ('passivo', 'Cartão de crédito'),
    'emprestimo': ('passivo', 'Empréstimo / financiamento'),
    'outro_passivo': ('passivo', 'Outra dívida'),
}
DISPONIVEIS = ('corrente', 'poupanca', 'dinheiro', 'carteira')

TIPOS_TRANSACAO = {
    'receita': 'Receita', 'despesa': 'Despesa', 'transferencia': 'Transferência',
    'pagamento_fatura': 'Pagamento de fatura', 'estorno': 'Estorno', 'ajuste': 'Ajuste',
    'abertura': 'Saldo inicial', 'rendimento': 'Rendimento',
}
_PERMITIDOS = {
    'receita': {'ativo', 'passivo', 'receita'},
    'despesa': {'ativo', 'passivo', 'despesa'},
    'transferencia': {'ativo', 'passivo'},
    'pagamento_fatura': {'ativo', 'passivo', 'despesa'},
    'estorno': {'ativo', 'passivo', 'despesa', 'receita'},
    'ajuste': {'ativo', 'passivo', 'despesa', 'receita', 'patrimonio'},
    'abertura': {'ativo', 'passivo', 'patrimonio'},
    'rendimento': {'ativo', 'receita'},
}
NATUREZA_CREDORA = {'passivo', 'receita', 'patrimonio'}


def _erro_banco(exc):
    if 'MES_FECHADO' in str(exc):
        return ErroValidacao('Este mês está fechado. Reabra o mês em "Fechamento" para alterar lançamentos dele.')
    return exc


# ---------------------------------------------------------------- contas

def contas(c, tipo=None, subtipos=None, incluir_inativas=False, incluir_papeis=False):
    """Contas para listas e escolhas. Contas com papel especial (valores a receber) só com `incluir_papeis`:
    elas são movimentadas pelas telas próprias, não escolhidas como conta de pagamento."""
    sql = 'SELECT * FROM contas WHERE 1=1'
    args = []
    if not incluir_papeis:
        sql += ' AND papel IS NULL'
    if tipo:
        sql += ' AND tipo=?'; args.append(tipo)
    if subtipos:
        sql += f' AND subtipo IN ({",".join("?" * len(subtipos))})'; args.extend(subtipos)
    if not incluir_inativas:
        sql += ' AND ativa=1'
    return c.execute(sql + ' ORDER BY tipo, nome', args).fetchall()


def conta(c, conta_id):
    row = c.execute('SELECT * FROM contas WHERE id=?', (conta_id,)).fetchone()
    if row is None:
        raise ErroValidacao('Conta não encontrada.')
    return row


def conta_sistema(c, subtipo):
    return c.execute('SELECT id FROM contas WHERE subtipo=? ORDER BY id LIMIT 1', (subtipo,)).fetchone()[0]


def criar_conta(c, nome, subtipo, tipo_categoria=None, instituicao='', dia_fechamento=None,
                dia_vencimento=None, limite_centavos=None, titular_id=None, identificador_externo='', regra_fechamento='proxima'):
    nome = (nome or '').strip()
    if not 1 <= len(nome) <= 80:
        raise ErroValidacao('Informe um nome de até 80 caracteres.')
    if subtipo == 'categoria':
        if tipo_categoria not in ('receita', 'despesa'):
            raise ErroValidacao('Categoria deve ser de receita ou de despesa.')
        tipo = tipo_categoria
    elif subtipo in SUBTIPOS:
        tipo = SUBTIPOS[subtipo][0]
    else:
        raise ErroValidacao('Tipo de conta inválido.')
    if subtipo == 'cartao':
        try:
            dia_fechamento, dia_vencimento = int(dia_fechamento), int(dia_vencimento)
        except (TypeError, ValueError):
            raise ErroValidacao('Cartão precisa de dia de fechamento e dia de vencimento.')
        if not (1 <= dia_fechamento <= 31 and 1 <= dia_vencimento <= 31):
            raise ErroValidacao('Dias de fechamento e vencimento devem estar entre 1 e 31.')
    else:
        dia_fechamento = dia_vencimento = None
    if c.execute('SELECT 1 FROM contas WHERE tipo=? AND lower(nome)=lower(?)', (tipo, nome)).fetchone():
        raise ErroValidacao(f'Já existe uma conta chamada "{nome}".')
    if regra_fechamento not in ('proxima', 'atual'):
        raise ErroValidacao('Regra de fechamento inválida.')
    cid = c.execute('''INSERT INTO contas(nome,tipo,subtipo,instituicao,dia_fechamento,dia_vencimento,
                       limite_centavos,titular_id,identificador_externo,regra_fechamento) VALUES(?,?,?,?,?,?,?,?,?,?)''',
                    (nome, tipo, subtipo, (instituicao or '').strip()[:80], dia_fechamento, dia_vencimento,
                     limite_centavos, titular_id, (identificador_externo or '').strip()[:80], regra_fechamento)).lastrowid
    auditar(c, 'criar', 'conta', cid, nome)
    return cid


def atualizar_conta(c, conta_id, nome, instituicao='', dia_fechamento=None, dia_vencimento=None,
                    limite_centavos=None, titular_id=None, identificador_externo='', ativa=True, regra_fechamento=None):
    atual = conta(c, conta_id)
    nome = (nome or '').strip()
    if not 1 <= len(nome) <= 80:
        raise ErroValidacao('Informe um nome de até 80 caracteres.')
    if atual['subtipo'] == 'cartao':
        try:
            dia_fechamento, dia_vencimento = int(dia_fechamento), int(dia_vencimento)
        except (TypeError, ValueError):
            raise ErroValidacao('Cartão precisa de dia de fechamento e dia de vencimento.')
    else:
        dia_fechamento = dia_vencimento = None
    if atual['subtipo'] in ('abertura', 'ajuste'):
        raise ErroValidacao('Contas do sistema não podem ser alteradas.')
    if c.execute('SELECT 1 FROM contas WHERE tipo=? AND lower(nome)=lower(?) AND id<>?',
                 (atual['tipo'], nome, conta_id)).fetchone():
        raise ErroValidacao(f'Já existe uma conta chamada "{nome}".')
    regra_fechamento = regra_fechamento or atual['regra_fechamento']
    if regra_fechamento not in ('proxima', 'atual'):
        raise ErroValidacao('Regra de fechamento inválida.')
    c.execute('''UPDATE contas SET nome=?,instituicao=?,dia_fechamento=?,dia_vencimento=?,limite_centavos=?,
                 titular_id=?,identificador_externo=?,ativa=?,regra_fechamento=? WHERE id=?''',
              (nome, (instituicao or '').strip()[:80], dia_fechamento, dia_vencimento, limite_centavos,
               titular_id, (identificador_externo or '').strip()[:80], 1 if ativa else 0, regra_fechamento, conta_id))
    auditar(c, 'editar', 'conta', conta_id, json.dumps(dict(atual), default=str, ensure_ascii=False))


# ---------------------------------------------------------------- transações

def registrar(c, quando, descricao, tipo, lancamentos, status='confirmada', plano_id=None, parcela_n=None,
              previsao_id=None, estorno_de=None, lote_id=None, chave_origem=None, observacao=''):
    """lancamentos: lista de (conta_id, valor_centavos[, pessoa_id])."""
    quando = ler_data(quando).isoformat()
    descricao = (descricao or '').strip()
    if not 1 <= len(descricao) <= 200:
        raise ErroValidacao('Informe uma descrição de até 200 caracteres.')
    if tipo not in TIPOS_TRANSACAO:
        raise ErroValidacao('Tipo de transação inválido.')
    if status not in ('agendada', 'confirmada', 'conciliada'):
        raise ErroValidacao('Situação inválida.')
    linhas = []
    for item in lancamentos:
        conta_id, valor = item[0], item[1]
        pessoa = item[2] if len(item) > 2 else None
        if type(valor) is not int:
            raise TypeError('Valores devem ser inteiros em centavos.')
        if valor == 0:
            continue
        linhas.append((int(conta_id), valor, pessoa))
    if len(linhas) < 2:
        raise ErroValidacao('A transação precisa movimentar ao menos duas contas.')
    if sum(v for _, v, _ in linhas) != 0:
        raise ErroValidacao('Transação desequilibrada: a soma dos lançamentos deve ser zero.')
    tipos = {}
    for conta_id, _, _ in linhas:
        row = c.execute('SELECT tipo, ativa FROM contas WHERE id=?', (conta_id,)).fetchone()
        if row is None:
            raise ErroValidacao('Conta inexistente na transação.')
        tipos[conta_id] = row['tipo']
    usados = set(tipos.values())
    if not usados <= _PERMITIDOS[tipo]:
        raise ErroValidacao(f'Contas incompatíveis com {TIPOS_TRANSACAO[tipo].lower()}.')
    if tipo == 'receita' and 'receita' not in usados:
        raise ErroValidacao('Receita precisa de uma categoria de receita.')
    if tipo == 'despesa' and 'despesa' not in usados:
        raise ErroValidacao('Despesa precisa de uma categoria de despesa.')
    if tipo == 'pagamento_fatura' and not any(tipos[a] == 'passivo' and v > 0 for a, v, _ in linhas):
        raise ErroValidacao('Pagamento de fatura precisa abater uma dívida.')
    if len({a for a, _, _ in linhas}) != len(linhas) and tipo != 'ajuste':
        raise ErroValidacao('A mesma conta aparece duas vezes na transação.')
    try:
        tid = c.execute('''INSERT INTO transacoes(data,descricao,tipo,status,plano_id,parcela_n,previsao_id,
                           estorno_de,lote_id,chave_origem,observacao) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
                        (quando, descricao, tipo, status, plano_id, parcela_n, previsao_id, estorno_de,
                         lote_id, chave_origem, (observacao or '')[:500])).lastrowid
        c.executemany('INSERT INTO lancamentos(transacao_id,conta_id,valor_centavos,pessoa_id) VALUES(?,?,?,?)',
                      [(tid, a, v, p) for a, v, p in linhas])
    except sqlite3.IntegrityError as exc:
        raise _erro_banco(exc)
    return tid


def transacao(c, tid):
    t = c.execute('SELECT * FROM transacoes WHERE id=?', (tid,)).fetchone()
    if t is None:
        raise ErroValidacao('Lançamento não encontrado.')
    return t


def lancamentos_de(c, tid):
    return c.execute('''SELECT l.*, k.nome conta_nome, k.tipo conta_tipo, k.subtipo conta_subtipo, p.nome pessoa
                        FROM lancamentos l JOIN contas k ON k.id=l.conta_id LEFT JOIN pessoas p ON p.id=l.pessoa_id
                        WHERE l.transacao_id=? ORDER BY l.valor_centavos DESC''', (tid,)).fetchall()


def snapshot(c, tid):
    tags = [r[0] for r in c.execute('SELECT g.nome FROM tags g JOIN transacao_tags x ON x.tag_id=g.id WHERE x.transacao_id=?', (tid,))]
    return json.dumps({'transacao': dict(transacao(c, tid)),
                       'lancamentos': [dict(x) for x in lancamentos_de(c, tid)], 'tags': tags}, default=str, ensure_ascii=False)


def excluir(c, tid, plano_inteiro=False):
    t = transacao(c, tid)
    if c.execute('SELECT 1 FROM transacoes WHERE estorno_de=?', (tid,)).fetchone():
        raise ErroValidacao('Esta compra tem estorno registrado. Exclua o estorno antes.')
    alvos = [tid]
    if t['plano_id'] and plano_inteiro:
        alvos = [r[0] for r in c.execute('SELECT id FROM transacoes WHERE plano_id=?', (t['plano_id'],))]
        if c.execute(f'SELECT 1 FROM transacoes WHERE estorno_de IN ({",".join("?" * len(alvos))})', alvos).fetchone():
            raise ErroValidacao('Alguma parcela tem estorno registrado. Exclua o estorno antes.')
    try:
        for alvo in alvos:
            auditar(c, 'excluir', 'transacao', alvo, snapshot(c, alvo))
            c.execute("UPDATE linhas_importacao SET situacao='nova', transacao_id=NULL WHERE transacao_id=?", (alvo,))
            c.execute('DELETE FROM transacoes WHERE id=?', (alvo,))
        if t['plano_id'] and plano_inteiro:
            c.execute('DELETE FROM planos_parcelas WHERE id=?', (t['plano_id'],))
    except sqlite3.IntegrityError as exc:
        raise _erro_banco(exc)
    return len(alvos)


def lixeira(c, dias=90):
    """Transações excluídas nos últimos `dias` e ainda não restauradas (a partir da auditoria)."""
    rows = c.execute('''SELECT a.* FROM auditoria a WHERE a.acao='excluir' AND a.entidade='transacao'
                         AND a.em >= datetime('now', ?) AND NOT EXISTS(SELECT 1 FROM auditoria r WHERE r.acao='restaurar'
                         AND r.entidade='auditoria' AND r.entidade_id=a.id) ORDER BY a.id DESC''', (f'-{int(dias)} days',)).fetchall()
    itens = []
    for r in rows:
        try:
            dados = json.loads(r['detalhes'])
            itens.append({'auditoria_id': r['id'], 'em': r['em'], 'transacao': dados['transacao'], 'lancamentos': dados['lancamentos']})
        except (ValueError, KeyError):
            continue
    return itens


def restaurar(c, auditoria_id):
    """Recria uma transação excluída a partir da cópia guardada na auditoria (ganha um número novo)."""
    r = c.execute("SELECT * FROM auditoria WHERE id=? AND acao='excluir' AND entidade='transacao'", (auditoria_id,)).fetchone()
    if r is None:
        raise ErroValidacao('Item não encontrado na lixeira.')
    if c.execute("SELECT 1 FROM auditoria WHERE acao='restaurar' AND entidade='auditoria' AND entidade_id=?", (auditoria_id,)).fetchone():
        raise ErroValidacao('Este lançamento já foi restaurado.')
    try:
        dados = json.loads(r['detalhes'])
        t, ls = dados['transacao'], dados['lancamentos']
    except (ValueError, KeyError):
        raise ErroValidacao('A cópia guardada deste lançamento está incompleta.')
    for x in ls:
        if not c.execute('SELECT 1 FROM contas WHERE id=?', (x['conta_id'],)).fetchone():
            raise ErroValidacao('Uma das contas deste lançamento não existe mais.')
    plano = t.get('plano_id') if t.get('plano_id') and c.execute('SELECT 1 FROM planos_parcelas WHERE id=?', (t['plano_id'],)).fetchone() else None
    original = t.get('estorno_de') if t.get('estorno_de') and c.execute('SELECT 1 FROM transacoes WHERE id=?', (t['estorno_de'],)).fetchone() else None
    if t['tipo'] == 'estorno' and t.get('estorno_de') and not original:
        original = None
    novo = registrar(c, t['data'], t['descricao'], t['tipo'],
                     [(x['conta_id'], x['valor_centavos'], x.get('pessoa_id')) for x in ls],
                     status=t['status'], plano_id=plano, parcela_n=t.get('parcela_n') if plano else None,
                     estorno_de=original, observacao=t.get('observacao') or '')
    if t.get('meio_pagamento'):
        c.execute('UPDATE transacoes SET meio_pagamento=? WHERE id=?', (t['meio_pagamento'], novo))
    if dados.get('tags'):
        from fin404.dominio import tags as _tags
        _tags.adicionar(c, [novo], ', '.join(dados['tags']))
    auditar(c, 'restaurar', 'auditoria', auditoria_id, f'transacao {novo}')
    return novo


def editar(c, tid, descricao, quando, observacao='', valor=None, contraparte_id=None, pessoa_id=None, conta_id=None):
    """Edita descrição, data e observação; em transações simples (2 lançamentos), também valor,
    categoria/conta de contrapartida e pessoa."""
    t = transacao(c, tid)
    antes = snapshot(c, tid)
    quando = ler_data(quando).isoformat()
    descricao = (descricao or '').strip()
    if not 1 <= len(descricao) <= 200:
        raise ErroValidacao('Informe uma descrição de até 200 caracteres.')
    linhas = lancamentos_de(c, tid)
    try:
        c.execute('UPDATE transacoes SET descricao=?, data=?, observacao=? WHERE id=?',
                  (descricao, quando, (observacao or '')[:500], tid))
        if (valor is not None or contraparte_id is not None or conta_id is not None) and len(linhas) == 2 and t['tipo'] in ('receita', 'despesa', 'transferencia', 'pagamento_fatura'):
            # Lado "categoria" é o de receita/despesa; em transferências, o lado positivo.
            if t['tipo'] in ('receita', 'despesa'):
                lado = next(x for x in linhas if x['conta_tipo'] in ('receita', 'despesa'))
            else:
                lado = next(x for x in linhas if x['valor_centavos'] > 0)
            outro = next(x for x in linhas if x['id'] != lado['id'])
            novo_valor = abs(lado['valor_centavos']) if valor is None else int(valor)
            if novo_valor <= 0:
                raise ErroValidacao('Informe um valor positivo.')
            sinal = 1 if lado['valor_centavos'] > 0 else -1
            nova_conta = int(contraparte_id) if contraparte_id else lado['conta_id']
            tipo_nova = conta(c, nova_conta)['tipo']
            if tipo_nova != lado['conta_tipo']:
                raise ErroValidacao('A nova conta precisa ser do mesmo tipo da anterior.')
            if nova_conta == outro['conta_id']:
                raise ErroValidacao('As duas contas da transação devem ser diferentes.')
            c.execute('UPDATE lancamentos SET valor_centavos=?, conta_id=?, pessoa_id=? WHERE id=?',
                      (sinal * novo_valor, nova_conta, pessoa_id if pessoa_id is not None else lado['pessoa_id'], lado['id']))
            nova_outra = outro['conta_id']
            if conta_id and int(conta_id) != outro['conta_id']:
                # trocar a conta ou o cartão por onde o dinheiro passou (lançou no cartão errado, no Pix em vez do débito…)
                k_nova = conta(c, int(conta_id))
                if k_nova['tipo'] not in ('ativo', 'passivo'):
                    raise ErroValidacao('Escolha uma conta, cartão ou dívida.')
                if t['plano_id']:
                    raise ErroValidacao('Parcela não muda de cartão sozinha: use "Mover a compra para outro cartão", logo abaixo, que leva todas as parcelas juntas.')
                if int(conta_id) == nova_conta:
                    raise ErroValidacao('As duas contas da transação devem ser diferentes.')
                nova_outra = int(conta_id)
            c.execute('UPDATE lancamentos SET valor_centavos=?, conta_id=? WHERE id=?', (-sinal * novo_valor, nova_outra, outro['id']))
            if t['tipo'] == 'despesa' or t['tipo'] == 'receita':
                estornado = total_estornado(c, tid)
                if estornado > novo_valor:
                    raise ErroValidacao('O novo valor é menor do que o total já estornado.')
    except sqlite3.IntegrityError as exc:
        raise _erro_banco(exc)
    verificar_transacao(c, tid)
    auditar(c, 'editar', 'transacao', tid, antes)


def confirmar(c, tid, novo_status='confirmada'):
    try:
        c.execute('UPDATE transacoes SET status=? WHERE id=?', (novo_status, tid))
    except sqlite3.IntegrityError as exc:
        raise _erro_banco(exc)


def verificar_transacao(c, tid):
    soma, n = c.execute('SELECT COALESCE(SUM(valor_centavos),0), COUNT(*) FROM lancamentos WHERE transacao_id=?', (tid,)).fetchone()
    if soma != 0 or n < 2:
        raise ErroValidacao('Transação desequilibrada.')


def total_estornado(c, tid):
    """Quanto da despesa original já foi estornado (valor positivo)."""
    return -c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                         JOIN contas k ON k.id=l.conta_id WHERE t.estorno_de=? AND k.tipo='despesa' ''',
                      (tid,)).fetchone()[0]


def estornar(c, original_id, valor, quando, descricao=None):
    """Estorno parcial ou total de uma despesa: devolve o valor à conta/cartão da compra
    e reduz a despesa da mesma categoria."""
    t = transacao(c, original_id)
    if t['tipo'] != 'despesa':
        raise ErroValidacao('Só é possível estornar despesas.')
    linhas = lancamentos_de(c, original_id)
    cat = [x for x in linhas if x['conta_tipo'] == 'despesa']
    pag = [x for x in linhas if x['conta_tipo'] in ('ativo', 'passivo')]
    if len(cat) != 1 or len(pag) != 1:
        raise ErroValidacao('Estorno automático só funciona em despesas com uma categoria e uma conta.')
    original = cat[0]['valor_centavos']
    ja = total_estornado(c, original_id)
    if valor <= 0 or ja + valor > original:
        raise ErroValidacao(f'O estorno excede o valor da compra. Ainda pode ser estornado: {formatar(original - ja)}.')
    return registrar(c, quando, descricao or f'Estorno: {t["descricao"]}', 'estorno',
                     [(pag[0]['conta_id'], valor), (cat[0]['conta_id'], -valor, cat[0]['pessoa_id'])],
                     estorno_de=original_id)


# ---------------------------------------------------------------- saldos

def saldo(c, conta_id, ate=None, incluir_agendadas=False):
    """Saldo contábil (débito positivo) até a data, inclusive."""
    sql = '''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
             WHERE l.conta_id=?'''
    args = [conta_id]
    if ate is not None:
        sql += ' AND t.data<=?'; args.append(ler_data(ate).isoformat())
    if not incluir_agendadas:
        sql += " AND t.status<>'agendada'"
    return c.execute(sql, args).fetchone()[0]


def saldo_natural(c, conta_row, ate=None, incluir_agendadas=False):
    """Saldo no sentido natural: dívida positiva para passivos, receita positiva para receitas."""
    s = saldo(c, conta_row['id'], ate, incluir_agendadas)
    return -s if conta_row['tipo'] in NATUREZA_CREDORA else s


def saldos_por_conta(c, ate=None, tipos=('ativo', 'passivo')):
    ate = ler_data(ate or date.today()).isoformat()
    rows = c.execute(f'''SELECT k.*, COALESCE(SUM(CASE WHEN t.status<>'agendada' AND t.data<=? THEN l.valor_centavos END),0) saldo
                         FROM contas k LEFT JOIN lancamentos l ON l.conta_id=k.id LEFT JOIN transacoes t ON t.id=l.transacao_id
                         WHERE k.tipo IN ({",".join("?" * len(tipos))}) AND k.ativa=1
                         GROUP BY k.id ORDER BY k.tipo, k.subtipo, k.nome''', [ate, *tipos]).fetchall()
    return [dict(r, saldo_natural=(-r['saldo'] if r['tipo'] in NATUREZA_CREDORA else r['saldo'])) for r in rows]


def verificar_tudo(c):
    problemas = []
    for r in c.execute('SELECT transacao_id, SUM(valor_centavos) s, COUNT(*) n FROM lancamentos GROUP BY transacao_id HAVING s<>0 OR n<2'):
        problemas.append(f'Transação {r[0]} desequilibrada')
    for r in c.execute('SELECT t.id FROM transacoes t LEFT JOIN lancamentos l ON l.transacao_id=t.id WHERE l.id IS NULL'):
        problemas.append(f'Transação {r[0]} sem lançamentos')
    for r in c.execute('''SELECT o.id, (SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN contas k ON k.id=l.conta_id
                              WHERE l.transacao_id=o.id AND k.tipo='despesa') valor,
                             (SELECT -COALESCE(SUM(l.valor_centavos),0) FROM transacoes e JOIN lancamentos l ON l.transacao_id=e.id
                              JOIN contas k ON k.id=l.conta_id WHERE e.estorno_de=o.id AND k.tipo='despesa') estornado
                          FROM transacoes o WHERE o.tipo='despesa' '''):
        if r['estornado'] and r['estornado'] > r['valor']:
            problemas.append(f'Estorno acima da compra na transação {r["id"]}')
    return problemas


# ---------------------------------------------------------------- exclusão de cadastros

def uso_da_conta(c, conta_id):
    """O que impede ou acompanha a exclusão de uma conta, cartão ou categoria."""
    movs = c.execute('''SELECT CASE WHEN t.status='agendada' THEN 'agendada' ELSE t.tipo END tipo, COUNT(DISTINCT t.id) n
                        FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id WHERE l.conta_id=? GROUP BY 1''', (conta_id,)).fetchall()
    por_tipo = {r['tipo']: r['n'] for r in movs}
    return {
        'lancamentos': sum(n for t, n in por_tipo.items() if t not in ('abertura', 'agendada')),
        'previstos': por_tipo.get('agendada', 0),
        'aberturas': por_tipo.get('abertura', 0),
        'importacoes': c.execute('SELECT COUNT(*) FROM lotes_importacao WHERE conta_id=? AND desfeito_em IS NULL', (conta_id,)).fetchone()[0],
        'previsoes': c.execute('SELECT COUNT(*) FROM previsoes WHERE conta_id=? OR contraparte_id=?', (conta_id, conta_id)).fetchone()[0],
        'parcelamentos': c.execute('SELECT COUNT(*) FROM planos_parcelas WHERE conta_cartao_id=?', (conta_id,)).fetchone()[0],
    }


PROTEGIDAS = {'Gastos não identificados', 'Entradas não identificadas', 'Juros, tarifas e IOF', 'Rendimentos de investimentos',
              'Dívidas antigas e parcelamentos', 'Outras receitas', 'Outras despesas'}


def excluir_conta(c, conta_id):
    """Exclui conta, cartão ou categoria que não tem histórico.

    Pode excluir junto: o saldo inicial, importações já desfeitas, previsões que a usam (e os previstos não confirmados delas),
    orçamentos, regras e datas de fechamento. Com lançamentos de verdade, recusa: o caminho é desativar (o histórico fica).
    """
    k = conta(c, conta_id)
    if k['tipo'] == 'patrimonio' or (k['tipo'] in ('receita', 'despesa') and k['nome'] in PROTEGIDAS):
        raise ErroValidacao('Esta conta é usada internamente e não pode ser excluída.')
    u = uso_da_conta(c, conta_id)
    oque = 'categoria' if k['tipo'] in ('receita', 'despesa') else 'conta'
    if u['lancamentos']:
        raise ErroValidacao(f'Esta {oque} tem {u["lancamentos"]} lançamento(s). Para não perder o histórico, desative em vez de excluir '
                            '(ela some dos formulários). Se foi criada por engano, exclua ou mude os lançamentos antes.')
    if u['importacoes']:
        raise ErroValidacao('Há importações ativas nesta conta. Desfaça-as em Importações antes de excluir.')
    if u['parcelamentos']:
        raise ErroValidacao('Há parcelamentos ligados a este cartão. Exclua os lançamentos deles antes.')
    for (tid,) in c.execute('''SELECT DISTINCT t.id FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id
                               WHERE l.conta_id=?''', (conta_id,)).fetchall():
        excluir(c, tid)  # só sobram saldo inicial e previstos: vão para a lixeira
    for (pid,) in c.execute('SELECT id FROM previsoes WHERE conta_id=? OR contraparte_id=?', (conta_id, conta_id)).fetchall():
        for (tid,) in c.execute("SELECT id FROM transacoes WHERE previsao_id=? AND status='agendada'", (pid,)).fetchall():
            excluir(c, tid)
        c.execute('DELETE FROM previsoes WHERE id=?', (pid,))
    c.execute('DELETE FROM lotes_importacao WHERE conta_id=? AND desfeito_em IS NOT NULL', (conta_id,))
    c.execute('DELETE FROM faturas_documento WHERE conta_cartao_id=?', (conta_id,))
    c.execute('DELETE FROM contas WHERE id=?', (conta_id,))
    from fin404.dados.banco import auditar
    auditar(c, 'excluir_conta', 'conta', conta_id, f'{k["nome"]} ({k["tipo"]}/{k["subtipo"]})')
    return k['nome']


def excluir_pessoa(c, pessoa_id):
    p = c.execute('SELECT * FROM pessoas WHERE id=?', (pessoa_id,)).fetchone()
    if p is None:
        raise ErroValidacao('Pessoa não encontrada.')
    n = c.execute('SELECT COUNT(*) FROM lancamentos WHERE pessoa_id=?', (pessoa_id,)).fetchone()[0]
    c.execute('DELETE FROM pessoas WHERE id=?', (pessoa_id,))
    from fin404.dados.banco import auditar
    auditar(c, 'excluir_pessoa', 'pessoa', pessoa_id, f'{p["nome"]}; {n} lançamento(s) ficaram sem pessoa')
    return p['nome'], n


def dividir(c, tid, partes):
    """Reparte a categoria de uma despesa ou receita em várias (ex.: mercado + farmácia na mesma nota).

    `partes` = [(categoria_id, valor_centavos > 0), …], somando o valor do lançamento. A conta ou cartão não muda.
    Com uma parte só, troca a categoria (e desfaz uma divisão anterior).
    """
    t = transacao(c, tid)
    if t['tipo'] not in ('despesa', 'receita'):
        raise ErroValidacao('Só despesas e receitas podem ser divididas por categoria.')
    if total_estornado(c, tid):
        raise ErroValidacao('Este lançamento tem estorno; divida antes de estornar.')
    linhas = lancamentos_de(c, tid)
    tipo_cat = 'despesa' if t['tipo'] == 'despesa' else 'receita'
    cats = [x for x in linhas if x['conta_tipo'] == tipo_cat]
    total = abs(sum(x['valor_centavos'] for x in cats))
    sinal = 1 if t['tipo'] == 'despesa' else -1
    partes = [(int(k), int(v)) for k, v in partes if k and v]
    if not partes:
        raise ErroValidacao('Informe ao menos uma categoria com valor.')
    if any(v <= 0 for _, v in partes):
        raise ErroValidacao('Os valores das partes precisam ser positivos.')
    soma = sum(v for _, v in partes)
    if soma != total:
        raise ErroValidacao(f'As partes somam {formatar(soma)}, mas o lançamento é de {formatar(total)}: '
                            + (f'faltam {formatar(total - soma)}.' if soma < total else f'sobram {formatar(soma - total)}.'))
    for k, _ in partes:
        if conta(c, k)['tipo'] != tipo_cat:
            raise ErroValidacao('Escolha só categorias de ' + ('despesa.' if tipo_cat == 'despesa' else 'receita.'))
    antes = snapshot(c, tid)
    pessoa = cats[0]['pessoa_id'] if cats else None
    try:
        for x in cats:
            c.execute('DELETE FROM lancamentos WHERE id=?', (x['id'],))
        juntas = {}
        for k, v in partes:
            juntas[k] = juntas.get(k, 0) + v
        for k, v in juntas.items():
            c.execute('INSERT INTO lancamentos(transacao_id, conta_id, valor_centavos, pessoa_id) VALUES(?,?,?,?)',
                      (tid, k, sinal * v, pessoa))
    except sqlite3.IntegrityError as exc:
        raise _erro_banco(exc)
    verificar_transacao(c, tid)
    auditar(c, 'dividir', 'transacao', tid, antes)
    return len(juntas)
