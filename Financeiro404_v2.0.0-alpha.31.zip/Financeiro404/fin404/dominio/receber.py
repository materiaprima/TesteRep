"""Valores a receber (R3): dinheiro emprestado ou gasto pago por outra pessoa, que vai voltar.

Modelo: uma conta de ativo "Valores a receber" (contas.papel = 'a_receber'); cada lançamento nela leva a pessoa que deve
(lancamentos.pessoa_id). Tudo é transferência, nunca despesa nem receita:
- Emprestar ou pagar por alguém: conta de origem (ou cartão) → a receber. Os gastos do mês não mudam; o patrimônio, também
  não (o dinheiro só mudou de forma).
- Devolução: a receber → conta que recebeu. Parcial abate só o valor devolvido.
- Uma despesa já lançada (ex.: veio na fatura) pode virar a receber: a categoria é trocada pela conta a receber.
- "Quem deve": saldo por pessoa; as devoluções abatem as dívidas mais antigas primeiro (para saber "desde quando").
"""
import sqlite3
from datetime import date

from fin404.dinheiro import ErroValidacao, data as ler_data, formatar

PAPEL = 'a_receber'
NOME = 'Valores a receber'
DIAS_ALERTA = 90


def conta(c, criar=True):
    r = c.execute('SELECT id FROM contas WHERE papel=? ORDER BY id LIMIT 1', (PAPEL,)).fetchone()
    if r:
        return r[0]
    if not criar:
        return None
    from fin404.dominio import razao
    nome = NOME
    if c.execute("SELECT 1 FROM contas WHERE tipo='ativo' AND lower(nome)=lower(?)", (nome,)).fetchone():
        nome = NOME + ' (Financeiro 404)'
    cid = razao.criar_conta(c, nome, 'bem')
    c.execute('UPDATE contas SET papel=? WHERE id=?', (PAPEL, cid))
    return cid


def eh_a_receber(c, conta_id):
    r = c.execute('SELECT papel FROM contas WHERE id=?', (conta_id,)).fetchone()
    return bool(r and r['papel'] == PAPEL)


def pessoa(c, pessoa_id=None, nome=''):
    """Pessoa já cadastrada, ou cria pelo nome (quem deve nem sempre é da família)."""
    if pessoa_id:
        r = c.execute('SELECT id FROM pessoas WHERE id=?', (pessoa_id,)).fetchone()
        if not r:
            raise ErroValidacao('Pessoa não encontrada.')
        return r[0]
    nome = (nome or '').strip()[:60]
    if not nome:
        raise ErroValidacao('Diga quem deve: escolha a pessoa ou escreva o nome.')
    r = c.execute('SELECT id FROM pessoas WHERE lower(nome)=lower(?)', (nome,)).fetchone()
    return r[0] if r else c.execute('INSERT INTO pessoas(nome) VALUES(?)', (nome,)).lastrowid


def _nome_pessoa(c, pessoa_id):
    return c.execute('SELECT nome FROM pessoas WHERE id=?', (pessoa_id,)).fetchone()[0]


def _validar_conta_propria(c, conta_id, papel):
    from fin404.dominio import razao
    k = razao.conta(c, conta_id)
    if k['tipo'] not in ('ativo', 'passivo') or k['papel']:
        raise ErroValidacao('Escolha uma conta, carteira ou cartão de vocês.')
    if papel == 'destino' and k['tipo'] != 'ativo':
        raise ErroValidacao('A devolução entra numa conta, carteira ou dinheiro, não num cartão.')
    return k


def emprestar(c, quando, pessoa_id, valor, conta_origem, descricao=''):
    """Saiu dinheiro (ou foi no cartão) por outra pessoa: vira valor a receber, não gasto."""
    from fin404.dominio import razao
    if not valor or valor <= 0:
        raise ErroValidacao('Informe um valor maior que zero.')
    _validar_conta_propria(c, conta_origem, 'origem')
    nome = _nome_pessoa(c, pessoa_id)
    return razao.registrar(c, quando, (descricao or '').strip() or f'Emprestado a {nome}', 'transferencia',
                           [(conta(c), valor, pessoa_id), (conta_origem, -valor)])


def receber(c, quando, pessoa_id, valor, conta_destino, descricao=''):
    from fin404.dominio import razao
    if not valor or valor <= 0:
        raise ErroValidacao('Informe um valor maior que zero.')
    _validar_conta_propria(c, conta_destino, 'destino')
    aberto = saldo_da_pessoa(c, pessoa_id)
    nome = _nome_pessoa(c, pessoa_id)
    if valor > aberto:
        raise ErroValidacao(f'{nome} deve {formatar(aberto)}; a devolução não pode passar disso.')
    return razao.registrar(c, quando, (descricao or '').strip() or f'Devolvido por {nome}', 'transferencia',
                           [(conta_destino, valor), (conta(c), -valor, pessoa_id)])


def converter_despesa(c, tid, pessoa_id):
    """Despesa já lançada (ex.: veio na fatura) que foi para outra pessoa: troca a categoria pela conta a receber."""
    from fin404.dados.banco import auditar
    from fin404.dominio import razao
    t = razao.transacao(c, tid)
    if t['tipo'] != 'despesa':
        raise ErroValidacao('Só uma despesa pode virar valor a receber.')
    if razao.total_estornado(c, tid):
        raise ErroValidacao('Este lançamento tem estorno; resolva o estorno antes.')
    cats = [x for x in razao.lancamentos_de(c, tid) if x['conta_tipo'] == 'despesa']
    if len(cats) != 1:
        raise ErroValidacao('Este lançamento está dividido em categorias; junte numa só antes.')
    nome = _nome_pessoa(c, pessoa_id)
    try:
        c.execute('UPDATE lancamentos SET conta_id=?, pessoa_id=? WHERE id=?', (conta(c), pessoa_id, cats[0]['id']))
        c.execute("UPDATE transacoes SET tipo='transferencia' WHERE id=?", (tid,))
    except sqlite3.IntegrityError as exc:       # mês fechado (gatilho do banco)
        raise razao._erro_banco(exc)
    auditar(c, 'converter_a_receber', 'transacao', tid, f'{t["descricao"]}: {cats[0]["conta_nome"]} → a receber de {nome}')


def saldo_da_pessoa(c, pessoa_id):
    k = conta(c, criar=False)
    if not k:
        return 0
    return c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                        WHERE l.conta_id=? AND l.pessoa_id IS ? AND t.status<>'agendada' ''', (k, pessoa_id)).fetchone()[0]


def quem_deve(c, hoje=None):
    """[{pessoa_id, nome, aberto, desde, dias, itens, devolvido}] com saldo em aberto, maior primeiro.

    As devoluções abatem as dívidas mais antigas primeiro; `itens` são as dívidas ainda (total ou parcialmente) em aberto."""
    hoje = ler_data(hoje or date.today())
    k = conta(c, criar=False)
    if not k:
        return []
    rows = c.execute('''SELECT l.pessoa_id, COALESCE(p.nome, 'Sem pessoa') nome, t.id tid, t.data, t.descricao, l.valor_centavos v
                        FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id LEFT JOIN pessoas p ON p.id=l.pessoa_id
                        WHERE l.conta_id=? AND t.status<>'agendada' ORDER BY t.data, t.id''', (k,)).fetchall()
    por = {}
    for r in rows:
        d = por.setdefault(r['pessoa_id'], {'pessoa_id': r['pessoa_id'], 'nome': r['nome'], 'dividas': [], 'devolvido': 0})
        if r['v'] > 0:
            d['dividas'].append({'tid': r['tid'], 'data': r['data'], 'descricao': r['descricao'], 'valor': r['v'], 'restante': r['v']})
        else:
            d['devolvido'] += -r['v']
    out = []
    for d in por.values():
        sobra = d['devolvido']
        for x in d['dividas']:
            usado = min(sobra, x['restante'])
            x['restante'] -= usado
            sobra -= usado
        abertas = [x for x in d['dividas'] if x['restante'] > 0]
        aberto = sum(x['restante'] for x in abertas)
        if aberto <= 0:
            continue
        desde = abertas[0]['data']
        out.append({'pessoa_id': d['pessoa_id'], 'nome': d['nome'], 'aberto': aberto, 'desde': desde,
                    'dias': (hoje - ler_data(desde)).days, 'itens': abertas, 'devolvido': d['devolvido']})
    return sorted(out, key=lambda x: -x['aberto'])


def movimentos(c, limite=100):
    k = conta(c, criar=False)
    if not k:
        return []
    return c.execute('''SELECT t.id, t.data, t.descricao, l.valor_centavos v, COALESCE(p.nome, 'Sem pessoa') nome
                        FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id LEFT JOIN pessoas p ON p.id=l.pessoa_id
                        WHERE l.conta_id=? AND t.status<>'agendada' ORDER BY t.data DESC, t.id DESC LIMIT ?''', (k, limite)).fetchall()


def alertas(c, hoje=None):
    return [(x, f'{x["nome"]} deve {formatar(x["aberto"])} desde {ler_data(x["desde"]).strftime("%d/%m/%Y")}.')
            for x in quem_deve(c, hoje) if x['dias'] > DIAS_ALERTA]
