"""Lançamento em lote a partir de texto livre: uma linha por gasto, do jeito que se anota no celular.

Exemplos aceitos:
    18,50 padaria pix
    padaria 18,50
    05/11 uber 23,90 crédito
    ontem farmácia 32,90
    +500 freela pix          (o "+" indica entrada)
    R$ 1.234,56 aluguel boleto
"""
import re
from datetime import date, timedelta

from fin404.dinheiro import ErroValidacao, centavos, data as ler_data

FORMAS = {
    'pix': 'pix', 'debito': 'debito', 'débito': 'debito', 'credito': 'credito', 'crédito': 'credito',
    'cartao': 'credito', 'cartão': 'credito', 'dinheiro': 'dinheiro', 'especie': 'dinheiro', 'espécie': 'dinheiro',
    'boleto': 'boleto', 'vr': 'beneficio', 'va': 'beneficio', 'vale': 'beneficio', 'ted': 'transferencia',
    'picpay': 'carteira_digital', 'mercadopago': 'carteira_digital', 'paypal': 'carteira_digital', 'carne': 'crediario',
    'carnê': 'crediario', 'crediario': 'crediario', 'crediário': 'crediario', 'folha': 'desconto_folha',
    'pontos': 'pontos', 'milhas': 'pontos', 'cashback': 'pontos',
}
DIAS = {'hoje': 0, 'ontem': 1, 'anteontem': 2}
RE_DATA = re.compile(r'^(\d{1,2})/(\d{1,2})(?:/(\d{2}|\d{4}))?$')
RE_VALOR = re.compile(r'^[+-]?(?:r\$)?\d[\d.]*(?:,\d{1,2})?$|^[+-]?(?:r\$)?\d+(?:\.\d{1,2})?$', re.I)
MAX_LINHAS = 200


def _data(token, hoje):
    t = token.lower()
    if t in DIAS:
        return hoje - timedelta(days=DIAS[t])
    m = RE_DATA.match(token)
    if not m:
        return None
    dia, mes, ano = int(m.group(1)), int(m.group(2)), m.group(3)
    ano = (int(ano) + 2000 if len(ano) == 2 else int(ano)) if ano else hoje.year
    try:
        d = date(ano, mes, dia)
    except ValueError:
        return None
    if not m.group(3) and d > hoje + timedelta(days=31):
        d = date(ano - 1, mes, dia)   # "28/12" anotado em janeiro é do ano passado
    return d


def interpretar_linha(linha, hoje):
    original = linha.strip()
    tokens = original.replace('R$ ', 'R$').split()
    quando, valor, forma, entrada, resto = None, None, None, False, []
    for tk in tokens:
        baixo = tk.lower().strip('.,;')
        if quando is None and _data(tk, hoje):
            quando = _data(tk, hoje)
            continue
        if valor is None and RE_VALOR.match(tk):
            entrada = tk.startswith('+')
            try:
                valor = centavos(tk.lstrip('+-').replace('R$', '').replace('r$', ''))
            except ErroValidacao:
                valor = None
            if valor:
                continue
        if forma is None and baixo in FORMAS:
            forma = FORMAS[baixo]
            continue
        resto.append(tk)
    descricao = ' '.join(resto).strip(' -–:')
    erro = None
    if not valor:
        erro = 'sem valor'
    elif not descricao:
        erro = 'sem descrição'
    return {'linha': original, 'data': quando or hoje, 'valor': valor or 0, 'descricao': descricao[:200],
            'forma': forma, 'tipo': 'receita' if entrada else 'despesa', 'erro': erro}


def interpretar(texto, hoje=None):
    hoje = ler_data(hoje or date.today())
    linhas = [x for x in (texto or '').splitlines() if x.strip()]
    if not linhas:
        raise ErroValidacao('Cole ao menos uma linha, por exemplo: 18,50 padaria pix')
    if len(linhas) > MAX_LINHAS:
        raise ErroValidacao(f'No máximo {MAX_LINHAS} linhas por vez.')
    return [interpretar_linha(x, hoje) for x in linhas]
