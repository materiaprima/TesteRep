"""Tags: etiquetas livres que cruzam categorias ("viagem", "Natal", "casa nova")."""
import re

from fin404.dinheiro import ErroValidacao

_REAL = "t.status<>'agendada'"


def separar(texto):
    """'viagem, Natal ,casa nova' → ['viagem', 'Natal', 'casa nova'] (sem repetidos, ordem mantida)."""
    vistos, saida = set(), []
    for parte in re.split(r'[,;#\n]+', texto or ''):
        nome = ' '.join(parte.split())
        if not nome:
            continue
        if len(nome) > 40:
            raise ErroValidacao(f'Tag muito longa: "{nome[:40]}…" (máximo 40 caracteres).')
        if nome.lower() not in vistos:
            vistos.add(nome.lower())
            saida.append(nome)
    return saida


def _id(c, nome):
    r = c.execute('SELECT id FROM tags WHERE nome=? COLLATE NOCASE', (nome,)).fetchone()
    return r[0] if r else c.execute('INSERT INTO tags(nome) VALUES(?)', (nome,)).lastrowid


def definir(c, transacao_id, texto):
    """Substitui as tags do lançamento pelas do texto (vazio = sem tags). Tags sem uso são apagadas."""
    nomes = separar(texto)
    c.execute('DELETE FROM transacao_tags WHERE transacao_id=?', (transacao_id,))
    for n in nomes:
        c.execute('INSERT OR IGNORE INTO transacao_tags(transacao_id, tag_id) VALUES(?,?)', (transacao_id, _id(c, n)))
    c.execute('DELETE FROM tags WHERE id NOT IN (SELECT tag_id FROM transacao_tags)')
    return nomes


def adicionar(c, ids, texto):
    for n in separar(texto):
        tid = _id(c, n)
        for t in ids:
            c.execute('INSERT OR IGNORE INTO transacao_tags(transacao_id, tag_id) VALUES(?,?)', (t, tid))


def de(c, transacao_id):
    return [r[0] for r in c.execute('''SELECT g.nome FROM tags g JOIN transacao_tags x ON x.tag_id=g.id
                                       WHERE x.transacao_id=? ORDER BY g.nome COLLATE NOCASE''', (transacao_id,))]


def listar(c):
    """Cada tag com quantos lançamentos, total de despesas e de receitas, primeira e última data."""
    return [dict(r) for r in c.execute(f'''
        SELECT g.id, g.nome, COUNT(DISTINCT t.id) n, MIN(t.data) primeira, MAX(t.data) ultima,
          COALESCE(SUM(CASE WHEN k.tipo='despesa' AND {_REAL} THEN l.valor_centavos END),0) despesas,
          COALESCE(-SUM(CASE WHEN k.tipo='receita' AND {_REAL} THEN l.valor_centavos END),0) receitas
        FROM tags g JOIN transacao_tags x ON x.tag_id=g.id JOIN transacoes t ON t.id=x.transacao_id
        LEFT JOIN lancamentos l ON l.transacao_id=t.id LEFT JOIN contas k ON k.id=l.conta_id
        GROUP BY g.id ORDER BY ultima DESC, g.nome''')]


def renomear(c, tag_id, nome):
    nome = ' '.join((nome or '').split())
    if not 1 <= len(nome) <= 40:
        raise ErroValidacao('Nome da tag: de 1 a 40 caracteres.')
    outra = c.execute('SELECT id FROM tags WHERE nome=? COLLATE NOCASE AND id<>?', (nome, tag_id)).fetchone()
    if outra:  # renomear para uma que já existe = juntar as duas
        c.execute('INSERT OR IGNORE INTO transacao_tags(transacao_id, tag_id) SELECT transacao_id, ? FROM transacao_tags WHERE tag_id=?',
                  (outra[0], tag_id))
        c.execute('DELETE FROM tags WHERE id=?', (tag_id,))
        return outra[0]
    c.execute('UPDATE tags SET nome=? WHERE id=?', (nome, tag_id))
    return tag_id


def excluir(c, tag_id):
    c.execute('DELETE FROM tags WHERE id=?', (tag_id,))
