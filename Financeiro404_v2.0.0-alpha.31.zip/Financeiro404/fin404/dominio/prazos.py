"""Prazos e garantias (R12).

- **Garantia**: nasce de um lançamento, de uma compra planejada (ao comprar, se o item tem meses de garantia) ou de um item
  de nota fiscal. Avisa N dias antes de acabar; depois de acabar, some dos alertas sozinha.
- **Prazo que não é compra** (CNH, licenciamento, seguro, contrato, revisão, documento): avisa N dias antes e continua
  avisando depois de vencido, até ser concluído. "Concluir e renovar" cria o próximo (ex.: licenciamento todo ano).
- Busca: "geladeira" acha a garantia, a compra, o lançamento e o comprovante anexado.
"""
from datetime import date

from fin404.dinheiro import ErroValidacao, data as ler_data, somar_meses

TIPOS = {'garantia': 'Garantia', 'cnh': 'CNH', 'licenciamento': 'Licenciamento / IPVA', 'seguro': 'Seguro',
         'contrato': 'Fim de contrato', 'revisao': 'Revisão / manutenção', 'documento': 'Documento', 'saude': 'Saúde (exame, vacina)',
         'outro': 'Outro'}
REPETE_PADRAO = {'licenciamento': 12, 'seguro': 12, 'revisao': 12, 'cnh': 120}


def _validar(tipo, titulo, data_fim, avisar_dias, repete_meses):
    titulo = (titulo or '').strip()
    if not titulo:
        raise ErroValidacao('Diga do que é o prazo.')
    if tipo not in TIPOS:
        raise ErroValidacao('Escolha o tipo.')
    avisar_dias = int(avisar_dias if avisar_dias not in (None, '') else 30)
    if not 0 <= avisar_dias <= 365:
        raise ErroValidacao('Avisar entre 0 e 365 dias antes.')
    repete_meses = int(repete_meses) if repete_meses else None
    if repete_meses is not None and not 1 <= repete_meses <= 240:
        raise ErroValidacao('Repetição entre 1 e 240 meses.')
    return titulo[:120], ler_data(data_fim).isoformat(), avisar_dias, repete_meses


def criar(c, tipo, titulo, data_fim, avisar_dias=30, repete_meses=None, observacao='', compra_id=None, transacao_id=None,
          nota_id=None):
    titulo, data_fim, avisar_dias, repete_meses = _validar(tipo, titulo, data_fim, avisar_dias, repete_meses)
    return c.execute('''INSERT INTO prazos(tipo, titulo, data_fim, avisar_dias, repete_meses, observacao, compra_id, transacao_id, nota_id)
                        VALUES(?,?,?,?,?,?,?,?,?)''', (tipo, titulo, data_fim, avisar_dias, repete_meses, (observacao or '').strip()[:300],
                                                       compra_id, transacao_id, nota_id)).lastrowid


def fim_da_garantia(inicio, meses):
    inicio = ler_data(inicio)
    meses = int(meses)
    if not 1 <= meses <= 240:
        raise ErroValidacao('Garantia entre 1 e 240 meses.')
    fim = somar_meses(inicio, meses)
    return fim


def garantia(c, titulo, inicio, meses=None, data_fim=None, avisar_dias=30, **ligacoes):
    """Garantia a partir da data da compra + meses (ou data final direta)."""
    if not meses and not data_fim:
        raise ErroValidacao('Informe os meses de garantia ou a data em que ela acaba.')
    fim = ler_data(data_fim) if data_fim else fim_da_garantia(inicio, meses)
    return criar(c, 'garantia', titulo, fim, avisar_dias, None, f'Comprado em {ler_data(inicio).strftime("%d/%m/%Y")}.', **ligacoes)


def atualizar(c, prazo_id, tipo, titulo, data_fim, avisar_dias=30, repete_meses=None, observacao=''):
    um(c, prazo_id)
    titulo, data_fim, avisar_dias, repete_meses = _validar(tipo, titulo, data_fim, avisar_dias, repete_meses)
    c.execute('UPDATE prazos SET tipo=?, titulo=?, data_fim=?, avisar_dias=?, repete_meses=?, observacao=? WHERE id=?',
              (tipo, titulo, data_fim, avisar_dias, repete_meses, (observacao or '').strip()[:300], prazo_id))


def um(c, prazo_id):
    r = c.execute('SELECT * FROM prazos WHERE id=?', (prazo_id,)).fetchone()
    if not r:
        raise ErroValidacao('Prazo não encontrado.')
    return r


def concluir(c, prazo_id, renovar=False, hoje=None):
    """Marca como resolvido. Com `renovar`, cria o próximo com a mesma repetição (data final + N meses)."""
    p = um(c, prazo_id)
    if p['concluido_em']:
        raise ErroValidacao('Este prazo já foi concluído.')
    c.execute('UPDATE prazos SET concluido_em=? WHERE id=?', (ler_data(hoje or date.today()).isoformat(), prazo_id))
    if renovar:
        meses = p['repete_meses'] or REPETE_PADRAO.get(p['tipo'])
        if not meses:
            raise ErroValidacao('Diga de quanto em quanto tempo este prazo se repete (edite o prazo) para renovar.')
        return criar(c, p['tipo'], p['titulo'], somar_meses(ler_data(p['data_fim']), meses), p['avisar_dias'], meses,
                     p['observacao'], p['compra_id'], p['transacao_id'], p['nota_id'])
    return None


def reabrir(c, prazo_id):
    um(c, prazo_id)
    c.execute('UPDATE prazos SET concluido_em=NULL WHERE id=?', (prazo_id,))


def excluir(c, prazo_id):
    from fin404.dados.banco import auditar
    p = um(c, prazo_id)
    c.execute('DELETE FROM prazos WHERE id=?', (prazo_id,))
    auditar(c, 'excluir_prazo', 'prazo', prazo_id, f'{TIPOS.get(p["tipo"], p["tipo"])}: {p["titulo"]} ({p["data_fim"]})')
    return p['titulo']


def _com_dias(r, hoje):
    d = dict(r)
    d['dias'] = (ler_data(r['data_fim']) - hoje).days
    if r['tipo'] == 'garantia':
        d['estado'] = 'acabou' if d['dias'] < 0 else ('acabando' if d['dias'] <= r['avisar_dias'] else 'na garantia')
    else:
        d['estado'] = 'vencido' if d['dias'] < 0 else ('perto' if d['dias'] <= r['avisar_dias'] else 'em dia')
    return d


def abertos(c, hoje=None, incluir_garantias_acabadas=False):
    hoje = ler_data(hoje or date.today())
    rows = [_com_dias(r, hoje) for r in c.execute('SELECT * FROM prazos WHERE concluido_em IS NULL ORDER BY data_fim, id')]
    if not incluir_garantias_acabadas:
        rows = [r for r in rows if not (r['tipo'] == 'garantia' and r['dias'] < 0)]
    return rows


def encerrados(c, hoje=None, limite=50):
    """Concluídos e garantias que já acabaram (histórico)."""
    hoje = ler_data(hoje or date.today())
    return [_com_dias(r, hoje) for r in c.execute(
        '''SELECT * FROM prazos WHERE concluido_em IS NOT NULL OR (tipo='garantia' AND data_fim<?)
           ORDER BY COALESCE(concluido_em, data_fim) DESC LIMIT ?''', (hoje.isoformat(), limite))]


def alertas(c, hoje=None):
    """[(nivel, texto, prazo)] dos prazos dentro da janela de aviso (e dos vencidos que não são garantia)."""
    hoje = ler_data(hoje or date.today())
    out = []
    for p in abertos(c, hoje):
        if p['dias'] > p['avisar_dias']:
            continue
        fim = ler_data(p['data_fim']).strftime('%d/%m/%Y')
        if p['tipo'] == 'garantia':
            out.append(('conferir', f'A garantia de {p["titulo"]} acaba em {fim}'
                        + (' (hoje).' if p['dias'] == 0 else f' ({p["dias"]} dias). Se tem defeito, acione antes.'), p))
        elif p['dias'] < 0:
            out.append(('urgente', f'{TIPOS[p["tipo"]]}: {p["titulo"]} venceu em {fim}.', p))
        else:
            out.append(('urgente' if p['dias'] <= 7 else 'conferir',
                        f'{TIPOS[p["tipo"]]}: {p["titulo"]} vence em {fim} ({p["dias"]} dias).', p))
    return out


def compra_de(c, tid):
    """(transação de referência, data da compra) de um lançamento. Num parcelamento, toda parcela aponta para a
    primeira transação do plano e para a data da compra: a garantia conta da compra, não da parcela."""
    t = c.execute('SELECT id, data, plano_id FROM transacoes WHERE id=?', (tid,)).fetchone()
    if not t:
        raise ErroValidacao('Lançamento não encontrado.')
    if not t['plano_id']:
        return t['id'], t['data']
    p = c.execute('SELECT data_compra FROM planos_parcelas WHERE id=?', (t['plano_id'],)).fetchone()
    primeira = c.execute('SELECT MIN(id) FROM transacoes WHERE plano_id=?', (t['plano_id'],)).fetchone()[0]
    return primeira, (p['data_compra'] if p else t['data'])


def de_transacao(c, tid):
    ref, _ = compra_de(c, tid)
    return c.execute('SELECT * FROM prazos WHERE transacao_id=? ORDER BY data_fim DESC', (ref,)).fetchall()


def garantia_de_lancamento(c, tid, titulo='', meses=None, data_fim=None, avisar_dias=30):
    ref, inicio = compra_de(c, tid)
    desc = c.execute('SELECT descricao FROM transacoes WHERE id=?', (ref,)).fetchone()[0]
    return garantia(c, (titulo or '').strip() or desc, inicio, meses, data_fim, avisar_dias, transacao_id=ref)


def buscar(c, termo, hoje=None):
    """Acha garantias e prazos pelo texto, e compras/lançamentos com esse nome que têm garantia ou comprovante."""
    hoje = ler_data(hoje or date.today())
    termo = (termo or '').strip()
    if len(termo) < 2:
        return {'prazos': [], 'lancamentos': []}
    like = f'%{termo}%'
    achados = [_com_dias(r, hoje) for r in c.execute(
        '''SELECT p.* FROM prazos p LEFT JOIN transacoes t ON t.id=p.transacao_id LEFT JOIN compras_planejadas cp ON cp.id=p.compra_id
           WHERE p.titulo LIKE ? OR p.observacao LIKE ? OR t.descricao LIKE ? OR cp.descricao LIKE ?
           ORDER BY p.data_fim DESC''', (like, like, like, like))]
    for p in achados:
        p['anexos'] = (c.execute('SELECT id, nome FROM anexos WHERE transacao_id=?', (p['transacao_id'],)).fetchall()
                       if p['transacao_id'] else [])
    # Compras com esse nome sem garantia: num parcelamento, só a primeira transação do plano representa a compra
    sem_garantia = c.execute(
        '''SELECT t.id, COALESCE(pp.data_compra, t.data) data, t.descricao,
                  (SELECT COUNT(*) FROM anexos a WHERE a.transacao_id=t.id) n_anexos
           FROM transacoes t LEFT JOIN planos_parcelas pp ON pp.id=t.plano_id
           WHERE t.descricao LIKE ? AND t.tipo='despesa'
             AND (t.plano_id IS NULL OR t.id=(SELECT MIN(t2.id) FROM transacoes t2 WHERE t2.plano_id=t.plano_id))
             AND NOT EXISTS(SELECT 1 FROM prazos p WHERE p.transacao_id=t.id)
           ORDER BY data DESC LIMIT 10''', (like,)).fetchall()
    return {'prazos': achados, 'lancamentos': sem_garantia}
