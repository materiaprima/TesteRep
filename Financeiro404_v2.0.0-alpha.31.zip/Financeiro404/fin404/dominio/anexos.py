"""Comprovantes e recibos anexados aos lançamentos.

Ficam dentro do próprio banco (tabela `anexos`), então entram na cópia diária e nos backups cifrados.
Só PDF e imagens; o tipo é conferido pelo conteúdo do arquivo, não só pela extensão.
"""
import hashlib
from pathlib import PurePath

from fin404.dinheiro import ErroValidacao

LIMITE = 8_000_000
ASSINATURAS = (
    (b'%PDF-', 'application/pdf', '.pdf'),
    (b'\xff\xd8\xff', 'image/jpeg', '.jpg'),
    (b'\x89PNG\r\n\x1a\n', 'image/png', '.png'),
    (b'RIFF', 'image/webp', '.webp'),   # conferido abaixo: RIFF....WEBP
)
EXTENSOES = {'.pdf', '.jpg', '.jpeg', '.png', '.webp'}


def _tipo(dados):
    for assinatura, tipo, ext in ASSINATURAS:
        if dados.startswith(assinatura):
            if tipo == 'image/webp' and dados[8:12] != b'WEBP':
                continue
            return tipo, ext
    return None, None


def adicionar(c, transacao_id, nome, dados):
    if not c.execute('SELECT 1 FROM transacoes WHERE id=?', (transacao_id,)).fetchone():
        raise ErroValidacao('Lançamento não encontrado.')
    if not dados:
        raise ErroValidacao('Escolha um arquivo.')
    if len(dados) > LIMITE:
        raise ErroValidacao('Arquivo maior que 8 MB. Reduza a foto ou o PDF antes de anexar.')
    nome = PurePath((nome or 'comprovante').replace('\\', '/')).name.strip()[:200] or 'comprovante'
    tipo, ext = _tipo(dados)
    if tipo is None or PurePath(nome).suffix.lower() not in EXTENSOES:
        raise ErroValidacao('Anexe PDF, JPG, PNG ou WEBP.')
    sha = hashlib.sha256(dados).hexdigest()
    if c.execute('SELECT 1 FROM anexos WHERE transacao_id=? AND sha256=?', (transacao_id, sha)).fetchone():
        raise ErroValidacao('Este arquivo já está anexado a este lançamento.')
    return c.execute('INSERT INTO anexos(transacao_id, nome, tipo, tamanho, sha256, dados) VALUES(?,?,?,?,?,?)',
                     (transacao_id, nome, tipo, len(dados), sha, dados)).lastrowid


def listar(c, transacao_id):
    return c.execute('SELECT id, nome, tipo, tamanho, criado_em FROM anexos WHERE transacao_id=? ORDER BY id', (transacao_id,)).fetchall()


def obter(c, anexo_id):
    r = c.execute('SELECT * FROM anexos WHERE id=?', (anexo_id,)).fetchone()
    if r is None:
        raise ErroValidacao('Anexo não encontrado.')
    return r


def excluir(c, anexo_id):
    r = obter(c, anexo_id)
    c.execute('DELETE FROM anexos WHERE id=?', (anexo_id,))
    return r['transacao_id']


def contar(c, transacao_id):
    return c.execute('SELECT COUNT(*) FROM anexos WHERE transacao_id=?', (transacao_id,)).fetchone()[0]
