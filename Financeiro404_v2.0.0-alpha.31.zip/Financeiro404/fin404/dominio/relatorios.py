"""Visões do passado, do presente e do futuro, sempre calculadas a partir do razão."""
from collections import OrderedDict
from datetime import date, timedelta
from pathlib import Path, PureWindowsPath

from fin404.dinheiro import data as ler_data, fim_do_mes, fmt_mes, formatar, mes as ler_mes, mes_seguinte, somar_meses
from fin404.dominio import cartoes, razao

_REAL = "t.status<>'agendada'"


def resumo_mes(c, ym):
    inicio, fim = ym + '-01', fim_do_mes(ym).isoformat()
    linhas = c.execute(f'''SELECT k.id, k.nome, k.tipo, SUM(l.valor_centavos) v FROM lancamentos l
                           JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                           WHERE {_REAL} AND t.data BETWEEN ? AND ? AND k.tipo IN ('receita','despesa')
                           GROUP BY k.id ORDER BY k.nome''', (inicio, fim)).fetchall()
    receitas = [(r['id'], r['nome'], -r['v']) for r in linhas if r['tipo'] == 'receita' and r['v']]
    despesas = [(r['id'], r['nome'], r['v']) for r in linhas if r['tipo'] == 'despesa' and r['v']]
    despesas.sort(key=lambda x: -x[2]); receitas.sort(key=lambda x: -x[2])
    pessoas = c.execute(f'''SELECT COALESCE(p.nome,'Casal / não informado') pessoa, SUM(l.valor_centavos) v FROM lancamentos l
                            JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                            LEFT JOIN pessoas p ON p.id=l.pessoa_id
                            WHERE {_REAL} AND t.data BETWEEN ? AND ? AND k.tipo='despesa' GROUP BY pessoa ORDER BY v DESC''',
                        (inicio, fim)).fetchall()
    total_r = sum(x[2] for x in receitas); total_d = sum(x[2] for x in despesas)
    no_cartao = c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                              JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND t.data BETWEEN ? AND ? AND k.tipo='despesa'
                              AND EXISTS(SELECT 1 FROM lancamentos l2 JOIN contas k2 ON k2.id=l2.conta_id
                                         WHERE l2.transacao_id=t.id AND k2.subtipo='cartao')''', (inicio, fim)).fetchone()[0]
    return {'mes': ym, 'receitas': receitas, 'despesas': despesas, 'total_receitas': total_r,
            'total_despesas': total_d, 'resultado': total_r - total_d,
            'despesas_no_cartao': no_cartao, 'despesas_fora_cartao': total_d - no_cartao,
            'por_pessoa': [(r['pessoa'], r['v']) for r in pessoas if r['v']],
            'custo_credito': next((v for _, n, v in despesas if n == 'Juros, tarifas e IOF'), 0),
            'por_forma': [(r['forma'], r['v']) for r in c.execute(f'''SELECT t.meio_pagamento forma, SUM(l.valor_centavos) v
                            FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                            WHERE {_REAL} AND k.tipo='despesa' AND t.data BETWEEN ? AND ? GROUP BY t.meio_pagamento
                            HAVING v>0 ORDER BY v DESC''', (inicio, fim))]}


def resumo_ano(c, ano):
    meses = OrderedDict((f'{ano}-{m:02d}', {'receitas': 0, 'despesas': 0}) for m in range(1, 13))
    for r in c.execute(f'''SELECT substr(t.data,1,7) ym, k.tipo, SUM(l.valor_centavos) v FROM lancamentos l
                           JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                           WHERE {_REAL} AND substr(t.data,1,4)=? AND k.tipo IN ('receita','despesa') GROUP BY ym, k.tipo''',
                       (str(ano),)):
        meses[r['ym']]['receitas' if r['tipo'] == 'receita' else 'despesas'] = -r['v'] if r['tipo'] == 'receita' else r['v']
    categorias = c.execute(f'''SELECT k.nome, SUM(l.valor_centavos) v FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                               JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND substr(t.data,1,4)=? AND k.tipo='despesa'
                               GROUP BY k.id HAVING v<>0 ORDER BY v DESC''', (str(ano),)).fetchall()
    juros = c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                          JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND substr(t.data,1,4)=? AND k.nome='Juros, tarifas e IOF' ''',
                      (str(ano),)).fetchone()[0]
    for v in meses.values():
        v['resultado'] = v['receitas'] - v['despesas']
    tr = sum(v['receitas'] for v in meses.values()); td = sum(v['despesas'] for v in meses.values())
    return {'ano': ano, 'meses': meses, 'categorias': [(r['nome'], r['v']) for r in categorias],
            'total_receitas': tr, 'total_despesas': td, 'resultado': tr - td, 'juros_tarifas': juros,
            'taxa_poupanca': round((tr - td) * 100 / tr) if tr > 0 else None}


def posicao(c, hoje=None):
    hoje = ler_data(hoje or date.today())
    contas = razao.saldos_por_conta(c, hoje)
    disp = sum(k['saldo_natural'] for k in contas if k['subtipo'] in razao.DISPONIVEIS)
    invest = sum(k['saldo_natural'] for k in contas if k['subtipo'] == 'investimento')
    bens = sum(k['saldo_natural'] for k in contas if k['subtipo'] == 'bem' and not k.get('papel'))
    a_receber = sum(k['saldo_natural'] for k in contas if k.get('papel') == 'a_receber')
    cartoes_hoje = sum(k['saldo_natural'] for k in contas if k['subtipo'] == 'cartao')
    outras_dividas = sum(k['saldo_natural'] for k in contas if k['tipo'] == 'passivo' and k['subtipo'] != 'cartao')
    parcelas_futuras = -c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                                      JOIN contas k ON k.id=l.conta_id WHERE k.subtipo='cartao' AND t.status<>'agendada' AND t.data>?''',
                                   (hoje.isoformat(),)).fetchone()[0]
    ativos = disp + invest + bens + a_receber
    passivos = cartoes_hoje + outras_dividas
    return {'hoje': hoje, 'contas': contas, 'disponivel': disp, 'investimentos': invest, 'bens': bens, 'a_receber': a_receber,
            'cartoes': cartoes_hoje, 'outras_dividas': outras_dividas, 'parcelas_futuras': parcelas_futuras,
            'ativos': ativos, 'passivos': passivos, 'patrimonio_liquido': ativos - passivos,
            'patrimonio_apos_parcelas': ativos - passivos - parcelas_futuras}


def _eventos_cartao(c, hoje, ate):
    """Saídas previstas de caixa para pagar faturas até `ate`."""
    eventos = []
    for k in cartoes.lista(c):
        if not k['dia_fechamento'] or not k['dia_vencimento']:
            continue
        f = cartoes.fechamento_da_compra(k, hoje)
        f = cartoes.fechamento_anterior(k, f)  # inclui a fatura fechada ainda não vencida (ou vencida e não paga)
        while True:
            venc = cartoes.vencimento(k, f)
            if venc > ate:
                break
            fat = cartoes.fatura(c, k['id'], f, hoje) if venc < hoje else None
            if fat is not None and fat['restante'] > 0:
                # fatura vencida e não paga: ainda vai sair dinheiro, e já (conta como hoje)
                eventos.append((hoje, f'Fatura {k["nome"]} vencida em {venc.strftime("%d/%m")}', -fat['restante'], 'fatura'))
            if venc >= hoje:
                fat = cartoes.fatura(c, k['id'], f, hoje)
                if f <= hoje:
                    valor = fat['restante']
                else:
                    # Ciclo ainda aberto ou futuro: só o que entrou no ciclo (supõe faturas anteriores pagas).
                    estornos = sum(i['valor_centavos'] for i in fat['itens'] if i['valor_centavos'] > 0 and i['tipo'] == 'estorno')
                    valor = max(fat['compras'] - estornos, 0)
                agendado = c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                                        WHERE l.conta_id=? AND t.status='agendada' AND l.valor_centavos>0 AND t.data BETWEEN ? AND ?''',
                                     (k['id'], f.isoformat(), venc.isoformat())).fetchone()[0]
                valor = max(valor - agendado, 0)
                if valor:
                    eventos.append((venc, f'Fatura {k["nome"]} (fecha {f.strftime("%d/%m")})', -valor, 'fatura'))
            f = cartoes.fechamento_seguinte(k, f)
    return eventos


def fluxo_caixa(c, dias=90, hoje=None):
    hoje = ler_data(hoje or date.today())
    ate = hoje + timedelta(days=dias)
    disponiveis = [k['id'] for k in razao.contas(c, subtipos=razao.DISPONIVEIS)]
    inicial = sum(razao.saldo(c, i, hoje) for i in disponiveis)
    eventos = []
    if disponiveis:
        marc = ','.join('?' * len(disponiveis))
        for r in c.execute(f'''SELECT t.data, t.descricao, t.status, SUM(l.valor_centavos) v FROM lancamentos l
                               JOIN transacoes t ON t.id=l.transacao_id
                               WHERE l.conta_id IN ({marc}) AND t.data>? AND t.data<=? GROUP BY t.id
                               HAVING v<>0 ORDER BY t.data''', [*disponiveis, hoje.isoformat(), ate.isoformat()]):
            eventos.append((ler_data(r['data']), r['descricao'], r['v'], 'previsto' if r['status'] == 'agendada' else 'confirmado'))
        # "a pagar" / "a receber" com data que já passou e ainda não aconteceu: continua devido, então entra hoje
        for r in c.execute(f'''SELECT t.data, t.descricao, SUM(l.valor_centavos) v FROM lancamentos l
                               JOIN transacoes t ON t.id=l.transacao_id
                               WHERE l.conta_id IN ({marc}) AND t.status='agendada' AND t.data<=? GROUP BY t.id
                               HAVING v<>0 ORDER BY t.data''', [*disponiveis, hoje.isoformat()]):
            eventos.append((hoje, f'{r["descricao"]} (atrasado, era {ler_data(r["data"]).strftime("%d/%m")})', r['v'], 'previsto'))
    eventos.extend(_eventos_cartao(c, hoje, ate))
    eventos.sort(key=lambda e: (e[0], e[2]))
    saldo = inicial; linhas = []; menor = (hoje, inicial)
    for quando, desc, v, tipo in eventos:
        saldo += v
        linhas.append({'data': quando, 'descricao': desc, 'valor': v, 'saldo': saldo, 'tipo': tipo})
        if saldo < menor[1]:
            menor = (quando, saldo)
    return {'inicial': inicial, 'linhas': linhas, 'final': saldo, 'menor_data': menor[0], 'menor_saldo': menor[1],
            'hoje': hoje, 'ate': ate}


def compromissos(c, meses=12, hoje=None):
    """Saídas futuras já contratadas ou previstas, por mês: parcelas de cartão e previsões."""
    hoje = ler_data(hoje or date.today())
    base = date(hoje.year, hoje.month, 1)
    resultado = OrderedDict()
    for i in range(meses):
        ym = somar_meses(base, i).strftime('%Y-%m')
        resultado[ym] = {'parcelas': 0, 'previstas_saida': 0, 'previstas_entrada': 0}
    fim = fim_do_mes(list(resultado)[-1]).isoformat()
    # Parcelas de cartão: pelo mês em que a fatura vence (quando o dinheiro sai), a partir da fatura em aberto.
    for k in cartoes.lista(c):
        if not k['dia_fechamento'] or not k['dia_vencimento']:
            continue
        f = cartoes.fechamento_da_compra(k, hoje)
        anterior = cartoes.fechamento_anterior(k, f)
        if cartoes.vencimento(k, anterior) >= hoje:      # fatura já fechada que ainda vai ser paga
            f = anterior
        for _ in range(meses + 2):
            venc = cartoes.vencimento(k, f)
            ym = venc.strftime('%Y-%m')
            if ym in resultado:
                inicio, fim_ciclo = cartoes.ciclo(k, f)
                v = -c.execute('''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                                  WHERE l.conta_id=? AND t.plano_id IS NOT NULL AND t.status<>'agendada' AND l.valor_centavos<0
                                  AND t.data>=? AND t.data<?''', (k['id'], inicio.isoformat(), fim_ciclo.isoformat())).fetchone()[0]
                resultado[ym]['parcelas'] += v
            f = cartoes.fechamento_seguinte(k, f)
    for r in c.execute('''SELECT substr(t.data,1,7) ym, k.tipo, SUM(l.valor_centavos) v FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                          JOIN contas k ON k.id=l.conta_id WHERE t.status='agendada' AND t.data>=? AND t.data<=?
                          AND k.tipo IN ('receita','despesa') GROUP BY ym, k.tipo''', (hoje.isoformat(), fim)):
        if r['ym'] in resultado:
            if r['tipo'] == 'despesa':
                resultado[r['ym']]['previstas_saida'] = r['v']
            else:
                resultado[r['ym']]['previstas_entrada'] = -r['v']
    return resultado


def orcamento(c, ym):
    inicio, fim = ym + '-01', fim_do_mes(ym).isoformat()
    return c.execute(f'''SELECT k.id, k.nome, o.valor_centavos limite,
                         COALESCE((SELECT SUM(l.valor_centavos) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                                   WHERE l.conta_id=k.id AND {_REAL} AND t.data BETWEEN ? AND ?),0) gasto
                         FROM contas k LEFT JOIN orcamentos o ON o.conta_id=k.id AND o.mes=?
                         WHERE k.tipo='despesa' AND k.ativa=1 ORDER BY (o.valor_centavos IS NULL), k.nome''',
                     (inicio, fim, ym)).fetchall()


def definir_orcamento(c, ym, conta_id, valor):
    if razao.conta(c, conta_id)['tipo'] != 'despesa':
        from fin404.dinheiro import ErroValidacao
        raise ErroValidacao('Orçamento é definido por categoria de despesa.')
    if valor == 0:
        c.execute('DELETE FROM orcamentos WHERE mes=? AND conta_id=?', (ym, conta_id))
    else:
        c.execute('''INSERT INTO orcamentos(mes,conta_id,valor_centavos) VALUES(?,?,?)
                     ON CONFLICT(mes,conta_id) DO UPDATE SET valor_centavos=excluded.valor_centavos''', (ym, conta_id, valor))


def copiar_orcamento(c, de_ym, para_ym):
    c.execute('''INSERT OR IGNORE INTO orcamentos(mes,conta_id,valor_centavos)
                 SELECT ?, conta_id, valor_centavos FROM orcamentos WHERE mes=?''', (para_ym, de_ym))


SINCRONIZADAS = ('onedrive', 'google drive', 'googledrive', 'dropbox', 'icloud', 'meu drive', 'my drive')


def pasta_sincronizada(pasta):
    """O Windows 11 põe Área de Trabalho e Documentos no OneDrive por padrão; banco SQLite aberto ali pode ser
    corrompido pela sincronização (cópia no meio de uma gravação, conflitos com o -wal)."""
    import os
    caminho = str(pasta) if PureWindowsPath(str(pasta)).drive else str(Path(pasta).resolve())
    partes = PureWindowsPath(caminho).parts   # separa por / e por \\ nos dois sistemas
    if any(parte.lower() in SINCRONIZADAS or parte.lower().startswith('onedrive') for parte in partes):
        return True
    # OneDrive com pasta renomeada: o Windows informa onde ela está nestas variáveis
    for var in ('OneDrive', 'OneDriveConsumer', 'OneDriveCommercial'):
        raiz = os.environ.get(var)
        if raiz and PureWindowsPath(caminho.lower()).is_relative_to(PureWindowsPath(raiz.lower())):
            return True
    return False


def alertas(c, hoje=None):
    hoje = ler_data(hoje or date.today())
    itens = []
    n = c.execute("SELECT COUNT(*) FROM linhas_importacao li JOIN lotes_importacao lo ON lo.id=li.lote_id WHERE li.situacao='nova' AND lo.desfeito_em IS NULL").fetchone()[0]
    if n:
        itens.append(('importacao', f'{n} linha(s) de extrato aguardando revisão.', '/importacoes'))
    for k in cartoes.lista(c):
        if not k['dia_fechamento']:
            itens.append(('config', f'Cartão "{k["nome"]}" sem dias de fechamento e vencimento.', f'/contas/{k["id"]}'))
            continue
        if cartoes.saldo_inicial_pendente(c, k['id']):
            itens.append(('conferir', f'"{k["nome"]}": as faturas do app não partem da mesma dívida que o banco (falta o saldo inicial).', '/cartoes'))
        n_pag = len(cartoes.pagamentos_como_gasto(c, k['id']))
        if n_pag:
            itens.append(('conferir', f'"{k["nome"]}": {n_pag} pagamento(s) de fatura lançado(s) como estorno; o gasto do mês fica menor do que foi.', '/cartoes'))
        f = cartoes.fechamento_anterior(k, cartoes.fechamento_da_compra(k, hoje))
        fat = cartoes.fatura(c, k['id'], f, hoje)
        dias = (fat['vencimento'] - hoje).days
        if fat['restante'] > 0 and 0 <= dias <= 5:
            quando = {0: 'hoje', 1: 'amanhã'}.get(dias, f'em {dias} dias')
            itens.append(('urgente' if dias <= 2 else 'conferir',
                          f'Fatura de {k["nome"]} vence {quando} ({fat["vencimento"].strftime("%d/%m")}): falta pagar {formatar(fat["restante"])}.',
                          f'/cartoes/{k["id"]}/fatura/{f.isoformat()}'))
        if fat['situacao'] == 'vencida':
            itens.append(('urgente', f'Fatura de {k["nome"]} venceu em {fat["vencimento"].strftime("%d/%m")} sem pagamento registrado.', f'/cartoes/{k["id"]}'))
        if fat['diferenca']:
            itens.append(('conferir', f'Fatura de {k["nome"]} difere do documento do banco.', f'/cartoes/{k["id"]}/fatura/{f.isoformat()}'))
    for k in razao.contas(c, subtipos=razao.DISPONIVEIS):
        if not c.execute("SELECT 1 FROM transacoes t JOIN lancamentos l ON l.transacao_id=t.id WHERE l.conta_id=? AND t.tipo='abertura'", (k['id'],)).fetchone():
            itens.append(('config', f'Conta "{k["nome"]}" sem saldo inicial.', f'/contas/{k["id"]}'))
    for k in c.execute("SELECT id, nome FROM contas WHERE subtipo='corrente' AND ativa=1").fetchall():
        s_ = razao.saldo(c, k['id'], hoje)
        if s_ < 0:
            itens.append(('urgente', f'A conta {k["nome"]} está negativa em {formatar(-s_)} (cheque especial). '
                                     'Os juros do cheque especial estão entre os mais altos: cubra assim que puder.', f'/contas/{k["id"]}'))
    ausentes = cartoes.parcelas_ausentes(c)
    if ausentes:
        itens.append(('conferir', f'{len(ausentes)} parcela(s) prevista(s) não vieram na fatura importada: antecipadas ou canceladas?', '/parcelamentos'))
    n = c.execute("SELECT COUNT(*) FROM transacoes WHERE status='agendada' AND data<=?", (hoje.isoformat(),)).fetchone()[0]
    if n:
        itens.append(('conferir', f'{n} lançamento(s) previsto(s) para confirmar (salário, contas fixas…).', '/confirmar'))
    ultimo = c.execute("SELECT MAX(em) FROM auditoria WHERE acao='backup'").fetchone()[0]
    tem_dados = c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0] > 0
    from fin404.dados import config
    auto = config.obter('backup_auto', None, c)
    st = config.obter('backup_auto_status', None, c) or {}
    if auto:
        if st.get('erro'):
            itens.append(('urgente', 'O backup automático falhou: ' + st['erro'], '/backup'))
        elif not st.get('ultimo_sucesso') or (hoje - ler_data(st['ultimo_sucesso'][:10])).days > 2:
            itens.append(('conferir', 'O backup automático não roda há mais de 2 dias (pasta desconectada?).', '/backup'))
        verif = config.obter('backup_verificado', None, c)
        if not verif:
            itens.append(('config', 'O backup automático ainda não foi testado com a senha. Teste em "Backup e segurança".', '/backup'))
        elif (hoje - ler_data(verif['em'][:10])).days > 90:
            itens.append(('conferir', 'O último teste do backup tem mais de 3 meses. Teste de novo (e confirme que lembram a senha).', '/backup'))
    elif tem_dados and not ultimo:
        itens.append(('config', 'Nenhum backup cifrado ainda. Ative o backup automático em "Backup e segurança".', '/backup'))
    elif tem_dados and (hoje - ler_data(ultimo[:10])).days > 7:
        itens.append(('conferir', f'Último backup cifrado em {ler_data(ultimo[:10]).strftime("%d/%m")}. Faça um novo.', '/backup'))
    from fin404.dados import banco
    if pasta_sincronizada(banco.pasta_dados()):
        itens.append(('urgente', 'A pasta do programa está dentro do OneDrive, Google Drive ou Dropbox. Isso pode corromper o banco '
                                 'enquanto ele está aberto. Mova a pasta do Financeiro 404 para C:\\Financeiro404 (o backup cifrado '
                                 'continua indo para a nuvem).', '/backup'))
    fluxo = fluxo_caixa(c, 60, hoje)
    if fluxo['menor_saldo'] < 0:
        itens.append(('urgente', f'O caixa projetado fica negativo em {fluxo["menor_data"].strftime("%d/%m")}.', '/fluxo'))
    from fin404.dominio import analises
    from fin404.dominio import conferencias
    for k, dias, texto in conferencias.alertas(c, hoje):
        itens.append(('conferir', texto + ' Sem extrato, só a conferência mostra o que ficou sem lançar.', f'/contas/{k["id"]}#conferir'))
    from fin404.dominio import prazos
    for nivel, texto, p in prazos.alertas(c, hoje):
        itens.append((nivel, texto, f'/prazos#prazo-{p["id"]}'))
    from fin404.dominio import reuniao
    pendente = reuniao.lembrete(c, hoje)
    if pendente:
        itens.append(('conferir', f'Falta a reunião financeira de {fmt_mes(pendente)} (15 minutos, juntos).', f'/reuniao?mes={pendente}'))
    from fin404.dominio import receber
    for _, texto in receber.alertas(c, hoje):
        itens.append(('conferir', texto, '/receber'))
    itens.extend(analises.alertas_extras(c, hoje))
    return itens


# ---------------------------------------------------------------- dispensar alertas

DIAS_DISPENSA = {'urgente': 3}
DIAS_DISPENSA_PADRAO = 30


def chave_alerta(tipo, texto, link):
    """Identifica o alerta sem os números (valores, dias), para que "vence em 3 dias" e "em 2 dias" sejam o mesmo."""
    import hashlib
    import re
    base = re.sub(r'(R\$\s*)?[−-]?[\d.,/:%]+', '#', texto)
    base = re.sub(r'\b(hoje|amanhã|em # dias?)(?!\w)', '#', base)
    return hashlib.sha256(f'{tipo}|{link}|{base}'.encode('utf-8')).hexdigest()[:16]


def alertas_visiveis(c, hoje=None):
    """(alertas com chave, quantos estão dispensados)."""
    from fin404.dados import config
    hoje = ler_data(hoje or date.today())
    dispensados = config.obter('alertas_dispensados', {}, c) or {}
    visiveis, ocultos = [], 0
    for tipo, texto, link in alertas(c, hoje):
        chave = chave_alerta(tipo, texto, link)
        if dispensados.get(chave, '') >= hoje.isoformat():
            ocultos += 1
        else:
            visiveis.append((tipo, texto, link, chave))
    return visiveis, ocultos


def dispensar_alerta(c, chave, tipo, hoje=None):
    from fin404.dados import config
    hoje = ler_data(hoje or date.today())
    if not chave or len(chave) != 16 or not all(ch in '0123456789abcdef' for ch in chave):
        from fin404.dinheiro import ErroValidacao
        raise ErroValidacao('Alerta inválido.')
    dias = DIAS_DISPENSA.get(tipo, DIAS_DISPENSA_PADRAO)
    atuais = {k: v for k, v in (config.obter('alertas_dispensados', {}, c) or {}).items() if v >= hoje.isoformat()}
    atuais[chave] = (hoje + timedelta(days=dias)).isoformat()
    config.definir('alertas_dispensados', atuais, c)
    return dias


def reexibir_alertas(c):
    from fin404.dados import config
    config.definir('alertas_dispensados', None, c)


# ---------------------------------------------------------------- "quanto gastei no mês", por três jeitos de olhar

VISOES = {
    'fatura': 'Pela fatura',
    'compra': 'Pela data da compra',
    'caixa': 'Pelo dinheiro que saiu',
}


def _ciclos_do_mes(c, ym):
    """Para cada cartão com fechamento configurado: as faturas que fecham no mês e os ciclos que tocam o mês."""
    from fin404.dominio import cartoes
    inicio, fim = date.fromisoformat(ym + '-01'), fim_do_mes(ym)
    res = []
    for k in cartoes.lista(c):
        if not k['dia_fechamento']:
            continue
        f = cartoes.fechamento_da_compra(k, inicio - timedelta(days=1))
        while True:
            ini_c, fim_c = cartoes.ciclo(k, f)
            if ini_c > fim:
                break
            importada = c.execute('''SELECT 1 FROM faturas_documento WHERE conta_cartao_id=? AND fechamento=?
                                     UNION SELECT 1 FROM lotes_importacao WHERE conta_id=? AND fatura_fechamento=? AND desfeito_em IS NULL''',
                                  (k['id'], f.isoformat(), k['id'], f.isoformat())).fetchone() is not None
            res.append({'cartao': k, 'fechamento': f, 'inicio': ini_c, 'fim': fim_c - timedelta(days=1),
                        'fecha_no_mes': inicio <= f <= fim, 'toca_o_mes': fim_c > inicio, 'importada': importada})
            f = cartoes.fechamento_seguinte(k, f)
    return res


def _usa_importacao(c, cartao_id):
    return c.execute('SELECT 1 FROM lotes_importacao WHERE conta_id=? AND fatura_fechamento IS NOT NULL AND desfeito_em IS NULL LIMIT 1',
                     (cartao_id,)).fetchone() is not None


_NO_CARTAO = '''EXISTS(SELECT 1 FROM lancamentos l2 WHERE l2.transacao_id=t.id AND l2.conta_id={})'''
_ALGUM_CARTAO = '''EXISTS(SELECT 1 FROM lancamentos l2 JOIN contas k2 ON k2.id=l2.conta_id
                          WHERE l2.transacao_id=t.id AND k2.subtipo='cartao' AND k2.dia_fechamento IS NOT NULL)'''


def _por_categoria(c, onde, args):
    return c.execute(f'''SELECT k.id, k.nome, SUM(l.valor_centavos) v, COUNT(DISTINCT t.id) n FROM lancamentos l
                         JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                         WHERE {_REAL} AND k.tipo='despesa' AND ({onde}) GROUP BY k.id''', args).fetchall()


def gastos_do_mes(c, ym, ver='fatura'):
    """Quanto se gastou no mês, por categoria, num dos três jeitos de olhar. Devolve também o que ainda falta chegar.

    - fatura: no cartão, as compras da fatura que FECHOU no mês (é o que o banco cobrou); fora do cartão, a data do gasto.
    - compra: tudo pela data da compra (no parcelado, a data de cada parcela). O mês só fica completo quando chega a fatura
      seguinte, porque as compras do fim do mês entram nela.
    - caixa: o dinheiro que saiu das contas no mês: gastos fora do cartão + pagamentos de fatura e de dívidas.
    """
    if ver not in VISOES:
        ver = 'fatura'
    inicio, fim = ym + '-01', fim_do_mes(ym).isoformat()
    ciclos = _ciclos_do_mes(c, ym)
    blocos, faltando, explica, conferir = [], [], [], []
    fora = f"t.data BETWEEN ? AND ? AND NOT {_ALGUM_CARTAO}"
    if ver == 'fatura':
        for ci in [x for x in ciclos if x['fecha_no_mes']]:
            k = ci['cartao']
            parte = (f"{_NO_CARTAO.format('?')} AND t.data BETWEEN ? AND ?", (k['id'], ci['inicio'].isoformat(), ci['fim'].isoformat()))
            blocos.append(('cartao', k['nome'], parte, _por_categoria(c, *parte)))
            fechou = 'fechou' if ci['fechamento'] < date.today() else 'fecha'
            explica.append(f'{k["nome"]}: fatura que {fechou} em {ci["fechamento"].strftime("%d/%m")} '
                           f'(compras de {ci["inicio"].strftime("%d/%m")} a {ci["fim"].strftime("%d/%m")})'
                           + ('' if fechou == 'fechou' else ' — ainda aberta, conta só o que já foi lançado'))
            conferir.append({'cartao': k, **cartoes.fatura(c, k['id'], ci['fechamento'])})
            if not ci['importada'] and _usa_importacao(c, k['id']):
                faltando.append(f'A fatura do {k["nome"]} que fecha em {ci["fechamento"].strftime("%d/%m/%Y")} ainda não foi importada.')
        blocos.append(('fora', 'Fora do cartão', (fora, (inicio, fim)), _por_categoria(c, fora, (inicio, fim))))
    elif ver == 'compra':
        parte = ('t.data BETWEEN ? AND ?', (inicio, fim))
        blocos.append(('tudo', 'Todas as despesas', parte, _por_categoria(c, *parte)))
        for ci in [x for x in ciclos if x['toca_o_mes']]:
            if not ci['importada'] and _usa_importacao(c, ci['cartao']['id']):
                de = max(ci['inicio'], date.fromisoformat(inicio))
                ate = min(ci['fim'], date.fromisoformat(fim))
                faltando.append(f'Compras de {de.strftime("%d/%m")} a {ate.strftime("%d/%m")} no {ci["cartao"]["nome"]}: vêm na fatura '
                                f'que fecha em {ci["fechamento"].strftime("%d/%m/%Y")}, ainda não importada.')
    else:
        blocos.append(('fora', 'Gastos fora do cartão', (fora, (inicio, fim)), _por_categoria(c, fora, (inicio, fim))))
    categorias = {}
    for *_, linhas in blocos:
        for r in linhas:
            atual = categorias.setdefault(r['id'], {'id': r['id'], 'nome': r['nome'], 'v': 0, 'n': 0})
            atual['v'] += r['v'] or 0
            atual['n'] += r['n']
    cats = sorted((x for x in categorias.values() if x['v']), key=lambda x: -x['v'])
    pagamentos = []
    if ver == 'caixa':
        pagamentos = c.execute(f'''SELECT k.nome, SUM(l.valor_centavos) v, COUNT(DISTINCT t.id) n FROM lancamentos l
                                   JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                                   WHERE {_REAL} AND k.tipo='passivo' AND l.valor_centavos>0 AND t.tipo='pagamento_fatura'
                                   AND t.data BETWEEN ? AND ? GROUP BY k.id ORDER BY v DESC''', (inicio, fim)).fetchall()
    sub = {nome: sum(r['v'] or 0 for r in linhas) for tipo, nome, _, linhas in blocos}
    total = sum(x['v'] for x in cats) + sum(p['v'] for p in pagamentos)
    return {'mes': ym, 'ver': ver, 'categorias': cats, 'pagamentos': [(p['nome'], p['v'], p['n']) for p in pagamentos],
            'subtotais': [(n, v) for n, v in sub.items()], 'total': total, 'faltando': faltando, 'explica': explica,
            'ciclos': ciclos, 'partes': [b[2] for b in blocos], 'faturas': conferir}


def gastos_periodo(c, de, ate, ver='fatura'):
    """Quanto gastei de um mês até outro: soma mês a mês (cada mês no mesmo jeito de olhar), sem contar nada duas vezes.
    Até 24 meses. Devolve o mesmo formato de gastos_do_mes, mais 'meses' = [(ym, total)]."""
    de, ate = ler_mes(de), ler_mes(ate)
    if ate < de:
        de, ate = ate, de
    if de == ate:
        r = gastos_do_mes(c, de, ver)
        return {**r, 'de': de, 'ate': ate, 'meses': [(de, r['total'])]}
    meses, m = [], de
    while m <= ate and len(meses) < 24:
        meses.append(m)
        m = mes_seguinte(m)
    cats, pags, sub, faltando, partes, por_mes = {}, {}, {}, [], [], []
    for ym in meses:
        r = gastos_do_mes(c, ym, ver)
        for x in r['categorias']:
            a = cats.setdefault(x['id'], {'id': x['id'], 'nome': x['nome'], 'v': 0, 'n': 0})
            a['v'] += x['v']; a['n'] += x['n']
        for nome, v, n in r['pagamentos']:
            a = pags.setdefault(nome, [0, 0]); a[0] += v; a[1] += n
        for nome, v in r['subtotais']:
            sub[nome] = sub.get(nome, 0) + v
        faltando += [f for f in r['faltando'] if f not in faltando]
        partes += r['partes']
        por_mes.append((ym, r['total']))
    return {'mes': de, 'de': de, 'ate': meses[-1], 'ver': ver, 'categorias': sorted(cats.values(), key=lambda x: -x['v']),
            'pagamentos': sorted(((n, v, q) for n, (v, q) in pags.items()), key=lambda x: -x[1]),
            'subtotais': list(sub.items()), 'total': sum(t for _, t in por_mes), 'faltando': faltando, 'explica': [],
            'ciclos': [], 'partes': partes, 'faturas': [], 'meses': por_mes}


def gastos_itens(c, ym, ver, categoria_id, ate=None):
    """Os lançamentos de uma categoria que entram na conta do mês (ou do período) naquele jeito de olhar."""
    partes = (gastos_periodo(c, ym, ate, ver) if ate and ate != ym else gastos_do_mes(c, ym, ver))['partes']
    if not partes:
        return []
    onde = ' OR '.join(f'({o})' for o, _ in partes)
    args = [a for _, xs in partes for a in xs]
    return c.execute(f'''SELECT t.id, t.data, t.descricao, t.parcela_n, l.valor_centavos v,
                                (SELECT k2.nome FROM lancamentos l2 JOIN contas k2 ON k2.id=l2.conta_id
                                 WHERE l2.transacao_id=t.id AND k2.tipo IN ('ativo','passivo') LIMIT 1) conta,
                                (SELECT COALESCE(li.data_original, li.data) FROM linhas_importacao li WHERE li.transacao_id=t.id ORDER BY li.id DESC LIMIT 1) data_banco
                         FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                         WHERE {_REAL} AND l.conta_id=? AND ({onde}) ORDER BY t.data, t.id''', [categoria_id] + args).fetchall()



def proximos_meses(c, meses=6, estimar=True, hoje=None):
    """Previsão mês a mês: o que entra, o que sai (faturas, contas, compras planejadas e, se pedido, uma estimativa do gasto do
    dia a dia) e o saldo disponível no fim de cada mês."""
    from fin404.dominio import compras as _compras
    hoje = ler_data(hoje or date.today())
    base = date(hoje.year, hoje.month, 1)
    yms = [somar_meses(base, i).strftime('%Y-%m') for i in range(meses)]
    ate = fim_do_mes(yms[-1])
    f = fluxo_caixa(c, (ate - hoje).days, hoje)
    linhas = OrderedDict((ym, {'ym': ym, 'entradas': 0, 'faturas': 0, 'contas': 0, 'compras': 0, 'estimativa': 0}) for ym in yms)
    for l in f['linhas']:
        ym = l['data'].strftime('%Y-%m')
        if ym not in linhas:
            continue
        if l['valor'] > 0:
            linhas[ym]['entradas'] += l['valor']
        elif l['tipo'] == 'fatura':
            linhas[ym]['faturas'] -= l['valor']
        else:
            linhas[ym]['contas'] -= l['valor']
    try:
        for m in _compras.plano(c, hoje)['calendario']:
            if m['ym'] in linhas:
                linhas[m['ym']]['compras'] += m['total']
    except Exception:          # o plano de compras é um extra: sem ele a previsão continua valendo
        pass
    media = 0
    if estimar:
        # gasto do dia a dia: despesas confirmadas que não são parcela nem conta fixa, média dos 3 meses completos anteriores
        ini = somar_meses(base, -3).isoformat()
        tot = c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                               JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND k.tipo='despesa' AND t.plano_id IS NULL
                               AND t.previsao_id IS NULL AND t.data>=? AND t.data<?''', (ini, base.isoformat())).fetchone()[0]
        media = max(-(-tot // 3), 0) if tot > 0 else 0
        ja = c.execute(f'''SELECT COALESCE(SUM(l.valor_centavos),0) FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                              JOIN contas k ON k.id=l.conta_id WHERE {_REAL} AND k.tipo='despesa' AND t.plano_id IS NULL
                              AND t.previsao_id IS NULL AND t.data>=? AND t.data<=?''', (base.isoformat(), hoje.isoformat())).fetchone()[0]
        for i, ym in enumerate(yms):
            linhas[ym]['estimativa'] = max(media - max(ja, 0), 0) if i == 0 else media
    saldo = f['inicial']
    for ym, x in linhas.items():
        x['saidas'] = x['faturas'] + x['contas'] + x['compras'] + x['estimativa']
        saldo += x['entradas'] - x['saidas']
        x['saldo_fim'] = saldo
    return {'inicial': f['inicial'], 'meses': list(linhas.values()), 'media_dia_a_dia': media,
            'primeiro_negativo': next((x['ym'] for x in linhas.values() if x['saldo_fim'] < 0), None)}
