"""Leitura de páginas de nota fiscal salvas pelo usuário (R10, sem internet: quem abre a Sefaz é a pessoa, no navegador).

- **Página da NFC-e** (consulta pelo QR code ou detalhe na Nota Fiscal Paulista, salva com Ctrl+S): segue o leiaute padrão
  das consultas de NFC-e (itens em `txtTit`, `Rqtd`, `RUN`, `RvlUnit`, `valor`; emitente em `txtTopo`; totais em
  `totalNumb`; chave em `chave`). Se não for esse leiaute, tenta uma tabela com colunas de descrição, quantidade, valor
  unitário e total. Nada é aceito sem as mesmas travas do CSV.
- **Lista de documentos da Nota Fiscal Paulista** (salva com Ctrl+S): cada linha de tabela com data, CNPJ e valor vira um
  documento sem itens, para conferir com os lançamentos (toda compra com CPF na nota aparece ali, paga do jeito que for).
"""
import re
from html.parser import HTMLParser

from fin404.dinheiro import ErroValidacao, centavos, data as ler_data

RE_DATA = re.compile(r'\b(\d{2}/\d{2}/\d{4})\b')
RE_CNPJ = re.compile(r'\b(\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2})\b')
RE_VALOR = re.compile(r'(?<![\d.,])(\d{1,3}(?:\.\d{3})*,\d{2})(?![\d,])')
RE_CHAVE = re.compile(r'((?:\d[\s.]*){44})')
CLASSES = {'txtTopo', 'txtTit', 'RCod', 'Rqtd', 'RUN', 'RvlUnit', 'valor', 'totalNumb', 'chave'}


def _texto(dados):
    for cod in ('utf-8', 'cp1252', 'latin-1'):
        try:
            return dados.decode(cod)
        except UnicodeDecodeError:
            continue
    return dados.decode('utf-8', 'replace')


class _Coletor(HTMLParser):
    """Coleta, em ordem: (classe de interesse, texto) e as linhas de todas as tabelas, e o texto corrido da página."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pilha = []          # (tag, classe de interesse ou None, partes de texto)
        self.marcados = []
        self.tabelas = []
        self._linha = None
        self._celula = None
        self.corrido = []
        self._ignorar = 0

    def handle_starttag(self, tag, attrs):
        if tag in ('script', 'style'):
            self._ignorar += 1
        if tag in ('br', 'img', 'input', 'meta', 'link', 'hr'):
            return
        classes = set((dict(attrs).get('class') or '').split())
        alvo = next((k for k in ('txtTopo', 'RCod', 'Rqtd', 'RUN', 'RvlUnit', 'valor', 'totalNumb', 'chave', 'txtTit') if k in classes), None)
        self.pilha.append((tag, alvo, []))
        if tag == 'table':
            self.tabelas.append([])
        elif tag == 'tr' and self.tabelas:
            self._linha = []
        elif tag in ('td', 'th') and self._linha is not None:
            self._celula = []

    def handle_endtag(self, tag):
        if tag in ('script', 'style'):
            self._ignorar = max(0, self._ignorar - 1)
        if tag in ('td', 'th') and self._celula is not None and self._linha is not None:
            self._linha.append(' '.join(' '.join(self._celula).split()))
            self._celula = None
        elif tag == 'tr' and self._linha is not None and self.tabelas:
            if any(self._linha):
                self.tabelas[-1].append(self._linha)
            self._linha = None
        while self.pilha:
            t, alvo, partes = self.pilha.pop()
            if alvo:
                texto = ' '.join(' '.join(partes).split())
                self.marcados.append((alvo, texto))
            if self.pilha:
                self.pilha[-1][2].extend(partes)
            if t == tag:
                break

    def handle_data(self, data):
        if self._ignorar:
            return
        if self.pilha:
            self.pilha[-1][2].append(data)
        if self._celula is not None:
            self._celula.append(data)
        self.corrido.append(data)


def _coletar(dados):
    p = _Coletor()
    p.feed(_texto(dados))
    p.close()
    return p, ' '.join(' '.join(p.corrido).split())


def _valor(texto):
    m = RE_VALOR.search(texto or '')
    return centavos(m.group(1), permitir_zero=True) if m else None


def _qtd(texto):
    from fin404.dominio.notas import quantidade_mil
    m = re.search(r'(\d+(?:[.,]\d{1,4})?)', (texto or '').replace('Qtde.:', ''))
    if not m:
        raise ValueError('quantidade')
    t = m.group(1)
    if ',' in t:
        inteiro, frac = t.split(',')
        t = inteiro + ',' + frac[:3]
    elif '.' in t:
        inteiro, frac = t.split('.')
        t = inteiro + ',' + frac[:3]
    return quantidade_mil(t)


def _cabecalho(corrido, marcados):
    loja = next((t for k, t in marcados if k == 'txtTopo' and t), '')
    m_cnpj = RE_CNPJ.search(corrido)
    m_data = re.search(r'Emiss[ãa]o:?\s*(\d{2}/\d{2}/\d{4})', corrido) or RE_DATA.search(corrido)
    chave = ''
    for k, t in marcados:
        if k == 'chave':
            chave = re.sub(r'\D', '', t)
    if len(chave) != 44:
        m = re.search(r'Chave de acesso:?\s*((?:\d[\s.]*){44})', corrido, re.I) or RE_CHAVE.search(corrido)
        chave = re.sub(r'\D', '', m.group(1)) if m else ''
    if not loja:
        m = re.search(r'(?:Raz[ãa]o Social|Emitente|Nome)\s*:?\s*([^\d|]{3,80}?)\s+(?:CNPJ|Inscri|Endere|IE\b)', corrido, re.I)
        loja = m.group(1).strip() if m else ''
    cnpj = re.sub(r'\D', '', m_cnpj.group(1)) if m_cnpj else ''
    return {'loja': (loja or (f'CNPJ {cnpj}' if cnpj else ''))[:120], 'cnpj': cnpj,
            'data': ler_data(m_data.group(1)) if m_data else None, 'chave': chave if len(chave) == 44 else None}


def _itens_padrao(marcados):
    itens, atual = [], None
    for k, t in marcados:
        if k == 'txtTit':
            if not t or t.lower().startswith('vl. total') or t.lower().startswith('vl total'):
                continue
            atual = {'descricao': t[:200], 'gtin': '', 'qtd': None, 'unidade': 'UN', 'unit': None, 'total': None}
            itens.append(atual)
        elif atual is None:
            continue
        elif k == 'RCod':
            atual['gtin'] = re.sub(r'\D', '', t)
        elif k == 'Rqtd':
            atual['qtd'] = _qtd(t)
        elif k == 'RUN':
            atual['unidade'] = re.sub(r'(?i)^UN:\s*', '', t).strip().upper()[:6] or 'UN'
        elif k == 'RvlUnit':
            atual['unit'] = _valor(t)
        elif k == 'valor' and atual['total'] is None:
            atual['total'] = _valor(t)
    return itens


def _itens_tabela(tabelas):
    for linhas in tabelas:
        if len(linhas) < 2:
            continue
        cab = [c.lower() for c in linhas[0]]
        def col(*nomes):
            return next((i for i, c in enumerate(cab) if any(n in c for n in nomes)), None)
        i_desc, i_qtd, i_un = col('descri', 'produto'), col('qtd', 'quant'), col('un')
        i_unit, i_total = col('unit'), col('total')
        if None in (i_desc, i_qtd, i_total) or i_total == i_unit:
            continue
        itens = []
        for row in linhas[1:]:
            if len(row) <= max(x for x in (i_desc, i_qtd, i_total) if x is not None):
                continue
            total = _valor(row[i_total])
            if total is None or not row[i_desc]:
                continue
            itens.append({'descricao': row[i_desc][:200], 'gtin': '', 'qtd': _qtd(row[i_qtd]),
                          'unidade': (row[i_un].upper()[:6] if i_un is not None and i_un < len(row) and row[i_un] else 'UN'),
                          'unit': _valor(row[i_unit]) if i_unit is not None and i_unit < len(row) else None, 'total': total})
        if itens:
            return itens
    return []


def ler_pagina(dados):
    """Uma página de NFC-e salva → dict no formato de notas.gravar_nota. Levanta ErroValidacao se não reconhecer ou não fechar."""
    p, corrido = _coletar(dados)
    try:
        itens = _itens_padrao(p.marcados) or _itens_tabela(p.tabelas)
    except ValueError:
        itens = []
    if not itens:
        raise ErroValidacao('Não reconheci os itens desta página como uma nota fiscal (NFC-e). Salve a página do detalhe da nota '
                            '(Ctrl+S, "somente HTML") ou mande o arquivo para ajustarmos o leitor.')
    cab = _cabecalho(corrido, p.marcados)
    totais = [t for k, t in p.marcados if k == 'totalNumb']
    def total_rotulado(*rotulos):
        for r in rotulos:
            m = re.search(r + r'\s*(?:R\$)?\s*:?\s*(?:R\$)?\s*(\d{1,3}(?:\.\d{3})*,\d{2})', corrido, re.I)
            if m:
                return centavos(m.group(1), permitir_zero=True)
        return None
    pagar = total_rotulado(r'Valor a pagar', r'Valor pago', r'Valor total da nota', r'Valor total')
    desconto = total_rotulado(r'Descontos?') or 0
    if pagar is None and totais:
        pagar = _valor(totais[-1])
    for it in itens:
        if it['qtd'] is None:
            it['qtd'] = 1000
        if it['total'] is None and it['unit'] is not None:
            it['total'] = (it['qtd'] * it['unit'] + 500) // 1000
        if it['unit'] is None and it['total'] is not None:
            it['unit'] = (it['total'] * 1000 + it['qtd'] // 2) // it['qtd']
    if any(it['total'] is None for it in itens) or pagar is None or not cab['data']:
        raise ErroValidacao('A página não traz o total, a data ou o valor de algum item. Nada foi gravado.')
    nota = {**cab, 'total': pagar, 'desconto': desconto,
            'itens': [{'descricao': it['descricao'], 'gtin': it['gtin'], 'quantidade_mil': it['qtd'], 'unidade': it['unidade'],
                       'preco': it['unit'], 'total': it['total']} for it in itens]}
    soma = sum(i['total'] for i in nota['itens'])
    if soma - desconto != pagar:
        raise ErroValidacao(f'Os itens desta página somam {soma} centavos (desconto {desconto}), mas o total é {pagar}. Nada foi gravado.')
    if not nota['loja']:
        raise ErroValidacao('Não achei o nome da loja nem o CNPJ na página.')
    return nota


def ler_lista(dados):
    """Lista de documentos (Nota Fiscal Paulista): cada linha com data, CNPJ e valor vira um documento sem itens."""
    p, _ = _coletar(dados)
    docs = []
    for linhas in p.tabelas:
        for row in linhas:
            texto = ' | '.join(row)
            m_d, m_c, valores = RE_DATA.search(texto), RE_CNPJ.search(texto), RE_VALOR.findall(texto)
            if not (m_d and m_c and valores):
                continue
            nome = max((c for c in row if re.search(r'[A-Za-zÀ-ú]{3}', c) and not RE_VALOR.search(c) and not RE_DATA.search(c)),
                       key=len, default='')
            m_ch = RE_CHAVE.search(texto)
            chave = re.sub(r'\D', '', m_ch.group(1)) if m_ch else None
            docs.append({'data': ler_data(m_d.group(1)), 'cnpj': re.sub(r'\D', '', m_c.group(1)),
                         'loja': (nome or f'CNPJ {re.sub(r"[^0-9]", "", m_c.group(1))}')[:120],
                         'total': centavos(valores[0]), 'desconto': 0, 'chave': chave if chave and len(chave) == 44 else None,
                         'itens': []})
    if not docs:
        raise ErroValidacao('Não achei documentos nesta página (linhas com data, CNPJ e valor). Salve a página do resultado da '
                            'consulta de documentos da Nota Fiscal Paulista (Ctrl+S, "somente HTML").')
    return docs
