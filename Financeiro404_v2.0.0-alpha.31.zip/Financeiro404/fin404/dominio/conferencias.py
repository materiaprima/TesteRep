"""Completude dos dados (R11): histórico de conferências de saldo, alerta de conta sem conferência e trava do fechamento.

- Cada conferência fica gravada com a diferença encontrada. **Conferida** = bateu (diferença zero), inclusive depois de
  "lançar a diferença" ou ajustar, que gravam uma nova conferência já zerada.
- Alerta: conta corrente, poupança ou carteira ativa sem conferência que bateu há mais de 35 dias (contando da criação
  da conta, se nunca foi conferida).
- Fechamento do mês: toda conta disponível com movimento ou saldo até o fim do mês precisa estar conferida com data
  dentro do mês, ou ter a conferência dispensada para aquele mês (fica na auditoria).
"""
from datetime import date

from fin404.dinheiro import ErroValidacao, data as ler_data, fim_do_mes, mes as ler_mes

DIAS_ALERTA = 35
CONFERIVEIS_ALERTA = ('corrente', 'poupanca', 'carteira')


def registrar(c, conta_id, quando, saldo_informado):
    """Compara com o saldo calculado na data e grava o resultado. Devolve o mesmo dict de operacoes.conciliar_saldo."""
    from fin404.dominio import operacoes
    quando = ler_data(quando)
    r = operacoes.conciliar_saldo(c, conta_id, quando, saldo_informado)
    c.execute('INSERT INTO conferencias(conta_id, data, saldo_informado, saldo_calculado, diferenca) VALUES(?,?,?,?,?)',
              (conta_id, quando.isoformat(), saldo_informado, r['calculado'], r['diferenca']))
    return r


def ultima(c, conta_id, so_batidas=False):
    filtro = ' AND diferenca=0' if so_batidas else ''
    return c.execute(f'SELECT * FROM conferencias WHERE conta_id=?{filtro} ORDER BY data DESC, id DESC LIMIT 1',
                     (conta_id,)).fetchone()


def historico(c, conta_id, limite=12):
    return c.execute('SELECT * FROM conferencias WHERE conta_id=? ORDER BY data DESC, id DESC LIMIT ?', (conta_id, limite)).fetchall()


def alertas(c, hoje=None):
    """[(conta, dias, texto)] das contas sem conferência que bateu há mais de 35 dias."""
    hoje = ler_data(hoje or date.today())
    out = []
    marcas = ','.join('?' * len(CONFERIVEIS_ALERTA))
    for k in c.execute(f'SELECT * FROM contas WHERE ativa=1 AND subtipo IN ({marcas}) ORDER BY nome', CONFERIVEIS_ALERTA):
        ok = ultima(c, k['id'], so_batidas=True)
        referencia = ler_data(ok['data']) if ok else ler_data(k['criada_em'][:10])
        dias = (hoje - referencia).days
        if dias <= DIAS_ALERTA:
            continue
        if ok:
            texto = f'A conta {k["nome"]} não é conferida com o banco há {dias} dias.'
        else:
            texto = f'A conta {k["nome"]} nunca foi conferida com o banco.'
        ult = ultima(c, k['id'])
        if ult and ult['diferenca'] and (not ok or ult['id'] != ok['id']):
            texto += f' A última conferência ({ler_data(ult["data"]).strftime("%d/%m")}) não bateu.'
        out.append((k, dias, texto))
    return out


def situacao_do_mes(c, ym):
    """Contas disponíveis que o fechamento de `ym` exige, com o estado de cada uma:
    'conferida' (bateu, com data no mês), 'diferenca' (conferida no mês, mas não bateu), 'dispensada' ou 'pendente'."""
    from fin404.dominio import razao
    ym = ler_mes(ym)
    inicio, fim = ym + '-01', fim_do_mes(ym).isoformat()
    marcas = ','.join('?' * len(razao.DISPONIVEIS))
    # Só contas com movimento até o fim do mês (a data de criação não serve: contas cadastradas hoje recebem meses passados).
    contas = c.execute(f'''SELECT k.* FROM contas k WHERE k.ativa=1 AND k.subtipo IN ({marcas})
                           AND EXISTS(SELECT 1 FROM lancamentos l JOIN transacoes t ON t.id=l.transacao_id
                                      WHERE l.conta_id=k.id AND t.status<>'agendada' AND t.data<=?)
                           ORDER BY k.nome''', (*razao.DISPONIVEIS, fim)).fetchall()
    out = []
    for k in contas:
        # Vale a conferência mais recente do mês: se a última não bateu, uma anterior que bateu não serve mais.
        ultima_mes = c.execute('SELECT * FROM conferencias WHERE conta_id=? AND data BETWEEN ? AND ? ORDER BY data DESC, id DESC LIMIT 1',
                               (k['id'], inicio, fim)).fetchone()
        dispensa = c.execute('SELECT * FROM dispensas_conferencia WHERE mes=? AND conta_id=?', (ym, k['id'])).fetchone()
        bateu = ultima_mes if ultima_mes and ultima_mes['diferenca'] == 0 else None
        tentativa = ultima_mes
        if bateu:
            estado = 'conferida'
        elif dispensa:
            estado = 'dispensada'
        elif tentativa:
            estado = 'diferenca'
        else:
            estado = 'pendente'
        out.append({'conta': k, 'estado': estado, 'conferencia': bateu or tentativa, 'dispensa': dispensa})
    return out


def dispensar(c, ym, conta_id, motivo=''):
    from fin404.dados.banco import auditar
    from fin404.dominio import razao
    ym = ler_mes(ym)
    k = razao.conta(c, conta_id)
    motivo = (motivo or '').strip()[:200]
    c.execute('INSERT OR REPLACE INTO dispensas_conferencia(mes, conta_id, motivo) VALUES(?,?,?)', (ym, conta_id, motivo))
    auditar(c, 'dispensar_conferencia', 'conta', conta_id, f'{ym}: {k["nome"]}' + (f' — {motivo}' if motivo else ''))


def desfazer_dispensa(c, ym, conta_id):
    c.execute('DELETE FROM dispensas_conferencia WHERE mes=? AND conta_id=?', (ler_mes(ym), conta_id))


def fechar_mes(c, ym):
    """Fecha o mês só se toda conta exigida estiver conferida ou dispensada."""
    from fin404.dados.banco import auditar
    ym = ler_mes(ym)
    faltam = [s['conta']['nome'] for s in situacao_do_mes(c, ym) if s['estado'] in ('pendente', 'diferenca')]
    if faltam:
        raise ErroValidacao('Antes de fechar, confira com o banco ou dispense a conferência de: ' + ', '.join(faltam) + '.')
    c.execute('INSERT OR IGNORE INTO meses_fechados(mes) VALUES(?)', (ym,))
    auditar(c, 'fechar', 'mes', None, ym)
