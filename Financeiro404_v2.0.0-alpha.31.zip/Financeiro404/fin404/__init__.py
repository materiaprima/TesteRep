"""Financeiro 404 — gestão financeira familiar local, baseada em livro-razão."""
VERSAO = '2.0.0-alpha.31'
