"""Traz os dados da versão antiga (v0.2 a v1.0, tabela `entries`) para o livro-razão.

Nunca altera o arquivo antigo (aberto somente para leitura). Gera relatório comparando totais
por mês antes e depois. A simulação roda num banco temporário; a execução exige banco novo vazio.
"""
import json
import sqlite3
import tempfile
from collections import defaultdict
from pathlib import Path

from fin404.dados import banco
from fin404.dados.banco import auditar
from fin404.dinheiro import ErroValidacao
from fin404.dominio import operacoes, razao

CATEGORIAS = {
    'Moradia': 'Moradia', 'Mercado': 'Mercado', 'Restaurantes e delivery': 'Restaurantes e delivery',
    'Transporte e Uber': 'Transporte', 'Saúde e farmácia': 'Saúde', 'Vestuário': 'Vestuário',
    'Beleza': 'Beleza e cuidados', 'Lazer': 'Lazer e viagens', 'Assinaturas': 'Assinaturas',
    'Educação': 'Educação', 'Casa 404': 'Casa nova',
}
SUBTIPO = {'bank': 'corrente', 'cash': 'dinheiro', 'card': 'cartao'}


def _ler_legado(caminho):
    caminho = Path(caminho)
    if not caminho.exists():
        raise ErroValidacao('Arquivo da versão anterior não encontrado.')
    c = sqlite3.connect(Path(caminho).resolve().as_uri() + '?mode=ro', uri=True)
    c.row_factory = sqlite3.Row
    return c


def _tabela(c, nome):
    return c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (nome,)).fetchone() is not None


def _categoria(c, nome_antigo, tipo):
    if tipo == 'receita':
        nome = 'Outras receitas' if nome_antigo in ('Outros', '', None) else nome_antigo
    else:
        nome = CATEGORIAS.get(nome_antigo, 'Outras despesas')
    row = c.execute("SELECT id FROM contas WHERE tipo=? AND nome=?", (tipo, nome)).fetchone()
    if row:
        return row[0]
    return razao.criar_conta(c, nome, 'categoria', tipo_categoria=tipo)


def _totais_legado(old):
    tot = defaultdict(lambda: {'receitas': 0, 'despesas': 0})
    for r in old.execute("SELECT substr(due_date,1,7) ym, kind, SUM(amount_cents) v FROM entries GROUP BY ym, kind"):
        if r['kind'] == 'income':
            tot[r['ym']]['receitas'] += r['v']
        elif r['kind'] == 'expense':
            tot[r['ym']]['despesas'] += r['v']
    if _tabela(old, 'treasury_movements'):
        for r in old.execute('''SELECT substr(m.effective_date,1,7) ym, SUM(m.amount_cents) v FROM treasury_movements m
                                WHERE m.operation='refund' GROUP BY ym'''):
            tot[r['ym']]['estornos'] = r['v']
    return tot


def _totais_novos(c):
    tot = defaultdict(lambda: {'receitas': 0, 'despesas': 0})
    for r in c.execute('''SELECT substr(t.data,1,7) ym, k.tipo, SUM(l.valor_centavos) v FROM lancamentos l
                          JOIN transacoes t ON t.id=l.transacao_id JOIN contas k ON k.id=l.conta_id
                          WHERE k.tipo IN ('receita','despesa') AND t.tipo<>'estorno' GROUP BY ym, k.tipo'''):
        tot[r['ym']]['receitas' if r['tipo'] == 'receita' else 'despesas'] += -r['v'] if r['tipo'] == 'receita' else r['v']
    return tot


def _migrar(c, old):
    rel = {'contas': 0, 'lancamentos': 0, 'agendados': 0, 'revisar': [], 'transferencias': 0, 'pagamentos': 0,
           'estornos': 0, 'saldos_iniciais': 0, 'previsoes': 0, 'orcamentos': 0, 'nao_migrado': []}
    if c.execute("SELECT COUNT(*) FROM transacoes").fetchone()[0]:
        raise ErroValidacao('O banco novo já tem lançamentos. A migração só pode ser feita num banco vazio.')
    mapa_conta, mapa_entry = {}, {}
    for a in old.execute('SELECT * FROM accounts ORDER BY id'):
        sub = SUBTIPO.get(a['kind'], 'corrente')
        nome = a['name']
        tipo = razao.SUBTIPOS[sub][0]
        if c.execute('SELECT 1 FROM contas WHERE tipo=? AND lower(nome)=lower(?)', (tipo, nome)).fetchone():
            nome = f'{nome} (v0.9)'
        if sub == 'cartao':
            cid = c.execute("INSERT INTO contas(nome,tipo,subtipo) VALUES(?,?,?)", (nome, 'passivo', 'cartao')).lastrowid
            rel['revisar'].append(f'Cartão "{nome}": informe os dias de fechamento e vencimento.')
        else:
            cid = razao.criar_conta(c, nome, sub)
        mapa_conta[a['id']] = cid
        rel['contas'] += 1
    for e in old.execute('SELECT * FROM entries ORDER BY id'):
        conta = mapa_conta[e['account_id']]
        k = razao.conta(c, conta)
        v = e['amount_cents']
        obs = []
        if e['event_date'] != e['due_date']:
            obs.append(f'compra em {e["event_date"]}')
        if e['notes']:
            obs.append(e['notes'])
        importado = 'Importado' in (e['notes'] or '')
        if importado:
            rel['revisar'].append(f'Lançamento importado "{e["description"]}" ({e["due_date"]}): confira se não é pagamento de fatura ou transferência.')
        desc = e['description'] + (f' ({e["installment"]}/{e["installments"]})' if (e['installments'] or 1) > 1 else '')
        if k['subtipo'] == 'cartao':
            status = 'confirmada'          # compra no cartão é real; "pago" na versão antiga significava fatura paga
        else:
            status = 'confirmada' if e['status'] == 'paid' else 'agendada'
        if e['kind'] == 'income':
            tid = razao.registrar(c, e['due_date'], desc, 'receita',
                                  [(conta, v), (_categoria(c, e['category'], 'receita'), -v)], status=status,
                                  observacao='; '.join(obs))
        elif e['kind'] == 'expense':
            tid = razao.registrar(c, e['due_date'], desc, 'despesa',
                                  [(_categoria(c, e['category'], 'despesa'), v), (conta, -v)], status=status,
                                  observacao='; '.join(obs))
        else:
            tid = razao.registrar(c, e['due_date'], desc, 'ajuste',
                                  [(conta, -v), (razao.conta_sistema(c, 'ajuste'), v)], status=status,
                                  observacao='Transferência sem contrapartida na versão antiga')
            rel['revisar'].append(f'"{e["description"]}" era uma transferência sem conta de destino; ficou como ajuste.')
        mapa_entry[e['id']] = tid
        rel['lancamentos'] += 1
        rel['agendados'] += status == 'agendada'
    if _tabela(old, 'treasury_movements'):
        for m in old.execute('SELECT * FROM treasury_movements ORDER BY id'):
            v = m['amount_cents']
            if m['operation'] == 'transfer':
                razao.registrar(c, m['effective_date'], m['description'], 'transferencia',
                                [(mapa_conta[m['destination_account']], v), (mapa_conta[m['source_account']], -v)])
                rel['transferencias'] += 1
            elif m['operation'] == 'card_payment':
                razao.registrar(c, m['effective_date'], m['description'], 'pagamento_fatura',
                                [(mapa_conta[m['destination_account']], v), (mapa_conta[m['source_account']], -v)])
                rel['pagamentos'] += 1
            elif m['operation'] == 'refund':
                original = mapa_entry.get(m['entry_id'])
                if original:
                    razao.estornar(c, original, v, m['effective_date'], m['description'])
                else:
                    razao.registrar(c, m['effective_date'], m['description'], 'estorno',
                                    [(mapa_conta[m['destination_account']], v), (_categoria(c, 'Outros', 'despesa'), -v)])
                rel['estornos'] += 1
            else:
                rel['nao_migrado'].append(f'Movimento {m["id"]} ({m["operation"]})')
    if _tabela(old, 'opening_balances'):
        for o in old.execute('SELECT * FROM opening_balances'):
            operacoes.saldo_inicial(c, mapa_conta[o['account_id']], o['as_of'], o['cents'])
            rel['saldos_iniciais'] += 1
    if _tabela(old, 'card_statements'):
        for s in old.execute('SELECT * FROM card_statements'):
            c.execute('INSERT OR REPLACE INTO faturas_documento(conta_cartao_id,fechamento,total_centavos,origem) VALUES(?,?,?,?)',
                      (mapa_conta[s['card_account']], s['closing_date'], s['stated_total_cents'], 'v0.9'))
    if _tabela(old, 'recurring'):
        for r in old.execute('SELECT * FROM recurring'):
            tipo = 'receita' if r['kind'] == 'income' else 'despesa'
            c.execute('''INSERT INTO previsoes(descricao,valor_centavos,conta_id,contraparte_id,sentido,dia,inicio,fim)
                         VALUES(?,?,?,?,?,?,?,?)''', (r['description'], r['amount_cents'], mapa_conta[r['account_id']],
                                                       _categoria(c, r['category'], tipo), 'entrada' if tipo == 'receita' else 'saida',
                                                       r['day'], r['start_month'], r['end_month']))
            rel['previsoes'] += 1
    if _tabela(old, 'budgets'):
        for b in old.execute('SELECT * FROM budgets'):
            c.execute('INSERT OR REPLACE INTO orcamentos(mes,conta_id,valor_centavos) VALUES(?,?,?)',
                      (b['month'], _categoria(c, b['category'], 'despesa'), b['limit_cents']))
            rel['orcamentos'] += 1
    if _tabela(old, 'goals') and old.execute('SELECT COUNT(*) FROM goals').fetchone()[0]:
        rel['nao_migrado'].append('Metas: anote-as e recrie em Planejamento → Metas (o formato antigo não tem prazo nem conta).')
    antigo, novo = _totais_legado(old), _totais_novos(c)
    meses = sorted(set(antigo) | set(novo))
    rel['comparacao'] = [{'mes': m, 'receitas_antes': antigo[m]['receitas'], 'receitas_depois': novo[m]['receitas'],
                          'despesas_antes': antigo[m]['despesas'], 'despesas_depois': novo[m]['despesas']} for m in meses]
    rel['totais_conferem'] = all(x['receitas_antes'] == x['receitas_depois'] and x['despesas_antes'] == x['despesas_depois']
                                 for x in rel['comparacao'])
    problemas = razao.verificar_tudo(c)
    if problemas:
        raise ErroValidacao('Migração interrompida: ' + '; '.join(problemas[:5]))
    return rel


def simular(caminho_legado):
    old = _ler_legado(caminho_legado)
    try:
        with tempfile.TemporaryDirectory() as tmp:
            destino = Path(tmp) / 'simulacao.sqlite3'
            banco.migrar(destino)
            with banco.transacao(destino) as c:
                rel = _migrar(c, old)
            return rel
    finally:
        old.close()


def executar(caminho_legado):
    old = _ler_legado(caminho_legado)
    try:
        banco.migrar()
        with banco.transacao() as c:
            rel = _migrar(c, old)
            if not rel['totais_conferem']:
                raise ErroValidacao('Os totais por mês não conferem depois da migração. Nada foi gravado.')
            auditar(c, 'migrar', 'v0.9', None, json.dumps({k: v for k, v in rel.items() if k != 'comparacao'}, ensure_ascii=False))
        return rel
    finally:
        old.close()


def arquivo_legado():
    p = banco.pasta_dados() / 'financeiro.sqlite3'
    return p if p.exists() else None
