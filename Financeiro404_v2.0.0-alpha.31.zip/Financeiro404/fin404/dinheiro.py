"""Conversão de valores monetários e datas no padrão brasileiro.

Todo valor é tratado como inteiro em centavos. Nenhuma função aqui usa float.
"""
import calendar
import re
from datetime import date, timedelta
from decimal import Decimal, InvalidOperation

LIMITE_CENTAVOS = 99_999_999_999  # R$ 999.999.999,99


class ErroValidacao(ValueError):
    """Erro de entrada do usuário, com mensagem pronta para exibição."""


_MILHAR_VIRGULA = re.compile(r'\d{1,3}(?:\.\d{3})+(?:,\d{1,2})?|\d+(?:,\d{1,2})?')
_PONTO_DECIMAL = re.compile(r'\d+\.\d{1,2}')


def centavos(texto, permitir_negativo=False, permitir_zero=False):
    """Converte '1.234,56', '1234,56', '1234', '1234.56', 'R$ 12,30', '-12,30',
    '12,30-', '12,30 D' e '12,30 C' para centavos.

    Sufixos: 'D' ou '-' no fim = negativo; 'C' = positivo (extratos bancários).
    """
    if isinstance(texto, int) and not isinstance(texto, bool):
        valor = texto
    else:
        s = str(texto or '').strip().upper().replace('R$', '').replace(' ', '').replace(' ', '')
        if not s:
            raise ErroValidacao('Informe um valor.')
        negativo = False
        if s.endswith('D'):
            negativo, s = True, s[:-1]
        elif s.endswith('C'):
            s = s[:-1]
        if s.startswith('(') and s.endswith(')'):
            negativo, s = True, s[1:-1]
        if s.startswith('-'):
            negativo, s = not negativo, s[1:]
        elif s.startswith('+'):
            s = s[1:]
        if s.endswith('-'):
            negativo, s = not negativo, s[:-1]
        if _MILHAR_VIRGULA.fullmatch(s):
            numero = s.replace('.', '').replace(',', '.')
        elif _PONTO_DECIMAL.fullmatch(s):
            numero = s
        else:
            raise ErroValidacao(f'Valor inválido: "{texto}". Use, por exemplo, 1.234,56 ou 1234,56.')
        try:
            valor = int(Decimal(numero) * 100)
        except InvalidOperation:
            raise ErroValidacao(f'Valor inválido: "{texto}".')
        if negativo:
            valor = -valor
    if abs(valor) > LIMITE_CENTAVOS:
        raise ErroValidacao('Valor acima do limite permitido.')
    if valor == 0 and not permitir_zero:
        raise ErroValidacao('O valor não pode ser zero.')
    if valor < 0 and not permitir_negativo:
        raise ErroValidacao('Informe um valor positivo.')
    return valor


def percentual(texto):
    """'1,85' ou '1.85' -> Decimal('1.85'). Rejeita NaN e infinito."""
    s = str(texto or '').strip().replace('%', '').replace(' ', '')
    if not re.fullmatch(r'\d{1,3}(?:[.,]\d{1,6})?', s):
        raise ErroValidacao(f'Taxa inválida: "{texto}". Use, por exemplo, 1,85.')
    return Decimal(s.replace(',', '.'))


def formatar(cent, sinal=True):
    neg = cent < 0
    inteiro, resto = divmod(abs(cent), 100)
    s = f'{inteiro:,}'.replace(',', '.') + f',{resto:02d}'
    return ('−' if neg and sinal else '') + 'R$ ' + s


def para_campo(cent):
    """Valor para preencher um campo de formulário (sem 'R$')."""
    inteiro, resto = divmod(abs(cent), 100)
    return ('-' if cent < 0 else '') + f'{inteiro},{resto:02d}'


def data(texto):
    """Aceita AAAA-MM-DD, DD/MM/AAAA e DD/MM/AA."""
    if isinstance(texto, date):
        return texto
    s = str(texto or '').strip()
    try:
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', s):
            return date.fromisoformat(s)
        m = re.fullmatch(r'(\d{1,2})/(\d{1,2})/(\d{2}|\d{4})', s)
        if m:
            d, mes, a = (int(x) for x in m.groups())
            if a < 100:
                a += 2000
            return date(a, mes, d)
    except ValueError:
        pass
    raise ErroValidacao(f'Data inválida: "{texto}". Use DD/MM/AAAA.')


def mes(texto):
    s = str(texto or '').strip()
    if not re.fullmatch(r'\d{4}-\d{2}', s) or not 1 <= int(s[5:]) <= 12:
        raise ErroValidacao(f'Mês inválido: "{texto}".')
    return s


def somar_meses(d, n):
    a = d.year + (d.month - 1 + n) // 12
    m = (d.month - 1 + n) % 12 + 1
    return date(a, m, min(d.day, calendar.monthrange(a, m)[1]))


def dia_no_mes(ano, m, dia):
    return date(ano, m, min(dia, calendar.monthrange(ano, m)[1]))


def fim_do_mes(ym):
    a, m = int(ym[:4]), int(ym[5:])
    return date(a, m, calendar.monthrange(a, m)[1])


def mes_seguinte(ym):
    return somar_meses(date.fromisoformat(ym + '-01'), 1).strftime('%Y-%m')


def fmt_data(d):
    d = data(d)
    return d.strftime('%d/%m/%Y')


MESES = ('jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez')


def fmt_mes(ym):
    return f'{MESES[int(ym[5:]) - 1]}/{ym[:4]}'


def dividir(total, n):
    """Divide total em n partes inteiras; o resto vai para as primeiras."""
    q, r = divmod(total, n)
    return [q + (1 if i < r else 0) for i in range(n)]


def um_dia(d):
    return d + timedelta(days=1)
