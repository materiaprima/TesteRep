"""PIN de acesso ao programa, sessões e proteção contra tentativas repetidas.

- PIN guardado como hash scrypt (biblioteca padrão), nunca em texto.
- Sessão por cookie HttpOnly + SameSite=Strict, válida só enquanto o programa está aberto.
- Bloqueio automático após `inatividade` minutos sem uso.
- Após 5 PINs errados, espera crescente (1 min, depois 5 min).
Esquecer o PIN: feche o programa e rode `ferramentas/remover_pin.py` (exige acesso aos arquivos do computador).
"""
import base64
import hashlib
import hmac
import os
import secrets
import threading
import time

from fin404.dados import config
from fin404.dinheiro import ErroValidacao

COOKIE = 'fin404_sessao'
_N, _R, _P = 2 ** 14, 8, 1
_sessoes = {}            # token -> último uso (time.monotonic)
_falhas = {'n': 0, 'ate': 0.0}
_trava = threading.Lock()


def _hash(pin, sal, n=_N, r=_R, p=_P):
    return hashlib.scrypt(pin.encode('utf-8'), salt=sal, n=n, r=r, p=p, dklen=32)


def pin_ativo(c=None):
    return config.obter('pin', None, c) is not None


def inatividade_minutos(c=None):
    return int(config.obter('pin_inatividade', 30, c))


def definir_pin(pin, inatividade=30, c=None):
    pin = (pin or '').strip()
    if not (4 <= len(pin) <= 32):
        raise ErroValidacao('O PIN deve ter de 4 a 32 caracteres (recomendado: 6 ou mais).')
    if pin.isdigit() and len(set(pin)) == 1:
        raise ErroValidacao('Escolha um PIN que não seja um número repetido.')
    inatividade = int(inatividade)
    if not 5 <= inatividade <= 480:
        raise ErroValidacao('O bloqueio por inatividade deve ficar entre 5 e 480 minutos.')
    sal = os.urandom(16)
    config.definir('pin', {'sal': base64.b64encode(sal).decode(), 'hash': base64.b64encode(_hash(pin, sal)).decode(),
                           'n': _N, 'r': _R, 'p': _P}, c)
    config.definir('pin_inatividade', inatividade, c)


def remover_pin(c=None):
    config.definir('pin', None, c)
    with _trava:
        _sessoes.clear()


def _espera_restante():
    return max(0, int(_falhas['ate'] - time.monotonic()))


def verificar_pin(pin, c=None):
    """Confere o PIN e devolve um token de sessão. Levanta ErroValidacao se errado ou bloqueado."""
    with _trava:
        espera = _espera_restante()
    if espera:
        raise ErroValidacao(f'Muitas tentativas erradas. Aguarde {espera} segundos.')
    dados = config.obter('pin', None, c)
    if dados is None:
        return nova_sessao()
    esperado = base64.b64decode(dados['hash'])
    calculado = _hash((pin or '').strip(), base64.b64decode(dados['sal']), dados['n'], dados['r'], dados['p'])
    if not hmac.compare_digest(esperado, calculado):
        with _trava:
            _falhas['n'] += 1
            if _falhas['n'] >= 5:
                _falhas['ate'] = time.monotonic() + (60 if _falhas['n'] < 10 else 300)
        raise ErroValidacao('PIN incorreto.')
    with _trava:
        _falhas['n'] = 0
        _falhas['ate'] = 0.0
    return nova_sessao()


def nova_sessao():
    token = secrets.token_urlsafe(32)
    with _trava:
        _sessoes[token] = time.monotonic()
    return token


def sessao_valida(token, c=None):
    if not token:
        return False
    limite = inatividade_minutos(c) * 60
    with _trava:
        ultimo = _sessoes.get(token)
        if ultimo is None:
            return False
        if time.monotonic() - ultimo > limite:
            _sessoes.pop(token, None)
            return False
        _sessoes[token] = time.monotonic()
        return True


def encerrar(token):
    with _trava:
        _sessoes.pop(token, None)


def cabecalho_cookie(token):
    return f'{COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/'


def ler_cookie(cabecalho):
    for parte in (cabecalho or '').split(';'):
        nome, _, valor = parte.strip().partition('=')
        if nome == COOKIE:
            return valor
    return None
