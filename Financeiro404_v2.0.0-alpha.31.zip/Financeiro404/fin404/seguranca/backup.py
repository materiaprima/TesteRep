"""Backup cifrado e restauração guiada com troca segura do banco.

Formato FIN404ENC2: 'FIN404ENC2' | versão(1) | log2(N)(1) | r(1) | p(1) | sal(16) | nonce(12) | AES-256-GCM(dados)
O cabeçalho inteiro é dado autenticado (AAD): qualquer alteração invalida o arquivo.
Também lê o formato antigo FIN404ENC1 (v0.6–v1.0, scrypt N=2^15).

Formato FIN404ENC3 (backup automático, sem senha guardada no computador):
'FIN404ENC3' | versão(1) | tamanho(4) | chave privada X25519 cifrada pela senha (formato ENC2) | chave efêmera(32) | nonce(12) | AES-256-GCM(dados)
O computador guarda só a chave PÚBLICA: consegue cifrar, mas não decifrar. A chave privada vai dentro de cada
backup, protegida pela senha (scrypt). Para restaurar, basta o arquivo e a senha.
"""
import datetime
import logging
import os
import shutil
import sqlite3
import struct
import tempfile
import time
from pathlib import Path

from fin404.dados import banco
from fin404.dinheiro import ErroValidacao

log = logging.getLogger('fin404')

MAGICO_V3 = b'FIN404ENC3'
MAGICO_V2 = b'FIN404ENC2'
MAGICO_V1 = b'FIN404ENC1'
LOG_N, R, P = 17, 8, 1          # scrypt: N=2^17 (mínimo recomendado pela OWASP), r=8, p=1
SENHA_MINIMA = 12


def _crypto():
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
    except ImportError:
        raise ErroValidacao('Para backup cifrado, instale o pacote "cryptography" (veja o README).')
    return AESGCM, Scrypt


def cifrar(dados, senha):
    if len(senha or '') < SENHA_MINIMA:
        raise ErroValidacao(f'A senha do backup precisa ter ao menos {SENHA_MINIMA} caracteres.')
    AESGCM, Scrypt = _crypto()
    sal, nonce = os.urandom(16), os.urandom(12)
    cab = MAGICO_V2 + struct.pack('BBBB', 2, LOG_N, R, P) + sal + nonce
    chave = Scrypt(salt=sal, length=32, n=2 ** LOG_N, r=R, p=P).derive(senha.encode('utf-8'))
    return cab + AESGCM(chave).encrypt(nonce, dados, cab)


def _x25519():
    try:
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
        from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    except ImportError:
        raise ErroValidacao('Para backup cifrado, instale o pacote "cryptography" (veja o README).')
    return X25519PrivateKey, X25519PublicKey, HKDF, hashes, serialization


def _chave_sessao(compartilhado):
    _, _, HKDF, hashes, _ = _x25519()
    return HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b'fin404-enc3').derive(compartilhado)


def criar_chaves(senha):
    """Gera o par de chaves do backup automático. Devolve (pública, privada_cifrada_pela_senha)."""
    X25519PrivateKey, _, _, _, serialization = _x25519()
    privada = X25519PrivateKey.generate()
    bruta = privada.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
    publica = privada.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return publica, cifrar(bruta, senha)


def cifrar_publica(dados, publica, privada_cifrada):
    AESGCM, _ = _crypto()
    X25519PrivateKey, X25519PublicKey, _, _, serialization = _x25519()
    efemera = X25519PrivateKey.generate()
    chave = _chave_sessao(efemera.exchange(X25519PublicKey.from_public_bytes(publica)))
    nonce = os.urandom(12)
    cab = (MAGICO_V3 + struct.pack('>BI', 3, len(privada_cifrada)) + privada_cifrada +
           efemera.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw) + nonce)
    return cab + AESGCM(chave).encrypt(nonce, dados, cab)


def decifrar(blob, senha):
    AESGCM, Scrypt = _crypto()
    from cryptography.exceptions import InvalidTag
    if blob.startswith(MAGICO_V3) and len(blob) > 15:
        versao, tam = struct.unpack('>BI', blob[10:15])
        if versao != 3 or tam > 4096 or len(blob) < 15 + tam + 44:
            raise ErroValidacao('Cabeçalho do backup inválido.')
        privada_cifrada = blob[15:15 + tam]
        efemera = blob[15 + tam:15 + tam + 32]
        nonce = blob[15 + tam + 32:15 + tam + 44]
        cab = blob[:15 + tam + 44]
        X25519PrivateKey, X25519PublicKey, _, _, _ = _x25519()
        privada = X25519PrivateKey.from_private_bytes(decifrar(privada_cifrada, senha))
        chave = _chave_sessao(privada.exchange(X25519PublicKey.from_public_bytes(efemera)))
        try:
            return AESGCM(chave).decrypt(nonce, blob[len(cab):], cab)
        except InvalidTag:
            raise ErroValidacao('Arquivo de backup alterado ou corrompido.')
    if blob.startswith(MAGICO_V2) and len(blob) > 42:
        versao, log_n, r, p = struct.unpack('BBBB', blob[10:14])
        if versao != 2 or not 14 <= log_n <= 22 or r > 32 or p > 4:
            raise ErroValidacao('Cabeçalho do backup inválido.')
        sal, nonce, cab = blob[14:30], blob[30:42], blob[:42]
        chave = Scrypt(salt=sal, length=32, n=2 ** log_n, r=r, p=p).derive((senha or '').encode('utf-8'))
        corpo, aad = blob[42:], cab
    elif blob.startswith(MAGICO_V1) and len(blob) > 38:
        sal, nonce = blob[10:26], blob[26:38]
        chave = Scrypt(salt=sal, length=32, n=2 ** 15, r=8, p=1).derive((senha or '').encode('utf-8'))
        corpo, aad = blob[38:], MAGICO_V1
    else:
        raise ErroValidacao('Este arquivo não é um backup do Financeiro 404.')
    try:
        return AESGCM(chave).decrypt(nonce, corpo, aad)
    except InvalidTag:  # só a falha de autenticação vira "senha incorreta"; outro erro aparece como erro de verdade
        raise ErroValidacao('Senha incorreta ou arquivo de backup alterado/corrompido.')


def gerar(senha):
    """Retorna (nome_sugerido, bytes) do backup cifrado do banco atual."""
    with tempfile.TemporaryDirectory() as tmp:
        copia = banco.copia_consistente(Path(tmp) / 'copia.sqlite3')
        dados = copia.read_bytes()
    nome = 'financeiro404_' + datetime.datetime.now().strftime('%Y-%m-%d_%H%M') + '.fin404'
    return nome, cifrar(dados, senha)


def configurar_automatico(senha, pasta, manter=30):
    """Ativa o backup automático cifrado numa pasta (pendrive, OneDrive…). A senha não é guardada."""
    from fin404.dados import config
    if (senha or '') and len(senha) < SENHA_MINIMA:
        raise ErroValidacao(f'A senha do backup precisa ter ao menos {SENHA_MINIMA} caracteres.')
    destino = Path((pasta or '').strip().strip('"'))
    if not str(destino) or not destino.is_absolute():
        raise ErroValidacao('Informe o caminho completo da pasta (por exemplo, D:\\Backups ou a pasta do OneDrive).')
    if not destino.is_dir():
        raise ErroValidacao('A pasta não existe ou não está acessível agora (pendrive desconectado?).')
    try:
        teste = destino / '.fin404_teste_escrita'
        teste.write_bytes(b'ok'); teste.unlink()
    except OSError:
        raise ErroValidacao('Não foi possível gravar nessa pasta. Escolha outra.')
    if destino.resolve() == banco.pasta_dados().resolve():
        raise ErroValidacao('Escolha uma pasta fora da pasta de dados do programa (de preferência, fora do notebook).')
    import base64
    publica, privada_cifrada = criar_chaves(senha)
    config.definir('backup_auto', {'pasta': str(destino), 'publica': base64.b64encode(publica).decode(),
                                   'privada_cifrada': base64.b64encode(privada_cifrada).decode(), 'manter': int(manter)})
    config.definir('backup_auto_status', None)
    return executar_automatico(forcar=True)


def desativar_automatico():
    from fin404.dados import config
    config.definir('backup_auto', None)
    config.definir('backup_auto_status', None)


LEIA_ME = """COMO RECUPERAR ESTES BACKUPS (mesmo sem o Financeiro 404)
=========================================================

Cada arquivo financeiro404_auto_AAAA-MM-DD.fin404 e uma copia cifrada do banco de dados daquele dia.
Para abrir, voce precisa da SENHA DO BACKUP (a que foi definida em "Backup e seguranca"). Sem ela, nao ha como abrir.

Com o Financeiro 404 instalado:
  Backup e seguranca > Restaurar > escolha o arquivo > digite a senha.

Sem o programa (computador novo, programa perdido):
  1. Instale o Python 3.10 ou mais novo (python.org), marcando "Add python.exe to PATH".
  2. Abra o Prompt de Comando nesta pasta e rode:
       py -m pip install cryptography
       py recuperar_backup.py financeiro404_auto_AAAA-MM-DD.fin404
  3. Digite a senha. Sai um arquivo .sqlite3 com todos os dados, conferido.
  4. Para voltar a usar o programa: instale o Financeiro 404, feche-o e coloque o .sqlite3 em
     data\\financeiro_v2.sqlite3 dentro da pasta do programa. Ou abra o .sqlite3 no DB Browser for SQLite.

Guarde tambem uma copia do instalador (o .zip do Financeiro 404) nesta mesma pasta.
"""


def _kit_de_recuperacao(destino):
    """Deixa na pasta dos backups o script que decifra sem o programa e as instruções (só regrava se mudou)."""
    script = Path(__file__).resolve().parents[2] / 'ferramentas' / 'recuperar_backup.py'
    itens = [('LEIA-ME_RECUPERACAO.txt', LEIA_ME.encode('utf-8'))]
    if script.is_file():
        itens.append(('recuperar_backup.py', script.read_bytes()))
    for nome, conteudo in itens:
        alvo = destino / nome
        try:
            if not alvo.is_file() or alvo.read_bytes() != conteudo:
                alvo.write_bytes(conteudo)
        except OSError:  # o backup em si já foi gravado; o kit é um extra, mas a falha fica registrada
            log.warning('Não foi possível gravar %s na pasta do backup', alvo, exc_info=True)


def executar_automatico(forcar=False):
    """Gera o backup do dia na pasta configurada (uma vez por dia). Guarda o resultado em backup_auto_status."""
    import base64
    from fin404.dados import config
    cfg = config.obter('backup_auto')
    if not cfg:
        return None
    hoje = datetime.date.today().isoformat()
    status = config.obter('backup_auto_status') or {}
    if not forcar and status.get('ultimo_sucesso', '')[:10] == hoje:
        return status
    destino = Path(cfg['pasta'])
    try:
        if not destino.is_dir():
            raise OSError('pasta indisponível')
        with tempfile.TemporaryDirectory() as tmp:
            dados = banco.copia_consistente(Path(tmp) / 'copia.sqlite3').read_bytes()
        blob = cifrar_publica(dados, base64.b64decode(cfg['publica']), base64.b64decode(cfg['privada_cifrada']))
        final = destino / f'financeiro404_auto_{hoje}.fin404'
        parcial = destino / f'.financeiro404_auto_{hoje}.parcial'
        parcial.write_bytes(blob)
        os.replace(parcial, final)
        _kit_de_recuperacao(destino)
        antigos = sorted(destino.glob('financeiro404_auto_*.fin404'))[:-int(cfg.get('manter', 30))]
        for a in antigos:
            a.unlink(missing_ok=True)
        status = {'ultimo_sucesso': datetime.datetime.now().isoformat(timespec='seconds'), 'arquivo': final.name, 'erro': ''}
    except OSError as exc:
        status = dict(status, erro=f'{datetime.datetime.now():%d/%m %H:%M}: não foi possível gravar em {destino} ({exc.strerror or exc}).')
    config.definir('backup_auto_status', status)
    return status


def testar_automatico(senha):
    """Abre o backup automático mais recente com a senha, num arquivo temporário, e confere a integridade.

    Não toca no banco em uso. Grava o resultado em `backup_verificado` (data, arquivo, número de lançamentos).
    """
    from fin404.dados import config
    cfg = config.obter('backup_auto')
    if not cfg:
        raise ErroValidacao('O backup automático não está ativado.')
    pasta = Path(cfg['pasta'])
    arquivos = sorted(pasta.glob('financeiro404_auto_*.fin404')) if pasta.is_dir() else []
    if not arquivos:
        raise ErroValidacao(f'Nenhum backup automático encontrado em {pasta}.')
    ultimo = arquivos[-1]
    dados = decifrar(ultimo.read_bytes(), senha)
    with tempfile.TemporaryDirectory() as tmp:
        caminho = Path(tmp) / 'teste.sqlite3'
        caminho.write_bytes(dados)
        info = _examinar(caminho)
    resultado = {'em': datetime.datetime.now().isoformat(timespec='seconds'), 'arquivo': ultimo.name,
                 'transacoes': info['transacoes'], 'ultima_data': info['ultima_data']}
    config.definir('backup_verificado', resultado)
    return resultado


def _examinar(caminho):
    c = sqlite3.connect(Path(caminho).resolve().as_uri() + '?mode=ro', uri=True)
    try:
        if c.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
            raise ErroValidacao('O banco dentro do backup está corrompido.')
        if c.execute('PRAGMA foreign_key_check').fetchall():
            raise ErroValidacao('O banco dentro do backup tem referências inválidas.')
        tabelas = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if 'transacoes' in tabelas:
            n = c.execute('SELECT COUNT(*) FROM transacoes').fetchone()[0]
            ultima = c.execute('SELECT MAX(data) FROM transacoes').fetchone()[0]
            return {'formato': 'v2', 'transacoes': n, 'ultima_data': ultima,
                    'contas': c.execute("SELECT COUNT(*) FROM contas WHERE tipo IN ('ativo','passivo')").fetchone()[0],
                    'versao': c.execute('PRAGMA user_version').fetchone()[0]}
        if 'entries' in tabelas:
            return {'formato': 'v0.9', 'transacoes': c.execute('SELECT COUNT(*) FROM entries').fetchone()[0],
                    'ultima_data': c.execute('SELECT MAX(due_date) FROM entries').fetchone()[0], 'contas': None, 'versao': None}
        raise ErroValidacao('O arquivo não contém um banco do Financeiro 404.')
    finally:
        c.close()


def preparar_restauracao(blob, senha):
    """Decifra, valida e guarda o banco recuperado em data/restauracoes/. Não toca no banco em uso."""
    if len(blob) > 200_000_000:
        raise ErroValidacao('Backup acima de 200 MB.')
    dados = decifrar(blob, senha)
    pasta = banco.pasta_dados() / 'restauracoes'
    pasta.mkdir(parents=True, exist_ok=True)
    destino = pasta / ('recuperado_' + datetime.datetime.now().strftime('%Y%m%d_%H%M%S') + '.sqlite3')
    tmp = destino.with_suffix('.tmp')
    tmp.write_bytes(dados)
    try:
        info = _examinar(tmp)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise
    os.replace(tmp, destino)
    return destino, info


def _substituir(origem, destino, tentativas=6, espera=0.25):
    """os.replace com novas tentativas: no Windows, antivírus, indexador ou OneDrive seguram o arquivo por instantes."""
    for n in range(tentativas):
        try:
            os.replace(origem, destino)
            return
        except PermissionError:
            if n == tentativas - 1:
                raise
            time.sleep(espera * (n + 1))


def _checkpoint(caminho):
    """Passa todo o WAL para o arquivo principal. Se outro programa estiver lendo o banco, o WAL não esvazia, e tirá-lo
    do lugar perderia dados: nesse caso, para tudo."""
    c = sqlite3.connect(caminho, timeout=5)
    try:
        ocupado, paginas, copiadas = c.execute('PRAGMA wal_checkpoint(TRUNCATE)').fetchone()
    finally:
        c.close()
    if ocupado or (paginas != -1 and paginas != copiadas):
        raise ErroValidacao('Outro programa está com o banco aberto (visualizador de SQLite, antivírus, sincronização). '
                            'Feche-o e tente de novo.')


def _afastar_extras(ativo, destino_base):
    movidos = []
    for sufixo in ('-wal', '-shm'):
        extra = Path(str(ativo) + sufixo)
        if extra.exists():
            alvo = Path(str(destino_base) + sufixo + '.antigo')
            _substituir(extra, alvo)
            movidos.append((extra, alvo))
    return movidos


def _devolver_extras(movidos):
    for original, afastado in reversed(movidos):
        try:
            _substituir(afastado, original)
        except OSError:
            log.exception('Não foi possível devolver %s', original)


def _voltar_ao_anterior(ativo, guarda):
    """Reverte para a cópia guardada. O -wal/-shm presentes são do banco restaurado: aplicá-los sobre a cópia antiga
    a corromperia, então são descartados antes da troca."""
    banco._pausado.set()
    try:
        if not banco.aguardar_sem_conexoes(20):
            log.warning('Revertendo a restauração com conexões ainda abertas')
        for sufixo in ('-wal', '-shm'):
            Path(str(ativo) + sufixo).unlink(missing_ok=True)
        voltando = ativo.with_suffix('.voltando')
        shutil.copyfile(guarda, voltando)
        _substituir(voltando, ativo)
    finally:
        banco._pausado.clear()


def ativar_restauracao(caminho_recuperado):
    """Troca o banco em uso pelo recuperado, com segurança:
    1. valida o recuperado; 2. bloqueia novas conexões e espera as abertas terminarem;
    3. guarda cópia consistente do banco atual; 4. esvazia o WAL (e para se outro programa o segura), afasta -wal/-shm e
    substitui atomicamente, com novas tentativas no Windows; 5. aplica migrações e confere integridade;
    6. em qualquer falha, devolve o banco anterior (inclusive os -wal/-shm afastados)."""
    origem = Path(caminho_recuperado).resolve()
    pasta = (banco.pasta_dados() / 'restauracoes').resolve()
    if origem.parent != pasta or not origem.exists():
        raise ErroValidacao('Arquivo de restauração inválido.')
    info = _examinar(origem)
    if info['formato'] != 'v2':
        raise ErroValidacao('Este backup é da versão antiga. Use "Trazer dados da versão anterior".')
    ativo = banco.caminho_banco()
    carimbo = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
    guarda = banco.pasta_dados() / 'copias' / f'antes_da_restauracao_{carimbo}.sqlite3'
    if ativo.exists():
        banco.copia_consistente(guarda)
    temporario = ativo.with_suffix('.restaurando')
    movidos = []
    banco._pausado.set()
    try:
        if not banco.aguardar_sem_conexoes(20):
            raise ErroValidacao('O banco está em uso. Tente de novo em alguns segundos.')
        if ativo.exists():
            _checkpoint(ativo)
        movidos = _afastar_extras(ativo, guarda)
        shutil.copyfile(origem, temporario)
        _substituir(temporario, ativo)
    except Exception as exc:
        log.exception('Falha ao trocar o banco na restauração; banco anterior mantido')
        _devolver_extras(movidos)
        temporario.unlink(missing_ok=True)
        banco._pausado.clear()
        if isinstance(exc, PermissionError):
            raise ErroValidacao('O Windows não liberou o arquivo do banco (antivírus, OneDrive ou outro programa usando). '
                                'Nada foi alterado: seus dados continuam como estavam. Feche o que estiver usando a pasta '
                                'do Financeiro 404 e tente de novo.') from exc
        raise
    banco._pausado.clear()
    try:
        banco.migrar()
        resultado = banco.integridade()
        if resultado['integridade'] != 'ok' or resultado['transacoes_desequilibradas']:
            raise ErroValidacao('O banco restaurado não passou na verificação.')
    except Exception:
        log.exception('Banco restaurado reprovado; voltando ao anterior')
        if guarda.exists():
            _voltar_ao_anterior(ativo, guarda)
        raise
    return {'copia_anterior': guarda, **info}
