-- 0003: categoria para parcelas de dívidas anteriores ao uso do sistema (ex.: parcelamento de fatura).
INSERT INTO contas(nome,tipo,subtipo)
SELECT 'Dívidas antigas e parcelamentos','despesa','categoria'
WHERE NOT EXISTS(SELECT 1 FROM contas WHERE tipo='despesa' AND lower(nome)=lower('Dívidas antigas e parcelamentos'));
