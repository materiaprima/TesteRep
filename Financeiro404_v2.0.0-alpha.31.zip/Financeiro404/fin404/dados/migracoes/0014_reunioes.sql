-- 0014 (R13): reunião financeira do mês. Uma linha por mês: quando aconteceu e o que foi decidido.
CREATE TABLE reunioes_mes(
  mes TEXT PRIMARY KEY,
  feita_em TEXT NOT NULL,
  decisoes TEXT NOT NULL DEFAULT '',
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
