-- 0012 (R11): histórico de conferências de saldo e dispensas de conferência no fechamento do mês. Só tabelas novas.
CREATE TABLE conferencias(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conta_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
  data TEXT NOT NULL,                       -- data do saldo informado pelo banco (não a data em que conferiu)
  saldo_informado INTEGER NOT NULL,
  saldo_calculado INTEGER NOT NULL,
  diferenca INTEGER NOT NULL,               -- informado − calculado, no sentido natural da conta; 0 = bateu
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_conferencias_conta ON conferencias(conta_id, data);

CREATE TABLE dispensas_conferencia(
  mes TEXT NOT NULL,
  conta_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
  motivo TEXT NOT NULL DEFAULT '',
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(mes, conta_id)
);
