-- 0017 (R10): fotos de notas fiscais, para digitar os itens olhando a imagem. Só tabela nova.
CREATE TABLE fotos_nota(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nota_id INTEGER REFERENCES notas_fiscais(id) ON DELETE SET NULL,
  nome TEXT NOT NULL,
  tipo TEXT NOT NULL,
  tamanho INTEGER NOT NULL CHECK(tamanho BETWEEN 1 AND 8000000),
  sha256 TEXT NOT NULL UNIQUE,
  dados BLOB NOT NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_fotos_nota ON fotos_nota(nota_id);

-- De qual importação veio cada item: uma nota da lista da Nota Fiscal Paulista (sem itens) pode ser completada depois pela
-- página ou pela foto; desfazer essa segunda importação tira só os itens dela. NULL = itens da própria importação da nota.
ALTER TABLE itens_nota ADD COLUMN importacao_id INTEGER REFERENCES importacoes_notas(id) ON DELETE SET NULL;
