-- Financeiro 404 v2 — livro-razão de partidas dobradas.
-- IDs com AUTOINCREMENT: nunca são reaproveitados após exclusão (links e auditoria continuam válidos).
-- Convenção: valor positivo = débito (aumenta ativo ou despesa);
--            valor negativo = crédito (aumenta passivo, receita ou patrimônio).

CREATE TABLE pessoas(
  id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL UNIQUE CHECK(length(trim(nome)) BETWEEN 1 AND 60)
);

CREATE TABLE contas(
  id INTEGER PRIMARY KEY,
  nome TEXT NOT NULL CHECK(length(trim(nome)) BETWEEN 1 AND 80),
  tipo TEXT NOT NULL CHECK(tipo IN ('ativo','passivo','receita','despesa','patrimonio')),
  subtipo TEXT NOT NULL CHECK(subtipo IN (
    'corrente','poupanca','dinheiro','carteira','investimento','bem',
    'cartao','emprestimo','outro_passivo',
    'categoria','abertura','ajuste')),
  titular_id INTEGER REFERENCES pessoas(id) ON DELETE SET NULL,
  instituicao TEXT NOT NULL DEFAULT '',
  identificador_externo TEXT NOT NULL DEFAULT '',
  dia_fechamento INTEGER CHECK(dia_fechamento BETWEEN 1 AND 31),
  dia_vencimento INTEGER CHECK(dia_vencimento BETWEEN 1 AND 31),
  limite_centavos INTEGER CHECK(limite_centavos >= 0),
  ativa INTEGER NOT NULL DEFAULT 1 CHECK(ativa IN (0,1)),
  criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(tipo, nome),
  CHECK(subtipo <> 'cartao' OR tipo = 'passivo'),
  CHECK(subtipo <> 'categoria' OR tipo IN ('receita','despesa'))
);

CREATE TABLE planos_parcelas(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  descricao TEXT NOT NULL,
  total_centavos INTEGER NOT NULL CHECK(total_centavos > 0),
  n_parcelas INTEGER NOT NULL CHECK(n_parcelas BETWEEN 2 AND 72),
  conta_cartao_id INTEGER NOT NULL REFERENCES contas(id),
  data_compra TEXT NOT NULL,
  criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE previsoes(
  id INTEGER PRIMARY KEY,
  descricao TEXT NOT NULL,
  valor_centavos INTEGER NOT NULL CHECK(valor_centavos > 0),
  conta_id INTEGER NOT NULL REFERENCES contas(id),
  contraparte_id INTEGER NOT NULL REFERENCES contas(id),
  sentido TEXT NOT NULL CHECK(sentido IN ('entrada','saida')),
  dia INTEGER NOT NULL CHECK(dia BETWEEN 1 AND 31),
  inicio TEXT NOT NULL,
  fim TEXT,
  ativa INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE lotes_importacao(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  conta_id INTEGER NOT NULL REFERENCES contas(id),
  formato TEXT NOT NULL,
  arquivo TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  identificador_conta TEXT NOT NULL DEFAULT '',
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  desfeito_em TEXT
);

CREATE TABLE transacoes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  data TEXT NOT NULL CHECK(data GLOB '[0-9][0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]'),
  descricao TEXT NOT NULL CHECK(length(trim(descricao)) BETWEEN 1 AND 200),
  tipo TEXT NOT NULL CHECK(tipo IN ('receita','despesa','transferencia','pagamento_fatura','estorno','ajuste','abertura','rendimento')),
  status TEXT NOT NULL CHECK(status IN ('agendada','confirmada','conciliada')),
  plano_id INTEGER REFERENCES planos_parcelas(id) ON DELETE CASCADE,
  parcela_n INTEGER,
  previsao_id INTEGER REFERENCES previsoes(id) ON DELETE SET NULL,
  estorno_de INTEGER REFERENCES transacoes(id),
  lote_id INTEGER REFERENCES lotes_importacao(id),
  chave_origem TEXT UNIQUE,
  observacao TEXT NOT NULL DEFAULT '',
  criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_transacoes_data ON transacoes(data);

CREATE TABLE lancamentos(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  transacao_id INTEGER NOT NULL REFERENCES transacoes(id) ON DELETE CASCADE,
  conta_id INTEGER NOT NULL REFERENCES contas(id),
  valor_centavos INTEGER NOT NULL CHECK(valor_centavos <> 0),
  pessoa_id INTEGER REFERENCES pessoas(id) ON DELETE SET NULL
);
CREATE INDEX idx_lancamentos_conta ON lancamentos(conta_id);
CREATE INDEX idx_lancamentos_transacao ON lancamentos(transacao_id);

CREATE TABLE faturas_documento(
  conta_cartao_id INTEGER NOT NULL REFERENCES contas(id),
  fechamento TEXT NOT NULL,
  total_centavos INTEGER NOT NULL,
  origem TEXT NOT NULL DEFAULT 'manual',
  PRIMARY KEY(conta_cartao_id, fechamento)
);

CREATE TABLE linhas_importacao(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lote_id INTEGER NOT NULL REFERENCES lotes_importacao(id) ON DELETE CASCADE,
  ordem INTEGER NOT NULL,
  data TEXT NOT NULL,
  valor_centavos INTEGER NOT NULL CHECK(valor_centavos <> 0),
  descricao TEXT NOT NULL,
  id_externo TEXT,
  chave TEXT NOT NULL,
  situacao TEXT NOT NULL CHECK(situacao IN ('nova','casada','criada','ignorada','duplicada')),
  sugestao TEXT NOT NULL DEFAULT '',
  motivo TEXT NOT NULL DEFAULT '',
  transacao_id INTEGER REFERENCES transacoes(id) ON DELETE SET NULL,
  status_anterior TEXT
);
CREATE INDEX idx_linhas_chave ON linhas_importacao(chave);

CREATE TABLE regras(
  id INTEGER PRIMARY KEY,
  padrao TEXT NOT NULL CHECK(length(trim(padrao)) >= 3),
  acao TEXT NOT NULL CHECK(acao IN ('categoria','transferencia','pagamento_fatura','ignorar')),
  conta_id INTEGER REFERENCES contas(id) ON DELETE CASCADE,
  prioridade INTEGER NOT NULL DEFAULT 100,
  criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orcamentos(
  mes TEXT NOT NULL,
  conta_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
  valor_centavos INTEGER NOT NULL CHECK(valor_centavos >= 0),
  PRIMARY KEY(mes, conta_id)
);

CREATE TABLE meses_fechados(
  mes TEXT PRIMARY KEY,
  fechado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE auditoria(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  acao TEXT NOT NULL,
  entidade TEXT NOT NULL,
  entidade_id INTEGER,
  detalhes TEXT NOT NULL DEFAULT ''
);

-- Mês fechado: nenhuma escrita em transações ou lançamentos daquele mês.
CREATE TRIGGER trg_mes_fechado_ins BEFORE INSERT ON transacoes
WHEN EXISTS(SELECT 1 FROM meses_fechados WHERE mes = substr(NEW.data,1,7))
BEGIN SELECT RAISE(ABORT, 'MES_FECHADO'); END;

CREATE TRIGGER trg_mes_fechado_upd BEFORE UPDATE ON transacoes
WHEN EXISTS(SELECT 1 FROM meses_fechados WHERE mes IN (substr(OLD.data,1,7), substr(NEW.data,1,7)))
BEGIN SELECT RAISE(ABORT, 'MES_FECHADO'); END;

CREATE TRIGGER trg_mes_fechado_del BEFORE DELETE ON transacoes
WHEN EXISTS(SELECT 1 FROM meses_fechados WHERE mes = substr(OLD.data,1,7))
BEGIN SELECT RAISE(ABORT, 'MES_FECHADO'); END;

CREATE TRIGGER trg_mes_fechado_lanc_ins BEFORE INSERT ON lancamentos
WHEN EXISTS(SELECT 1 FROM meses_fechados m JOIN transacoes t ON m.mes = substr(t.data,1,7) WHERE t.id = NEW.transacao_id)
BEGIN SELECT RAISE(ABORT, 'MES_FECHADO'); END;

CREATE TRIGGER trg_mes_fechado_lanc_upd BEFORE UPDATE ON lancamentos
WHEN EXISTS(SELECT 1 FROM meses_fechados m JOIN transacoes t ON m.mes = substr(t.data,1,7) WHERE t.id = OLD.transacao_id)
BEGIN SELECT RAISE(ABORT, 'MES_FECHADO'); END;

-- Contas do sistema e categorias iniciais.
INSERT INTO contas(nome,tipo,subtipo) VALUES
 ('Saldos iniciais','patrimonio','abertura'),
 ('Ajustes de conciliação','patrimonio','ajuste'),
 ('Moradia','despesa','categoria'),
 ('Mercado','despesa','categoria'),
 ('Restaurantes e delivery','despesa','categoria'),
 ('Transporte','despesa','categoria'),
 ('Saúde e farmácia','despesa','categoria'),
 ('Educação','despesa','categoria'),
 ('Vestuário','despesa','categoria'),
 ('Beleza e cuidados','despesa','categoria'),
 ('Lazer e viagens','despesa','categoria'),
 ('Assinaturas','despesa','categoria'),
 ('Casa nova','despesa','categoria'),
 ('Impostos e taxas','despesa','categoria'),
 ('Seguros','despesa','categoria'),
 ('Juros, tarifas e IOF','despesa','categoria'),
 ('Presentes e doações','despesa','categoria'),
 ('Outras despesas','despesa','categoria'),
 ('Salário','receita','categoria'),
 ('13º e férias','receita','categoria'),
 ('Rendimentos de investimentos','receita','categoria'),
 ('Reembolsos','receita','categoria'),
 ('Outras receitas','receita','categoria');
