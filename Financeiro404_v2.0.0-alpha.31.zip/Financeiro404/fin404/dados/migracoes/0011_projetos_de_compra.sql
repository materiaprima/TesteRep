-- 0011: projetos de compra (casa, carro, viagem, reposições, eventos), itens por ambiente/grupo, cotações e vida útil.
-- A tabela compras_planejadas (0010) é refeita para aceitar item ainda sem preço ("a cotar"). É seguro reconstruí-la:
-- nenhuma outra tabela aponta para ela e ela não guarda dinheiro do razão (só planos).
CREATE TABLE planos_compra(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL CHECK(length(trim(nome)) BETWEEN 1 AND 80),
  tipo TEXT NOT NULL DEFAULT 'outro',
  orcamento_centavos INTEGER CHECK(orcamento_centavos IS NULL OR orcamento_centavos > 0),
  mes_alvo TEXT,
  observacao TEXT NOT NULL DEFAULT '',
  situacao TEXT NOT NULL DEFAULT 'ativo',
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE compras_planejadas_nova(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  plano_id INTEGER REFERENCES planos_compra(id) ON DELETE SET NULL,
  grupo TEXT NOT NULL DEFAULT '',
  descricao TEXT NOT NULL CHECK(length(trim(descricao)) BETWEEN 1 AND 120),
  tipo_item TEXT NOT NULL DEFAULT 'compra',
  quantidade INTEGER NOT NULL DEFAULT 1 CHECK(quantidade BETWEEN 1 AND 9999),
  valor_centavos INTEGER CHECK(valor_centavos IS NULL OR valor_centavos > 0),
  guardado_centavos INTEGER NOT NULL DEFAULT 0 CHECK(guardado_centavos >= 0),
  revenda_centavos INTEGER NOT NULL DEFAULT 0 CHECK(revenda_centavos >= 0),
  categoria_id INTEGER REFERENCES contas(id) ON DELETE SET NULL,
  prioridade TEXT NOT NULL DEFAULT 'importante',
  mes_alvo TEXT,
  parcelas INTEGER NOT NULL DEFAULT 1 CHECK(parcelas BETWEEN 1 AND 72),
  vida_util_meses INTEGER CHECK(vida_util_meses IS NULL OR vida_util_meses BETWEEN 1 AND 600),
  observacao TEXT NOT NULL DEFAULT '',
  situacao TEXT NOT NULL DEFAULT 'planejada',
  transacao_id INTEGER REFERENCES transacoes(id) ON DELETE SET NULL,
  valor_pago_centavos INTEGER,
  origem_id INTEGER,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  concluida_em TEXT
);
INSERT INTO compras_planejadas_nova(id, descricao, valor_centavos, guardado_centavos, categoria_id, prioridade, mes_alvo,
                                    parcelas, observacao, situacao, transacao_id, valor_pago_centavos, criado_em, concluida_em)
  SELECT id, descricao, valor_centavos, guardado_centavos, categoria_id, prioridade, mes_alvo, parcelas, observacao, situacao,
         transacao_id, valor_pago_centavos, criado_em, concluida_em FROM compras_planejadas;
DROP TABLE compras_planejadas;
ALTER TABLE compras_planejadas_nova RENAME TO compras_planejadas;
CREATE INDEX idx_compras_situacao ON compras_planejadas(situacao, prioridade, mes_alvo);
CREATE INDEX idx_compras_plano ON compras_planejadas(plano_id, grupo);

CREATE TABLE cotacoes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  compra_id INTEGER NOT NULL REFERENCES compras_planejadas(id) ON DELETE CASCADE,
  loja TEXT NOT NULL CHECK(length(trim(loja)) BETWEEN 1 AND 80),
  valor_centavos INTEGER NOT NULL CHECK(valor_centavos > 0),
  parcelas INTEGER NOT NULL DEFAULT 1 CHECK(parcelas BETWEEN 1 AND 72),
  frete_centavos INTEGER NOT NULL DEFAULT 0 CHECK(frete_centavos >= 0),
  link TEXT NOT NULL DEFAULT '',
  data TEXT NOT NULL DEFAULT (date('now')),
  observacao TEXT NOT NULL DEFAULT ''
);
CREATE INDEX idx_cotacoes_compra ON cotacoes(compra_id);
CREATE INDEX IF NOT EXISTS idx_transacoes_plano ON transacoes(plano_id);
