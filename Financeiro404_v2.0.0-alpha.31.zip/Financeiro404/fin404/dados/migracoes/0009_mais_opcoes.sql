-- 0009: mais opções sem perder dados.
-- SQLite não altera CHECK de coluna existente; por isso a forma de pagamento passa para uma coluna nova
-- (validada pelo programa) e as previsões ganham "frequencia" (semanal a anual) e "data_base" (âncora das semanais).
ALTER TABLE transacoes ADD COLUMN meio_pagamento TEXT;
UPDATE transacoes SET meio_pagamento = forma_pagamento WHERE forma_pagamento IS NOT NULL;
ALTER TABLE previsoes ADD COLUMN meio_pagamento TEXT;
UPDATE previsoes SET meio_pagamento = forma_pagamento WHERE forma_pagamento IS NOT NULL;
ALTER TABLE previsoes ADD COLUMN frequencia TEXT;
UPDATE previsoes SET frequencia = periodicidade;
ALTER TABLE previsoes ADD COLUMN data_base TEXT;

-- Categorias que faltavam para situações comuns (só cria se não existir com esse nome).
INSERT INTO contas(nome, tipo, subtipo, natureza)
SELECT v.nome, v.tipo, 'categoria', v.natureza FROM (
  SELECT 'Contas da casa' nome, 'despesa' tipo, 'essencial' natureza UNION ALL
  SELECT 'Pets', 'despesa', 'essencial' UNION ALL
  SELECT 'Filhos', 'despesa', 'essencial' UNION ALL
  SELECT 'Academia e esportes', 'despesa', 'discricionario' UNION ALL
  SELECT 'Serviços domésticos', 'despesa', 'discricionario' UNION ALL
  SELECT 'Trabalhos extras', 'receita', NULL UNION ALL
  SELECT 'Vendas de usados', 'receita', NULL UNION ALL
  SELECT 'Aluguel recebido', 'receita', NULL UNION ALL
  SELECT 'Vale-refeição e alimentação', 'receita', NULL UNION ALL
  SELECT 'Restituição do Imposto de Renda', 'receita', NULL UNION ALL
  SELECT 'Bônus e PLR', 'receita', NULL UNION ALL
  SELECT 'Presentes recebidos', 'receita', NULL
) v WHERE NOT EXISTS (SELECT 1 FROM contas k WHERE k.tipo = v.tipo AND lower(k.nome) = lower(v.nome));
