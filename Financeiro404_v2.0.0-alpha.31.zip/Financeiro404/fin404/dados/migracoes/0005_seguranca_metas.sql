-- 0005: configurações (PIN, backup automático, tema), metas e informações extras da fatura.
CREATE TABLE configuracoes(
  chave TEXT PRIMARY KEY,
  valor TEXT NOT NULL
);

CREATE TABLE metas(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL CHECK(length(trim(nome)) BETWEEN 1 AND 80),
  alvo_centavos INTEGER NOT NULL CHECK(alvo_centavos > 0),
  conta_id INTEGER REFERENCES contas(id) ON DELETE SET NULL,
  guardado_centavos INTEGER NOT NULL DEFAULT 0 CHECK(guardado_centavos >= 0),
  prazo TEXT,
  ativa INTEGER NOT NULL DEFAULT 1,
  criada_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Taxas, mínimo e limite lidos da fatura (JSON), para o simulador de dívida e alertas de limite.
ALTER TABLE lotes_importacao ADD COLUMN fatura_info TEXT;
