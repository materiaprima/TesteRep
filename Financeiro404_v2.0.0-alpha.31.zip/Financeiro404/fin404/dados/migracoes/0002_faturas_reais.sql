-- 0002: datas reais de fechamento e importação de fatura em PDF.

-- Compra no dia do fechamento: 'proxima' (vai para a fatura seguinte) ou 'atual' (entra na que fecha; ex.: Ourocard BB).
ALTER TABLE contas ADD COLUMN regra_fechamento TEXT NOT NULL DEFAULT 'proxima' CHECK(regra_fechamento IN ('proxima','atual'));

-- Fechamentos e vencimentos informados pelo banco (o BB, por exemplo, não fecha sempre no mesmo dia).
CREATE TABLE fechamentos_conhecidos(
  conta_cartao_id INTEGER NOT NULL REFERENCES contas(id) ON DELETE CASCADE,
  fechamento TEXT NOT NULL,
  vencimento TEXT,
  origem TEXT NOT NULL DEFAULT 'manual',
  PRIMARY KEY(conta_cartao_id, fechamento)
);

-- Dados da fatura lida (para conferência e para sugerir o saldo inicial do cartão).
ALTER TABLE lotes_importacao ADD COLUMN fatura_fechamento TEXT;
ALTER TABLE lotes_importacao ADD COLUMN fatura_total INTEGER;
ALTER TABLE lotes_importacao ADD COLUMN fatura_saldo_anterior INTEGER;
ALTER TABLE lotes_importacao ADD COLUMN fatura_parcelado_futuro INTEGER;

-- Linha da fatura: data original da compra (quando difere da data contábil), portador do cartão e categoria do banco.
ALTER TABLE linhas_importacao ADD COLUMN data_original TEXT;
ALTER TABLE linhas_importacao ADD COLUMN portador TEXT NOT NULL DEFAULT '';
ALTER TABLE linhas_importacao ADD COLUMN categoria_banco TEXT NOT NULL DEFAULT '';
