-- 0013 (R3): papel da conta. NULL = conta comum; 'a_receber' = valores a receber (dinheiro emprestado ou pago por alguém).
-- Coluna nova em vez de subtipo novo: o CHECK de contas.subtipo não pode ser alterado sem reconstruir a tabela,
-- e contas tem chaves estrangeiras apontando para ela (regra 4). O subtipo guardado é 'bem' (ativo fora de disponível
-- e de reserva); o que define o comportamento é o papel.
ALTER TABLE contas ADD COLUMN papel TEXT;
CREATE INDEX idx_contas_papel ON contas(papel);
