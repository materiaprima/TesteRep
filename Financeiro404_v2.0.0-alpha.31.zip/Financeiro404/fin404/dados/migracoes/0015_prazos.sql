-- 0015 (R12): prazos e garantias. Uma tabela para os dois casos (garantia de compra e prazo que não é compra:
-- CNH, licenciamento, seguro, contrato, revisão, documento). Só acréscimo.
CREATE TABLE prazos(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tipo TEXT NOT NULL DEFAULT 'outro',
  titulo TEXT NOT NULL CHECK(length(trim(titulo)) BETWEEN 1 AND 120),
  data_fim TEXT NOT NULL,
  avisar_dias INTEGER NOT NULL DEFAULT 30 CHECK(avisar_dias BETWEEN 0 AND 365),
  repete_meses INTEGER CHECK(repete_meses IS NULL OR repete_meses BETWEEN 1 AND 240),
  compra_id INTEGER REFERENCES compras_planejadas(id) ON DELETE SET NULL,
  transacao_id INTEGER REFERENCES transacoes(id) ON DELETE SET NULL,
  nota_id INTEGER,                            -- nota fiscal (R10); sem FK porque a tabela vem na 0016
  observacao TEXT NOT NULL DEFAULT '',
  concluido_em TEXT,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_prazos_abertos ON prazos(concluido_em, data_fim);
ALTER TABLE compras_planejadas ADD COLUMN garantia_meses INTEGER;
