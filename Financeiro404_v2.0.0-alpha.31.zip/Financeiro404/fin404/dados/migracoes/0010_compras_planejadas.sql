-- 0010: compras planejadas (o que a família precisa ou quer comprar, quanto separar por mês e se cabe na sobra).
-- Sem CHECK com lista fixa de valores (prioridade, situação): o SQLite não deixa alterar CHECK depois; o código valida.
CREATE TABLE compras_planejadas(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  descricao TEXT NOT NULL CHECK(length(trim(descricao)) BETWEEN 1 AND 120),
  valor_centavos INTEGER NOT NULL CHECK(valor_centavos > 0),
  guardado_centavos INTEGER NOT NULL DEFAULT 0 CHECK(guardado_centavos >= 0),
  categoria_id INTEGER REFERENCES contas(id) ON DELETE SET NULL,
  prioridade TEXT NOT NULL DEFAULT 'importante',
  mes_alvo TEXT,
  parcelas INTEGER NOT NULL DEFAULT 1 CHECK(parcelas BETWEEN 1 AND 72),
  observacao TEXT NOT NULL DEFAULT '',
  situacao TEXT NOT NULL DEFAULT 'planejada',
  transacao_id INTEGER REFERENCES transacoes(id) ON DELETE SET NULL,
  valor_pago_centavos INTEGER,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  concluida_em TEXT
);
CREATE INDEX idx_compras_situacao ON compras_planejadas(situacao, prioridade, mes_alvo);
