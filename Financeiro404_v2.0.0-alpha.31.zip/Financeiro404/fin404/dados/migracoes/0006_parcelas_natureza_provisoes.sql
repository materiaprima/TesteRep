-- 0006: encerrar parcelamentos (antecipação/cancelamento), natureza das categorias (essencial/comprometido/discricionário),
--       previsões anuais (provisões) e separação de Saúde e Farmácia (para o apoio ao IRPF).

ALTER TABLE planos_parcelas ADD COLUMN encerrado_em TEXT;
ALTER TABLE planos_parcelas ADD COLUMN motivo_encerramento TEXT;

ALTER TABLE contas ADD COLUMN natureza TEXT CHECK(natureza IS NULL OR natureza IN ('essencial','comprometido','discricionario'));

ALTER TABLE previsoes ADD COLUMN periodicidade TEXT NOT NULL DEFAULT 'mensal' CHECK(periodicidade IN ('mensal','anual'));
ALTER TABLE previsoes ADD COLUMN mes_do_ano INTEGER CHECK(mes_do_ano IS NULL OR mes_do_ano BETWEEN 1 AND 12);

-- Saúde (consultas, exames, dentista, plano: costumam ser dedutíveis) separada de farmácia (em regra, não dedutível).
UPDATE contas SET nome='Saúde' WHERE tipo='despesa' AND nome='Saúde e farmácia'
  AND NOT EXISTS(SELECT 1 FROM contas WHERE tipo='despesa' AND lower(nome)=lower('Saúde'));
INSERT INTO contas(nome,tipo,subtipo)
SELECT 'Farmácia e remédios','despesa','categoria'
WHERE NOT EXISTS(SELECT 1 FROM contas WHERE tipo='despesa' AND lower(nome)=lower('Farmácia e remédios'));

UPDATE contas SET natureza='essencial' WHERE tipo='despesa' AND natureza IS NULL AND nome IN
  ('Moradia','Mercado','Transporte','Saúde','Saúde e farmácia','Farmácia e remédios','Educação','Impostos e taxas','Seguros',
   'Gastos não identificados');
UPDATE contas SET natureza='comprometido' WHERE tipo='despesa' AND natureza IS NULL AND nome IN
  ('Juros, tarifas e IOF','Dívidas antigas e parcelamentos');
UPDATE contas SET natureza='discricionario' WHERE tipo='despesa' AND natureza IS NULL AND nome IN
  ('Restaurantes e delivery','Vestuário','Beleza e cuidados','Lazer e viagens','Assinaturas','Casa nova','Presentes e doações',
   'Outras despesas');
