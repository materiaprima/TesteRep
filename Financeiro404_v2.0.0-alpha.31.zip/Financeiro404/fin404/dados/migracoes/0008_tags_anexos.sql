-- 0008: tags (etiquetas transversais às categorias) e anexos (comprovantes guardados no próprio banco, entram no backup).
CREATE TABLE tags(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK(length(trim(nome)) BETWEEN 1 AND 40)
);
CREATE TABLE transacao_tags(
  transacao_id INTEGER NOT NULL REFERENCES transacoes(id) ON DELETE CASCADE,
  tag_id INTEGER NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  PRIMARY KEY(transacao_id, tag_id)
);
CREATE INDEX idx_transacao_tags_tag ON transacao_tags(tag_id);
CREATE TABLE anexos(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  transacao_id INTEGER NOT NULL REFERENCES transacoes(id) ON DELETE CASCADE,
  nome TEXT NOT NULL CHECK(length(nome) BETWEEN 1 AND 200),
  tipo TEXT NOT NULL,
  tamanho INTEGER NOT NULL CHECK(tamanho BETWEEN 1 AND 8000000),
  sha256 TEXT NOT NULL,
  dados BLOB NOT NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_anexos_transacao ON anexos(transacao_id);
