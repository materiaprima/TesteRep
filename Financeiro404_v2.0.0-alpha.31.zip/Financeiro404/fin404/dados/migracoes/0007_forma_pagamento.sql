-- 0007: forma de pagamento (Pix, débito, crédito, boleto…) nos lançamentos e nas previsões.
ALTER TABLE transacoes ADD COLUMN forma_pagamento TEXT CHECK(forma_pagamento IS NULL OR forma_pagamento IN
  ('pix','debito','credito','boleto','dinheiro','transferencia','debito_automatico','beneficio','outro'));
ALTER TABLE previsoes ADD COLUMN forma_pagamento TEXT CHECK(forma_pagamento IS NULL OR forma_pagamento IN
  ('pix','debito','credito','boleto','dinheiro','transferencia','debito_automatico','beneficio','outro'));
-- Compras no cartão já registradas são crédito.
UPDATE transacoes SET forma_pagamento='credito' WHERE forma_pagamento IS NULL AND tipo IN ('despesa','estorno') AND id IN
  (SELECT l.transacao_id FROM lancamentos l JOIN contas k ON k.id=l.conta_id WHERE k.subtipo='cartao');
