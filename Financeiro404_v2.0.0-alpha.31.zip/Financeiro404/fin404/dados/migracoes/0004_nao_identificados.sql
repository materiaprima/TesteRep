-- 0004: categorias para fechar a conta sem extrato (diferença entre o saldo do app do banco e o calculado).
INSERT INTO contas(nome,tipo,subtipo)
SELECT 'Gastos não identificados','despesa','categoria'
WHERE NOT EXISTS(SELECT 1 FROM contas WHERE tipo='despesa' AND lower(nome)=lower('Gastos não identificados'));
INSERT INTO contas(nome,tipo,subtipo)
SELECT 'Entradas não identificadas','receita','categoria'
WHERE NOT EXISTS(SELECT 1 FROM contas WHERE tipo='receita' AND lower(nome)=lower('Entradas não identificadas'));
