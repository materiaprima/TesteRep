-- 0016 (R10): notas fiscais, itens, catálogo de produtos e apelidos. Só tabelas novas; as chaves estrangeiras vão das
-- novas para as existentes (transacoes), nunca o contrário. Quantidade em milésimos (0,512 kg = 512), dinheiro em centavos.
CREATE TABLE importacoes_notas(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  arquivo TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  desfeito_em TEXT
);

CREATE TABLE notas_fiscais(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  importacao_id INTEGER REFERENCES importacoes_notas(id) ON DELETE SET NULL,
  data TEXT NOT NULL,
  loja TEXT NOT NULL CHECK(length(trim(loja)) BETWEEN 1 AND 120),
  cnpj TEXT NOT NULL DEFAULT '',
  chave TEXT,                                  -- chave de acesso da NFC-e (44 dígitos), quando houver
  desconto_centavos INTEGER NOT NULL DEFAULT 0 CHECK(desconto_centavos >= 0),
  total_centavos INTEGER NOT NULL CHECK(total_centavos > 0),
  transacao_id INTEGER REFERENCES transacoes(id) ON DELETE SET NULL,
  origem TEXT NOT NULL DEFAULT 'csv',
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE UNIQUE INDEX idx_notas_chave ON notas_fiscais(chave) WHERE chave IS NOT NULL;
CREATE INDEX idx_notas_data ON notas_fiscais(data);
CREATE INDEX idx_notas_transacao ON notas_fiscais(transacao_id);

CREATE TABLE produtos(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gtin TEXT UNIQUE,
  nome TEXT NOT NULL CHECK(length(trim(nome)) BETWEEN 1 AND 200),
  nome_norm TEXT NOT NULL DEFAULT '',
  marca TEXT NOT NULL DEFAULT '',
  tamanho TEXT NOT NULL DEFAULT '',
  tipo TEXT NOT NULL DEFAULT '',
  fonte TEXT NOT NULL DEFAULT 'manual',
  criado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_produtos_nome ON produtos(nome_norm);

CREATE TABLE itens_nota(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nota_id INTEGER NOT NULL REFERENCES notas_fiscais(id) ON DELETE CASCADE,
  ordem INTEGER NOT NULL,
  descricao TEXT NOT NULL CHECK(length(trim(descricao)) BETWEEN 1 AND 200),
  descricao_norm TEXT NOT NULL,
  gtin TEXT NOT NULL DEFAULT '',
  quantidade_mil INTEGER NOT NULL CHECK(quantidade_mil > 0),
  unidade TEXT NOT NULL DEFAULT 'UN',
  preco_unit_centavos INTEGER NOT NULL CHECK(preco_unit_centavos >= 0),
  total_centavos INTEGER NOT NULL CHECK(total_centavos >= 0),
  tipo TEXT NOT NULL DEFAULT 'Outros',
  produto_id INTEGER REFERENCES produtos(id) ON DELETE SET NULL
);
CREATE INDEX idx_itens_nota ON itens_nota(nota_id);
CREATE INDEX idx_itens_produto ON itens_nota(produto_id);
CREATE INDEX idx_itens_desc ON itens_nota(descricao_norm);

CREATE TABLE produto_apelidos(
  descricao_norm TEXT PRIMARY KEY,
  produto_id INTEGER NOT NULL REFERENCES produtos(id) ON DELETE CASCADE
);

CREATE TABLE fontes_catalogo(
  fonte TEXT PRIMARY KEY,
  atribuicao TEXT NOT NULL,
  registros INTEGER NOT NULL DEFAULT 0,
  importado_em TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
