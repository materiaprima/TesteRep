"""Acesso ao SQLite: conexões sempre fechadas, transações explícitas, migrações numeradas.

Atenção: `with sqlite3.connect(...)` NÃO fecha a conexão (só faz commit/rollback).
Toda conexão deste projeto passa por `conexao()`, que fecha explicitamente.
"""
import contextlib
import datetime
import os
import re
import sqlite3
import threading
from pathlib import Path

RAIZ = Path(__file__).resolve().parents[2]
MIGRACOES = Path(__file__).resolve().parent / 'migracoes'
NOME_BANCO = 'financeiro_v2.sqlite3'

_trava_migracao = threading.Lock()
_pausado = threading.Event()   # ligado durante a troca do banco (restauração)
_cond = threading.Condition()
_ativos = 0                    # conexões abertas agora


def _entrar():
    global _ativos
    with _cond:
        _ativos += 1


def _sair():
    global _ativos
    with _cond:
        _ativos -= 1
        _cond.notify_all()


def aguardar_sem_conexoes(limite_segundos=15):
    """Usado na restauração: espera até que nenhuma conexão esteja aberta."""
    with _cond:
        return _cond.wait_for(lambda: _ativos == 0, timeout=limite_segundos)


def pasta_dados():
    return Path(os.environ.get('FIN404_DATA') or (RAIZ / 'data'))


def caminho_banco():
    return pasta_dados() / NOME_BANCO


class ErroBanco(RuntimeError):
    pass


def _abrir(caminho=None, somente_leitura=False):
    if _pausado.is_set():
        raise ErroBanco('O banco está sendo restaurado. Aguarde alguns segundos e recarregue a página.')
    caminho = Path(caminho or caminho_banco())
    if somente_leitura:
        c = sqlite3.connect(Path(caminho).resolve().as_uri() + '?mode=ro', uri=True, timeout=15, isolation_level=None)
    else:
        caminho.parent.mkdir(parents=True, exist_ok=True)
        c = sqlite3.connect(caminho, timeout=15, isolation_level=None)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=15000')
    return c


@contextlib.contextmanager
def conexao(caminho=None, somente_leitura=False):
    """Conexão para leitura (autocommit). Sempre fechada ao sair."""
    c = _abrir(caminho, somente_leitura)
    _entrar()
    try:
        yield c
    finally:
        c.close()
        _sair()


@contextlib.contextmanager
def transacao(caminho=None):
    """Transação de escrita: BEGIN IMMEDIATE, commit no sucesso, rollback em erro, sempre fecha."""
    c = _abrir(caminho)
    _entrar()
    try:
        c.execute('BEGIN IMMEDIATE')
        yield c
        c.execute('COMMIT')
    except BaseException:
        if c.in_transaction:
            c.execute('ROLLBACK')
        raise
    finally:
        c.close()
        _sair()


def migracoes_disponiveis():
    itens = []
    for p in sorted(MIGRACOES.glob('*.sql')):
        m = re.match(r'(\d{4})_', p.name)
        if m:
            itens.append((int(m.group(1)), p))
    return itens


def versao(caminho=None):
    with conexao(caminho) as c:
        return c.execute('PRAGMA user_version').fetchone()[0]


def copia_consistente(destino, caminho=None):
    """Cópia online consistente (API de backup do SQLite)."""
    destino = Path(destino)
    destino.parent.mkdir(parents=True, exist_ok=True)
    with conexao(caminho) as origem:
        alvo = sqlite3.connect(destino)
        try:
            origem.backup(alvo)
        finally:
            alvo.close()
    return destino


def migrar(caminho=None):
    """Aplica migrações pendentes. Faz cópia antes de alterar um banco existente."""
    caminho = Path(caminho or caminho_banco())
    with _trava_migracao:
        existia = caminho.exists() and caminho.stat().st_size > 0
        if existia:
            with conexao(caminho) as c:
                c.execute('PRAGMA journal_mode=WAL')
                atual = c.execute('PRAGMA user_version').fetchone()[0]
                tem_tabelas = c.execute("SELECT 1 FROM sqlite_master WHERE name='transacoes'").fetchone()
                if atual == 0 and c.execute("SELECT 1 FROM sqlite_master WHERE name='entries'").fetchone():
                    raise ErroBanco('Este arquivo é um banco da versão antiga. Use ferramentas/migrar_v09.py.')
        else:
            atual, tem_tabelas = 0, None
        pendentes = [(n, p) for n, p in migracoes_disponiveis() if n > atual]
        maior = max((n for n, _ in migracoes_disponiveis()), default=0)
        if atual > maior:
            raise ErroBanco('O banco foi criado por uma versão mais nova do Financeiro 404. Atualize o programa.')
        if pendentes and existia and tem_tabelas:
            carimbo = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            copia_consistente(caminho.parent / 'copias_pre_migracao' / f'antes_v{maior}_{carimbo}.sqlite3', caminho)
        for numero, arquivo in pendentes:
            sql = arquivo.read_text(encoding='utf-8')
            c = _abrir(caminho)
            try:
                c.execute('PRAGMA journal_mode=WAL')
                c.executescript('BEGIN IMMEDIATE;\n' + sql + f'\nPRAGMA user_version={numero};\nCOMMIT;')
            except BaseException:
                if c.in_transaction:
                    c.execute('ROLLBACK')
                raise
            finally:
                c.close()
    return caminho


def copia_diaria(manter=14):
    """Cópia local automática, uma por dia, guardando as últimas `manter`. Protege contra erro e corrupção,
    não contra perda do notebook (fica no mesmo disco e sem cifragem: para isso existe o backup cifrado)."""
    if not caminho_banco().exists():
        return None
    pasta = pasta_dados() / 'copias'
    destino = pasta / f'automatica_{datetime.date.today().isoformat()}.sqlite3'
    if not destino.exists():
        copia_consistente(destino)
    for antiga in sorted(pasta.glob('automatica_*.sqlite3'))[:-manter]:
        antiga.unlink(missing_ok=True)
    return destino


def integridade(caminho=None):
    with conexao(caminho) as c:
        return {
            'integridade': c.execute('PRAGMA integrity_check').fetchone()[0],
            'chaves_estrangeiras': len(c.execute('PRAGMA foreign_key_check').fetchall()),
            'versao': c.execute('PRAGMA user_version').fetchone()[0],
            'transacoes_desequilibradas': c.execute(
                'SELECT COUNT(*) FROM (SELECT transacao_id FROM lancamentos GROUP BY transacao_id HAVING SUM(valor_centavos)<>0)'
            ).fetchone()[0],
            'transacoes_sem_lancamentos': c.execute(
                'SELECT COUNT(*) FROM transacoes t WHERE (SELECT COUNT(*) FROM lancamentos l WHERE l.transacao_id=t.id)<2'
            ).fetchone()[0],
        }


def auditar(c, acao, entidade, entidade_id, detalhes=''):
    c.execute('INSERT INTO auditoria(acao,entidade,entidade_id,detalhes) VALUES(?,?,?,?)',
              (acao, entidade, entidade_id, str(detalhes)[:4000]))
