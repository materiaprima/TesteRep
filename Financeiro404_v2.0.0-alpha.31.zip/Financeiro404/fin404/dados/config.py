"""Configurações simples (chave -> valor JSON) guardadas no próprio banco."""
import json

from fin404.dados import banco


def obter(chave, padrao=None, c=None):
    if c is None:
        with banco.conexao() as c2:
            return obter(chave, padrao, c2)
    row = c.execute('SELECT valor FROM configuracoes WHERE chave=?', (chave,)).fetchone()
    return json.loads(row[0]) if row else padrao


def definir(chave, valor, c=None):
    if c is None:
        with banco.transacao() as c2:
            return definir(chave, valor, c2)
    if valor is None:
        c.execute('DELETE FROM configuracoes WHERE chave=?', (chave,))
    else:
        c.execute('INSERT INTO configuracoes(chave,valor) VALUES(?,?) ON CONFLICT(chave) DO UPDATE SET valor=excluded.valor',
                  (chave, json.dumps(valor, ensure_ascii=False)))
