# Tecnologia

- Python >= 3.10, servidor HTTP da biblioteca padrão, sem framework, sem JavaScript (HTML no servidor, CSP estrita, sem estilo inline).
- SQLite (WAL, BEGIN IMMEDIATE, chaves estrangeiras ligadas). Migrações numeradas em `fin404/dados/migracoes/`, só por acréscimo;
  nunca reconstruir tabela (apagaria dados em cascata); nunca editar migração publicada.
- Dinheiro em centavos inteiros; `float(` e `/100` são proibidos (há teste que falha).
- Livro-razão de partidas dobradas: toda escrita de dinheiro passa por `razao.registrar` (soma zero) dentro de `banco.transacao()`.
- Dependências: cryptography, pymupdf. Testes: pytest, hypothesis, playwright. Rodar: `python -m pytest -q` (inclui e2e com Chrome).
- Segurança: só 127.0.0.1, CSRF, Host/Origin/Sec-Fetch-Site, backup cifrado (AES-256-GCM, X25519). Nunca versionar `data/`.
