# Estrutura

- `app.py`: entrada. `iniciar_windows.bat`: instala dependências e abre o navegador.
- `fin404/dinheiro.py`: centavos, datas, formatação BR.
- `fin404/dados/`: banco (conexões, migração, cópias), config, migrações SQL.
- `fin404/dominio/`: razao (livro-razão), cartoes (ciclos, faturas, parcelas), operacoes (lançamentos, previsões), relatorios,
  analises (Raio-X, evolução, alertas), categorias (inferência), simulador, metas, tags, anexos, lote (texto em lote).
- `fin404/importacao/`: adaptadores OFX, CSV e PDF Ourocard; pipeline (staging, sugestões, aplicar, desfazer).
- `fin404/seguranca/`: backup (ENC2/ENC3, restauração), acesso (PIN).
- `fin404/web/`: servidor, componentes (HTML, gráficos SVG), páginas por área em `pg_*.py`, `static/app.css`.
- `tests/`: unidade, integracao, propriedades (hypothesis), e2e (navegador real).
