# Produto

Financeiro 404: finanças de um casal, 100% local (Windows, navegador em 127.0.0.1:4040). Objetivo: visão do passado, presente e
futuro do dinheiro da família, com foco em dívida de cartão. Uma pessoa opera; a outra só quer ver um resumo.
Não há extrato bancário recorrente: a fonte automática é a fatura do Ourocard (BB) em PDF; o resto é lançamento manual, em lote
(texto colado) e previsões, conferidos com o saldo do app do banco.
Interface em português do Brasil, frases curtas, sem jargão contábil. Contexto completo, decisões e backlog: `PARA_O_KIRO.md`.
