# R11 — Completude dos dados (P0)

> Spec do item R11 da seção 8 do `PARA_O_KIRO.md`. Baseada na leitura de `fin404/dominio/operacoes.py`
> (`conciliar_saldo`, `ajustar_saldo`, `pistas_da_diferenca`), `fin404/web/pg_planejamento.py`
> (`/fechamento`), `fin404/web/pg_contas.py` (`conta_conciliar`) e `fin404/dominio/relatorios.py` (`alertas`).
>
> **Status das tarefas: não executar.**

## Introdução

Sem extrato, tudo que não passa pela fatura do Ourocard (Pix, boleto, débito automático, saque, outros
cartões) depende de lançamento manual. Em um ou dois meses, os números descolam da realidade e o sistema
perde a confiança. R2 (OFX do BB) e R7 (Open Finance) atacam a causa; a R11 é a **rede de segurança** até lá:
tornar visível quando os dados estão ficando incompletos.

**O que já existe (lido no código):**
- **Conferência de saldo com pistas:** `operacoes.conciliar_saldo` compara saldo calculado × informado pelo
  banco; `pistas_da_diferenca` sugere o que explica a diferença (previsto não confirmado, lançamento em
  dobro, sentido trocado); `ajustar_saldo` lança a diferença como ajuste rotulado quando o usuário decide.
  Usados em `pg_contas.conta_conciliar`.
- **Fechamento do mês:** `/fechamento` já mostra um checklist com três itens — linhas de extrato pendentes,
  previstos não confirmados, e **lançamentos de conta corrente/cartão não conferidos com extrato** — e trava
  o mês (`meses_fechados`, garantido no banco).
- **Alertas** (`relatorios.alertas`) já cobrem cheque especial, fatura vencendo, parcela ausente etc.

**O que falta (a construir):**
1. Não há carimbo de **"última conferência de saldo"** por conta — logo não dá para alertar "faz mais de 35
   dias que você não confere esta conta".
2. O checklist do fechamento **mostra** pendências mas **não exige** (nem registra dispensa) a conferência de
   cada conta antes de fechar.
3. O Início não destaca **quanto foi lançado fora do cartão** no mês — o sinal mais direto de um mês "vazio"
   de Pix e boletos.

## Requisitos

### Requisito 1 — Alerta de conta sem conferência recente

**História:** Como usuário, quero ser avisado quando uma conta não é conferida há muito tempo, para não
deixar os números envelhecerem sem perceber.

#### Critérios de aceite
1. O sistema DEVE registrar a **data da última conferência de saldo** de cada conta (corrente, poupança,
   carteira) quando o usuário fizer a conferência.
2. QUANDO uma conta corrente, poupança ou carteira não tiver conferência de saldo há mais de **35 dias**, o
   sistema DEVE exibir um alerta (não urgente) no Início, com link para conferir.
3. O alerta NÃO DEVE aparecer para contas desativadas nem para tipos sem conferência (investimento, bem,
   cartão, dívida).

### Requisito 2 — Fechamento exige (ou registra dispensa de) conferência

**História:** Como usuário, quero que o fechamento do mês me obrigue a decidir sobre a conferência de cada
conta, para não fechar um mês com dados pela metade sem querer.

#### Critérios de aceite
1. QUANDO o usuário for fechar o mês, o sistema DEVE listar cada conta disponível e seu estado de conferência
   no mês (conferida em DD/MM, ou não conferida).
2. QUANDO uma conta não estiver conferida no mês, o sistema DEVE exigir que o usuário **confira** ou
   **dispense explicitamente** a conferência daquela conta antes de permitir fechar.
3. QUANDO o usuário dispensar a conferência de uma conta, o sistema DEVE registrar a dispensa (com a data e,
   idealmente, um motivo livre) na auditoria, para consulta posterior.
4. O mês NÃO DEVE poder ser fechado enquanto houver conta disponível sem conferência nem dispensa.

### Requisito 3 — Início mostra o que foi lançado fora do cartão

**História:** Como usuário, quero ver no Início quanto do mês foi lançado fora do cartão, para perceber na
hora um mês sem nenhum Pix ou boleto registrado (sinal de dado faltando).

#### Critérios de aceite
1. O Início DEVE mostrar, para o mês corrente, o total lançado **fora do cartão de crédito** (Pix, débito,
   boleto, dinheiro, débito automático etc.), separado do total no cartão.
2. QUANDO o total fora do cartão no mês for **zero** (ou muito abaixo da média dos meses anteriores), o
   sistema DEVE sinalizar que o mês pode estar incompleto (provável falta de lançamentos manuais).
3. A métrica DEVE usar o livro-razão existente (sem segundo caminho de cálculo), consumindo `razao`/`relatorios`.

## Fora de escopo
- Importação automática de extrato (é R2/R7).
- Qualquer lançamento automático: a R11 só torna visível a incompletude, não inventa dados.
