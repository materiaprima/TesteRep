# R11 — Tarefas: Completude dos dados

> **Status: feita (alpha.15), pelo Claude.** Ordem: schema primeiro, depois alerta, gate e indicador.

- [x] 1. Migração 0012 (só acréscimo — regra 4)
  - [x] 1.1 `0012_conferencia_saldo.sql`: adicionar registro de conferência. Decidir entre coluna
    `contas.ultima_conferencia TEXT` (simples) ou tabela `conferencias(conta_id,data,saldo_informado,diferenca,criado_em)`
    (histórico, recomendada). Se gate por dispensa, incluir `dispensas_conferencia(mes,conta_id,motivo,criado_em)`.
  - [x] 1.2 `test_migracao_0012_acrescenta_coluna` (banco v0011 → 0012 sem perda).

- [x] 2. Gravar a conferência (Requisito 1.1)
  - [x] 2.1 Em `pg_contas.conta_conciliar` e `operacoes.ajustar_saldo`, registrar a data da conferência.

- [x] 3. Alerta de 35 dias (Requisito 1)
  - [x] 3.1 Em `relatorios.alertas`, item para conta `corrente/poupanca/carteira` ativa sem conferência há
    > 35 dias, link `/contas/<id>/conciliar`, severidade não-urgente.
  - [x] 3.2 `test_alerta_conferencia_35_dias` (40 dias gera; 10 não; investimento/cartão nunca).

- [x] 4. Gate de conferência no fechamento (Requisito 2)
  - [x] 4.1 GET `/fechamento`: listar contas disponíveis com estado de conferência no mês.
  - [x] 4.2 Ação POST `acao=dispensar` (conta_id, motivo) registrando na auditoria e/ou tabela de dispensas.
  - [x] 4.3 POST `acao=fechar`: recusar se houver conta disponível sem conferência nem dispensa no mês.
  - [x] 4.4 `test_fechamento_exige_conferencia` (recusa → conferir/dispensar → aceita; dispensa auditada).

- [x] 5. Indicador "fora do cartão" no Início (Requisito 3)
  - [x] 5.1 Em `relatorios.resumo_mes` (ou apoio), calcular `total_fora_cartao` e `total_no_cartao` a partir
    do razão (sem segundo caminho de cálculo).
  - [x] 5.2 Mostrar as duas somas no Início (`pg_inicio`).
  - [x] 5.3 Aviso de "mês pode estar incompleto" quando `total_fora_cartao` for zero (limiar a calibrar).
  - [x] 5.4 `test_inicio_fora_do_cartao`.

- [x] 6. Regressão
  - [x] 6.1 `pytest tests` inteiro verde; testes de `/fechamento` e conciliação não quebram.

## Decisões a confirmar antes de executar
- Coluna simples ou tabela de histórico de conferências? (recomendo histórico)
- Gate do fechamento bloqueante (exige dispensa) ou só aviso forte?
- Limiar do "mês incompleto": zero absoluto ou % da média?

## Execução (Claude)
Decisões: tabela de histórico (conferencias) + dispensas_conferencia (migração 0012); fechamento bloqueante com dispensa
auditada (pedido do usuário no R11 original); mês incompleto = zero fora do cartão a partir do dia 7. "Conferida" = a conferência
mais recente com data no mês bateu (diferença zero). Contas exigidas: disponíveis com movimento até o fim do mês (a data de
criação não serve: contas novas recebem meses passados). Testes: tests/integracao/test_conferencias.py (4) + e2e.
