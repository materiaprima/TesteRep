# R11 — Design: Completude dos dados

> Baseado em `operacoes.py` (conciliação), `pg_planejamento.py` (`/fechamento`), `pg_contas.py`
> (`conta_conciliar`), `relatorios.py` (`alertas`, `resumo_mes` com `por_forma`/`meio_pagamento`),
> e no schema `0001_razao.sql` (tabela `contas`) + migrações existentes (última: `0011`).

## Visão geral

A R11 amplia o que já existe em vez de criar subsistemas novos. Três frentes:
1. **Carimbo de última conferência** por conta → alerta de 35 dias.
2. **Gate de conferência** no fechamento do mês.
3. **Indicador "fora do cartão"** no Início, a partir de `resumo_mes`.

Tudo passa pelo livro-razão e pelas funções existentes; nenhuma viola a seção 9.

## 1. Carimbo de última conferência (migração 0012, só acréscimo)

**Schema atual (lido):** `contas` tem `subtipo`, `ativa`, `dia_fechamento`, `limite_centavos`,
`regra_fechamento`. Nenhuma coluna de conferência.

**Proposta:** migração `0012_conferencia_saldo.sql` — `ALTER TABLE contas ADD COLUMN ultima_conferencia TEXT`
(data ISO, nulo = nunca). **Acréscimo de coluna**, exatamente o padrão permitido pela regra 4; não reconstrói
tabela nem mexe em FK.

**Onde gravar:** em `pg_contas.conta_conciliar`, ao registrar a conferência (e em `ajustar_saldo`), gravar
`UPDATE contas SET ultima_conferencia=? WHERE id=?`. Alternativa mais auditável: uma tabela
`conferencias(conta_id, data, saldo_informado, diferenca, criado_em)` que também serve de histórico. Decidir
entre coluna simples (mais barato) e tabela de histórico (mais completa) — ver pontos em aberto.

**Alerta (Requisito 1):** em `relatorios.alertas`, para cada conta `subtipo IN ('corrente','poupanca',
'carteira')` e `ativa=1`, se `ultima_conferencia` é nula ou > 35 dias atrás, acrescentar item `('conferir',
'A conta X não é conferida há N dias.', '/contas/<id>/conciliar')`. Severidade não-urgente.

## 2. Gate de conferência no fechamento (Requisito 2)

**Estado atual (lido):** `/fechamento` monta um checklist de 3 itens (pendências de importação, previstos não
confirmados, não conferidos) mas o botão "Fechar" não depende deles — fecha sempre.

**Proposta:**
- Na GET `/fechamento`, acrescentar uma lista de contas disponíveis com o estado de conferência **no mês**
  (conferida em DD/MM, via `ultima_conferencia` dentro do intervalo do mês, ou "não conferida").
- O botão "Fechar" só habilita quando toda conta disponível estiver **conferida no mês** ou com **dispensa
  registrada** para aquele mês. Como não há JS, o gate é no servidor: a POST `fechamento_acao` com
  `acao=fechar` valida e recusa (com mensagem) se houver conta pendente sem dispensa.
- **Dispensa:** nova ação POST (`acao=dispensar`, `conta_id`, `motivo`) que grava na auditoria
  (`banco.auditar(c, 'dispensar_conferencia', 'conta', conta_id, f'{ym}: {motivo}')`). O registro de dispensa
  por mês pode viver numa tabela `dispensas_conferencia(mes, conta_id, motivo, criado_em)` (migração 0012
  junto) ou ser derivado da auditoria. Recomendo tabela própria para a checagem do gate ser simples e barata.

## 3. Indicador "fora do cartão" no Início (Requisito 3)

**Estado atual (lido):** `relatorios.resumo_mes` já devolve `por_forma` agrupando despesas por
`t.meio_pagamento`. Dá para derivar "fora do cartão" sem SQL novo: somar as formas que não são crédito, ou
somar despesas cujas contas de saída não são `subtipo='cartao'`.

**Proposta:**
- Em `resumo_mes` (ou numa função de apoio), calcular `total_fora_cartao` = despesas do mês cuja origem **não**
  é cartão de crédito, e `total_no_cartao` separadamente.
- No Início (`pg_inicio`), mostrar as duas somas lado a lado.
- Sinal de incompletude: se `total_fora_cartao == 0` com o mês já em curso, ou muito abaixo da média dos
  últimos meses (ex.: < 20% da média), exibir aviso "o mês pode estar incompleto: nenhum/poucos Pix, boletos
  ou débitos lançados". Usar a média que o Raio-X já calcula, para não criar terceiro caminho.

## Estratégia de testes
- `test_migracao_0012_acrescenta_coluna`: banco na v0011 migra para 0012 sem perda; coluna `ultima_conferencia`
  existe e começa nula.
- `test_alerta_conferencia_35_dias`: conta conferida há 40 dias gera alerta; há 10 dias, não; conta
  investimento/cartão nunca gera.
- `test_fechamento_exige_conferencia`: mês com conta não conferida e sem dispensa → `fechar` recusado; após
  conferir ou dispensar → `fechar` aceito; a dispensa aparece na auditoria.
- `test_inicio_fora_do_cartao`: mês só com compras no cartão → `total_fora_cartao==0` e aviso; mês com Pix →
  soma correta e sem aviso.
- Regressão: `pytest tests` inteiro verde; os testes de `/fechamento` e de conciliação existentes não podem
  quebrar.

## Pontos em aberto (decisão do usuário)
1. **Coluna simples `ultima_conferencia` vs tabela de histórico `conferencias`.** Histórico é mais útil a longo
   prazo (ver evolução das diferenças), mas é mais código. Minha recomendação: tabela de histórico, porque
   casa com o espírito do projeto (auditável) e serve a relatórios futuros.
2. **Limiar do "mês incompleto"** (zero absoluto? % da média?). Começaria com "zero fora do cartão" e evoluiria
   com uso real, para não gerar alarme falso.
3. **Gate rígido vs suave:** exigir dispensa explícita (rígido, como o Requisito 2.4 pede) pode irritar no uso
   diário. Confirmar que você quer o gate bloqueante, não só um aviso forte.
