# R14 — Simulador de financiamento (P2)

> Spec enxuta (só requirements) — P2, relevante se forem comprar imóvel ou carro. Baseada em
> `fin404/dominio/simulador.py`, que já tem `price()` (tabela Price) e o teto legal do rotativo, mas **não**
> tem SAC, FGTS, CET completo nem amortização extra.
>
> **Status: não executar.**

## Introdução

O simulador atual cobre dívida de cartão (rotativo, parcelamento, Price com teto legal). A R14 acrescenta um
simulador de **financiamento de bem** (imóvel/carro) em SAC e Price, com CET, FGTS e amortizações extras.
Tudo em centavos inteiros e Decimal para taxas (regra 1).

## Requisitos

### Requisito 1 — Simular SAC e Price
1. O sistema DEVE simular financiamento em **SAC** e **Price**: valor do bem, entrada, uso do FGTS, prazo,
   taxa anual e **CET** (custo efetivo total, com seguros e tarifas), mostrando **primeira e última parcela**,
   **total pago** e **total de juros**.

### Requisito 2 — Comparar com a renda e a reserva
1. O sistema DEVE comparar a parcela com a **renda média** (alerta acima de 30%) e com a **sobra média** do
   Raio-X.
2. O sistema DEVE mostrar o efeito na reserva de usar dinheiro guardado como **entrada**.

### Requisito 3 — Amortizações extras
1. O sistema DEVE permitir simular **amortizações extras**, mostrando o efeito de **reduzir prazo** ×
   **reduzir parcela**.

## Nota
Reusar `analises` (renda média, sobra, reserva) para as comparações, sem segundo caminho de cálculo. É
simulação (hipótese), nunca oferta de banco — deixar isso explícito, como o simulador atual já faz para
dívidas.
