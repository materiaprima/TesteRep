# R5 — Lixeira para projetos e compras (P2)

> Spec enxuta (só requirements) — P2. Design/tasks virão quando priorizada.
> Baseada em `razao.py` (`lixeira`/`restaurar`, 90 dias, sobre a auditoria) e `compras.py` (`excluir_plano`
> faz `DELETE` direto de projetos e itens).
>
> **Status: não executar.**

## Introdução

Hoje a Lixeira (`razao.lixeira`/`restaurar`) cobre **transações** (via auditoria, 90 dias). Projetos e itens
de compra, porém, são apagados de vez (`compras.excluir_plano` → `DELETE`). A R5 traz projetos e itens de
compra para o mesmo padrão de exclusão em dois passos + restauração.

## Requisitos

### Requisito 1 — Restaurar projeto/item excluído
1. QUANDO o usuário excluir um projeto ou item de compra, o sistema DEVE permitir restaurá-lo pela Lixeira
   (hoje só fica na auditoria).
2. A exclusão DEVE continuar em dois passos e auditada (regra 9).
3. A restauração DEVE respeitar a janela de 90 dias, como a dos lançamentos.

### Requisito 2 — Religar o lançamento ao item restaurado
1. QUANDO um lançamento ligado a uma compra for restaurado, a **ligação** com a compra DEVE voltar.

## Nota
Sobreposição com R5b (comprovantes na lixeira) e R12 (anexos/garantias). Alinhar o modelo de "soft delete"
para projetos/itens/anexos de uma vez, evitando três mecanismos diferentes.
