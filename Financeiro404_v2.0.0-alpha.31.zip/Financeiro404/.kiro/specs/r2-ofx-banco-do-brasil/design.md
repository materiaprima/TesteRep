# R2 — Design: Extrato OFX do Banco do Brasil

> Baseado em `fin404/importacao/adaptadores/ofx.py` e `fin404/importacao/pipeline.py` (lidos 07/11/2026).

## Visão geral

A R2 é majoritariamente **validação e ajuste fino**, não construção. O adaptador OFX já é tolerante. O
trabalho é: obter um OFX real do BB anonimizado, confirmar que o adaptador o lê inteiro e corretamente, e
corrigir só o que o arquivo real revelar. O risco de regressão é o maior perigo — por isso cada ajuste vem
com teste e a suíte inteira precisa continuar passando.

## O que já existe (lido)

- `ofx.ler(dados)` → `{formato, conta_externa (ACCTID), cartao (bool), linhas, avisos}`.
  - `_decodificar`: tenta, nesta ordem, o encoding do XML, cp1252 (se `CHARSET:1252`), latin-1 (se 8859-1),
    depois `utf-8-sig` e `cp1252`, com fallback `latin-1`.
  - Detecção de truncamento: compara `<STMTTRN>` abertos com blocos fechados e exige `</OFX>`.
  - FITID repetido → aviso + cai para casamento por data/valor.
  - Valor: trata `1.234,56` e `1234.56`; centavos inteiros via `Decimal`.
  - Descrição: usa `MEMO` ou `NAME` (o mais longo), limita a 200 chars.
- `pipeline.ler_arquivo` roteia `.ofx/.qfx` (ou conteúdo com `<OFX`/`OFXHEADER`) para `ofx.ler`.
- `pipeline.preparar` grava em staging, confere SHA-256 (mesmo arquivo → recusa), confere `conta_externa`
  contra `identificador_externo` da conta, e chama `sugerir`.
- `_candidatas`: casa por conta + valor + data ±3 dias (`TOLERANCIA_DIAS=3`).

## Mudanças prováveis (a confirmar com o arquivo real)

1. **Ordem de encoding:** se o BB exportar em utf-8 sem declarar, mover `utf-8` para antes de `cp1252`
   quando não houver `CHARSET` no cabeçalho. Decidir só vendo o arquivo.
2. **FITID longo/estável:** nenhum limite de tamanho hoje; confirmar que o BD aceita o tamanho real.
3. **Linhas de saldo:** `LEDGERBAL`/`AVAILBAL` são ignoradas. Para o Requisito 3 (se aceito), ler
   `<LEDGERBAL><BALAMT>` e `<DTASOF>` e devolvê-los em `ler()` (`saldo`, `saldo_em`), sem efeito no razão.
4. **`conta_externa` do BB:** confirmar o formato de `ACCTID` (agência/conta) para a checagem de conta certa
   não dar falso negativo.

## Estratégia de testes

- **Fixture anonimizada:** criar `tests/fixtures/bb_extrato_anon.ofx` a partir de um arquivo real com nomes,
  número de conta e valores substituídos por fictícios, **preservando o layout/charset/estrutura** que
  importam para o parser. Nunca commitar o arquivo real.
- `test_ofx_bb_le_todas_as_linhas`: contagem de linhas == nº de `<STMTTRN>`; acentos corretos.
- `test_ofx_bb_nao_duplica_na_reimportacao`: importar duas vezes → segunda recusada por SHA; e por FITID se
  o conteúdo mudar.
- `test_ofx_bb_casa_com_previsto`: previsão de salário + linha do OFX de mesmo valor em ±3 dias → sugere casar.
- (se Requisito 3) `test_ofx_le_saldo_ledgerbal`: OFX com `LEDGERBAL` → `ler()` devolve saldo e data.
- **Regressão:** `pytest tests` inteiro precisa continuar verde; os testes OFX sintéticos existentes não podem
  quebrar.

## Riscos e pontos em aberto
1. **Depende de um arquivo real.** Sem o OFX do BB em mãos, a validação não acontece — o adaptador pode estar
   100% certo e só confirmamos com o arquivo. Esta é a dependência externa da R2.
2. **Anonimização correta:** a substituição não pode alterar o que o parser testa (charset, tamanho de FITID,
   estrutura de blocos). Documentar o processo de anonimização.
3. **Requisito 3 (saldo) entra na R2 ou vira item separado?** Decisão sua.
