# R2 — Tarefas: Extrato OFX do Banco do Brasil

> **Não executar ainda.** Depende de um OFX real do BB (anonimizado) para a validação de verdade.

- [ ] 1. Obter e anonimizar um OFX real do BB
  - [ ] 1.1 Baixar o extrato OFX da conta no internet banking do BB.
  - [ ] 1.2 Anonimizar (nomes, número de conta/agência, valores) preservando charset, estrutura de blocos e
    formato de FITID. Documentar o processo.
  - [ ] 1.3 Salvar como `tests/fixtures/bb_extrato_anon.ofx`. **Nunca** commitar o arquivo real.

- [ ] 2. Confirmar leitura completa (Requisito 1)
  - [ ] 2.1 `test_ofx_bb_le_todas_as_linhas`: contagem == nº de `<STMTTRN>`, acentos corretos.
  - [ ] 2.2 Se o charset real exigir, ajustar a ordem de candidatos em `ofx._decodificar` (só se o teste pedir).
  - [ ] 2.3 Confirmar que truncamento/corrupção continua recusado (teste já existente não pode quebrar).

- [ ] 3. Confirmar casamento e não-duplicação (Requisito 2)
  - [ ] 3.1 `test_ofx_bb_casa_com_previsto` (previsto + linha OFX mesmo valor ±3 dias → casar).
  - [ ] 3.2 `test_ofx_bb_nao_duplica_na_reimportacao` (SHA e FITID).
  - [ ] 3.3 Confirmar formato de `ACCTID` do BB na checagem de conta certa; ajustar só se der falso negativo.

- [ ] 4. (Condicional à decisão) Saldo do OFX na conferência (Requisito 3)
  - [ ] 4.1 Ler `<LEDGERBAL><BALAMT>`/`<DTASOF>` em `ofx.ler`, devolvendo `saldo`/`saldo_em` sem efeito no razão.
  - [ ] 4.2 Oferecer o saldo como sugestão na tela de conferência de saldo.
  - [ ] 4.3 `test_ofx_le_saldo_ledgerbal`.

- [ ] 5. Regressão
  - [ ] 5.1 `pytest tests` inteiro verde; nenhum teste OFX sintético existente quebrado.

## Decisões a confirmar antes de executar
- Requisito 3 (ler saldo do OFX) entra na R2 ou vira item separado?
- Você consegue extrair o OFX do BB para gerarmos a fixture anonimizada? (bloqueia a validação real)
