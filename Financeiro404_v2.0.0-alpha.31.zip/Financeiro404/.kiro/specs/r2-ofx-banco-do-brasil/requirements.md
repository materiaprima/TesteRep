# R2 — Extrato OFX do Banco do Brasil (P0)

> Spec do item R2 da seção 8 do `PARA_O_KIRO.md`. Baseada na leitura de
> `fin404/importacao/adaptadores/ofx.py` e `fin404/importacao/pipeline.py`.
>
> **Status das tarefas: não executar.**

## Introdução

O casal não tem extratos bancários recorrentes; a fonte automática é a fatura do cartão em PDF. Descoberta
tardia: o internet banking do BB permite baixar o extrato da conta corrente em OFX. O **leitor OFX já
existe e é robusto** (lido em `ofx.py`): decodifica cp1252/latin-1/utf-8, detecta arquivo truncado
(`</OFX>` ausente ou contagem de `<STMTTRN>` divergente), trata FITID repetido como aviso (cai para
casamento por data+valor), ignora valor zero, e lê tanto SGML 1.x quanto XML 2.x. O pipeline já casa por
data ±3 dias e mesmo valor contra previstos e lançamentos manuais, e detecta duplicata por `id_externo`.

O que **falta** é validar com um **arquivo OFX real do BB** e ajustar o adaptador ao que esse arquivo
tiver de específico (charset real, formato de `FITID`, presença de linhas de saldo `LEDGERBAL`,
particularidades de `MEMO`/`NAME`), **sem quebrar os testes existentes**. Hoje só há fixtures sintéticas.

Risco central: este item ataca a causa do R11 (completude dos dados). Enquanto o OFX não estiver validado,
tudo que não passa pelo cartão depende de lançamento manual.

## Glossário

- **FITID:** identificador único da transação no OFX; usado para detectar reimportação do mesmo extrato.
- **LEDGERBAL/AVAILBAL:** saldo contábil/disponível que o OFX pode trazer; hoje o adaptador os ignora.
- **Casamento:** ligar uma linha do extrato a um previsto ou lançamento manual já existente (±3 dias, mesmo valor).

## Requisitos

### Requisito 1 — Ler o OFX real do BB sem perder linhas

**História:** Como usuário, quero importar o OFX que baixei do internet banking do BB e ver todas as
movimentações, para não precisar lançar à mão.

#### Critérios de aceite
1. QUANDO o usuário importar um OFX real do BB, o sistema DEVE ler **todas** as transações (`<STMTTRN>`),
   sem descartar nenhuma silenciosamente, e exibir a contagem.
2. QUANDO o arquivo usar o charset real do BB, o sistema DEVE decodificar corretamente acentos em
   descrições (confirmar se é cp1252 ou utf-8; ajustar a ordem de candidatos em `_decodificar` se preciso).
3. QUANDO o arquivo estiver truncado ou corrompido, o sistema DEVE recusar com a mensagem já existente
   ("OFX parece incompleto"), sem importar parcial.
4. A validação DEVE usar um OFX real **anonimizado** como fixture; nenhum dado real (nomes, números de conta)
   pode entrar no repositório (regra 7 da seção 9).

### Requisito 2 — Casar com previstos e manuais sem duplicar

**História:** Como usuário que já lança algumas coisas à mão (ou tem previsões), quero que o OFX case com o
que já existe em vez de criar duplicata.

#### Critérios de aceite
1. QUANDO uma linha do OFX corresponder a um lançamento já existente (mesmo valor, data ±3 dias), o sistema
   DEVE sugerir casar, não criar novo (comportamento atual do pipeline, a confirmar com arquivo real).
2. QUANDO o mesmo OFX for importado de novo na mesma conta, o sistema DEVE recusar pelo SHA-256 do arquivo
   (comportamento atual) OU, se o conteúdo mudar mas as linhas forem as mesmas, detectar duplicata por FITID.
3. QUANDO o FITID do BB tiver formato peculiar (ex.: muito longo, com espaços), o sistema DEVE tratá-lo como
   identificador estável; se repetir no mesmo arquivo, cair para casamento por data+valor (comportamento atual).

### Requisito 3 — Aproveitar o saldo do OFX na conferência (melhoria sugerida)

**História:** Como usuário, quero que o saldo que vem no OFX ajude a conferência mensal, já que é o ponto
fraco do sistema sem extrato.

> **Nota crítica (minha):** o adaptador hoje **ignora** `LEDGERBAL`. Como a conferência de saldo é
> justamente o calcanhar do projeto (R11), ler o saldo do OFX e oferecê-lo na conferência seria um ganho
> real e barato. Classifico como **melhoria recomendada**, não exigência do backlog — decisão sua se entra
> na R2 ou vira item à parte.

#### Critérios de aceite (se aceito)
1. QUANDO o OFX trouxer `LEDGERBAL`, o sistema PODE ler o saldo e a data (`DTASOF`) e oferecê-los na tela de
   conferência de saldo da conta, como valor sugerido.
2. A leitura do saldo NÃO DEVE alterar o livro-razão por si só; serve só de apoio à conferência manual.

## Fora de escopo
- Leitor de PDF de outros bancos (R6).
- Open Finance (R7).
- Qualquer sincronização automática: a importação continua manual, arquivo a arquivo.
