# R12 — Tarefas: Garantias e prazos

> **Status: feita (alpha.17), pelo Claude.**

- [x] 1. Schema (migração de acréscimo — regra 4)
  - [x] 1.1 Tabela `prazos` (tipo, titulo, data_fim, avisar_dias_antes, ligações opcionais, concluido_em).
  - [x] 1.2 `test_migracao_prazos`.

- [x] 2. Garantia de compra (Requisito 1)
  - [x] 2.1 Campo de garantia (meses → data_fim, ou data) no item de compra; anexar nota via `anexos`.
  - [x] 2.2 Aviso faltando 30 dias (integra `relatorios.alertas`).
  - [x] 2.3 Busca que acha garantia + anexo por título.
  - [x] 2.4 `test_garantia_avisa_30_dias`, `test_busca_garantia`.

- [x] 3. Painel de prazos não-financeiros (Requisito 2)
  - [x] 3.1 Página "Prazos" com lista ordenada por proximidade, aviso configurável, editar/concluir/excluir
    (dois passos, auditado).
  - [x] 3.2 Integração com alertas/compromissos.
  - [x] 3.3 `test_prazo_nao_financeiro_no_painel`, `test_aviso_antecipado_configuravel`.

- [x] 4. Regressão
  - [x] 4.1 `pytest tests` verde; `relatorios.alertas` existente intacto.

## Decisões a confirmar antes de executar
- Uma tabela `prazos` para tudo (recomendado) ou separadas por tipo?
- Garantia também a partir de lançamento avulso?
- Ordem em relação a R10 (nota) e R5b (anexos na lixeira)?

## Execução (Claude)
Decisões: uma tabela `prazos` (migração 0015) para garantias e prazos; garantia nasce do lançamento (num parcelamento conta
da data da compra e vale para todas as parcelas), da compra planejada (`garantia_meses`, ao comprar) e do item de nota fiscal.
Garantia acabada sai dos alertas sozinha; prazo vencido segue avisando até concluir. "Renovado" cria o próximo (padrão: 12 meses
para licenciamento/seguro/revisão, 120 para CNH). Busca acha prazo, lançamento e comprovante. Testes: test_prazos.py (5) + e2e.
