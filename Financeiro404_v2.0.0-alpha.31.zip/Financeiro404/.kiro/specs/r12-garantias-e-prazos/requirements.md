# R12 — Garantias e prazos (P1)

> Spec do item R12 da seção 8 do `PARA_O_KIRO.md`, registrado em 07/11/2026. Baseada na leitura de
> `fin404/dominio/anexos.py` (anexos ligados a transação) e `fin404/dominio/compras.py` (projetos e itens).
>
> **Status das tarefas: não executar.**

## Introdução

Dois problemas distintos reunidos: (a) **garantias** de compras (avisar antes de acabar, achar a nota
depois) e (b) **prazos que não são compras** (CNH, licenciamento, seguro, fim de contrato, revisão,
documentos). Hoje o app tem anexos (PDF/foto) ligados a **lançamentos** (`anexos.py`), mas não há conceito
de garantia, prazo de validade, nem painel de vencimentos não-financeiros.

## Requisitos

### Requisito 1 — Garantia de compras

**História:** Como usuário, quero informar o prazo de garantia de uma compra e anexar a nota, para ser
avisado antes de acabar e achar a nota quando precisar.

#### Critérios de aceite
1. QUANDO o usuário registrar uma compra (em Compras e projetos ou numa nota fiscal), o sistema DEVE permitir
   informar o **prazo de garantia** (meses ou data final) e **anexar a nota/comprovante**.
2. QUANDO faltarem **30 dias** para a garantia acabar, o sistema DEVE avisar.
3. A busca DEVE achar a nota e a garantia de um item em poucos passos (ex.: "a geladeira ainda está na
   garantia?").

### Requisito 2 — Painel de prazos não-financeiros

**História:** Como usuário, quero um lugar único para os prazos que não são compras, para não perder data de
CNH, seguro, licenciamento, contratos.

#### Critérios de aceite
1. O sistema DEVE ter um painel único de prazos: CNH, licenciamento, seguro do carro, fim de contrato
   (aluguel, internet, plano de celular), revisão, documentos.
2. Cada prazo DEVE ter aviso antecipado **configurável** (ex.: avisar 30/60/90 dias antes).
3. QUANDO um prazo estiver próximo, o sistema DEVE mostrá-lo entre os alertas/compromissos.

## Fora de escopo
- Renovação automática de qualquer documento (só aviso).
- Integração com órgãos (Detran etc.).

## Nota de modelagem
Anexos hoje ligam a **transação** (`anexos.py`). Garantia liga a uma **compra** (item de Compras/projeto) ou
a uma **nota** (R10) ou a um **lançamento**. Prazos não-financeiros não têm lançamento nenhum. Logo, R12
precisa de tabela(s) própria(s) de prazos/garantias, por acréscimo (regra 4). Ver design. Há sobreposição
com R10 (anexar a nota) e com R5/R5b (lixeira/anexos) — alinhar para não duplicar.
