# R12 — Design: Garantias e prazos

> Baseado em `anexos.py` (anexos por transação), `compras.py` (itens de compra), `relatorios.alertas`
> (mecanismo de alertas e compromissos já existente).

## Visão geral

Dois conceitos, uma mesma mecânica de aviso. Uma tabela `prazos` cobre os dois casos (garantia de compra e
prazo não-financeiro), diferenciados por um campo `tipo`. Reaproveita o motor de alertas de
`relatorios.alertas` (já lista fatura vencendo, parcela ausente etc.).

## Schema (migração de acréscimo — regra 4)

- `prazos(id, tipo, titulo, data_fim, avisar_dias_antes, compra_item_id NULL, nota_id NULL, transacao_id NULL,
  anexo_id NULL, observacao, criado_em, concluido_em NULL)`.
  - `tipo`: `garantia`, `cnh`, `licenciamento`, `seguro`, `contrato`, `revisao`, `documento`, `outro`.
  - `avisar_dias_antes`: inteiro configurável (default 30).
  - os `*_id` opcionais ligam o prazo a uma compra/nota/lançamento quando fizer sentido; nulos para prazos
    puramente de calendário (CNH).
FK só das novas para as existentes; sem reconstrução.

## Garantia (Requisito 1)

- No formulário de item de compra (`compras.py`/`pg_compras.py`) e, quando R10 existir, na nota, oferecer
  "prazo de garantia" (meses → calcula `data_fim`, ou data direta) e anexar nota (reusar `anexos.adicionar`,
  guardando o `anexo_id` no prazo).
- Busca: campo de busca que cruza título/compra/nota → mostra a garantia e o anexo. "A geladeira ainda está
  na garantia?" = achar o prazo `garantia` cujo título casa com "geladeira" e comparar `data_fim` com hoje.

## Painel de prazos (Requisito 2)

- Página "Prazos" listando os `prazos` abertos, ordenados por proximidade, com `tipo`, `data_fim`, dias
  restantes e aviso configurável. Editar/concluir/excluir (dois passos, auditado — regra 9).
- Integração com alertas: `relatorios.alertas` passa a incluir prazos cujo `data_fim - hoje <=
  avisar_dias_antes`, severidade conforme proximidade.

## Estratégia de testes
- `test_migracao_prazos`.
- `test_garantia_avisa_30_dias` (faltando 30 dias aparece; 31 não).
- `test_prazo_nao_financeiro_no_painel` (CNH sem lançamento aparece no painel e nos alertas).
- `test_busca_garantia` ("geladeira" encontra a garantia e o anexo).
- `test_aviso_antecipado_configuravel` (60/90 dias respeitados).
- Regressão completa verde; `relatorios.alertas` existente não quebra.

## Pontos em aberto (decisão do usuário)
1. **Uma tabela `prazos` para tudo** (recomendado) vs tabelas separadas por tipo. Uma só é mais simples.
2. **Garantia nasce só de Compras/projetos e notas, ou também de um lançamento qualquer?** Sugiro permitir de
   lançamento também (compra avulsa com comprovante).
3. **Sobreposição com R10 (anexar nota) e R5b (anexos na lixeira):** decidir a ordem; se R10 vier antes, a
   garantia já aproveita a nota importada.
