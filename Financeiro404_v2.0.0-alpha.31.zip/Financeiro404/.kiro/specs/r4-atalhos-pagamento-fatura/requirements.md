# R4 — Atalhos no pagamento de fatura (P1)

> Spec do item R4 da seção 8 do `PARA_O_KIRO.md`. Baseada na leitura de `fin404/web/pg_cartoes.py`
> (`fatura_pagina`, `cartao_pagar`), `fin404/dominio/cartoes.py` (`fatura`) e
> `fin404/importacao/adaptadores/pdf_bb.py` (`informacoes_extras`, que lê o "Pagamento mínimo").
>
> **Status das tarefas: não executar.**

## Introdução

Hoje a tela "Pagar esta fatura" (`fatura_pagina`) tem um campo de valor pré-preenchido com `fat['restante']`
(o que falta pagar) e um campo de data. Falta oferecer os atalhos que o dia a dia pede: pagar o **total**,
pagar o **mínimo**, ou **outro valor**, e avisar quando o pagamento for menor que o total (entrada no
rotativo, que é caro).

**O que o código já tem (lido):**
- `cartoes.fatura(...)` devolve `valor` (total da fatura), `restante` (falta pagar), `pagos`, `documento`.
- O leitor de PDF (`informacoes_extras`) **captura o "Pagamento mínimo"** da fatura e o guarda em
  `extras`/`fatura_info` do lote de importação. Ou seja, o mínimo da última fatura importada existe na base.
- Há um simulador de dívidas (`simulador.comparar`) que já explica o custo do rotativo e do parcelamento.

## Requisitos

### Requisito 1 — Atalhos de valor no pagamento

**História:** Como usuário, quero escolher rapidamente pagar o total, o mínimo ou outro valor, sem digitar à
mão o que o sistema já sabe.

#### Critérios de aceite
1. QUANDO o usuário abrir "Pagamento de fatura", o sistema DEVE oferecer as opções:
   - **"Total da fatura em aberto"** (= `fat['restante']`), preenchendo o valor automaticamente;
   - **"Mínimo"** (= pagamento mínimo da última fatura importada, quando disponível), preenchendo o valor;
   - **"Outro valor"** (campo livre, comportamento atual).
2. QUANDO o mínimo não estiver disponível (nenhuma fatura importada, ou o PDF não trouxe o campo), o sistema
   DEVE ocultar ou desabilitar a opção "Mínimo" com uma explicação curta, sem quebrar a tela.
3. A escolha do atalho DEVE funcionar **sem JavaScript** (a CSP proíbe JS): usar, por exemplo, botões de
   envio que submetem o formulário com o valor correspondente, ou campos pré-preenchidos por opção.

### Requisito 2 — Aviso de rotativo

**História:** Como usuário, quero ser avisado quando estou pagando menos que o total, porque isso me joga no
rotativo (juros altos).

#### Critérios de aceite
1. QUANDO o valor informado for **menor que o total da fatura em aberto**, o sistema DEVE avisar, em português
   claro, que o restante entra no rotativo e que os juros são altos.
2. O aviso PODE apontar para o simulador de dívidas já existente, para o usuário ver o custo.
3. QUANDO o valor for **maior que o total**, o sistema DEVE avisar (possível erro de digitação) antes de
   registrar.

## Fora de escopo
- Calcular o mínimo por conta própria (regras de cada banco variam); usamos o que o PDF informa.
- Parcelar a fatura pelo app (isso é operação do banco; o simulador só estima).

## Nota (crítica)
O "mínimo" vem da **última fatura importada**, não da fatura sendo paga necessariamente. Se o usuário pagar
uma fatura diferente da última importada, o mínimo exibido pode não corresponder. O design precisa deixar
claro de qual fatura é o mínimo (ex.: "mínimo da fatura de DD/MM").
