# R4 — Tarefas: Atalhos no pagamento de fatura

> **Status: feita (alpha.15), pelo Claude.**

- [x] 1. Ler o mínimo da última fatura importada (Requisito 1)
  - [x] 1.1 Função de apoio que lê `minimo` de `lotes_importacao.fatura_info` (última do cartão, não desfeita).
  - [x] 1.2 Expor a data da fatura de origem do mínimo para rotular na tela.

- [x] 2. Atalhos de valor na tela (Requisito 1)
  - [x] 2.1 Acrescentar os modos Total / Mínimo / Outro em `fatura_pagina`, sem JS (botões de envio).
  - [x] 2.2 Ocultar/explicar "Mínimo" quando indisponível.

- [x] 3. Confirmação com avisos (Requisito 2) — Opção 2 recomendada
  - [x] 3.1 Página de confirmação mostrando o valor escolhido.
  - [x] 3.2 Aviso de rotativo quando valor < total (link para simulador/custo do crédito).
  - [x] 3.3 Aviso de valor acima do total.
  - [x] 3.4 "Confirmar pagamento" chama `cartoes.pagar` (inalterado).

- [x] 4. Testes
  - [x] 4.1 `test_pagar_total_preenche_restante`.
  - [x] 4.2 `test_pagar_minimo_usa_ultima_fatura` (com e sem fatura importada).
  - [x] 4.3 `test_aviso_rotativo` e `test_aviso_valor_acima_do_total`.
  - [x] 4.4 Regressão: pagamento e e2e verdes.

## Decisões a confirmar antes de executar
- Um clique (Opção 1) ou confirmação em página (Opção 2, recomendada)?

## Execução (Claude)
Opção 2 (página de confirmação). Diferença do design: o mínimo é o do PDF da **própria** fatura sendo paga
(cartoes.minimo_da_fatura), não o da última importada; sem ele, o botão não aparece e a nota explica. Testes de integração e e2e.
