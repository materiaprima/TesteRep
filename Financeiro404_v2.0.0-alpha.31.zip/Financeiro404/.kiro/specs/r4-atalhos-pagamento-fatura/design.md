# R4 — Design: Atalhos no pagamento de fatura

> Baseado em `pg_cartoes.fatura_pagina`/`cartao_pagar`, `cartoes.fatura`, `pdf_bb.informacoes_extras`.

## Visão geral

Mudança pequena e localizada, só na camada web do cartão. Não toca no razão nem no modelo. O pagamento em si
continua por `cartoes.pagar` (transferência conta→passivo). Acrescentamos: atalhos de valor e avisos.

## Sem JavaScript (restrição da seção 9)

A CSP proíbe JS, então "clicar em Total/Mínimo preenche o campo" não pode ser feito no cliente. Duas formas
de obter o efeito no servidor:

- **Opção 1 — três botões de envio.** O formulário "Pagar" ganha três `<button name="modo" value="total|minimo|outro">`.
  No POST `cartao_pagar`, o servidor calcula o valor conforme `modo`: `total` → `fat['restante']`; `minimo` →
  mínimo da última fatura importada; `outro` → o que está no campo. Vantagem: um clique paga. Risco: o usuário
  não vê o valor antes de confirmar.
- **Opção 2 — página de confirmação.** Os botões levam a uma página de confirmação (padrão do projeto para
  ações, D2 do histórico) mostrando o valor escolhido, o aviso de rotativo se for o caso, e só então
  "Confirmar pagamento". Mais segura e coerente com o resto do app (confirmações em página). **Recomendada.**

## Fonte do mínimo

`informacoes_extras` guarda `minimo` em `extras`, persistido em `lotes_importacao.fatura_info` (JSON). O
design lê o mínimo da **última fatura importada daquele cartão**:
`SELECT fatura_info FROM lotes_importacao WHERE conta_id=? AND desfeito_em IS NULL AND fatura_info IS NOT NULL
 ORDER BY id DESC LIMIT 1`, extrai `minimo`. Se nulo/ausente → opção "Mínimo" indisponível com nota.
Exibir de qual fatura é ("mínimo da fatura de DD/MM").

## Avisos (Requisito 2)

Na página de confirmação (Opção 2):
- valor < `fat['restante']` → aviso "o restante (R$ X) entra no rotativo; juros altos", com link para
  `/simulador` ou a página de custo do crédito.
- valor > `fat['restante']` → aviso "valor acima do total em aberto (R$ Y); confira".
- valor == restante → sem aviso.

## Estratégia de testes
- `test_pagar_total_preenche_restante`: modo total → valor == `fat['restante']`.
- `test_pagar_minimo_usa_ultima_fatura`: com fatura importada que trouxe mínimo → modo mínimo usa esse valor;
  sem fatura → opção indisponível.
- `test_aviso_rotativo`: valor < total → confirmação mostra o aviso; == total → não mostra.
- `test_aviso_valor_acima_do_total`.
- Regressão: testes de `cartao_pagar`/`cartoes.pagar` existentes não quebram; e2e de pagamento continua verde.

## Pontos em aberto (decisão do usuário)
1. **Opção 1 (um clique) vs Opção 2 (confirmação).** Recomendo a 2, por segurança e coerência com o app.
2. **Mostrar o mínimo mesmo quando for de outra fatura?** Sim, mas rotulado com a data da fatura de origem,
   para não confundir.
