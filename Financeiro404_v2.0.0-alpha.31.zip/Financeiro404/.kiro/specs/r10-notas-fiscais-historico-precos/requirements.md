# R10 — Notas fiscais e histórico de preços (P1)

> Spec do item R10 da seção 8 do `PARA_O_KIRO.md`, pedido do usuário em 07/11/2026. Escopo "amplo" por
> decisão do usuário. Verifiquei no código que **hoje o app não faz nenhuma saída para a internet**
> (busca por `urllib`/`requests`/`http.client`/`urlopen` em `fin404/` não encontra chamada de rede).
>
> **Status das tarefas: não executar.** Esta é a spec mais delicada do backlog — ver "Alerta de arquitetura".

## Alerta de arquitetura e segurança (leia antes)

O Financeiro 404 é **100% local** por decisão fundadora (seção 5: "Local, só 127.0.0.1" — dados financeiros
sensíveis). A R10 **quebra essa premissa pela primeira vez**: consultar a Sefaz e baixar bases de produtos
são saídas para a internet. Isso não é uma feature comum; é uma mudança de postura de segurança. Por isso a
spec separa claramente o que é **local e seguro** do que **sai para a rede**, e trata cada saída como decisão
explícita do usuário, desligada por padrão.

Risco adicional: o escopo tem **responsáveis externos** citados (José para as notas; Claude para a base de
produtos). Esta spec define o comportamento do **software**; tarefas humanas (fotografar, transcrever, montar
catálogo) ficam fora do que o código faz e são registradas como dependências.

## Introdução

Objetivo: registrar notas fiscais de compras (sobretudo mercado) e acompanhar preço por produto ao longo do
tempo, por loja, e gasto por tipo de item. Duas fontes de dados:
1. **Notas da família** — transcritas para um CSV fixo (data, loja, CNPJ, item, quantidade, unidade, preço
   unitário, total, chave da NFC-e). Entrada **local**.
2. **Base de produtos de mercado** — catálogo local por código de barras (GTIN), importado de bases abertas
   (Open Food Facts, Open Beauty Facts, Open Products Facts; licença ODbL, **exige atribuição**). Importação
   **de arquivo baixado**, não raspagem de sites de supermercado (fora, por termos de uso).
3. (Opcional, a decidir) **Consulta à Sefaz por QR code da NFC-e** — a primeira saída para a internet.

## Requisitos

### Requisito 1 — Importar notas por CSV (local, sem internet)

**História:** Como usuário, quero importar as notas transcritas num CSV padrão, para registrar itens, preços
e lojas sem digitar um a um.

#### Critérios de aceite
1. QUANDO o usuário importar o CSV fixo (data, loja, CNPJ, item, quantidade, unidade, preço unitário, total,
   chave NFC-e), o sistema DEVE validar as colunas, conferir a trava de soma (Σ itens = total da nota) e
   gravar os itens, recusando o arquivo se a soma não bater (mesmo rigor do leitor de PDF).
2. O sistema DEVE ligar cada nota ao **lançamento correspondente** (por data, valor e cartão/conta), quando
   houver, sem duplicar a despesa.
3. A importação DEVE ser **atômica** e **desfazível**, como o pipeline de importação atual.
4. Nenhum dado real (CNPJ, chave NFC-e, nomes) pode ir para o repositório/testes (regra 7).

### Requisito 2 — Catálogo de produtos por GTIN (importado de arquivo)

**História:** Como usuário, quero um catálogo local de produtos (marca, tamanho, unidade) para agrupar
descrições diferentes do mesmo item entre lojas.

#### Critérios de aceite
1. QUANDO o usuário importar um dump de base aberta (Open Food/Beauty/Products Facts) por GTIN, o sistema DEVE
   gravar os produtos localmente, **registrando a atribuição ODbL** exigida pela licença.
2. QUANDO duas descrições diferentes referirem o mesmo produto ("LEITE INT ITALAC 1L" = "LT ITALAC INTEGRAL"),
   o sistema DEVE permitir agrupá-las no mesmo produto (manual ou assistido).
3. A importação do catálogo DEVE ser **de arquivo** (o usuário baixa o dump). Raspar sites de supermercado
   está **fora de escopo** (termos de uso). Fontes pagas (Cosmos/Bluesoft, GS1) só como opção futura.

### Requisito 3 — Histórico de preços e gasto por item

**História:** Como usuário, quero ver quanto custa cada produto ao longo do tempo e por loja, para comprar
melhor.

#### Critérios de aceite
1. O sistema DEVE mostrar o preço por produto ao longo do tempo e por loja.
2. O sistema DEVE mostrar o gasto por tipo de item.
3. Os números DEVEM vir dos itens de nota importados; onde faltar, o catálogo complementa descrição/marca.

### Requisito 4 — Consulta à Sefaz por QR code (PRIMEIRA saída para a internet — decisão do usuário)

**História:** Como usuário, quero colar o link do QR code de uma NFC-e e importar os itens automaticamente.

#### Critérios de aceite
1. Esta funcionalidade DEVE vir **desligada por padrão** e exigir ativação explícita, com aviso claro de que
   o app passará a acessar a internet (quebra da premissa 100% local).
2. QUANDO ativada e o usuário colar o link do QR code de uma NFC-e (inicialmente SP), o sistema DEVE buscar a
   nota na Sefaz e importar os itens, com a mesma trava de soma e atomicidade da importação local.
3. O acesso DEVE ser restrito ao domínio oficial da Sefaz do estado; nenhum outro host. Qualquer dado do app
   NÃO DEVE ser enviado além do estritamente necessário para a consulta (a chave/URL da própria nota).
4. Pontos a confirmar antes de implementar: **captcha** na consulta pública; **notas antigas CF-e SAT**
   (formato diferente); limites de requisição. Registrar como incerteza, não assumir.

## Fora de escopo
- Raspagem de sites de supermercado (termos de uso).
- Envio de qualquer dado financeiro para terceiros.
- Fontes pagas de catálogo nesta fase.

## Dependências humanas (não são software)
- **Envio das notas (responsável: José):** fotografar (papel térmico desbota) e transcrever para o CSV fixo.
- **Base de produtos (responsável: Claude):** montar/obter o dump por GTIN das bases abertas.
Estas tarefas ficam fora do que o código faz; são pré-condições para usar os Requisitos 1–3 com dados reais.
