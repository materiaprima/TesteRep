# R10 — Design: Notas fiscais e histórico de preços

> Baseado no pipeline de importação atual (`importacao/pipeline.py`, atômico e desfazível), em `anexos.py`
> (anexos no banco) e na constatação de que **não há saída de rede hoje** no `fin404/`.

## Visão geral

A R10 tem três camadas com níveis de risco crescentes. O design as mantém separadas para que as duas
primeiras (locais) possam ser feitas sem jamais tocar a internet, e a terceira (Sefaz) seja um módulo
isolado, desligável, auditável.

```
Camada 1 (local):    CSV de notas  → itens de nota → liga ao lançamento
Camada 2 (local):    dump GTIN     → catálogo de produtos (ODbL, atribuição)
Camada 3 (rede):     QR NFC-e      → Sefaz (desligado por padrão, host travado)
```

## Schema (migração de acréscimo — regra 4)

Tabelas novas (não reconstroem nada existente):
- `notas_fiscais(id, data, loja, cnpj, chave_nfce, total_centavos, transacao_id NULL, origem, criado_em)`.
- `itens_nota(id, nota_id, descricao, gtin NULL, quantidade, unidade, preco_unit_centavos, total_centavos,
  produto_id NULL)`.
- `produtos(id, gtin NULL, nome, marca, tamanho, unidade, fonte, atribuicao)` — catálogo.
- `produto_apelidos(produto_id, descricao_normalizada)` — para agrupar descrições diferentes.
FKs apontam **das tabelas novas para** `transacoes`/`produtos`; nenhuma FK nova aponta para `transacoes`
de forma que force reconstrução. `transacao_id` liga a nota ao lançamento sem duplicar despesa (a despesa
continua sendo a transação; a nota é um detalhamento).

## Camada 1 — CSV de notas (local)

Reaproveitar a espinha do `pipeline`: staging → validação (colunas + trava de soma Σ itens = total) →
aplicar atômico → desfazer. Ligação ao lançamento: casar por data+valor+conta (reusar `_candidatas` ou
lógica equivalente). Sem efeito no razão além do vínculo (a despesa já existe ou é criada normalmente).

## Camada 2 — Catálogo GTIN (local, de arquivo)

Importador de dump (JSON/CSV das bases abertas) → `produtos`. Guardar `fonte` e `atribuicao` (ODbL exige
crédito visível). Agrupamento de apelidos: tela para o usuário dizer "estas duas descrições são o mesmo
produto", gravando em `produto_apelidos`. Heurística de sugestão por similaridade de texto (reusar
`_assinatura`/`chave_grupo` que já existem).

## Camada 3 — Sefaz (rede; isolada e desligada por padrão)

- Módulo novo `fin404/externo/sefaz.py` — o **único** lugar do projeto que faz saída de rede. Mantê-lo
  isolado facilita auditar e testar com mock.
- **Desligado por padrão:** uma config `sefaz_habilitado` (default off). A tela de ativação explica a quebra
  da premissa local e pede confirmação.
- **Host travado:** só o domínio oficial da Sefaz do estado (lista fixa), via `https://` apenas. Timeout
  curto. Nenhum dado do app enviado além da URL/chave da própria nota.
- **Parsing** com a mesma trava de soma e atomicidade da Camada 1.
- **Incertezas a resolver antes (não assumir):** captcha na consulta pública; CF-e SAT antigo; limites de
  requisição. Se houver captcha, a automação pode ser inviável — registrar e, nesse caso, cair para entrada
  manual/CSV.
- **Testes sem rede:** mockar a resposta da Sefaz (fixture HTML/XML anonimizada); nunca bater na Sefaz real
  nos testes.

## Histórico de preços (Camada 3 de leitura, local)

Consultas sobre `itens_nota` + `produtos`: preço por produto no tempo, por loja; gasto por tipo. Gráficos em
SVG no servidor (como os demais). Sem JS.

## Estratégia de testes
- `test_csv_notas_trava_de_soma` (recusa quando Σ itens ≠ total).
- `test_nota_liga_ao_lancamento_sem_duplicar`.
- `test_importa_catalogo_gtin_com_atribuicao`.
- `test_agrupa_apelidos_de_produto`.
- `test_historico_preco_por_produto_e_loja`.
- `test_sefaz_desligada_por_padrao` e `test_sefaz_host_travado` (com mock; garante que só o domínio oficial é
  acessado e que, desligada, nenhuma rede é tocada).
- Regressão completa verde; e a suíte **não** pode ganhar nenhuma chamada de rede real.

## Pontos em aberto (decisão do usuário) — importantes
1. **A Camada 3 (Sefaz) entra agora ou fica para depois?** Recomendo **fazer 1 e 2 primeiro** (100% local,
   valor imediato) e tratar a 3 como spec própria, dado o peso de segurança. O backlog a marca como "decisão
   do usuário" de qualquer forma.
2. **Escopo "amplo" do catálogo:** baixar as três bases inteiras é muito dado. Confirmar se é catálogo
   completo ou só o que aparece nas notas da família (bem menor e suficiente no começo).
3. **Licença ODbL:** a atribuição precisa aparecer na interface onde os dados do catálogo são usados.
   Confirmar o texto de atribuição exigido.
