# R10 — Tarefas: Notas fiscais e histórico de preços

> **Status: camadas 1 e 2 feitas (alpha.17); alternativa local à camada 3 feita (alpha.18: página salva, lista NFP, foto); Sefaz automática não feita (decisão).**

- [x] 1. Schema (migração de acréscimo — regra 4)
  - [x] 1.1 Tabelas `notas_fiscais`, `itens_nota`, `produtos`, `produto_apelidos` (FKs só das novas para as
    existentes; nada que force reconstruir tabela com FK).
  - [x] 1.2 `test_migracao_notas` (sem perda de dados).

- [x] 2. Camada 1 — CSV de notas (local, Requisito 1)
  - [x] 2.1 Importador staging → validação de colunas + trava de soma → aplicar atômico → desfazer.
  - [x] 2.2 Ligar a nota ao lançamento por data+valor+conta, sem duplicar despesa.
  - [x] 2.3 `test_csv_notas_trava_de_soma`, `test_nota_liga_ao_lancamento_sem_duplicar`.

- [x] 3. Camada 2 — Catálogo GTIN (local, Requisito 2)
  - [x] 3.1 Importador de dump por GTIN → `produtos`, com `fonte`/`atribuicao` (ODbL).
  - [x] 3.2 Agrupar apelidos de produto (assistido por similaridade).
  - [x] 3.3 Atribuição ODbL visível na interface onde o catálogo aparece.
  - [x] 3.4 `test_importa_catalogo_gtin_com_atribuicao`, `test_agrupa_apelidos_de_produto`.

- [x] 4. Histórico de preços (Requisito 3)
  - [x] 4.1 Consultas: preço por produto no tempo e por loja; gasto por tipo de item.
  - [x] 4.2 Páginas/SVG no servidor, sem JS.
  - [x] 4.3 `test_historico_preco_por_produto_e_loja`.

- [x] 4b. Camada 3 sem rede (alpha.18) — o usuário abre a Sefaz/Nota Fiscal Paulista no próprio navegador e sobe o que salvou
  - [x] 4b.1 `nfce_pagina.ler_pagina`: detalhe da NFC-e salvo (leiaute padrão `txtTit/Rqtd/RUN/RvlUnit/valor/totalNumb/chave`,
    reserva por tabela com cabeçalho), mesmas travas, lote atômico. **Validar com página real.**
  - [x] 4b.2 `nfce_pagina.ler_lista`: lista de documentos da Nota Fiscal Paulista → notas sem itens (origem `lista_nfp`);
    conferência (notas sem lançamento: quantas e quanto) e "Tentar ligar de novo". **Validar com página real.**
  - [x] 4b.3 `notas.gravar_nota`: página/foto completa a nota sem itens da mesma compra (chave, ou data + CNPJ + total);
    `itens_nota.importacao_id` para desfazer só o que cada importação trouxe.
  - [x] 4b.4 `fotos_nota`: foto no banco (JPG/PNG/WEBP por assinatura, HEIC recusado com instrução, 8 MB), tela foto + formulário,
    linhas de item com 1/2/3 números, "Conferir soma", erro volta com o texto, próxima foto ao salvar.
  - [x] 4b.5 Testes: `test_notas_paginas.py` (12, páginas montadas no leiaute padrão, sem dado real) + e2e
    `test_nota_paulista_pagina_lista_e_foto`.
- [ ] 5. Camada 3 — Sefaz automática (rede) — **só se decidido; spec/subprojeto próprio recomendado** (Requisito 4)
  - [ ] 5.1 Módulo isolado `fin404/externo/sefaz.py` (único ponto de rede), host travado, `https` só.
  - [ ] 5.2 Config `sefaz_habilitado` default off + tela de ativação com aviso de quebra do 100% local.
  - [ ] 5.3 Resolver incertezas: captcha, CF-e SAT antigo, limites. Se captcha inviabilizar, cair para CSV.
  - [ ] 5.4 Parsing com trava de soma e atomicidade.
  - [ ] 5.5 `test_sefaz_desligada_por_padrao`, `test_sefaz_host_travado` (mock; nunca rede real nos testes).

- [x] 6. Regressão
  - [x] 6.1 `pytest tests` verde; nenhuma chamada de rede real na suíte.

## Decisões a confirmar antes de executar
- Sefaz (Camada 3) agora ou spec separada depois? (recomendo depois)
- Catálogo completo das bases abertas ou só o que aparece nas notas? (recomendo começar pequeno)
- Texto de atribuição ODbL exigido.

## Dependências humanas (fora do software)
- José: fotografar e transcrever as notas no CSV fixo.
- Claude: obter/montar o dump GTIN das bases abertas.

## Execução (Claude)
Camada 1: CSV fixo (`notas.COLUNAS`, modelo para baixar), travas por item e por nota, atômico, desfazível, chave repetida
pulada, liga ao lançamento por valor e data ±3 (inclusive parcelado pelo total do plano), lançar a partir da nota, tipo do item
por palavra/abreviação. Camada 2: catálogo por GTIN lido em fluxo (CLI `ferramentas/importar_catalogo.py` para o dump de
vários GB, web até 25 MB), filtro por país, atribuição ODbL gravada e exibida; agrupamento por apelido com sugestão por
semelhança (Jaccard com abreviação). Histórico: preço por produto no tempo e por loja, variação, gasto por tipo e por loja.
**Camada 3 (Sefaz) não feita de propósito:** sem uma página real de NFC-e de SP como amostra, o leitor seria adivinhação;
o projeto continua sem nenhuma saída de rede. Testes: test_notas.py (6) + e2e.

**alpha.18 — alternativa local à camada 3 (pedido do José: "preciso colocar tudo isso no app").** A Nota Fiscal Paulista não
exporta nada e o detalhe da nota exige gov.br + código por e-mail; automatizar isso quebraria o "nada sai do computador" e
dependeria de captcha. Então: o usuário abre o site no navegador dele, salva a página (Ctrl+S) e sobe no app. Três entradas
novas — página da nota (itens), lista de documentos (conferência de completude: compra com CPF na nota sem lançamento) e foto
(digitação assistida, sem OCR: cupom térmico fotografado engana OCR e a trava de soma é o que garante). A Sefaz automática
fica como decisão futura; com estas três entradas talvez não seja necessária. **Risco aberto:** os leitores foram escritos pelo
leiaute padrão da consulta de NFC-e, não por uma página real salva pelo José; a primeira importação real precisa ser conferida
(se o leitor não reconhecer, ele recusa com mensagem e nada é gravado).
