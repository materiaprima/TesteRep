# R9 — Acesso pelo celular (D — depende de decisão)

> Spec enxuta (só requirements) — classificada **D**. O backlog é explícito: só com **projeto de segurança
> próprio**. Verifiquei: hoje o servidor faz binding só em `127.0.0.1` (confirmado na revisão via `netstat`)
> e não há TLS nem sessão por dispositivo. Abrir na rede foi recusado por segurança na seção 5.
>
> **Status: não executar. Decisão do usuário + projeto de segurança antes de qualquer design.**

## Introdução

Acesso pelo celular exigiria expor o servidor além de `127.0.0.1`, o que a decisão fundadora (seção 5)
recusou. A R9 só existe com um projeto de segurança próprio. Até lá, a captura pelo celular é via "Lançar
vários" (colar texto), que já existe.

## Requisitos (rascunho — só com projeto de segurança)

### Requisito 1 — Pré-condições de segurança inegociáveis
1. QUALQUER acesso fora de `127.0.0.1` DEVE ter **TLS local**, **PIN obrigatório** e **sessão por
   dispositivo**.
2. O acesso DEVE ser restrito à rede doméstica, com autenticação, nunca exposto à internet.

### Requisito 2 — Alternativa atual (sem rede)
1. Até o projeto de segurança existir, a captura pelo celular DEVE continuar sendo o "Lançar vários" (texto
   colado), sem abrir o servidor na rede.

## Decisões que bloqueiam o design
- **Vale o risco?** A decisão da seção 5 recusou rede de casa por segurança. Reabrir isso é decisão do
  usuário, ciente do aumento de superfície de ataque.
- Se aprovado: certificado TLS local, modelo de sessão por dispositivo, bloqueio por tentativas, e um projeto
  de ameaça próprio. É um subprojeto, não uma tela.
