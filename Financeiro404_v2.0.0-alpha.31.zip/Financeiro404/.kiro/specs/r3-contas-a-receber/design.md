# R3 — Design: Contas a receber

> Baseado em `0001_razao.sql` (CHECK do `subtipo`), `razao.py` (`SUBTIPOS`, `DISPONIVEIS`, `COMPATIVEIS`,
> `criar_conta`), `0009_mais_opcoes.sql` (como o projeto contornou o CHECK antes).

## Visão geral

"A receber" é um **ativo**: o dinheiro saiu da minha conta mas é um crédito a recuperar, não um gasto.
Modela-se como **transferência** de uma conta disponível para uma conta-ativo "a receber", e a devolução é
a transferência inversa. Isso preserva "nada em dobro": não há despesa nem receita envolvidas.

## O conflito com a regra 4 (precisa de decisão)

O schema tem `subtipo TEXT NOT NULL CHECK(subtipo IN ('corrente',...,'ajuste'))`. `a_receber` **não está**
nessa lista. A regra 4 diz: *"SQLite não altera CHECK; reconstruir tabelas com chaves estrangeiras ligadas
apagaria dados em cascata"*. A migração 0009 deixou o precedente explícito: quando precisou de valores novos
numa coluna com CHECK (forma de pagamento), **criou coluna nova** em vez de alterar a existente.

Opções reais, com custo honesto:

- **Opção A — subtipo dedicado `a_receber` (ideal, mas esbarra no CHECK).** Exigiria reconstruir a tabela
  `contas` para ampliar o CHECK. `contas` tem FKs apontando para ela (`lancamentos.conta_id`, `titular_id`,
  etc.), então reconstruir é exatamente o que a regra 4 proíbe. **Rejeitada** a menos que você decida abrir
  exceção consciente (como foi a 0011).
- **Opção B — reutilizar um tipo existente + coluna marcadora (segue o precedente 0009).** Criar a conta "a
  receber" como `tipo='ativo'` usando um `subtipo` já aceito pelo CHECK (ex.: `outro` — **conferir se existe**;
  pelo schema lido, os ativos válidos são `corrente/poupanca/dinheiro/carteira/investimento/bem`, não há
  "outro" ativo). Como não há subtipo ativo genérico, esta opção precisa de uma coluna nova
  `papel TEXT` (ou `eh_a_receber INTEGER`) para marcar a conta como "a receber", mantendo o `subtipo` num
  valor já permitido. É feio, mas **respeita a regra 4** (só acréscimo de coluna).
- **Opção C — exceção consciente à regra 4 (como a 0011 foi).** A 0011 já reconstruiu `compras_planejadas`
  por ser uma tabela sem FK apontando para ela. `contas` **tem** FKs, então a reconstrução é mais arriscada;
  não recomendo. Só para registrar que existe.

**Minha recomendação:** Opção B. Adicionar, na migração **0012** (ou 0013 se a R11 pegar a 0012), uma coluna
`contas.papel TEXT` com `NULL` para contas normais e `'a_receber'` para as de crédito a recuperar. O
`subtipo` fica num valor aceito pelo CHECK; a semântica "a receber" vem de `papel`. `razao.criar_conta`,
`SUBTIPOS`/`DISPONIVEIS` e os relatórios passam a reconhecer `papel='a_receber'` como ativo fora do total de
despesas. **Esta decisão é sua** — é uma tensão real entre pureza do modelo e a regra 4.

## Fluxo (independe da opção de schema)

- **Registrar a receber:** transferência `[(a_receber, +valor, pessoa_id), (origem, -valor)]`, tipo
  `transferencia`. Não toca receita/despesa. `pessoa_id` liga ao devedor (tabela `pessoas` já existe).
- **Baixar (devolução):** transferência inversa `[(destino, +valor), (a_receber, -valor, pessoa_id)]`.
  Parcial = valor menor; o saldo da conta `a_receber` por pessoa reflete o aberto.
- **Quem deve:** `SELECT pessoa, SUM(saldo)` sobre lançamentos nas contas `papel='a_receber'`, agrupado por
  `pessoa_id`. Nova página ou bloco em Contas.

## Relatórios e Raio-X
- `a_receber` é ativo: entra no **patrimônio líquido**, mas **não** no total de despesas nem na média de
  gastos do Raio-X (confirmar que os SQLs de despesa filtram por `tipo='despesa'`, o que já fazem — visto em
  `resumo_mes`). Sem risco de dupla contagem, porque nunca é despesa.

## Estratégia de testes
- `test_migracao_papel_a_receber` (acréscimo de coluna, sem perda).
- `test_a_receber_nao_e_despesa`: registrar a receber → total de despesas do mês inalterado; PL sobe.
- `test_baixa_parcial_a_receber`: devolução parcial reduz o aberto, não vira receita.
- `test_quem_deve`: saldo por pessoa correto após vários a receber e baixas.
- Propriedade (se couber no hypothesis existente): a receber + baixa total → efeito líquido zero no PL.
- Regressão completa verde.

## Pontos em aberto (decisão do usuário)
1. **Opção de schema (A/B/C acima).** Recomendo B (coluna `papel`), que respeita a regra 4.
2. **Nome livre ou só pessoa cadastrada** para o devedor? `pessoas` já existe; nome livre exigiria criar
   pessoa na hora. Sugiro reutilizar `pessoas`.
3. **Onde mostrar "quem deve":** página própria em Contas, ou bloco no Início? Sugiro bloco discreto em Contas.
