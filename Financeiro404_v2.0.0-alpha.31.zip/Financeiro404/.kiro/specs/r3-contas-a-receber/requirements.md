# R3 — Contas a receber (P1)

> Spec do item R3 da seção 8 do `PARA_O_KIRO.md`. Baseada na leitura do schema de contas
> (`0001_razao.sql`: subtipos e tipos) e de `fin404/dominio/razao.py` (`TIPOS_TRANSACAO`, `COMPATIVEIS`).
>
> **Status das tarefas: não executar.**

## Introdução

Quando o usuário paga algo por outra pessoa, ou empresta dinheiro, hoje não há um jeito certo de registrar:
lançar como despesa infla os gastos (dinheiro que vai voltar), e lançar como transferência não deixa claro
quem deve. A R3 cria o conceito de **"a receber"** como **ativo**: o dinheiro saiu mas é um crédito a
recuperar, não um gasto.

**O que o código já tem (lido):**
- Subtipos de conta em `0001_razao.sql`: `corrente, poupanca, dinheiro, carteira, investimento, bem, cartao,
  emprestimo, outro_passivo, categoria, abertura, ajuste`. Há `emprestimo` e `outro_passivo` — mas ambos são
  **passivos** (dívidas minhas). **Não há** um subtipo para crédito a receber (ativo).
- `razao.TIPOS_TRANSACAO` e `COMPATIVEIS` definem quais tipos de conta cada transação aceita. "A receber"
  provavelmente se modela como **transferência** entre a conta de origem e uma conta-ativo "a receber", não
  como receita/despesa — preservando a regra "nada em dobro".

## Requisitos

### Requisito 1 — Registrar um valor a receber sem virar despesa

**História:** Como usuário, quando pago algo por outra pessoa ou empresto dinheiro, quero registrar o valor
como "a receber", para não contar como gasto meu e saber quem me deve.

#### Critérios de aceite
1. QUANDO o usuário registrar um valor pago por outra pessoa (ou empréstimo), o sistema DEVE lançar como
   **ativo a receber**, não como despesa — o dinheiro sai da conta de origem e vira um crédito a recuperar.
2. O lançamento DEVE permitir associar **quem deve** (uma pessoa já cadastrada, ou um nome livre) e uma
   descrição.
3. O valor a receber NÃO DEVE entrar no total de despesas dos relatórios nem do Raio-X.
4. O sistema DEVE mostrar, em algum lugar visível, **quanto cada pessoa deve** (saldo por devedor).

### Requisito 2 — Baixar o valor quando for devolvido

**História:** Como usuário, quando a pessoa me devolve, quero dar baixa no "a receber" sem que isso vire
receita.

#### Critérios de aceite
1. QUANDO o valor for devolvido, o sistema DEVE baixar o "a receber" como **transferência** (entra na conta
   que recebeu, reduz o ativo a receber), nunca como receita.
2. QUANDO a devolução for parcial, o sistema DEVE abater só o valor devolvido e manter o restante em aberto.
3. O saldo de "a receber" por pessoa DEVE refletir as baixas.

### Requisito 3 — Visão de quem deve

**História:** Como usuário, quero uma lista de quem me deve e quanto, para cobrar quando fizer sentido.

#### Critérios de aceite
1. O sistema DEVE listar os valores a receber em aberto, por pessoa/descrição, com data e valor.
2. QUANDO um valor a receber estiver em aberto há muito tempo, o sistema PODE sinalizar (sem ser intrusivo).

## Fora de escopo
- Juros sobre o valor emprestado (empréstimo formal é outra coisa; aqui é dinheiro entre conhecidos).
- Cobrança automática ou lembrete externo.

## Nota de modelagem (crítica)
"A receber" é **ativo**, não o `emprestimo`/`outro_passivo` que já existem (esses são dívidas minhas). Vai
exigir **migração de acréscimo** para um subtipo novo (ex.: `a_receber`) respeitando a regra 4 (sem
reconstruir tabela). Ver o design.
