# R3 — Tarefas: Contas a receber

> **Status: feita (alpha.15), pelo Claude.** A tarefa 1 depende da decisão de schema (ver design, pontos em aberto).

- [x] 1. Schema para "a receber" (Requisito 1) — **decisão de schema primeiro**
  - [x] 1.1 Migração de acréscimo (Opção B recomendada): `ALTER TABLE contas ADD COLUMN papel TEXT`
    (`NULL` = normal; `'a_receber'` = crédito a recuperar). Respeita a regra 4 (não altera CHECK, não
    reconstrói tabela).
  - [x] 1.2 `test_migracao_papel_a_receber` (sem perda de dados).

- [x] 2. Registrar a receber (Requisito 1)
  - [x] 2.1 Fluxo de criar conta `papel='a_receber'` (tipo ativo) e lançar como **transferência** da origem.
  - [x] 2.2 Associar o devedor (reutilizar `pessoas`) e descrição.
  - [x] 2.3 `test_a_receber_nao_e_despesa` (despesas do mês inalteradas; PL sobe).

- [x] 3. Baixar devolução (Requisito 2)
  - [x] 3.1 Transferência inversa; suportar baixa parcial.
  - [x] 3.2 `test_baixa_parcial_a_receber`.

- [x] 4. Visão de quem deve (Requisito 3)
  - [x] 4.1 Consulta de saldo a receber por pessoa.
  - [x] 4.2 Bloco/página listando valores em aberto por pessoa, com data e valor.
  - [x] 4.3 `test_quem_deve`.

- [x] 5. Relatórios / Raio-X
  - [x] 5.1 Confirmar que `a_receber` entra no PL e **não** no total de despesas nem na média do Raio-X.

- [x] 6. Regressão
  - [x] 6.1 `pytest tests` inteiro verde.

## Decisões a confirmar antes de executar
- Opção de schema A/B/C? (recomendo B, coluna `papel`)
- Devedor: só pessoa cadastrada, ou nome livre?
- "Quem deve" em página própria ou bloco em Contas?

## Execução (Claude)
Decisões: opção B confirmada pelo usuário (coluna contas.papel, migração 0013); devedor = pessoa cadastrada ou nome livre
(cria a pessoa); "quem deve" em página própria (A receber, menu Dia a dia) + bloco em Contas. Extra: converter uma despesa já
lançada (ex.: veio na fatura) em valor a receber; devoluções abatem o mais antigo primeiro (FIFO) para saber "desde quando";
alerta acima de 90 dias. Testes: tests/integracao/test_receber.py (4) + e2e.
