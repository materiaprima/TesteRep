# R8 — Orçamento base zero / envelopes (D — depende de decisão)

> Spec enxuta (só requirements) — classificada **D**. Só faz sentido se o casal quiser adotar o método
> (YNAB/Actual). Baseada no orçamento por categoria que já existe (`relatorios.py`: `orcamentos`).
>
> **Status: não executar. Decisão do usuário sobre adotar o método.**

## Introdução

O app já tem orçamento por categoria. A R8 seria o método de **envelopes / base zero** (cada real recebido é
alocado a um envelope até sobrar zero), ao estilo YNAB/Actual. É uma mudança de **fluxo de trabalho**, não só
de tela — por isso é D.

## Requisitos (rascunho — só se adotado)

### Requisito 1 — Alocar por envelope
1. QUANDO o usuário receber dinheiro, o sistema DEVE permitir alocá-lo a envelopes (categorias) até zerar o
   não alocado.
2. O sistema DEVE mostrar quanto há em cada envelope e quanto ainda não foi alocado.

### Requisito 2 — Gastar do envelope
1. QUANDO uma despesa ocorrer, ela DEVE descontar do envelope correspondente; estourar o envelope DEVE
   avisar, não bloquear.

## Decisões que bloqueiam o design
- **O casal quer mesmo o método de envelopes?** Ele convive ou substitui o orçamento por categoria atual?
- Como lidar com o dinheiro já gasto do mês ao migrar para envelopes (estado inicial).
- Risco de complexidade: envelopes exigem disciplina diária; pode conflitar com o perfil "a esposa quer só
  ver um resumo" (R13).
