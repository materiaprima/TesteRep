# R6 — Leitor de fatura de outros bancos (P2)

> Spec enxuta (só requirements) — P2. Baseada em `importacao/adaptadores/pdf_bb.py` (leitor Ourocard com
> trava de soma) e no roteamento de `pipeline.ler_arquivo`.
>
> **Status: não executar.**

## Introdução

Hoje só a fatura do Ourocard (BB) é lida em PDF. Outros bancos dependem de amostra. A R6 replica o padrão do
leitor atual (ler itens, total e datas, com **trava de soma**: saldo anterior + lançamentos = total, ou
recusa) para cada banco com amostra anonimizada.

## Requisitos

### Requisito 1 — Novo leitor por banco com amostra
1. Para cada banco com **amostra anonimizada** disponível, o sistema DEVE ler itens, total e datas de
   fechamento/vencimento da fatura em PDF.
2. O leitor DEVE ter **trava de soma** equivalente à do Ourocard: se a soma não bater, recusa o arquivo.
3. O novo leitor DEVE se encaixar no roteamento de `pipeline.ler_arquivo` sem quebrar o do Ourocard.
4. Nenhuma fatura/dado real pode ir para o repositório; os testes usam fixtures sintéticas no layout do banco
   (regra 7).

## Nota
Depende inteiramente de **amostra anonimizada** de cada banco — sem ela não há o que calibrar. OCR (PDF
digitalizado) continua fora. Priorizar os bancos que o casal usa de fato.
