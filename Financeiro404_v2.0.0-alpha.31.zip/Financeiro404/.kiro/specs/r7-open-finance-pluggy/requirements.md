# R7 — Open Finance via Meu Pluggy (D — depende de decisão)

> Spec enxuta (só requirements) — classificada **D** (decisão do usuário) no backlog. Verifiquei: o app
> **não faz nenhuma saída de rede hoje**. Este item, como a R10/Sefaz, quebraria a premissa 100% local.
>
> **Status: não executar. Decisão do usuário antes de qualquer design.**

## Introdução

Sincronização opcional de dados bancários via Open Finance (Meu Pluggy), para atacar a causa da incompletude
(R11). É uma mudança de postura de segurança: dados passam por um **terceiro**. Por isso é D, não P.

## Requisitos (rascunho — a validar com o usuário)

### Requisito 1 — Sincronização opcional e consentida
1. A sincronização DEVE vir **desligada por padrão** e exigir **consentimento explícito**, com aviso claro de
   que os dados passam por um terceiro (Pluggy) e saem do computador.
2. O sistema DEVE registrar e respeitar a validade do consentimento do Open Finance (**expira em 12 meses**).
3. QUANDO o consentimento expirar, a sincronização DEVE parar e avisar.

### Requisito 2 — Importação pelo mesmo pipeline
1. Os dados sincronizados DEVEM entrar pelo pipeline de importação existente (staging → sugestão → revisão →
   aplicar atômico → desfazer), casando com previstos/manuais sem duplicar.

## Decisões que bloqueiam o design
- **O casal aceita que dados financeiros passem por um terceiro?** (premissa fundadora diz o contrário)
- Custo/termos do Pluggy; escopo mínimo de dados; onde guardar tokens com segurança (sem senha em claro).
- Se aprovado, isolar toda a rede num módulo único (como recomendado para a Sefaz na R10) e tratar como
  subprojeto de segurança próprio.
