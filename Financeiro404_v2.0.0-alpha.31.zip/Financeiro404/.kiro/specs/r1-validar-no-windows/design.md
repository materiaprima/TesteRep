# R1 — Design: Validar no Windows

> Baseado na leitura de `fin404/dados/banco.py`, `fin404/seguranca/backup.py`, `iniciar_windows.bat` e
> `app.py` (07/11/2026). Respeita as regras da seção 9 do `PARA_O_KIRO.md`: sem JS, sem estilo inline,
> dinheiro só por `razao.registrar`, migração só por acréscimo, texto por `e()`.

## Visão geral

A R1 não muda o modelo de dados nem o servidor; endurece três pontos de contato com o Windows
(iniciador, restauração, pasta de dados) e fecha arestas de robustez. O trabalho é majoritariamente em
`iniciar_windows.bat`, `fin404/seguranca/backup.py`, um módulo novo de detecção de pasta sincronizada, o
exportador CSV e a suíte de testes.

## Componentes e mudanças

### 1. Iniciador Windows (`iniciar_windows.bat`)

**Problema atual (lido):** `set "PY=py -3"` seleciona a versão mais nova. O check de dependências é
`%PY% -c "import cryptography, pymupdf"`; se a instalação falhar, o `.bat` só imprime um aviso e **segue
para `%PY% app.py`**, abrindo o app degradado.

**Mudança proposta:**
- Selecionar interpretador preferindo versões suportadas. Estratégia: tentar `py -3.13`, depois `py -3.12`,
  `py -3.11`, `py -3.10`; só cair para `py -3` se nenhuma específica existir. Isso evita que 3.14 seja
  escolhido por padrão quando há uma versão testada instalada.
- Após o `pip install`, **reverificar** `import cryptography, pymupdf`. Se ainda falhar, NÃO seguir direto:
  exibir mensagem clara (o que ficou indisponível e por quê) e exigir confirmação explícita (`choice` ou
  `set /p`) para abrir degradado. O padrão deve ser **não abrir** degradado sem o usuário mandar.
- Trocar `pip install --user` por instalação no interpretador selecionado sem `--user` quando for um venv,
  ou manter `--user` documentando a limitação. Decisão aberta (ver "Pontos em aberto").

> A escolha de qual Python suportar oficialmente (incluir 3.14 ou não) depende do Requisito 6 (rodar a
> suíte em 3.14). O `.bat` deve refletir a decisão que sair dali.

### 2. Restauração segura (`fin404/seguranca/backup.py::ativar_restauracao`)

**Problema atual (lido):** a sequência move `-wal/-shm` para `*.antigo`, copia o recuperado para
`.restaurando` e faz `os.replace(temporario, ativo)`. O bloco `except` dessa fase só faz
`banco._pausado.clear(); raise` — **não desfaz o movimento dos `-wal/-shm`** nem restaura o `ativo` se o
`os.replace` falhar no meio. A reversão só está implementada para falha de **migração/integridade** (fase
posterior), via `shutil.copyfile(guarda, ...)`.

**Mudança proposta:**
- Extrair a reversão para uma função única `_reverter_para_guarda(ativo, guarda)` que restaura o banco **e**
  os `-wal/-shm` a partir de `*.antigo`, e chamá-la em **ambos** os blocos `except` (o da troca e o da
  migração).
- Envolver o `os.replace(temporario, ativo)` num retry curto específico do Windows (ex.: 5 tentativas com
  200 ms), porque o handle preso costuma liberar em milissegundos quando o GC do SQLite fecha a conexão do
  `wal_checkpoint`. Se esgotar, reverter e falhar com mensagem clara.
- Garantir que a conexão do `wal_checkpoint(TRUNCATE)` seja fechada de forma determinística (já está em
  `finally: c.close()` — manter e cobrir por teste).

**Mecanismos existentes a reusar (lidos em `banco.py`):** `_pausado` (Event), `aguardar_sem_conexoes(limite)`
(espera `_ativos == 0`), `_entrar`/`_sair` (contagem de conexões). O design não cria concorrência nova;
apenas endurece a reversão.

### 3. Detecção de pasta sincronizada (JÁ EXISTE — só confirmar e revisar texto)

**Estado atual (verificado no código):** `relatorios.pasta_sincronizada(pasta)` (`relatorios.py:196`) já
detecta OneDrive/Google Drive/Dropbox/iCloud/Meu Drive por segmento do caminho (case-insensitive, com
`startswith('onedrive')` para cobrir "OneDrive - Empresa"), e `relatorios.alertas()` emite o alerta. A
detecção usa `PureWindowsPath(...).parts`, então funciona mesmo rodando a análise em outro SO.

**O que fazer (não reconstruir):**
- Confirmar, no Windows real, que o alerta aparece quando a pasta de dados está sob OneDrive (o caso atual
  do projeto). Teste `test_pasta_sincronizada` cobrindo a tupla `SINCRONIZADAS` e um caminho `C:\Financeiro404`
  (deve dar `False`). **Nota:** confirmar se já existe esse teste; se não, criar.
- Revisar o **texto** do alerta para deixar explícito que o backup cifrado pode continuar na nuvem, só a
  pasta de dados ativa é que não pode.
- Considerar reforçar a detecção com as variáveis de ambiente do Windows (`%OneDrive%`,
  `%OneDriveConsumer%`, `%OneDriveCommercial%`) como complemento, para o caso de a pasta ser um link/junção
  que não tenha "OneDrive" no texto do caminho resolvido. Melhoria opcional.

### 4. CSV sem injeção de fórmula (`pg_lancamentos.lancamentos_csv`)

**Proposta:** ao escrever campos de texto (`descricao`, `observacao` e quaisquer campos livres), se o valor
começar com `=`, `+`, `-`, `@`, tab ou CR, prefixar com uma aspa simples `'` (convenção de planilha) OU com
um apóstrofo invisível documentado. A reimportação do próprio app deve remover o prefixo para não alterar o
dado. Centralizar numa função `_campo_csv_seguro(texto)` usada por todos os exportadores CSV.

### 5. Logs em vez de `except` mudo

**Proposta:** nos pontos lidos (`backup._kit_de_recuperacao` com `except OSError: pass`;
`componentes.tema()` e `executar_automatico` com `except Exception`), registrar o erro em
`data/logs` (mecanismo de log que o projeto já usa para o tratador global de erros — D9 do
`ESTADO_DA_ENTREGA.md`) sem alterar o fluxo. Estreitar `except Exception` para `(ErroBanco, sqlite3.Error)`
onde o escopo permitir.

## Estratégia de testes

Todos novos, em `tests/integracao/` e `tests/unidade/` conforme o caso:
- `test_restauracao_com_conexao_aberta`: abre uma `conexao()`, dispara restauração em thread, confirma que
  espera e conclui (ou falha limpa), e que ao final `integridade()` está `ok`.
- `test_restauracao_reverte_em_falha_de_troca`: injeta falha no `os.replace` (monkeypatch) e verifica que o
  banco **e** os `-wal/-shm` voltam ao estado anterior.
- `test_restauracao_reverte_em_falha_de_migracao`: injeta falha em `banco.migrar` e verifica reversão.
- `test_data_com_acento`: roda um ciclo (criar → registrar → backup → restaurar) com `FIN404_DATA` apontando
  para uma pasta temporária com acento e espaço no nome.
- `test_pasta_em_nuvem`: tabela de caminhos (OneDrive, Google Drive, Meu Drive, Dropbox, iCloud, caminho
  local) → serviço esperado/`None`.
- `test_csv_neutraliza_formula`: exporta lançamento com descrição `=HYPERLINK(...)` e confere o prefixo; e a
  reimportação recupera o texto original.
- Testes dirigidos de parcelamento (Requisito 5.2): antecipação mantendo a parcela do ciclo atual;
  cancelamento antes de qualquer fatura; parcela ausente que gera alerta. Reproduzem o exemplo do
  `INDICADORES.md`.

## Pontos em aberto (decisão do usuário)
1. **Python 3.14 entra na matriz de suporte?** Depende de rodar a suíte em 3.14 (Requisito 6.2). Se passar,
   o `.bat` pode aceitar 3.14; se não, deve evitá-la.
2. **`pip --user` vs venv dedicado:** criar um venv em `.venv` dentro da pasta do programa deixa a instalação
   previsível e isolada, ao custo de ~alguns segundos no primeiro boot e de espaço. Alternativa: manter
   `--user`. Recomendo venv dedicado pela previsibilidade no Windows, mas é decisão sua.
3. **Mover a pasta de dados automaticamente?** O alerta só recomenda. Oferecer um botão "mover para
   C:\Financeiro404" é mais cômodo mas mexe em caminhos em uso — eu deixaria como instrução manual nesta R1.
