# R1 — Tarefas: Validar no Windows

> **Status: feita em parte (alpha.14 e alpha.15), pelo Claude.** Lista de implementação para revisão. Cada tarefa cita o requisito que atende.
> Ordem pensada para entregar valor cedo e deixar as decisões abertas (Python 3.14, venv) para o fim.

- [x] 1. Reversão completa da restauração de backup (Requisito 2)
  - [x] 1.1 Extrair `_reverter_para_guarda(ativo, guarda)` em `fin404/seguranca/backup.py` que restaura o
    banco **e** os `-wal/-shm` a partir dos `*.antigo`.
  - [x] 1.2 Chamar `_reverter_para_guarda` no `except` da fase de troca (`os.replace`) **e** no da
    migração/integridade. Hoje só a migração reverte.
  - [x] 1.3 Envolver `os.replace(temporario, ativo)` num retry curto no Windows (5× / 200 ms) e, ao esgotar,
    reverter e levantar `ErroValidacao` com mensagem clara em pt-BR.
  - [x] 1.4 Testes: `test_restauracao_reverte_em_falha_de_troca`, `test_restauracao_reverte_em_falha_de_migracao`,
    `test_restauracao_com_conexao_aberta` (abre `conexao()`, restaura em thread, confere `integridade()==ok`).

- [x] 2. Teste de caminho com acento e espaço (Requisito 3)
  - [x] 2.1 `test_data_com_acento`: ciclo criar → registrar → backup → restaurar com `FIN404_DATA` numa pasta
    temporária com acento e espaço. Garante a invariante independente do ambiente de quem roda a suíte.

- [x] 3. Pasta sincronizada (Requisito 4) — **detecção JÁ EXISTE (`relatorios.pasta_sincronizada`); confirmar e revisar**
  - [x] 3.1 Confirmar no Windows real que o alerta dispara com a pasta de dados sob OneDrive (caso atual).
  - [x] 3.2 Revisar o texto do alerta: deixar claro que o backup cifrado pode continuar na nuvem; só a pasta
    de dados ativa é que não pode.
  - [x] 3.3 Garantir teste cobrindo a tupla `SINCRONIZADAS` e um caminho local (`C:\Financeiro404` → False);
    criar `test_pasta_sincronizada` se ainda não existir.
  - [x] 3.4 (Opcional) Complementar a detecção com `%OneDrive%`/`%OneDriveConsumer%`/`%OneDriveCommercial%`.

- [x] 4. CSV sem injeção de fórmula (Requisito 5.1)
  - [x] 4.1 `_campo_csv_seguro(texto)`: prefixa `'` se começar com `= + - @ \t \r`. Usar em todos os
    exportadores CSV (lançamentos e quaisquer outros).
  - [x] 4.2 Ajustar a reimportação para remover o prefixo, preservando o texto original.
  - [x] 4.3 Teste `test_csv_neutraliza_formula` (exporta `=HYPERLINK(...)`, confere prefixo e ida-volta).

- [x] 5. Testes dirigidos de parcelamento de fatura importada (Requisito 5.2)
  - [x] 5.1 Antecipação mantendo a parcela do ciclo atual (reproduz o exemplo do `INDICADORES.md`).
  - [x] 5.2 Cancelamento antes de qualquer fatura.
  - [x] 5.3 Parcela ausente na fatura seguinte → alerta `parcelas_ausentes`.

- [x] 6. Logs em vez de `except` mudo (Requisito 5.3)
  - [x] 6.1 Registrar erro em `data/logs` em `backup._kit_de_recuperacao` (mantendo o fluxo).
  - [x] 6.2 Estreitar `except Exception` em `componentes.tema()` e `executar_automatico` para
    `(ErroBanco, sqlite3.Error)` e logar o resto.

- [x] 7. Endurecer o iniciador (Requisito 1) — **depende da decisão sobre 3.14 (tarefa 8)**
  - [x] 7.1 Selecionar interpretador preferindo 3.13 → 3.12 → 3.11 → 3.10, caindo para `py -3` só se nenhuma
    específica existir.
  - [x] 7.2 Reverificar `import cryptography, pymupdf` após o `pip install`; se falhar, mensagem clara e
    confirmação explícita antes de abrir degradado (padrão = não abrir).
  - [x] 7.3 (condicional à decisão) trocar `--user` por venv dedicado `.venv`, ou documentar a limitação.

- [ ] 8. Evidência de validação no Windows (Requisito 6)
  - [ ] 8.1 Rodar a suíte completa no Windows numa versão suportada e registrar a saída.
  - [ ] 8.2 Rodar a suíte em Python 3.14 e registrar; decidir se 3.14 entra na matriz (alimenta a tarefa 7.1).
  - [ ] 8.3 Ajustar `.github/workflows/testes.yml` para rodar no Windows com `playwright install` garantido.

## Decisões a confirmar antes de executar
- Python 3.14 é suportado? (tarefa 8.2 decide; 7.1 depende)
- `pip --user` ou venv dedicado? (tarefa 7.3)
- Alerta de OneDrive só recomenda, ou oferece mover a pasta? (design, ponto 3 em aberto)

## Execução (Claude)
Feito: 1 (troca com novas tentativas, devolução de -wal/-shm, reversão sem WAL alheio, checkpoint conferido, mensagem clara;
5 testes), 2 (ciclo com acento e espaço), 3 (alerta revisto; OneDrive também por %OneDrive*%; testes), 4 (CSV anti-fórmula e
reimportação sem o apóstrofo), 5 (testes dirigidos já existiam; varredura de encerramento em todas as posições), 6 (InvalidTag,
log no kit e no tema com except estreito), 7 (iniciador com .venv, preferência 3.13→3.12→3.11→3.10→3.14, nova checagem e
pergunta antes de abrir sem componentes; anterior em iniciar_sem_venv.bat).
Pendente: 8 — validar o iniciador novo e a restauração no Windows real (feito em Linux; Kiro já registrou 3.12 e 3.14) e ligar
o CI num repositório GitHub (matriz Linux+Windows × 3.10/3.13/3.14 pronta).
