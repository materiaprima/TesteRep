# R1 — Validar no Windows (P0)

> Spec gerada a partir do backlog da seção 8 do `PARA_O_KIRO.md` e **enriquecida** pela revisão crítica
> de 07/11/2026 (`.agents/tasks/revisao-critica-financeiro404.md`), que rodou a suíte e o servidor no
> Windows real (Python 3.12) e identificou os pontos que faltavam cobertura.
>
> **Status das tarefas: não executar.** Esta spec descreve o que fazer; a implementação só começa após revisão do usuário.

## Introdução

O Financeiro 404 nunca rodou no Windows, que é o ambiente real do casal. Toda a validação anterior foi
em Linux. A revisão de 07/11/2026 fechou parte dessa lacuna (a suíte passou 162/162 em Python 3.12 no
Windows, o servidor subiu em 127.0.0.1:4040 com CSP estrita, e a restauração de backup funcionou no
**caminho feliz**), mas sobraram três riscos concretos que precisam virar garantia antes do uso a sério:

1. **Restauração de backup com o banco em uso.** `os.replace` no Windows falha se qualquer processo
   mantém um handle aberto para o arquivo-alvo. O caminho de reversão em falha, lido em
   `fin404/seguranca/backup.py::ativar_restauracao`, tem uma assimetria: ele recopia a guarda do banco
   quando a *migração/integridade* falha, mas **não** restaura os arquivos `-wal/-shm` já movidos para
   `.antigo` se a própria troca (`os.replace`) falhar no meio. Nenhum teste exercita conexão concorrente
   nem reversão em falha.
2. **Seleção de Python pelo iniciador.** `iniciar_windows.bat` usa `py -3`, que escolhe a versão mais
   nova instalada. Nesta máquina isso é o **Python 3.14**, nunca testado a fundo (a suíte foi validada em
   3.10, 3.12 e 3.13). Se `cryptography`/`pymupdf` não tiverem distribuição pronta para a versão escolhida,
   a instalação falha e **o app abre degradado** — sem backup cifrado e sem leitura de PDF — o que é o
   pior modo de falha silenciosa para um app de dinheiro.
3. **Pasta de dados dentro do OneDrive.** O projeto está hoje em `OneDrive\Área de Trabalho\Financeiro404`.
   SQLite em modo WAL dentro de uma pasta sincronizada é uma causa conhecida de corrupção de banco.
   A detecção **já existe e funciona** — `relatorios.pasta_sincronizada` (`relatorios.py:196`), com a tupla
   `SINCRONIZADAS = ('onedrive', 'google drive', 'googledrive', 'dropbox', 'icloud', 'meu drive', 'my drive')`,
   chamada em `relatorios.alertas()`. Ou seja, o alerta **vai disparar** no seu uso atual. O ponto que
   permanece é operacional: alerta não impede corrupção; a pasta de dados precisa sair do OneDrive de fato.

Esta spec cobre, além dos três critérios originais do backlog (iniciador, restauração, caminho com acento),
as **arestas de robustez** que a revisão apontou e que são baratas de fechar junto: injeção de fórmula no
CSV exportado, `except` largos que engolem erro no Windows, e testes dirigidos de parcelamento de fatura
importada (a área que o usuário mais teme).

## Glossário

- **Caminho feliz da restauração:** restaurar um backup sem nenhuma outra conexão viva ao banco.
- **Degradar aberto:** o app subir mesmo sem `cryptography`/`pymupdf`, perdendo backup cifrado e leitura de PDF.
- **Pasta sincronizada:** pasta sob OneDrive, Google Drive, Dropbox ou iCloud, onde o SQLite-WAL corre risco.

## Requisitos

### Requisito 1 — Iniciar num Windows limpo

**História:** Como usuário no notebook Windows, quero rodar `iniciar_windows.bat` e ter o programa no ar,
para não depender de linha de comando.

#### Critérios de aceite
1. QUANDO o usuário executar `iniciar_windows.bat` num Windows com Python 3.10+ instalado, o sistema DEVE
   instalar as dependências, subir o servidor e abrir o navegador em `http://127.0.0.1:4040` sem erro.
2. QUANDO houver mais de uma versão de Python instalada, o iniciador DEVE escolher uma versão **com suporte
   comprovado** (3.10 a 3.13) em vez de simplesmente a mais nova, OU, se só houver uma versão mais nova
   (ex.: 3.14), DEVE verificar que `cryptography` e `pymupdf` importam antes de prosseguir.
3. QUANDO a instalação de `cryptography` ou `pymupdf` falhar, o sistema NÃO DEVE abrir degradado em silêncio:
   DEVE exibir uma mensagem clara em português dizendo exatamente o que ficou indisponível (backup cifrado,
   leitura de PDF) e como resolver, e só então perguntar se o usuário quer abrir mesmo assim.
4. QUANDO o Python não for encontrado, o sistema DEVE abrir a página de download e explicar o passo
   "Add Python to PATH" (comportamento atual, a manter).

### Requisito 2 — Restauração de backup segura no Windows

**História:** Como usuário, quero restaurar um backup com o programa aberto no navegador e ter certeza de
que, se algo falhar, meu banco atual não fica corrompido.

#### Critérios de aceite
1. QUANDO a restauração ocorrer com uma conexão ao banco ainda aberta, o sistema DEVE esperar as conexões
   terminarem e então concluir a troca, OU falhar com mensagem clara em português **sem** deixar o banco
   num estado quebrado.
2. QUANDO a troca atômica (`os.replace`) falhar no meio da restauração no Windows, o sistema DEVE restaurar
   o banco anterior **e** os arquivos `-wal/-shm` correspondentes, deixando o estado idêntico ao de antes
   da tentativa.
3. QUANDO a migração ou a verificação de integridade do banco restaurado falhar, o sistema DEVE reverter
   para o banco anterior (comportamento atual) e a reversão DEVE ser coberta por teste.
4. A restauração DEVE guardar a cópia de guarda `antes_da_restauracao_*.sqlite3` antes de qualquer troca
   (comportamento atual, a manter e testar).

### Requisito 3 — Caminho com acento e espaço

**História:** Como usuário, quero que o programa funcione mesmo que a pasta tenha acento ou espaço no
caminho (como "Área de Trabalho").

#### Critérios de aceite
1. QUANDO a pasta do programa ou a pasta de dados (`FIN404_DATA`) tiver acento, espaço ou caractere não-ASCII
   no caminho, todas as operações (subir, migrar, importar, backup, restaurar) DEVEM funcionar.
2. O sistema DEVE ter um teste automatizado que force `FIN404_DATA` para um caminho com acento e espaço, para
   que a garantia não dependa do ambiente de quem roda a suíte.

### Requisito 4 — Alerta de pasta sincronizada (OneDrive) efetivo

**História:** Como usuário, quero ser avisado de forma inequívoca se a pasta de dados estiver no OneDrive,
porque isso pode corromper meu banco.

#### Critérios de aceite
1. QUANDO a pasta de dados estiver sob OneDrive/Google Drive/Dropbox/iCloud, o sistema DEVE exibir alerta
   urgente recomendando mover para um caminho local (ex.: `C:\Financeiro404`). **Já implementado** em
   `relatorios.pasta_sincronizada` + `relatorios.alertas()`; a tarefa aqui é **confirmar** que o alerta
   aparece no seu caminho atual e revisar o texto, não reconstruir a detecção.
2. O alerta DEVE deixar claro que o **backup cifrado** pode continuar na nuvem; o que não pode é a **pasta de
   dados ativa**. (Revisar o texto atual do alerta para garantir que diz isso.)
3. A documentação de primeiros passos (`PRIMEIROS_PASSOS.md`, `README.md`) DEVE instruir a instalar fora do
   OneDrive desde o início.

### Requisito 5 — Arestas de robustez (dobradas da revisão)

**História:** Como usuário, quero que as bordas apontadas na revisão sejam fechadas enquanto validamos o
Windows, para não deixar dívida acumulando.

#### Critérios de aceite
1. QUANDO o usuário exportar lançamentos em CSV (`/lancamentos.csv`) e um campo de texto (descrição,
   observação) começar com `=`, `+`, `-`, `@` ou tab, o sistema DEVE neutralizar a injeção de fórmula
   (prefixo seguro), sem alterar o valor lido de volta na reimportação.
2. O encerramento de parcelamento (antecipação/cancelamento), a detecção de parcela ausente e a geração de
   parcelas futuras pela importação DEVEM ter testes dirigidos que reproduzam o exemplo do `INDICADORES.md`
   (antecipar mantendo a parcela do ciclo atual; cancelar antes de qualquer fatura; parcela que não volta).
3. Os blocos `except OSError: pass` em `backup._kit_de_recuperacao` e os `except Exception` largos em
   `componentes.tema()`/`executar_automatico` DEVEM registrar o erro em log (sem quebrar o fluxo), para que
   uma pasta somente-leitura ou falha no Windows seja diagnosticável.

### Requisito 6 — Evidência de validação no Windows

**História:** Como dono do projeto, quero evidência registrada de que o programa roda no Windows, não só a
afirmação.

#### Critérios de aceite
1. A suíte completa (unidade, integração, propriedades, e2e) DEVE passar no Windows em pelo menos uma versão
   suportada, com a saída registrada.
2. QUANDO a máquina tiver Python 3.14 como padrão, a suíte DEVE ser rodada também em 3.14 e o resultado
   registrado, para decidir se 3.14 entra na matriz de suporte ou se o iniciador deve evitá-la.
3. O `.github/workflows/testes.yml` DEVE rodar a suíte em Windows com `playwright install` garantido, para que
   a validação não dependa de um browser já presente na máquina.

## Fora de escopo
- Reescrever o servidor ou o modelo de dados (ambos validados pela revisão).
- OFX real do BB (é a R2) e leitor de PDF de outros bancos (R6).
- Qualquer mudança que viole as regras da seção 9 do `PARA_O_KIRO.md`.
