# R5b — Comprovantes na Lixeira (P2)

> Spec enxuta (só requirements) — P2. Baseada em `anexos.py` e no `ESTADO_DA_ENTREGA.md`, que confirma:
> "Excluir o lançamento apaga os anexos (a tela avisa; eles não voltam com a Lixeira)".
>
> **Status: não executar.**

## Introdução

Hoje, excluir um lançamento com comprovante **apaga os anexos** e eles **não voltam** ao restaurar da
Lixeira (o app avisa antes). A R5b faz os comprovantes acompanharem a restauração, guardando-os pelos mesmos
90 dias.

## Requisitos

### Requisito 1 — Comprovantes voltam com a restauração
1. QUANDO um lançamento com comprovante for excluído e depois restaurado dentro de 90 dias, os comprovantes
   DEVEM voltar junto.
2. Os comprovantes excluídos DEVEM ser guardados por 90 dias (como o lançamento), não apagados na hora.
3. Passados os 90 dias, a limpeza definitiva DEVE remover também os comprovantes (sem vazar espaço).

## Nota
Anexos ficam dentro do SQLite (entram nos backups cifrados). O "soft delete" de anexos precisa conviver com
o limite de tamanho do banco; considerar junto com R5 e R12 para um só mecanismo de lixeira de anexos.
