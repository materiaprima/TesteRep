# R13 — Design: Reunião financeira do mês

> Baseado em `relatorios.resumo_mes`, `pg_relatorios` (`/resumo` imprimível), `analises` (Raio-X: reserva,
> sobra média), `compras.py` (compras grandes futuras), `pg_planejamento` (`/fechamento`), `relatorios.alertas`.

## Visão geral

A R13 é composição de dados que já existem numa página nova, mais uma pequena persistência (data + decisões
da reunião) e um lembrete. Nenhum cálculo novo de dinheiro.

## Página "Reunião do mês" (Requisito 1)

Rota `GET /reuniao?mes=YYYY-MM`, imprimível (mesmo tratamento de impressão de `/resumo`: sem menu). Monta:
- **Sobrou/faltou:** de `resumo_mes(c, ym)` (`resultado`).
- **Cobertura da reserva (meses):** do Raio-X (`analises` já calcula `cobertura_*` e reserva em meses).
- **Compras grandes dos próximos 3 meses e se cabem:** de Compras e projetos (quanto separar por mês vs sobra
  média — a lógica "cabe?" já existe na alpha.12/13).
- **Alertas importantes:** de `relatorios.alertas` (reusar, talvez filtrando por severidade).
- **2–3 decisões a tomar:** derivadas (ex.: fatura no rotativo, categoria fora do padrão, meta atrasada) ou
  em branco para preencher na reunião.

## Persistência (Requisito 2) — migração de acréscimo

- `reunioes_mes(mes TEXT PRIMARY KEY, feita_em TEXT, decisoes TEXT, criado_em)`. Uma linha por mês.
- Ao fechar o mês (`/fechamento`), oferecer link para `/reuniao?mes=...`; na página, um formulário grava
  `feita_em` (hoje) e `decisoes` (texto livre, passado por `e()` ao exibir).

## Lembrete (Requisito 3)

Em `relatorios.alertas`: se hoje > dia 10 e não existe `reunioes_mes` para o mês anterior, item
`('conferir', 'Faça a reunião de <mês anterior>.', '/reuniao?mes=<ant>')`. Some quando a linha existir.

## Estratégia de testes
- `test_reuniao_monta_pagina` (campos presentes a partir de dados semeados).
- `test_registra_reuniao` (grava data + decisões; histórico consultável).
- `test_lembrete_dia_10` (dia 11 sem reunião → lembra; após registrar → não lembra).
- `test_reuniao_imprimivel_sem_menu` (e2e: página sem menu, sem violação de CSP).
- Regressão completa verde.

## Pontos em aberto (decisão do usuário)
1. **As "2–3 decisões" são sugeridas pelo sistema, em branco, ou as duas coisas?** Sugiro sugerir candidatas
   (rotativo, meta atrasada) e deixar editar.
2. **A página é só do mês fechado ou de qualquer mês?** Sugiro qualquer mês, com destaque para o último
   fechado.
