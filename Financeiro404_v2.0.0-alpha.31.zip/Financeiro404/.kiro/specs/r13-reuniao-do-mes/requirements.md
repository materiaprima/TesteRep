# R13 — Reunião financeira do mês (P1)

> Spec do item R13 da seção 8 do `PARA_O_KIRO.md`, registrado em 07/11/2026. Baseada na leitura de
> `fin404/dominio/relatorios.py` (`resumo_mes`), `fin404/web/pg_relatorios.py` (`/resumo` imprimível) e
> `fin404/web/pg_planejamento.py` (`/fechamento`).
>
> **Status das tarefas: não executar.**

## Introdução

A esposa quer "ter controle" sem operar o sistema. A R13 entrega isso: uma página de reunião mensal, curta
(15 minutos), imprimível, com o essencial para decidir. O app já tem `/resumo` (uma página imprimível com
entrou/saiu/sobrou, situação de hoje, faturas e alertas) e `resumo_mes`. A R13 **estende** essa base com o
que a reunião precisa: cobertura da reserva, compras grandes dos próximos 3 meses e se cabem, e um espaço
para registrar as decisões.

## Requisitos

### Requisito 1 — Página "Reunião do mês" (imprimível)

**História:** Como casal, queremos uma página curta para a reunião mensal, com o que importa para decidir.

#### Critérios de aceite
1. O sistema DEVE ter uma página "Reunião do mês" (imprimível, sem menu, como `/resumo`) contendo:
   - sobrou ou faltou no mês;
   - quanto a reserva cobre (em meses);
   - compras grandes dos próximos 3 meses e se cabem na sobra média;
   - alertas importantes;
   - 2 ou 3 decisões a tomar.
2. A página DEVE usar os cálculos existentes (`resumo_mes`, Raio-X, Compras e projetos), sem segundo caminho.

### Requisito 2 — Registrar a reunião

**História:** Como usuário, quero registrar que a reunião aconteceu e o que decidimos, para consultar depois.

#### Critérios de aceite
1. QUANDO o mês for fechado, o sistema DEVE oferecer a página da reunião.
2. O sistema DEVE registrar a **data** em que a reunião aconteceu e as **decisões** (texto livre), por mês.
3. As reuniões registradas DEVEM ficar consultáveis depois (histórico por mês).

### Requisito 3 — Lembrete

**História:** Como usuário, quero ser lembrado se passou do dia 10 sem a reunião do mês anterior.

#### Critérios de aceite
1. QUANDO passar o **dia 10** sem a reunião do mês anterior registrada, o Início DEVE lembrar.
2. O lembrete DEVE sumir quando a reunião for registrada.

## Fora de escopo
- Qualquer automação de decisão; a reunião é humana, o app só organiza e registra.
