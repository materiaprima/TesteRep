# R13 — Tarefas: Reunião financeira do mês

> **Status: feita (alpha.15), pelo Claude.**

- [x] 1. Schema (migração de acréscimo — regra 4)
  - [x] 1.1 Tabela `reunioes_mes(mes, feita_em, decisoes, criado_em)`.
  - [x] 1.2 `test_migracao_reunioes`.

- [x] 2. Página "Reunião do mês" (Requisito 1)
  - [x] 2.1 Rota `GET /reuniao?mes=` imprimível (sem menu), compondo: sobrou/faltou (`resumo_mes`), cobertura
    da reserva (Raio-X), compras grandes dos próximos 3 meses e se cabem (Compras e projetos), alertas,
    decisões.
  - [x] 2.2 `test_reuniao_monta_pagina`, `test_reuniao_imprimivel_sem_menu` (e2e, sem CSP violada).

- [x] 3. Registrar a reunião (Requisito 2)
  - [x] 3.1 Formulário que grava `feita_em` + `decisoes` (texto por `e()` ao exibir).
  - [x] 3.2 Link da reunião oferecido ao fechar o mês.
  - [x] 3.3 Histórico consultável por mês.
  - [x] 3.4 `test_registra_reuniao`.

- [x] 4. Lembrete (Requisito 3)
  - [x] 4.1 Em `relatorios.alertas`: após o dia 10 sem reunião do mês anterior → lembrete; some ao registrar.
  - [x] 4.2 `test_lembrete_dia_10`.

- [x] 5. Regressão
  - [x] 5.1 `pytest tests` verde.

## Decisões a confirmar antes de executar
- As "2–3 decisões" são sugeridas, em branco, ou ambos?
- Página só do mês fechado ou de qualquer mês?

## Execução (Claude)
Decisões: sugestões do sistema pré-preenchidas e editáveis; qualquer mês (abas dos últimos 6). Migração 0014 (reunioes_mes).
Lembrete a partir do dia 10 só se o mês anterior teve lançamentos. Testes: tests/integracao/test_reuniao.py + e2e.
